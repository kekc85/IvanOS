/**
 * Instrumentation
 *
 * Next.js calls `register()` exactly once when a server instance starts, in
 * both the Node.js and Edge runtimes, before any request is served. It is
 * the right place to fail loudly on a half-filled .env: validateCoreEnv()
 * throws a message naming every missing or invalid variable, instead of the
 * app booting cleanly and then crashing later, mid-request, on whichever
 * variable that request happened to touch first.
 *
 * The Edge runtime never sees this app's server-only env vars (DATABASE_URL
 * etc. are not available there), so the check only runs for Node.js.
 */
export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const { validateCoreEnv } = await import("@/lib/env");
    validateCoreEnv();
  }
}
