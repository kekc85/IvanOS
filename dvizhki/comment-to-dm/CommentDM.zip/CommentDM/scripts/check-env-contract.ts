/**
 * Settings-contract check for `npm run update` (phase 13, step 4).
 *
 * Compares the variable names in .env.example against the ones in .env.
 * Missing variables that the app actually requires at startup
 * (serverEnvSchema, lib/env.ts) are a hard stop: printed, then exit 1, so
 * scripts/update.sh halts before running migrations against a config the
 * app can't even boot with. Missing variables that are merely documented in
 * .env.example but optional are printed as an FYI and do not block.
 *
 * Usage: tsx scripts/check-env-contract.ts [envExamplePath] [envPath]
 * Defaults to .env.example / .env in the current working directory.
 */
import { readFileSync } from "node:fs";
import path from "node:path";
import { diffEnvContract } from "@/lib/env-contract";

function main() {
  const exampleArg = process.argv[2];
  const envArg = process.argv[3];

  const examplePath = exampleArg
    ? path.resolve(exampleArg)
    : path.join(process.cwd(), ".env.example");
  const envPath = envArg ? path.resolve(envArg) : path.join(process.cwd(), ".env");

  let exampleContent: string;
  try {
    exampleContent = readFileSync(examplePath, "utf8");
  } catch {
    console.error(`❌ Не найден ${examplePath} — сверку настроек делать не с чем.`);
    process.exitCode = 1;
    return;
  }

  let envContent: string;
  try {
    envContent = readFileSync(envPath, "utf8");
  } catch {
    console.error(`❌ Не найден ${envPath}.`);
    console.error(
      "   Обновление остановлено до миграций: без .env приложение не запустится."
    );
    console.error(
      `   Скопируй ${path.basename(examplePath)} в ${path.basename(envPath)} и заполни секреты, затем запусти npm run update ещё раз.`
    );
    process.exitCode = 1;
    return;
  }

  const { missingRequired, missingOptional } = diffEnvContract(
    exampleContent,
    envContent
  );

  if (missingRequired.length === 0 && missingOptional.length === 0) {
    console.log("✅ Контракт настроек в порядке: все переменные из .env.example есть в .env.");
    process.exitCode = 0;
    return;
  }

  if (missingOptional.length > 0) {
    console.log(
      "ℹ️  Необязательных переменных нет в .env (можно добавить позже, у них есть безопасные умолчания):"
    );
    for (const key of missingOptional) console.log(`   - ${key}`);
  }

  if (missingRequired.length > 0) {
    console.error("");
    console.error(
      "❌ Обновление остановлено до миграций: в .env не хватает обязательных переменных."
    );
    console.error(
      "   Новая версия добавила их, а в текущем .env их ещё нет — приложение не запустится:"
    );
    for (const key of missingRequired) console.error(`   - ${key}`);
    console.error("");
    console.error(
      `   Посмотри в ${path.basename(examplePath)}, что туда писать, добавь недостающие ключи в ${path.basename(envPath)}`
    );
    console.error("   и запусти npm run update ещё раз.");
    process.exitCode = 1;
    return;
  }

  process.exitCode = 0;
}

main();
