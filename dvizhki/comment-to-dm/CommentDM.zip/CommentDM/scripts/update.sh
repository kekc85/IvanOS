#!/usr/bin/env bash
#
# commentdm — update to the latest release: `npm run update`.
#
# Run from inside an installed repository (e.g. /opt/commentdm) as root —
# same expectation as install.sh, because the last two steps rewrite systemd
# units in /etc/systemd/system and restart both services.
#
# What it does, in order (each a numbered step below):
#   1. Dumps the database — before touching anything else. Without this dump
#      `npm run rollback` has nothing to restore to.
#   2. `git pull`. A student's Claude Code may have edited files in this
#      repo; if that collides with what this update brings in, git reports a
#      merge conflict. That is expected here, not a crash — see step 2 below
#      for exactly what happens and why nothing is discarded.
#   3. `npm ci` + `next build` with the same memory-limit heuristic
#      install.sh uses.
#   4. Settings-contract check: compares .env.example's variable names
#      against .env's. A variable the new code requires that isn't in this
#      .env yet is a hard stop, before migrations — see
#      scripts/check-env-contract.ts / lib/env-contract.ts for why.
#   5. `prisma migrate deploy`.
#   6. Reinstalls the systemd units from deploy/ (their content ships with
#      the code, same as install.sh) and restarts both services.
#   7. `npm run doctor`, for a final answer on whether the updated install is
#      healthy.
#
# Log: /var/log/commentdm-update.log
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# shellcheck source=deploy/lib.sh
source "$INSTALL_DIR/deploy/lib.sh"

APP_USER="commentdm"
ENV_FILE="$INSTALL_DIR/.env"
LOG_FILE="/var/log/commentdm-update.log"
STATE_FILE="$INSTALL_DIR/.commentdm-update-state"

trap 'on_unexpected_error $LINENO "$0"' ERR

require_env_file() {
  if [ ! -f "$ENV_FILE" ]; then
    fail "Не найден $ENV_FILE." "Это не похоже на установленный commentdm — запусти install.sh сначала."
  fi
}

# Разбор .env вместо его ИСПОЛНЕНИЯ через точку. .env принадлежит
# пользователю приложения, а этот скрипт работает из-под root: любая запись
# со стороны приложения превращалась бы в команду от root. Плюс легальное
# значение с пробелом (LEGAL_ENTITY_NAME=ООО Ромашка) точка разбирала как
# «присвоение и запуск команды Ромашка». Реализация — deploy/lib.sh.
load_env() {
  load_env_file "$ENV_FILE"
}

# ---------------------------------------------------------------------------
# Шаг 1: дамп базы данных, до всего остального.
# ---------------------------------------------------------------------------
dump_database() {
  step "1/7 Дамп базы данных"
  bash "$INSTALL_DIR/deploy/backup.sh"
  DUMP_PATH="$(find "$INSTALL_DIR/backups" -maxdepth 1 -name 'commentdm-*.sql.gz' -print0 \
    | xargs -0 ls -t 2>/dev/null | head -1)"
  if [ -z "$DUMP_PATH" ]; then
    fail "Дамп не создался." "deploy/backup.sh отработал без ошибки, но файла в $INSTALL_DIR/backups нет — обновление остановлено, чтобы не остаться без дампа для отката."
  fi
  ok "Дамп сохранён: $DUMP_PATH"
}

# ---------------------------------------------------------------------------
# Шаг 2: git pull. Ученик мог править код через Claude Code — это ожидаемая
# ситуация, обрабатывается явно, а не падением.
#
# Порядок: если в рабочем дереве есть незакоммиченные правки, они СНАЧАЛА
# коммитятся во временный коммит (ничего не теряется, не откладывается на
# "потом стешить и забыть"), только после этого делается git fetch + merge.
# Если merge конфликтует — своими же правками ученика с тем, что меняет эта
# версия, — обновление останавливается, конфликтующие файлы называются
# поимённо, и предлагается решение. npm ci/build/миграции после этого не
# запускаются: середина слияния — не то состояние, которое можно собирать
# или накатывать в базу.
# ---------------------------------------------------------------------------
git_pull_with_conflict_handling() {
  step "2/7 Обновляю код (git pull)"
  cd "$INSTALL_DIR"

  if [ ! -d .git ]; then
    fail "$INSTALL_DIR — не git-репозиторий." "Обновление через npm run update работает только для установки, сделанной install.sh (git clone). Обнови код вручную."
  fi

  PREVIOUS_COMMIT="$(git rev-parse HEAD)"

  if [ -n "$(git status --porcelain --untracked-files=all)" ]; then
    warn "В коде есть несохранённые правки (скорее всего — твои или Claude Code)."
    info "   Сохраняю их отдельным коммитом, прежде чем тянуть обновление — ничего не потеряется."
    git add -A
    # -c user.*: a fresh VPS root account usually has no git identity
    # configured at all — this commit must not depend on that being set up.
    git -c user.email="commentdm-update@localhost" -c user.name="commentdm update" \
      commit -q -m "WIP: локальные правки перед обновлением $(date -u +%Y-%m-%dT%H:%M:%SZ)"
    ok "Правки сохранены коммитом $(git rev-parse --short HEAD)"
  fi

  local branch
  branch="$(git rev-parse --abbrev-ref HEAD)"
  if [ "$branch" = "HEAD" ]; then
    fail "Репозиторий сейчас в состоянии detached HEAD (не на ветке)." "Скорее всего это следствие незавершённого прошлого отката. Выполни: git checkout main — и запусти npm run update ещё раз."
  fi

  info "   git fetch origin $branch"
  git fetch origin "$branch"

  if git -c user.email="commentdm-update@localhost" -c user.name="commentdm update" \
    merge --no-edit "origin/$branch" > /tmp/commentdm-update-merge.log 2>&1; then
    ok "Код обновлён: $(git rev-parse --short HEAD) ($branch)"
    rm -f /tmp/commentdm-update-merge.log
    return
  fi

  # Merge не прошёл чисто. Разбираемся, конфликт это или что-то другое.
  local conflicted
  conflicted="$(git diff --name-only --diff-filter=U || true)"

  if [ -z "$conflicted" ]; then
    # Слияние упало не на конфликте (например, локальный коммит переписывает
    # историю, которую fetch уже не может слить). Показываем git-у сказанное
    # и останавливаемся, ничего не отменяя самостоятельно.
    err "git merge не прошёл, и это не обычный конфликт файлов."
    cat /tmp/commentdm-update-merge.log >&2 || true
    info "   Ничего не откачено: код остался в промежуточном состоянии слияния."
    info "   Разберись вручную (git status) или отмени слияние: git merge --abort"
    clean_exit 3
  fi

  echo ""
  err "Обновление остановлено: твои правки конфликтуют с новой версией."
  info "   Это нормальная ситуация, а не поломка — Claude Code (или ты сам) менял"
  info "   те же файлы, что поменяла эта версия. Твоя работа НЕ затёрта, она лежит"
  info "   в коммите $(git rev-parse --short "$PREVIOUS_COMMIT")..HEAD и в рабочем дереве прямо сейчас, со"
  info "   стандартными метками конфликта git внутри файлов."
  echo ""
  info "   Файлы с конфликтом:"
  while IFS= read -r f; do
    [ -n "$f" ] && info "     - $f"
  done <<< "$conflicted"
  echo ""
  info "   Что сделать дальше — выбери одно:"
  info "   1) Попроси Claude Code в этой папке разрешить конфликты (в файлах выше"
  info "      сейчас есть строки <<<<<<<, =======, >>>>>>>), затем:"
  info "        git add -A && git commit"
  info "      и запусти npm run update ещё раз."
  info "   2) Передумал — отменить слияние и остаться на прежней версии:"
  info "        git merge --abort"
  echo ""
  rm -f /tmp/commentdm-update-merge.log
  clean_exit 2
}

# ---------------------------------------------------------------------------
# Шаг 3: npm ci + сборка (deploy/lib.sh::build_app_in)
# ---------------------------------------------------------------------------
build_step() {
  step "3/7 Ставлю зависимости и собираю"
  build_app_in "$INSTALL_DIR"
}

# ---------------------------------------------------------------------------
# Шаг 4: сверка контракта настроек — до миграций.
# ---------------------------------------------------------------------------
check_env_contract() {
  step "4/7 Сверяю контракт настроек (.env.example ↔ .env)"
  cd "$INSTALL_DIR"
  if ! npx tsx scripts/check-env-contract.ts; then
    fail "Обновление остановлено до миграций (см. недостающие переменные выше)." \
      "База данных и systemd-юниты этим запуском не тронуты — можно чинить .env без спешки."
  fi
}

# ---------------------------------------------------------------------------
# Шаг 5: миграции.
# ---------------------------------------------------------------------------
run_migrations() {
  step "5/7 Накатываю миграции базы данных"
  cd "$INSTALL_DIR"
  npx prisma migrate deploy
  ok "Миграции применены"
}

# ---------------------------------------------------------------------------
# Шаг 6: systemd-юниты + рестарт обоих сервисов.
# ---------------------------------------------------------------------------
reinstall_units_and_restart() {
  step "6/7 Переустанавливаю systemd-юниты и перезапускаю сервисы"
  install_systemd_units_from "$INSTALL_DIR" "$APP_USER"

  chown -R "${APP_USER}:${APP_USER}" "$INSTALL_DIR"

  systemctl restart commentdm.service
  systemctl restart commentdm-worker.service
  sleep 5

  if systemctl is-active --quiet commentdm.service; then
    ok "commentdm.service перезапущен"
  else
    warn "commentdm.service не поднялся — journalctl -u commentdm -n 50"
  fi
  if systemctl is-active --quiet commentdm-worker.service; then
    ok "commentdm-worker.service перезапущен"
  else
    warn "commentdm-worker.service не поднялся — journalctl -u commentdm-worker -n 50"
  fi
}

# ---------------------------------------------------------------------------
# Шаг 7: doctor.
# ---------------------------------------------------------------------------
run_doctor() {
  step "7/7 npm run doctor"
  cd "$INSTALL_DIR"
  sudo -u "$APP_USER" --preserve-env=PATH npm run doctor || \
    warn "doctor нашёл проблемы (вывод выше) — обновление всё равно завершено, почини по подсказкам doctor."
}

save_state() {
  {
    echo "PREVIOUS_COMMIT=$PREVIOUS_COMMIT"
    echo "DUMP_PATH=$DUMP_PATH"
    echo "UPDATED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    echo "NEW_COMMIT=$(git -C "$INSTALL_DIR" rev-parse HEAD)"
  } > "$STATE_FILE"
}

print_summary() {
  echo
  echo "################################################################################"
  echo "#   commentdm обновлён"
  echo "#"
  echo "#   Было:  $PREVIOUS_COMMIT"
  echo "#   Стало: $(git -C "$INSTALL_DIR" rev-parse HEAD)"
  echo "#"
  echo "#   Дамп базы до обновления: $DUMP_PATH"
  echo "#   Если что-то сломалось — откат одной командой:"
  echo "#     cd $INSTALL_DIR && npm run rollback"
  echo "################################################################################"
  echo
}

main() {
  require_root "npm run update (из $INSTALL_DIR)"
  require_env_file
  setup_logging "$LOG_FILE"
  load_env

  dump_database
  git_pull_with_conflict_handling
  build_step
  check_env_contract
  run_migrations
  reinstall_units_and_restart
  save_state
  run_doctor
  print_summary
}

main "$@"
