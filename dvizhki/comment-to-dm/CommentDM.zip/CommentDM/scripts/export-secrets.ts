/**
 * Prints what has to travel with you to a new server: `npm run export-secrets`.
 *
 * A machine migration usually goes: restore the database dump on the new
 * box, point DNS at it, done. The one thing that silently breaks that path
 * here is ENCRYPTION_KEY — every InstagramAccount.accessToken in the dump
 * was encrypted with the OLD server's key, and install.sh always generates
 * a brand-new random one on a fresh install (env_set_if_absent only
 * protects an *existing* key from being overwritten — on an empty .env
 * there is nothing to protect). Restore the dump under a different key and
 * every connected account fails to decrypt, with no obvious error pointing
 * at "the key" (see lib/doctor/checks/tokens.ts — that check is what would
 * eventually surface it, after the fact).
 *
 * This prints the three things a migration needs to carry across by hand,
 * plus the exact command sequence, so the order (key → dump → doctor) that
 * avoids the trap above is not something the operator has to reconstruct
 * from scratch:
 *
 *   - ENCRYPTION_KEY   — must be handed to `install.sh --restore
 *                        --encryption-key=...` on the new server BEFORE the
 *                        database dump is restored.
 *   - SESSION_SECRET   — not carrying it over is not a data-loss risk (worst
 *                        case: everyone has to log in again, and any
 *                        in-flight OAuth connect attempt has to restart),
 *                        but reusing it means logged-in sessions keep
 *                        working straight through the move.
 *   - owner passwordHash — informational. If OWNER_PASSWORD is left blank
 *                        on the new install (the default under
 *                        install.sh --restore — see there for why), the
 *                        restored database's own passwordHash keeps working
 *                        untouched and this value never actually needs to
 *                        be typed anywhere. It is printed anyway, with the
 *                        exact manual SQL to reapply it, as a fallback for
 *                        a partial migration that does not restore the full
 *                        dump.
 *
 * Usage: npm run export-secrets
 */
import { prisma } from "@/lib/db/client";
import { getEncryptionKeyHex, getSessionSecret } from "@/lib/env";

async function main() {
  let encryptionKey: string;
  let sessionSecret: string;
  try {
    encryptionKey = getEncryptionKeyHex();
    sessionSecret = getSessionSecret();
  } catch (error) {
    console.error("❌ Не удалось прочитать секреты из .env:");
    console.error(`   ${error instanceof Error ? error.message : String(error)}`);
    process.exitCode = 1;
    return;
  }

  const owner = await prisma.user.findFirst({
    orderBy: { createdAt: "asc" },
    select: { email: true, passwordHash: true },
  });

  const lines = [
    "",
    "─".repeat(78),
    "  commentdm — секреты для переезда на другой сервер",
    "",
    "  Это настоящие секреты. Не вставляй их в чат, тикет поддержки или",
    "  публичный репозиторий — только напрямую в .env нового сервера.",
    "",
    `  ENCRYPTION_KEY:  ${encryptionKey}`,
    `  SESSION_SECRET:  ${sessionSecret}`,
    "",
  ];

  if (owner) {
    lines.push(
      `  Владелец:        ${owner.email ?? "(без email)"}`,
      `  passwordHash:    ${owner.passwordHash ?? "(не задан)"}`,
      ""
    );
  } else {
    lines.push(
      "  Владелец:        в базе ещё нет строки User (свежая установка,",
      "                   бутстрап-пароль ни разу не создавался).",
      ""
    );
  }

  lines.push(
    "─".repeat(78),
    "",
    "  Порядок переезда (важен — в другом порядке ENCRYPTION_KEY может",
    "  провалить расшифровку токенов Instagram молча):",
    "",
    "  1. На НОВОМ сервере, ещё ДО восстановления дампа базы:",
    "       sudo bash install.sh --restore <домен> \\",
    `         --encryption-key=${encryptionKey} \\`,
    `         --session-secret=${sessionSecret}`,
    "     Пароль владельца (--owner-password) не задавай — тогда .env",
    "     останется без OWNER_PASSWORD, и после восстановления дампа сработает",
    "     старый пароль (его хеш живёт в самой базе, приезжает вместе с",
    "     дампом). Если задать --owner-password, он молча заменит собой",
    "     мигрировавший пароль.",
    "",
    "  2. Перенеси файл дампа (deploy/backup.sh кладёт их в backups/ на",
    "     старом сервере) на новый и восстанови им базу:",
    "       set -a; . .env; set +a",
    "       bash deploy/restore-db.sh <файл-дампа.sql.gz>",
    "",
    "  3. Проверь, что переезд получился:",
    "       npm run doctor",
    "     Если ENCRYPTION_KEY не совпал — doctor покажет это отдельным",
    "     кодом ошибки (отпечаток ключа не совпадает с тем, что видел",
    "     фоновый процесс), а не тихо промолчит.",
    "",
    "  Если решил переносить не через полный дамп базы, а восстанавливать",
    "  пароль владельца вручную — сырое значение passwordHash выше можно",
    "  вставить так (замени <email>):",
    "",
    owner
      ? `    UPDATE "User" SET "passwordHash" = '${owner.passwordHash}' WHERE email = '${owner.email}';`
      : "    (строки User ещё нет — этот шаг не нужен)",
    "─".repeat(78),
    ""
  );

  console.log(lines.join("\n"));
}

main()
  .catch((error) => {
    console.error("export-secrets упал:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
