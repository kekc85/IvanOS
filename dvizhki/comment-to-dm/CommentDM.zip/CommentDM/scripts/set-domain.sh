#!/usr/bin/env bash
#
# commentdm — move to a new domain: `npm run set-domain -- новый.домен`.
#
# What it does:
#   1. Points APP_URL (.env) and /etc/caddy/Caddyfile at the new domain.
#   2. Restarts commentdm + commentdm-worker (APP_URL is only read at
#      process start — a Caddy reload alone would not pick it up) and
#      reloads Caddy, which requests/renews the HTTPS certificate for the
#      new domain itself.
#   3. Prints a memo of the two things this script cannot do for you:
#      the Meta OAuth redirect URI has to be updated by hand in the Meta
#      developer console, and any /r/<slug> tracked link already sent out in
#      a DM on the old domain stops working the moment that domain no
#      longer points here.
#
# Usage:
#   npm run set-domain -- <домен> [--skip-dns-check]
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# shellcheck source=deploy/lib.sh
source "$INSTALL_DIR/deploy/lib.sh"

ENV_FILE="$INSTALL_DIR/.env"
LOG_FILE="/var/log/commentdm-set-domain.log"
# Overridable so the test suite can point this at a throwaway file instead
# of the real system Caddy config — same idea as DATABASE_URL being
# overridable, not a behavior change for a real install (default is the
# exact path install.sh itself writes to).
CADDY_CONFIG_PATH="${CADDY_CONFIG_PATH:-/etc/caddy/Caddyfile}"

NEW_DOMAIN=""
SKIP_DNS_CHECK=0

trap 'on_unexpected_error $LINENO "$0"' ERR

usage() {
  cat <<'USAGE'
Использование: npm run set-domain -- <домен> [--skip-dns-check]

  <домен>              Новый домен или поддомен. Его A-запись должна уже
                        указывать на IP этого сервера (иначе HTTPS-сертификат
                        не выпустится).
  --skip-dns-check      Пропустить проверку DNS (например, домен только что
                        добавлен и A-запись ещё не распространилась).

Пример:
  npm run set-domain -- bot.newdomain.com
USAGE
}

parse_args() {
  while [ $# -gt 0 ]; do
    case "$1" in
      --skip-dns-check) SKIP_DNS_CHECK=1 ;;
      -h|--help) usage; clean_exit 0 ;;
      -*)
        err "Неизвестный флаг: $1"
        usage
        clean_exit 1
        ;;
      *)
        if [ -z "$NEW_DOMAIN" ]; then
          NEW_DOMAIN="$1"
        else
          err "Лишний аргумент: $1"
          usage
          clean_exit 1
        fi
        ;;
    esac
    shift
  done

  if [ -z "$NEW_DOMAIN" ]; then
    err "Домен не указан."
    usage
    clean_exit 1
  fi

  # То же, что делает install.sh: сначала приводим к голому имени хоста,
  # потом проверяем. Без этого https:// в аргументе уезжало в APP_URL
  # дважды, а символ | ломал sed-подстановку в Caddyfile.
  local normalized
  normalized="$(normalize_domain "$NEW_DOMAIN")"
  if [ "$normalized" != "$NEW_DOMAIN" ]; then
    info "Домен приведён к виду: $normalized (было: $NEW_DOMAIN)"
    NEW_DOMAIN="$normalized"
  fi
  if ! validate_domain "$NEW_DOMAIN"; then
    err "«${NEW_DOMAIN}» не похоже на доменное имя."
    info "   Нужен домен или поддомен вида bot.example.com — латиница, цифры и дефисы,"
    info "   минимум одна точка, без порта, пробелов и спецсимволов."
    clean_exit 1
  fi
}

require_env_file() {
  if [ ! -f "$ENV_FILE" ]; then
    fail "Не найден $ENV_FILE." "Это не похоже на установленный commentdm."
  fi
}

get_old_domain() {
  local old_url
  old_url="$(env_get "$ENV_FILE" APP_URL)"
  # Strip scheme and any trailing path/slash.
  printf '%s' "$old_url" | sed -E 's#^https?://##; s#/.*$##'
}

check_dns() {
  if [ "$SKIP_DNS_CHECK" -eq 1 ]; then
    warn "Проверка DNS пропущена (--skip-dns-check). HTTPS не выпустится, пока A-запись не будет указывать сюда."
    return
  fi
  step "Проверяю DNS для $NEW_DOMAIN"
  if ! command -v curl >/dev/null 2>&1; then
    warn "curl не найден — проверку DNS пропускаю."
    return
  fi
  if ! check_domain_dns_matches "$NEW_DOMAIN"; then
    fail "Домен $NEW_DOMAIN ещё не указывает на этот сервер." \
      "Добавь/поправь A-запись у регистратора и подожди её распространения, либо запусти с --skip-dns-check, если точно уверен в DNS."
  fi
}

update_env_and_caddy() {
  step "Переключаю APP_URL и Caddy на https://$NEW_DOMAIN"
  # Владелец и режим .env восстанавливаются внутри самой env_set (см.
  # deploy/lib.sh::env_write_key) — раньше этот скрипт, в отличие от
  # update.sh и rollback.sh, chown обратно не делал, и .env уходил к root.
  # Веб при этом выживал (systemd читает от root), а воркер, который tsx
  # запускает от пользователя приложения, уходил в вечный рестарт: сайт
  # открыт, сообщения не уходят вообще.
  env_set "$ENV_FILE" APP_URL "https://$NEW_DOMAIN"
  ok "APP_URL обновлён в $ENV_FILE"

  render_template "$INSTALL_DIR/deploy/Caddyfile" "$CADDY_CONFIG_PATH" \
    "s|__DOMAIN__|${NEW_DOMAIN}|g"
  caddy validate --config "$CADDY_CONFIG_PATH" >/dev/null
  if systemctl is-active --quiet caddy; then
    systemctl reload caddy
  else
    systemctl restart caddy
  fi
  ok "Caddy настроен на $NEW_DOMAIN — сертификат выпускается автоматически при первом запросе"
}

restart_app() {
  step "Перезапускаю commentdm и commentdm-worker (чтобы подхватить новый APP_URL)"
  systemctl restart commentdm.service
  systemctl restart commentdm-worker.service
  sleep 5
  if systemctl is-active --quiet commentdm.service; then
    ok "commentdm.service перезапущен"
  else
    warn "commentdm.service не поднялся — journalctl -u commentdm -n 50"
  fi
  if systemctl is-active --quiet commentdm-worker.service; then
    ok "commentdm-worker.service перезапущен"
  else
    warn "commentdm-worker.service не поднялся — journalctl -u commentdm-worker -n 50"
  fi
}

print_memo() {
  local old_domain="$1"
  echo
  echo "################################################################################"
  echo "#   Домен переключён: ${old_domain:-(не было)} → ${NEW_DOMAIN}"
  echo "################################################################################"
  echo
  warn "Это не делается само — сделай руками, пока не сделано, часть функций не работает:"
  echo
  echo "1. Адрес возврата OAuth в кабинете Meta for Developers:"
  echo "     твоё приложение → API setup with Instagram login →"
  echo "     OAuth redirect URI (Business login settings) →"
  echo
  echo "       https://${NEW_DOMAIN}/api/instagram/callback"
  echo
  echo "   Пока не поменяешь — подключение/переподключение Instagram-аккаунта"
  echo "   будет падать с ошибкой несовпадения redirect_uri. Можно указать сразу"
  echo "   оба адреса (старый и новый) — тогда переходный период ничего не сломает."
  echo
  if [ -n "$old_domain" ]; then
    echo "2. Короткие ссылки в уже отправленных сообщениях:"
    echo "     Каждое сообщение со ссылкой, отправленное ДО этой смены домена,"
    echo "     содержит ссылку вида https://${old_domain}/r/<код> — она вела через"
    echo "     этот сервер на настоящий адрес. Как только ${old_domain} перестанет"
    echo "     указывать на этот сервер (или его DNS вообще уберут), эти ссылки"
    echo "     перестанут работать — переотправить их или предупредить получателей"
    echo "     нечем, это односторонняя операция."
    echo
  fi
  echo "Лог: $LOG_FILE"
  echo
}

main() {
  # parse_args first, same order install.sh uses — so `--help` doesn't
  # demand root before it's had a chance to print and exit.
  parse_args "$@"
  require_root "npm run set-domain -- <домен>"
  require_env_file
  setup_logging "$LOG_FILE"

  local old_domain
  old_domain="$(get_old_domain)"

  if [ "$old_domain" = "$NEW_DOMAIN" ]; then
    ok "APP_URL уже указывает на $NEW_DOMAIN — менять нечего."
    clean_exit 0
  fi

  check_dns
  update_env_and_caddy
  restart_app
  print_memo "$old_domain"
}

main "$@"
