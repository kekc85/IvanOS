/**
 * Subscriber data erasure — a follower's right to be forgotten.
 *
 * Usage:
 *   npm run gdpr:delete-subscriber -- <instagram-id-or-username>
 *
 * Looks up every DmLog row and every chain journey for the given
 * Instagram-scoped id or username, shows what it found, and — only after an
 * explicit "yes" — deletes it. See lib/gdpr/delete-subscriber.ts for what this
 * can and cannot reach: DmLog is matched by identity, but a row still inside
 * Meta's private-reply window is withheld rather than deleted (it also doubles
 * as the polling reconciler's dedup marker — deleting it too early causes a
 * duplicate DM); SubscriberJourney is deleted outright, which is also what
 * stops a chain that is still messaging this person; LinkClick carries no
 * identity to match against and is covered by the automatic retention job
 * instead, not this command.
 *
 * Runs as a one-off script (`tsx`, same as the worker entrypoint) rather than
 * an HTTP route: an operation that permanently deletes a real person's data
 * belongs behind a terminal and a typed confirmation, not a URL a browser
 * tab could hit by accident.
 */

import { createInterface } from "node:readline/promises";
import { prisma } from "@/lib/db/client";
import {
  eraseSubscriberData,
  previewSubscriberErasure,
} from "@/lib/gdpr/delete-subscriber";

async function confirm(question: string): Promise<boolean> {
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  try {
    const answer = await rl.question(question);
    return answer.trim().toLowerCase() === "да";
  } finally {
    rl.close();
  }
}

async function main() {
  const identifier = process.argv[2]?.trim();

  if (!identifier) {
    console.error(
      "Использование: npm run gdpr:delete-subscriber -- <instagram-id-или-username>"
    );
    process.exitCode = 1;
    return;
  }

  const preview = await previewSubscriberErasure(identifier);

  if (preview.dmLogs.length === 0 && preview.journeys.length === 0) {
    console.log(`Записей для "${identifier}" не найдено. Удалять нечего.`);
    return;
  }

  console.log(`Найдено ${preview.dmLogs.length} строк(и) DM-журнала для "${identifier}":`);
  for (const row of preview.dmLogs) {
    console.log(
      `  - ${row.createdAt.toISOString()}  commenterId=${row.commenterId}  имя=${
        row.commenterName ?? "(нет)"
      }  commentId=${row.commentId}`
    );
  }

  console.log("");
  console.log(
    `Из них будет удалено сейчас: ${preview.dmLogsDeletableNow}. ` +
      `Отложено: ${preview.dmLogsWithheld} - эти комментарии ещё внутри окна приватного ответа Meta ` +
      `(удалить их сейчас значит заставить опрос увидеть уже отвеченный комментарий как новый и отправить ` +
      `человеку второе сообщение). Запусти команду ещё раз после того, как окно пройдёт, чтобы удалить и их.`
  );
  console.log("");

  console.log(`Найдено ${preview.journeys.length} цепочек(и) касаний для "${identifier}":`);
  for (const row of preview.journeys) {
    console.log(
      `  - ${row.createdAt.toISOString()}  состояние=${row.state}  subscriberId=${
        row.subscriberId
      }  commenterId=${row.commenterId ?? "(нет)"}  имя=${row.subscriberName ?? "(нет)"}`
    );
  }
  console.log(
    `Все они будут удалены полностью. Из них идут прямо сейчас: ${preview.journeysLive} - ` +
      `удаление строки и есть остановка: следующие сообщения цепочки уходят только по живым строкам, ` +
      `так что после удаления человеку больше ничего не отправится.`
  );
  console.log("");

  console.log(`LinkClick: клики анонимны, к этому идентификатору не привязаны, отдельно чистить не нужно.`);
  console.log("");

  const proceed = await confirm(
    `Безвозвратно удалить ${preview.dmLogsDeletableNow} строк(и) DM-журнала и ${preview.journeys.length} цепочек(и), показанных выше? Введи "да" для продолжения: `
  );

  if (!proceed) {
    console.log("Отменено. Ничего не удалено.");
    return;
  }

  const result = await eraseSubscriberData(identifier);

  console.log("");
  console.log("Готово.");
  console.log(`  Удалено строк DM-журнала: ${result.dmLogsDeleted}`);
  console.log(
    `  Удалено цепочек касаний: ${result.journeysDeleted}` +
      (result.journeysStopped > 0
        ? ` (из них остановлено на ходу: ${result.journeysStopped} - больше этому человеку ничего не уйдёт)`
        : "")
  );
  if (result.dmLogsWithheld > 0) {
    console.log(
      `  Отложено (внутри окна Meta): ${result.dmLogsWithheld} - запусти команду ещё раз позже, чтобы удалить и их`
    );
  }
}

main()
  .catch((error) => {
    console.error("Удаление не выполнено:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
