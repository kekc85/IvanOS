/**
 * Self-diagnosis for a self-hosted install: `npm run doctor`.
 *
 * Built to run on an install that isn't even up yet — half-filled .env,
 * `prisma generate` never run, Postgres/Redis down, worker never started.
 * Every check degrades to one clear, copy-pasteable finding instead of
 * throwing, so this always finishes and always prints something a student
 * (working through Claude Code, not a human reading docs) can act on.
 *
 * Usage:
 *   npm run doctor                 human-readable report
 *   npm run -s doctor -- --json    same data as JSON, for a script/agent to
 *                                  parse. The -s is not optional: without it
 *                                  npm prints its own two-line preamble into
 *                                  this same stdout and jq dies on it.
 *
 * Exit code is 0 when nothing is at error level, 1 otherwise — so this can
 * gate a script (e.g. install.sh's final step, phase 12) without parsing
 * output.
 */
import { formatHuman, formatJson, summarize } from "@/lib/doctor/format";
import { runDoctor } from "@/lib/doctor/run";

async function main() {
  const jsonMode = process.argv.includes("--json");

  const findings = await runDoctor();
  const summary = summarize(findings);

  console.log(jsonMode ? formatJson(findings) : formatHuman(findings));

  process.exitCode = summary.error > 0 ? 1 : 0;
}

main().catch((err) => {
  // Should be unreachable — runDoctor() catches per-section — but a CLI tool
  // handed to a thousand beginners does not get to end in a raw stack trace.
  console.error("❌ npm run doctor не смог завершиться");
  console.error(`   Что случилось: ${err instanceof Error ? err.message : String(err)}`);
  process.exitCode = 1;
});
