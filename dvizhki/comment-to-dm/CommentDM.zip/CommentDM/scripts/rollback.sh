#!/usr/bin/env bash
#
# commentdm — undo the last `npm run update`: `npm run rollback`.
#
# Prisma has no down-migrations here (one squashed initial migration, phase
# 9) — there is no "reverse migration" to run. A rollback is instead: bring
# the database back to the dump `npm run update` took right before it
# touched anything (step 1 of update.sh), and bring the code back to the
# commit that was checked out before that update. Both are read from
# .commentdm-update-state, written by the last successful (or attempted)
# update.sh run.
#
# This is destructive on purpose: every DM sent, comment matched, or click
# tracked *after* that dump is gone once this runs. The script says so
# explicitly and requires typing an exact confirmation phrase before it
# touches anything — a plain "y" is not enough for something that discards
# data.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# shellcheck source=deploy/lib.sh
source "$INSTALL_DIR/deploy/lib.sh"

APP_USER="commentdm"
ENV_FILE="$INSTALL_DIR/.env"
STATE_FILE="$INSTALL_DIR/.commentdm-update-state"
LOG_FILE="/var/log/commentdm-rollback.log"
CONFIRM_PHRASE="ОТКАТИТЬ"

# Поднят в 1 ровно на то время, пока сервисы намеренно остановлены. Ловушка
# ниже смотрит только на него: любой выход из скрипта (падение команды,
# clean_exit, Ctrl-C) в этом окне обязан поднять сервисы обратно, иначе
# неудачный откат оставляет сервер лежать целиком.
SERVICES_STOPPED=0

restore_services_if_left_down() {
  if [ "$SERVICES_STOPPED" -eq 1 ]; then
    SERVICES_STOPPED=0
    echo
    warn "Откат не дошёл до конца — поднимаю сервисы обратно на текущем коде."
    systemctl start commentdm.service 2>/dev/null || true
    systemctl start commentdm-worker.service 2>/dev/null || true
    info "   Состояние базы данных проверьте отдельно: npm run doctor"
    info "   Лог: $LOG_FILE"
  fi
}

trap 'on_unexpected_error $LINENO "$0"' ERR
trap restore_services_if_left_down EXIT

# Разбор .env вместо его ИСПОЛНЕНИЯ через точку — см. тот же комментарий в
# scripts/update.sh. Реализация — deploy/lib.sh::load_env_file.
load_env() {
  if [ ! -f "$ENV_FILE" ]; then
    fail "Не найден $ENV_FILE." "Это не похоже на установленный commentdm."
  fi
  load_env_file "$ENV_FILE"
}

load_state() {
  if [ ! -f "$STATE_FILE" ]; then
    err "Нечего откатывать: $STATE_FILE не найден."
    info "   Он создаётся первым же успешным запуском npm run update и хранит,"
    info "   на какой коммит и какой дамп базы откатываться."
    info "   Если update ещё ни разу не запускался, откатывать не на что —"
    info "   это первая версия, установленная install.sh."
    info "   Восстановить базу вручную из любого дампа в $INSTALL_DIR/backups всё"
    info "   равно можно: bash deploy/restore-db.sh <файл-дампа>."
    clean_exit 1
  fi
  # Разбор, а не исполнение: файл состояния лежит рядом с .env в каталоге,
  # который принадлежит пользователю приложения, и точка исполняла бы его
  # содержимое от root. Плюс путь к дампу может содержать пробел.
  PREVIOUS_COMMIT="$(env_get "$STATE_FILE" PREVIOUS_COMMIT)"
  DUMP_PATH="$(env_get "$STATE_FILE" DUMP_PATH)"
  UPDATED_AT="$(env_get "$STATE_FILE" UPDATED_AT)"

  if [ -z "${PREVIOUS_COMMIT:-}" ] || [ -z "${DUMP_PATH:-}" ]; then
    fail "$STATE_FILE повреждён или неполон." "Записи PREVIOUS_COMMIT / DUMP_PATH нет. Восстанови базу вручную: bash deploy/restore-db.sh <файл-дампа>, код — git log / git checkout."
  fi

  if [ ! -f "$DUMP_PATH" ]; then
    fail "Дамп из $STATE_FILE не найден на диске: $DUMP_PATH" "Он мог быть удалён вручную. Без него безопасный откат базы невозможен — можно откатить только код: cd $INSTALL_DIR && git reset --hard $PREVIOUS_COMMIT"
  fi
}

# Всё, что можно проверить, не останавливая сервисы — проверяется здесь.
# Раньше первая же непроходимая проблема (битый дамп, недоступная база,
# нехватка прав на очистку схемы) всплывала уже ПОСЛЕ stop_services, и
# сервер оставался лежать.
preflight_checks() {
  step "Проверяю, что откат вообще выполним (сервисы пока работают)"
  if ! bash "$INSTALL_DIR/deploy/restore-db.sh" --check "$DUMP_PATH"; then
    fail "Откат остановлен до остановки сервисов — восстановление базы сейчас невозможно." \
      "Ничего не тронуто, приложение продолжает работать. Разберитесь с сообщением выше и запустите npm run rollback ещё раз."
  fi
  if ! git -C "$INSTALL_DIR" cat-file -e "${PREVIOUS_COMMIT}^{commit}" 2>/dev/null; then
    fail "Коммита $PREVIOUS_COMMIT нет в этом репозитории." \
      "Ничего не тронуто. Возможно, каталог переустанавливали заново — откатывать не на что, база восстанавливается отдельно: bash deploy/restore-db.sh $DUMP_PATH"
  fi
  ok "Проверки пройдены: дамп цел, база отвечает, коммит для отката на месте"
}

confirm_rollback() {
  local current_commit dirty
  current_commit="$(git -C "$INSTALL_DIR" rev-parse HEAD)"
  dirty="$(git -C "$INSTALL_DIR" status --porcelain --untracked-files=all)"

  echo
  warn "Откат сделает следующее:"
  info "   1. Остановит commentdm.service и commentdm-worker.service."
  info "   2. ПОЛНОСТЬЮ заменит текущую базу данных содержимым дампа:"
  info "        $DUMP_PATH"
  info "      (снят в ${UPDATED_AT:-неизвестно когда}, прямо перед последним npm run update)"
  info "   3. Вернёт код с $current_commit на $PREVIOUS_COMMIT."
  info "   4. Пересоберёт и перезапустит оба сервиса на этом коде."
  echo
  err "ВСЁ, что произошло в базе ПОСЛЕ снятия этого дампа, будет ПОТЕРЯНО:"
  info "   новые комментарии, отправленные сообщения, клики по ссылкам, статистика."
  info "   Это необратимо после подтверждения — резервной копии текущего"
  info "   (не откаченного) состояния базы этот скрипт не делает."
  echo

  # Экран подтверждения раньше говорил только про базу, а шаг 3 — это
  # git reset --hard, то есть ещё и правки в коде, которых нет ни в одном
  # коммите. Называем их поимённо и сразу говорим, что с ними будет.
  if [ -n "$dirty" ]; then
    err "В коде есть несохранённые правки (твои или Claude Code):"
    while IFS= read -r f; do
      [ -n "$f" ] && info "     ${f}"
    done <<< "$dirty"
    info "   Они будут сохранены отдельным коммитом ПЕРЕД откатом — из рабочего"
    info "   каталога исчезнут, но не пропадут: хеш этого коммита будет напечатан,"
    info "   вернуть можно через git reflog / git cherry-pick."
    info "   Хотите оставить их себе как есть — отмените откат и сделайте git commit сами."
    echo
  fi

  local answer
  read -r -p "Введи «${CONFIRM_PHRASE}» заглавными, чтобы продолжить, или что угодно другое для отмены: " answer
  if [ "$answer" != "$CONFIRM_PHRASE" ]; then
    info "Отменено. Ничего не тронуто."
    clean_exit 0
  fi
}

stop_services() {
  step "Останавливаю сервисы"
  systemctl stop commentdm.service 2>/dev/null || true
  systemctl stop commentdm-worker.service 2>/dev/null || true
  SERVICES_STOPPED=1
  ok "Сервисы остановлены"
}

restore_database() {
  step "Восстанавливаю базу данных из дампа"
  bash "$INSTALL_DIR/deploy/restore-db.sh" "$DUMP_PATH"
  ok "База данных восстановлена"
}

revert_code() {
  step "Возвращаю код на $PREVIOUS_COMMIT"
  cd "$INSTALL_DIR"
  # Сначала укладываем незакоммиченные правки в коммит — тем же приёмом,
  # что и update.sh. git reset --hard ниже стирает рабочий каталог, и без
  # этого шага правки ученика исчезали бы совсем, а не «оставались бы
  # достижимы по хешу».
  if [ -n "$(git status --porcelain --untracked-files=all)" ]; then
    git add -A
    git -c user.email="commentdm-rollback@localhost" -c user.name="commentdm rollback" \
      commit -q -m "WIP: локальные правки перед откатом $(date -u +%Y-%m-%dT%H:%M:%SZ)"
    ok "Несохранённые правки убраны в коммит $(git rev-parse --short HEAD) — вернуть: git cherry-pick $(git rev-parse --short HEAD)"
  fi
  # Deliberate git reset --hard: this is the one place in this project's
  # tooling that command is the right tool, on the operator's own deploy
  # checkout, after an explicit typed confirmation above. Anything that was
  # only a local WIP commit (update.sh auto-commits uncommitted edits before
  # pulling) is not destroyed by this — it stays reachable by hash / via
  # `git reflog` even though the branch pointer moves past it.
  git reset --hard "$PREVIOUS_COMMIT"
  ok "Код на $(git rev-parse --short HEAD)"
}

rebuild() {
  step "Пересобираю приложение под откаченный код"
  build_app_in "$INSTALL_DIR"
}

reinstall_units_and_start() {
  step "Переустанавливаю systemd-юниты и запускаю сервисы"
  install_systemd_units_from "$INSTALL_DIR" "$APP_USER"
  chown -R "${APP_USER}:${APP_USER}" "$INSTALL_DIR"

  systemctl restart commentdm.service
  systemctl restart commentdm-worker.service
  # С этого места сервисы снова подняты: окно «намеренно остановлены»
  # закрыто, ловушке на выходе поднимать больше нечего.
  SERVICES_STOPPED=0
  sleep 5

  if systemctl is-active --quiet commentdm.service; then
    ok "commentdm.service запущен"
  else
    warn "commentdm.service не поднялся — journalctl -u commentdm -n 50"
  fi
  if systemctl is-active --quiet commentdm-worker.service; then
    ok "commentdm-worker.service запущен"
  else
    warn "commentdm-worker.service не поднялся — journalctl -u commentdm-worker -n 50"
  fi
}

clear_state() {
  # A stale state file pointing at a dump/commit that is now itself "the
  # current version" would make a second, accidental rollback silently do
  # nothing useful. Rollback is one-shot until the next update.sh run.
  rm -f "$STATE_FILE"
}

run_doctor() {
  step "npm run doctor"
  cd "$INSTALL_DIR"
  sudo -u "$APP_USER" --preserve-env=PATH npm run doctor || \
    warn "doctor нашёл проблемы (вывод выше)."
}

main() {
  require_root "npm run rollback (из $INSTALL_DIR)"
  setup_logging "$LOG_FILE"
  load_env
  load_state
  preflight_checks
  confirm_rollback
  stop_services
  restore_database
  revert_code
  rebuild
  reinstall_units_and_start
  clear_state
  run_doctor
  echo
  ok "Откат завершён: база — на дамп ${UPDATED_AT:-}, код — на $PREVIOUS_COMMIT."
}

main "$@"
