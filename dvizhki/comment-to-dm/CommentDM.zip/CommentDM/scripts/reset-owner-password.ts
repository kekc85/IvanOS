/**
 * Owner password recovery — for when it's genuinely lost, not just due for a
 * rotation.
 *
 * Usage:
 *   npx tsx --env-file=.env scripts/reset-owner-password.ts <new-password>
 *
 * The normal way to change the password is the "Пароль владельца" form on
 * the Settings page (app/(dashboard)/settings/page.tsx →
 * /api/auth/change-password → lib/auth/owner.ts's changeOwnerPassword) —
 * that requires knowing the current password, on purpose.
 *
 * This script does not: it writes a new hash straight to the database. That
 * is intentional and safe here because running it already requires the same
 * level of access as editing .env or reading the database directly — a
 * terminal on the server itself. See ЛЕЧЕНИЕ.md, "Забыл пароль владельца",
 * for when to reach for this.
 *
 * Runs as a one-off script (`tsx`, same as scripts/delete-subscriber.ts)
 * rather than a web form for the same reason that one does: a page any
 * browser tab could hit is the wrong place for an operation this sensitive.
 */

import { prisma } from "@/lib/db/client";
import { checkPasswordPolicy, hashPassword } from "@/lib/auth/password";

async function main() {
  const newPassword = process.argv[2];

  if (!newPassword) {
    console.error(
      "Использование: npx tsx --env-file=.env scripts/reset-owner-password.ts <новый-пароль>"
    );
    process.exitCode = 1;
    return;
  }

  const policy = checkPasswordPolicy(newPassword);
  if (!policy.ok) {
    console.error(`Пароль не подходит: ${policy.reason}`);
    process.exitCode = 1;
    return;
  }

  const owner = await prisma.user.findFirst({
    orderBy: { createdAt: "asc" },
    select: { id: true, email: true },
  });

  if (!owner) {
    console.error(
      "Владелец ещё не создан - просто запусти приложение один раз, аккаунт создастся сам."
    );
    process.exitCode = 1;
    return;
  }

  const passwordHash = await hashPassword(newPassword);
  await prisma.user.update({
    where: { id: owner.id },
    data: { passwordHash },
  });

  console.log(`Готово. Пароль для ${owner.email ?? owner.id} обновлён.`);
  console.log(
    "Если сервер уже запущен, ничего перезапускать не нужно - новый пароль сработает сразу при следующем входе."
  );
}

main()
  .catch((error) => {
    console.error("Сброс пароля не выполнен:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
