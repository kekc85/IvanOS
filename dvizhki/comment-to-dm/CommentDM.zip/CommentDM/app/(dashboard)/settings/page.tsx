"use client";

import { Suspense, useEffect, useState, type FormEvent } from "react";
import type { AccountOption } from "@/components/account-select";
import { InstagramConnectNotice } from "@/components/instagram-connect-notice";
import {
  isAccountInSoftStart,
  softStartHoursRemaining,
  SOFT_START_DIVISOR,
} from "@/lib/utils/soft-start";
import {
  DEFAULT_CHAIN_JOURNEY_RETENTION_DAYS,
  DEFAULT_DM_LOG_RETENTION_DAYS,
  DEFAULT_LINK_CLICK_RETENTION_DAYS,
  DEFAULT_OPERATIONAL_EVENT_RETENTION_DAYS,
} from "@/lib/gdpr/retention-defaults";

interface SettingsData {
  workspace: {
    name: string;
    dmsSentThisPeriod: number;
  };
  instagramAccount: {
    id: string;
    username: string;
    instagramId: string;
    tokenExpiresAt: string | null;
  } | null;
  instagramAccounts: Array<
    AccountOption & {
      tokenExpiresAt: string | null;
      connectedAt: string | null;
    }
  >;
}

export default function SettingsPage() {
  const [data, setData] = useState<SettingsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [passwordSuccess, setPasswordSuccess] = useState(false);
  const [passwordBusy, setPasswordBusy] = useState(false);

  useEffect(() => {
    fetch("/api/dashboard/stats")
      .then((res) => res.json())
      .then((statsPayload) => {
        if (statsPayload.success) setData(statsPayload.data);
      })
      .finally(() => setLoading(false));
  }, []);

  async function changePassword(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPasswordError(null);
    setPasswordSuccess(false);

    if (newPassword !== confirmPassword) {
      setPasswordError("Новый пароль и подтверждение не совпадают");
      return;
    }

    setPasswordBusy(true);
    try {
      const response = await fetch("/api/auth/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const payload = await response.json();
      if (!payload.success) {
        setPasswordError(payload.error ?? "Не удалось сменить пароль");
        return;
      }
      setPasswordSuccess(true);
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } finally {
      setPasswordBusy(false);
    }
  }

  async function disconnectInstagram(instagramAccountId: string) {
    if (!confirm("Отключить Instagram? Кампании этого аккаунта перестанут отправлять сообщения в директ.")) {
      return;
    }

    setBusy(`disconnect:${instagramAccountId}`);
    await fetch("/api/instagram/disconnect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ instagramAccountId }),
    });
    window.location.reload();
  }

  if (loading) {
    return <div className="panel rounded p-8 h-64" />;
  }

  const accounts = data?.instagramAccounts ?? [];

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      {/* Surfaces the ?instagram= code the OAuth routes redirect back with.
          Needs a Suspense boundary: useSearchParams in a prerendered client
          page fails the production build without one. */}
      <Suspense fallback={null}>
        <InstagramConnectNotice />
      </Suspense>

      <section className="panel rounded p-4 sm:p-6">
        <h2 className="text-base font-semibold mb-6">Подключение Instagram</h2>

        <div className="space-y-4">
          <div className="flex items-center justify-between gap-3 py-3 border-b border-border">
            <div>
              <p className="text-sm font-medium text-foreground">Статус</p>
              <p className="text-xs text-muted mt-0.5">
                Опрос комментариев и приватные ответы работают только при активном подключении.
              </p>
            </div>
            <span
              className={`px-3 py-1.5 rounded-full text-xs font-medium ${
                accounts.length > 0
                  ? "bg-success/10 text-success"
                  : "bg-warning/10 text-warning"
              }`}
            >
              {accounts.length > 0 ? "Подключено" : "Не подключено"}
            </span>
          </div>

          <div className="flex items-center justify-between gap-3 py-3 border-b border-border">
            <div>
              <p className="text-sm font-medium text-foreground">Аккаунты</p>
              <p className="text-xs text-muted mt-0.5">
                Подключено профилей Instagram: {accounts.length}
              </p>
            </div>
            <span className="text-sm text-muted">
              {accounts.length > 0 ? `Подключено: ${accounts.length}` : "Нет"}
            </span>
          </div>

          <div className="space-y-3 py-3">
            {accounts.length === 0 && (
              <p className="text-sm text-muted">
                Подключи профессиональный аккаунт Instagram, чтобы запускать кампании.
              </p>
            )}
            {accounts.map((account) => (
              <div
                key={account.id}
                className="flex flex-col gap-3 rounded border border-border bg-surface/70 p-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <div>
                  <p className="text-sm font-semibold text-foreground">
                    @{account.username}
                  </p>
                  <p className="mt-1 text-xs text-muted">
                    Токен истекает:{" "}
                    {account.tokenExpiresAt
                      ? new Date(account.tokenExpiresAt).toLocaleDateString()
                      : "нет данных"}
                  </p>
                  {isAccountInSoftStart(account.connectedAt) && (
                    <p className="mt-2 inline-flex items-center gap-1.5 rounded-full border border-warning/30 bg-warning/10 px-2.5 py-1 text-xs text-warning">
                      Разогрев: отправляем {Math.round(100 / SOFT_START_DIVISOR)}
                      % от обычного объёма ещё{" "}
                      {softStartHoursRemaining(account.connectedAt)}ч, потом
                      скорость вернётся к полной автоматически.
                    </p>
                  )}
                </div>
                <button
                  onClick={() => disconnectInstagram(account.id)}
                  disabled={busy === `disconnect:${account.id}`}
                  className="inline-flex items-center justify-center rounded border border-error/20 px-4 py-2 text-sm font-medium text-error transition-all hover:border-error/40 hover:bg-error/10 disabled:opacity-50"
                >
                  {busy === `disconnect:${account.id}`
                    ? "Отключаем…"
                    : "Отключить"}
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-border flex gap-3">
          <a
            href="/api/instagram/connect"
            className="px-4 py-2 rounded text-sm font-medium transition-colors bg-accent text-white hover:bg-accent-hover"
          >
            {accounts.length > 0 ? "Подключить ещё аккаунт" : "Подключить Instagram"}
          </a>
        </div>
      </section>

      <section className="panel rounded p-4 sm:p-6">
        <h2 className="text-base font-semibold mb-6">Использование</h2>
        <div className="flex items-center justify-between gap-3 py-3">
          <div>
            <p className="text-sm font-medium text-foreground">
              Сообщений в директ за этот месяц
            </p>
            <p className="text-xs text-muted mt-0.5">
              Свой сервер - без лимитов тарифного плана.
            </p>
          </div>
          <span className="text-sm font-semibold text-foreground">
            {data?.workspace.dmsSentThisPeriod ?? 0}
          </span>
        </div>
      </section>

      <section className="panel rounded p-4 sm:p-6">
        <h2 className="text-base font-semibold mb-2">Пароль владельца</h2>
        <p className="text-xs text-muted mb-6">
          Смени пароль в любой момент, особенно если тот, что был показан при
          установке, мог остаться в чужих логах. Забыл текущий пароль
          полностью? В инструкции есть отдельный способ сбросить его на
          сервере - см. раздел «Забыл пароль» в{" "}
          <code className="text-foreground">ЛЕЧЕНИЕ.md</code>.
        </p>
        <form onSubmit={changePassword} className="space-y-3 max-w-sm">
          <div>
            <label className="block text-xs text-muted mb-1" htmlFor="currentPassword">
              Текущий пароль
            </label>
            <input
              id="currentPassword"
              type="password"
              autoComplete="current-password"
              value={currentPassword}
              onChange={(event) => setCurrentPassword(event.target.value)}
              required
              className="w-full rounded border border-border bg-surface px-3 py-2 text-sm text-foreground"
            />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1" htmlFor="newPassword">
              Новый пароль
            </label>
            <input
              id="newPassword"
              type="password"
              autoComplete="new-password"
              minLength={8}
              value={newPassword}
              onChange={(event) => setNewPassword(event.target.value)}
              required
              className="w-full rounded border border-border bg-surface px-3 py-2 text-sm text-foreground"
            />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1" htmlFor="confirmPassword">
              Повтори новый пароль
            </label>
            <input
              id="confirmPassword"
              type="password"
              autoComplete="new-password"
              minLength={8}
              value={confirmPassword}
              onChange={(event) => setConfirmPassword(event.target.value)}
              required
              className="w-full rounded border border-border bg-surface px-3 py-2 text-sm text-foreground"
            />
          </div>

          {passwordError && (
            <p className="text-sm text-error">{passwordError}</p>
          )}
          {passwordSuccess && (
            <p className="text-sm text-success">Пароль изменён.</p>
          )}

          <button
            type="submit"
            disabled={passwordBusy}
            className="inline-flex items-center justify-center rounded px-4 py-2 text-sm font-medium transition-colors bg-accent text-white hover:bg-accent-hover disabled:opacity-50"
          >
            {passwordBusy ? "Меняем…" : "Сменить пароль"}
          </button>
        </form>
      </section>

      <section className="panel rounded p-4 sm:p-6">
        <h2 className="text-base font-semibold mb-2">Данные и приватность</h2>
        <p className="text-xs text-muted mb-6">
          Эти данные хранятся на твоём собственном сервере. Никуда наружу
          они не отправляются.
        </p>

        <div className="space-y-3 text-sm text-muted">
          <div className="flex items-start justify-between gap-3 py-2 border-b border-border">
            <span>Журнал отправленных сообщений (кому и когда написали)</span>
            <span className="text-foreground whitespace-nowrap">
              хранится {DEFAULT_DM_LOG_RETENTION_DAYS} дн.
            </span>
          </div>
          <div className="flex items-start justify-between gap-3 py-2 border-b border-border">
            <span>Данные о кликах по ссылкам (обезличены - без имени и ID)</span>
            <span className="text-foreground whitespace-nowrap">
              хранятся {DEFAULT_LINK_CLICK_RETENTION_DAYS} дн.
            </span>
          </div>
          <div className="flex items-start justify-between gap-3 py-2 border-b border-border">
            <span>Внутренний журнал активности</span>
            <span className="text-foreground whitespace-nowrap">
              хранится {DEFAULT_OPERATIONAL_EVENT_RETENTION_DAYS} дн.
            </span>
          </div>
          <div className="flex items-start justify-between gap-3 py-2 border-b border-border">
            <span>Состояние цепочек касаний (кто на каком шаге)</span>
            <span className="text-foreground whitespace-nowrap">
              хранится {DEFAULT_CHAIN_JOURNEY_RETENTION_DAYS} дн.
            </span>
          </div>
          <div className="flex items-start justify-between gap-3 py-2">
            <span>Метка «уже обработан» на комментарии</span>
            <span className="text-foreground whitespace-nowrap">
              хранится минимум ~1 неделю
            </span>
          </div>
        </div>

        <p className="mt-4 text-xs text-muted">
          Старые записи удаляются автоматически по ежедневному расписанию -
          подробный разбор в{" "}
          <a href="/privacy" className="underline hover:text-foreground">
            Политике конфиденциальности
          </a>{" "}
          , а поменять сроки хранения можно через свой файл <code>.env</code>.
        </p>
        <p className="mt-3 text-xs text-muted">
          Если кто-то из тех, кто оставлял комментарии, попросит удалить его
          данные, запусти на своём сервере{" "}
          <code className="text-foreground">
            npm run gdpr:delete-subscriber
          </code>{" "}
          (см.{" "}
          <a href="/data-deletion" className="underline hover:text-foreground">
            Удаление данных
          </a>
          ). Команда найдёт человека по Instagram ID или username, покажет
          найденное и спросит подтверждение перед удалением.
        </p>
      </section>
    </div>
  );
}
