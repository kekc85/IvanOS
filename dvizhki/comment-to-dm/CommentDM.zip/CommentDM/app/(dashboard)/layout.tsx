import { redirect } from "next/navigation";
import DashboardShell from "@/components/dashboard-shell";
import { getCurrentUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db/client";
import { getOrCreateSingleWorkspace } from "@/lib/workspace";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getCurrentUser();

  if (!user) {
    // Via the sign-out route, not straight to /login: the cookie can still be
    // validly signed while the row it points at is gone (a reset database),
    // and the proxy would bounce a cookie-holder off /login forever.
    redirect("/api/auth/sign-out");
  }

  const workspace = await getOrCreateSingleWorkspace();
  const accounts = await prisma.instagramAccount.findMany({
    where: { workspaceId: workspace.id },
    orderBy: { connectedAt: "desc" },
    select: { username: true },
  });

  return (
    <DashboardShell
      workspaceName={workspace.name}
      instagramUsername={accounts[0]?.username ?? null}
      instagramAccountCount={accounts.length}
    >
      {children}
    </DashboardShell>
  );
}
