"use client";

/**
 * Campaign Detail
 *
 * Clicking a campaign opens this read-only view: a summary of the automation
 * on the left, and Insights / Preview tabs on the right. Edit and Stop/Resume
 * live in the top bar.
 */

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import CampaignPreview, { type PreviewTab } from "@/components/campaign-preview";
import {
  type ChainStepPayload,
  chainStepLabel,
  formatDelayRu,
} from "@/components/chain-utils";

/** Every state a person can be in inside a chain, counted by the API. */
interface JourneyCounts {
  GATE_SENT: number;
  ACTIVE: number;
  DONE: number;
  EXPIRED: number;
  STOPPED: number;
  SKIPPED: number;
  FAILED: number;
  total: number;
}

interface Campaign {
  id: string;
  name: string;
  postId: string | null;
  postUrl: string | null;
  pendingNextReel: boolean;
  matchAnyPost: boolean;
  keywords: string[];
  matchAnyWord: boolean;
  dmMessage: string;
  linkButtonLabel: string | null;
  publicReplyEnabled: boolean;
  publicReplyMessage: string | null;
  publicReplyMessages: string[];
  isActive: boolean;
  instagramAccountId: string;
  instagramAccount: { username: string };
  trackedLinks?: {
    destinationUrl: string;
    label?: string | null;
    trackedUrl?: string;
  }[];
  analytics: {
    sent: number;
    skipped: number;
    failed: number;
    clicks: number;
    ctr: number;
  };
  chainEnabled?: boolean;
  chainSteps?: ChainStepPayload[];
  journeys?: JourneyCounts;
}

type Tab = "insights" | "preview";

export default function CampaignDetailPage() {
  const router = useRouter();
  const { id } = useParams<{ id: string }>();

  const [campaign, setCampaign] = useState<Campaign | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [postThumb, setPostThumb] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>("insights");
  const [previewTab, setPreviewTab] = useState<PreviewTab>("dm");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetch("/api/automations", { cache: "no-store" })
      .then((r) => r.json())
      .then((payload) => {
        if (!payload.success) return setNotFound(true);
        const found = (payload.data as Campaign[]).find((c) => c.id === id);
        if (!found) return setNotFound(true);
        setCampaign(found);
      })
      .catch(() => setNotFound(true))
      .finally(() => setLoading(false));
  }, [id]);

  useEffect(() => {
    if (!campaign) return;
    const acct = campaign.instagramAccountId;
    fetch(`/api/instagram/profile?instagramAccountId=${acct}`)
      .then((r) => r.json())
      .then((d) =>
        setAvatarUrl(d.success ? d.data.profilePictureUrl ?? null : null)
      )
      .catch(() => setAvatarUrl(null));

    if (campaign.postId) {
      fetch(`/api/instagram/posts?instagramAccountId=${acct}&limit=50`)
        .then((r) => r.json())
        .then((payload) => {
          if (!payload.success) return;
          const hit = (
            payload.data as {
              id: string;
              thumbnail_url?: string;
              media_url?: string;
            }[]
          ).find((p) => p.id === campaign.postId);
          setPostThumb(hit?.thumbnail_url ?? hit?.media_url ?? null);
        })
        .catch(() => setPostThumb(null));
    }
  }, [campaign]);

  async function toggleActive() {
    if (!campaign) return;
    setBusy(true);
    try {
      await fetch(`/api/automations?id=${campaign.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive: !campaign.isActive }),
      });
      setCampaign({ ...campaign, isActive: !campaign.isActive });
    } finally {
      setBusy(false);
    }
  }

  if (loading) {
    return <div className="panel h-64 rounded" />;
  }
  if (notFound || !campaign) {
    return (
      <div className="panel rounded p-8 text-center">
        <p className="text-sm text-muted">Кампания не найдена.</p>
        <button
          onClick={() => router.push("/campaigns")}
          className="mt-4 rounded border border-border px-4 py-2 text-sm text-muted hover:text-foreground"
        >
          К списку кампаний
        </button>
      </div>
    );
  }

  const publicReplies =
    campaign.publicReplyMessages && campaign.publicReplyMessages.length > 0
      ? campaign.publicReplyMessages
      : campaign.publicReplyMessage
        ? [campaign.publicReplyMessage]
        : [];
  const hasLink = Boolean(campaign.trackedLinks?.[0]?.destinationUrl);
  const hasSecondLink = Boolean(campaign.trackedLinks?.[1]?.destinationUrl);

  const trigger = campaign.matchAnyPost
    ? "Любой пост или рилс"
    : campaign.pendingNextReel
      ? "Твой следующий рилс"
      : "Конкретный пост или рилс";
  const matchText = campaign.matchAnyWord
    ? "Любой комментарий"
    : campaign.keywords.join(", ") || "Нет ключевых слов";

  const chainEnabled = Boolean(campaign.chainEnabled);
  const chainSteps = [...(campaign.chainSteps ?? [])].sort(
    (a, b) => a.position - b.position
  );
  // Shown even at zero: "nobody is waiting" is an answer, a missing row is not.
  const journeyRows: { label: string; value: number }[] = [
    { label: "Ждут ответа", value: campaign.journeys?.GATE_SENT ?? 0 },
    { label: "В цепочке", value: campaign.journeys?.ACTIVE ?? 0 },
    { label: "Дошли до конца", value: campaign.journeys?.DONE ?? 0 },
    { label: "Истекло окно", value: campaign.journeys?.EXPIRED ?? 0 },
    { label: "Остановили словом", value: campaign.journeys?.STOPPED ?? 0 },
    { label: "Пропущены", value: campaign.journeys?.SKIPPED ?? 0 },
    { label: "Ошибка", value: campaign.journeys?.FAILED ?? 0 },
  ];

  const metrics = [
    { label: "Отправлено", value: campaign.analytics.sent },
    { label: "Клики", value: campaign.analytics.clicks },
    { label: "CTR (кликабельность)", value: `${campaign.analytics.ctr}%` },
    { label: "Ошибки", value: campaign.analytics.failed },
  ];

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,340px)_1fr]">
      {/* Left: config summary */}
      <div className="space-y-6">
        <div className="flex items-center gap-2">
          <Link
            href="/campaigns"
            className="text-sm text-muted hover:text-foreground"
          >
            &larr; Кампании
          </Link>
        </div>
        <div className="flex items-center gap-2">
          <h1 className="truncate text-lg font-semibold">{campaign.name}</h1>
          <span
            className={`shrink-0 rounded px-2 py-0.5 text-xs font-semibold ${
              campaign.isActive
                ? "bg-success/10 text-success"
                : "bg-zinc-500/10 text-muted"
            }`}
          >
            {campaign.isActive ? "ЗАПУЩЕНА" : "НА ПАУЗЕ"}
          </span>
        </div>

        <Summary title="Когда кто-то комментирует">
          <div className="flex items-center gap-3">
            {postThumb ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={postThumb}
                alt="Пост"
                className="h-14 w-14 rounded object-cover"
              />
            ) : (
              <div className="grid h-14 w-14 place-items-center rounded bg-surface-hover text-[10px] text-muted">
                {campaign.matchAnyPost || campaign.pendingNextReel ? "Любой" : "Пост"}
              </div>
            )}
            <span className="text-sm text-foreground">{trigger}</span>
          </div>
        </Summary>

        <Summary title="И в комментарии есть">
          <FieldBox>{matchText}</FieldBox>
          {publicReplies.length > 0 && (
            <div className="space-y-1.5">
              <p className="text-xs text-muted">Публичный ответ под постом</p>
              {publicReplies.map((m, i) => (
                <FieldBox key={i}>{m}</FieldBox>
              ))}
            </div>
          )}
        </Summary>

        <Summary
          title={
            chainEnabled
              ? "Первое сообщение (гейт) - просит человека ответить"
              : "Они получат сообщение в директ"
          }
        >
          <FieldBox>{campaign.dmMessage}</FieldBox>
          {hasLink && (
            <FieldBox>{campaign.linkButtonLabel || "Открыть ссылку"}</FieldBox>
          )}
          {hasSecondLink && (
            <FieldBox>
              {campaign.trackedLinks?.[1]?.label || "Открыть ссылку"}
            </FieldBox>
          )}
        </Summary>

        {hasLink && (
          <Summary title="Точная ссылка, которая отправляется">
            {campaign.trackedLinks
              ?.filter((link) => link.destinationUrl)
              .map((link, i) => (
                <div key={i} className="space-y-1">
                  <div className="rounded border border-border bg-surface px-3 py-2">
                    <p className="select-all break-all font-mono text-xs text-foreground">
                      {link.trackedUrl ?? link.destinationUrl}
                    </p>
                  </div>
                  <p className="text-xs text-muted">
                    {link.label ? `${link.label} · ` : ""}ведёт на{" "}
                    <span className="break-all">{link.destinationUrl}</span>
                  </p>
                </div>
              ))}
          </Summary>
        )}
      </div>

      {/* Right: top bar + tabs */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-3 border-b border-border pb-3">
          <div className="flex gap-4">
            <TabButton active={tab === "insights"} onClick={() => setTab("insights")}>
              Статистика
            </TabButton>
            <TabButton active={tab === "preview"} onClick={() => setTab("preview")}>
              Превью
            </TabButton>
          </div>
          <div className="flex items-center gap-2">
            <Link
              href={`/campaigns/${campaign.id}/edit`}
              className="rounded border border-border px-3 py-1.5 text-sm text-muted hover:text-foreground"
            >
              Изменить
            </Link>
            <button
              onClick={toggleActive}
              disabled={busy}
              className={`rounded border px-3 py-1.5 text-sm disabled:opacity-50 ${
                campaign.isActive
                  ? "border-error/30 text-error hover:bg-error/10"
                  : "border-success/30 text-success hover:bg-success/10"
              }`}
            >
              {campaign.isActive ? "Остановить" : "Запустить"}
            </button>
          </div>
        </div>

        {tab === "insights" && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
              {metrics.map((m) => (
                <div key={m.label} className="panel rounded p-4">
                  <p className="text-sm text-muted">{m.label}</p>
                  <p className="mt-1 text-2xl font-semibold text-foreground">
                    {m.value}
                  </p>
                </div>
              ))}
            </div>

            {chainEnabled && (
              <div className="space-y-4">
                <h2 className="text-sm font-semibold text-foreground">
                  Цепочка касаний
                </h2>

                <div className="space-y-2">
                  {chainSteps.length === 0 && (
                    <p className="text-sm text-muted">
                      Шагов пока нет - добавь их в «Изменить».
                    </p>
                  )}
                  {chainSteps.map((step) => (
                    <div
                      key={step.position}
                      className="rounded border border-border bg-surface px-3 py-2"
                    >
                      <div className="flex flex-wrap items-baseline justify-between gap-x-3">
                        <p className="text-sm font-medium text-foreground">
                          {chainStepLabel(step.position)}
                        </p>
                        <p className="text-xs text-muted">
                          {step.position === 0
                            ? "сразу после ответа"
                            : formatDelayRu(step.delaySeconds)}
                        </p>
                      </div>
                      <p className="mt-1 whitespace-pre-wrap text-sm text-foreground">
                        {step.message}
                      </p>
                    </div>
                  ))}
                </div>

                <div>
                  <p className="mb-2 text-xs text-muted">
                    Люди в цепочке: всего {campaign.journeys?.total ?? 0}
                  </p>
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                    {journeyRows.map((row) => (
                      <div key={row.label} className="panel rounded p-3">
                        <p className="text-xs text-muted">{row.label}</p>
                        <p
                          className={`mt-1 text-xl font-semibold ${
                            row.value > 0 ? "text-foreground" : "text-muted"
                          }`}
                        >
                          {row.value}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {tab === "preview" && (
          <div className="flex justify-center sm:justify-start">
          <CampaignPreview
            tab={previewTab}
            onTabChange={setPreviewTab}
            username={campaign.instagramAccount.username}
            avatarUrl={avatarUrl}
            postThumb={postThumb}
            caption=""
            sampleComment={campaign.matchAnyWord ? "класс!" : campaign.keywords[0] ?? "ССЫЛКА"}
            publicReplyEnabled={campaign.publicReplyEnabled}
            publicReplyMessage={publicReplies[0] ?? ""}
            revealMessage={campaign.dmMessage}
            chainEnabled={chainEnabled}
            chainSteps={chainSteps}
            hasLink={hasLink}
            linkButtonLabel={campaign.linkButtonLabel ?? "Открыть ссылку"}
            linkUrl={
              campaign.trackedLinks?.[0]?.trackedUrl ??
              campaign.trackedLinks?.[0]?.destinationUrl
            }
            hasSecondLink={hasSecondLink}
            secondLinkButtonLabel={
              campaign.trackedLinks?.[1]?.label ?? "Открыть ссылку"
            }
          />
          </div>
        )}
      </div>
    </div>
  );
}

function Summary({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <h2 className="text-sm font-semibold text-foreground">{title}</h2>
      {children}
    </div>
  );
}

function FieldBox({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded border border-border bg-surface px-3 py-2 text-sm text-foreground">
      {children}
    </div>
  );
}

function TabButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`border-b-2 pb-2 text-sm font-medium ${
        active
          ? "border-accent text-foreground"
          : "border-transparent text-muted hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );
}
