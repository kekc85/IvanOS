import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db/client";
import { getRedisConnection } from "@/lib/queue/client";
import { getRequestIp, hashClickIp } from "@/lib/tracking/server";

type RedirectRouteProps = {
  params: Promise<{ slug: string }>;
};

// Arbitrary length written unbounded into every anonymous click row —
// truncated so one crafted request can't grow the table by megabytes at a
// time. Long enough to keep a real UA string / referrer URL intact.
const USER_AGENT_MAX_LENGTH = 512;
const REFERRER_MAX_LENGTH = 1024;

// One click write per (slug, IP) pair per window. This is the tracking
// write, not the DM send — the DM rate limiter in lib/utils/rate-limiter.ts
// is unrelated and unaffected.
const CLICK_WRITE_WINDOW_SECONDS = 60;

function truncate(value: string | null, maxLength: number): string | null {
  if (!value) return value;
  return value.length > maxLength ? value.slice(0, maxLength) : value;
}

/**
 * Only http(s) destinations may be redirected to. `destinationUrl` is set by
 * the workspace owner today, but a redirect endpoint that accepts
 * `javascript:`, `data:`, or `file:` is a standing foot-gun the moment any
 * future path lets that value come from somewhere less trusted.
 */
function isSafeRedirectTarget(rawUrl: string): boolean {
  try {
    const parsed = new URL(rawUrl);
    return parsed.protocol === "http:" || parsed.protocol === "https:";
  } catch {
    return false;
  }
}

async function allowClickWrite(slug: string, ipHash: string | null): Promise<boolean> {
  const key = `redirect:click:${slug}:${ipHash ?? "unknown"}`;
  // SET ... NX EX is atomic: the first caller in the window gets "OK" and
  // every other caller in that window gets null, with no race between them.
  const result = await getRedisConnection().set(
    key,
    "1",
    "EX",
    CLICK_WRITE_WINDOW_SECONDS,
    "NX"
  );
  return result === "OK";
}

export async function GET(request: NextRequest, { params }: RedirectRouteProps) {
  const { slug } = await params;
  const trackedLink = await prisma.trackedLink.findUnique({
    where: { slug },
    select: {
      id: true,
      workspaceId: true,
      automationId: true,
      destinationUrl: true,
      automation: {
        select: {
          instagramAccountId: true,
        },
      },
    },
  });

  if (!trackedLink) {
    return NextResponse.redirect(new URL("/", request.url), { status: 302 });
  }

  if (!isSafeRedirectTarget(trackedLink.destinationUrl)) {
    return NextResponse.json(
      { error: "Tracked link has an unsupported destination scheme" },
      { status: 400 }
    );
  }

  const ipHash = hashClickIp(getRequestIp(request.headers));

  try {
    if (await allowClickWrite(slug, ipHash)) {
      await prisma.linkClick.create({
        data: {
          workspaceId: trackedLink.workspaceId,
          automationId: trackedLink.automationId,
          instagramAccountId: trackedLink.automation.instagramAccountId,
          trackedLinkId: trackedLink.id,
          ipHash,
          userAgent: truncate(request.headers.get("user-agent"), USER_AGENT_MAX_LENGTH),
          referrer: truncate(request.headers.get("referer"), REFERRER_MAX_LENGTH),
        },
      });
    }
  } catch (error) {
    // A tracking write must never block the redirect itself — the visitor
    // still needs to land on the destination even if Redis or the DB hiccup.
    console.error("[redirect] failed to record click:", error);
  }

  return NextResponse.redirect(trackedLink.destinationUrl, { status: 302 });
}
