import Link from "next/link";

/**
 * Without this file Next.js falls back to its own generic, unstyled,
 * English "This page could not be found." — the only unbranded English page
 * a self-hoster or a subscriber could stumble onto (a typo'd link, an old
 * bookmark to a removed route). This replaces it with something that at
 * least tells a human where they actually are and where to go next.
 */
export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background px-5 text-center text-foreground">
      <p className="text-sm font-semibold uppercase tracking-wide text-muted">
        Ошибка 404
      </p>
      <h1 className="text-3xl font-bold">Такой страницы нет</h1>
      <p className="max-w-md text-sm text-muted">
        Проверь адрес - возможно, опечатка или старая ссылка на страницу,
        которой больше нет.
      </p>
      <Link
        href="/dashboard"
        className="mt-2 inline-flex items-center justify-center rounded bg-accent px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-accent-hover"
      >
        На дашборд
      </Link>
    </main>
  );
}
