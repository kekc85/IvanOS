import type { Metadata } from "next";
import LegalShell from "@/components/legal-shell";
import { getLegalContactLine, getLegalOperatorName } from "@/lib/legal/operator";
import { META_PRIVATE_REPLY_WINDOW_HOURS } from "@/lib/polling/comment-reconciler";

export const metadata: Metadata = {
  title: "Удаление данных",
  description:
    "Как отключить Instagram и как подписчику запросить удаление своих данных из этого экземпляра инструмента.",
};

// Reads LEGAL_ENTITY_NAME / LEGAL_CONTACT_EMAIL per request, see app/privacy.
export const dynamic = "force-dynamic";

export default function DataDeletionPage() {
  const operatorName = getLegalOperatorName();
  const contactLine = getLegalContactLine();
  const metaWindowDays = Math.round(META_PRIVATE_REPLY_WINDOW_HOURS / 24);

  return (
    <LegalShell
      title="Удаление данных"
      description="Эта страница нужна для проверки приложения в Meta и для тех, кто хочет, чтобы оператор этого экземпляра удалил их данные."
      updatedAt="Обновлено при установке этого экземпляра"
    >
      <section>
        <h2 className="text-xl font-bold text-white">Отключить Instagram</h2>
        <p className="mt-3">
          Оператор может в любой момент зайти в панель управления, открыть
          «Настройки» и нажать «Отключить» рядом с нужным аккаунтом. Это
          удаляет сохранённый токен доступа и останавливает отправку личных
          сообщений от этого аккаунта.
        </p>
      </section>

      <section>
        <h2 className="text-xl font-bold text-white">
          Запросить удаление своих данных (подписчикам)
        </h2>
        <p className="mt-3">
          Если вы комментировали пост владельца этого экземпляра и хотите,
          чтобы связанные с вами данные были удалены, напишите оператору:{" "}
          {contactLine}. Укажите Instagram-аккаунт, с которого вы
          комментировали ({operatorName} может попросить подтвердить, что
          аккаунт действительно ваш, прежде чем удалять данные).
        </p>
        <p className="mt-3">
          Оператор выполняет удаление командой, встроенной в программу: она
          находит все ваши записи в журнале отправленных сообщений по
          идентификатору или имени пользователя Instagram и удаляет их
          после подтверждения. Команда показывает оператору, что именно
          будет удалено, до того как удаление произойдёт.
        </p>
      </section>

      <section>
        <h2 className="text-xl font-bold text-white">
          Что технически удаляется
        </h2>
        <p className="mt-3">
          Удаляются: строка в журнале отправленных сообщений (ваш
          идентификатор и имя пользователя Instagram, текст комментария,
          статус отправки) и служебная отметка «этот комментарий уже
          обработан» - если с момента комментария прошло больше{" "}
          {metaWindowDays} дней. Если прошло меньше, отметка удаляется
          позже автоматически, как только пройдёт этот срок: удалить её
          раньше значит рискнуть, что программа снова сочтёт ваш комментарий
          новым и отправит повторное сообщение, а не выполнит ваш запрос.
        </p>
        <p className="mt-3">
          Данные о переходах по ссылкам из сообщений не связаны с
          Instagram-аккаунтом или именем пользователя - они хранятся
          обезличенно (хеш IP-адреса, без возможности сопоставить запись с
          конкретным человеком) и удаляются автоматически по истечении
          срока хранения, без участия оператора.
        </p>
      </section>

      <section>
        <h2 className="text-xl font-bold text-white">Сроки и проверка</h2>
        <p className="mt-3">
          Оператор обрабатывает запросы на удаление в разумный срок.
          Оператор вправе попросить подтверждение того, что вы
          действительно владеете указанным Instagram-аккаунтом, прежде чем
          удалять данные, чтобы исключить удаление чужих данных по чужому
          запросу.
        </p>
      </section>

      <section>
        <h2 className="text-xl font-bold text-white">Контакты</h2>
        <p className="mt-3">
          Оператор этого экземпляра: {operatorName}. Связаться по вопросам
          удаления данных: {contactLine}.
        </p>
      </section>
    </LegalShell>
  );
}
