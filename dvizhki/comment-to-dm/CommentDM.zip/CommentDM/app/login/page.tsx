import { ensureOwner } from "@/lib/auth/owner";
import { getCampaignTemplate } from "@/lib/templates/campaign-templates";
import { signInWithPassword } from "@/app/login/actions";

export const metadata = {
  title: "Вход - CommentDM",
  description: "Войди, чтобы управлять автоответами на комментарии Instagram.",
};

// The page bootstraps the owner row and reads the failed-attempt state, so it
// must render per request. Prerendering it would also mean running the
// bootstrap at build time, with no database in reach.
export const dynamic = "force-dynamic";

function errorMessage(
  error: string | undefined,
  retry: string | undefined,
  left: string | undefined
): string | null {
  if (error === "locked") {
    const minutes = Number.parseInt(retry ?? "", 10);
    const window = Number.isFinite(minutes) && minutes > 0 ? minutes : 15;
    return `Слишком много неудачных попыток входа. Попробуй снова примерно через ${window} мин.`;
  }

  if (error === "invalid") {
    const remaining = Number.parseInt(left ?? "", 10);
    if (Number.isFinite(remaining) && remaining > 0) {
      return `Неверный пароль. Осталось попыток: ${remaining} - потом вход заблокируют на время.`;
    }
    return "Неверный пароль.";
  }

  return null;
}

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{
    callbackUrl?: string;
    template?: string;
    error?: string;
    retry?: string;
    left?: string;
  }>;
}) {
  // First render on a fresh install is what creates the owner row and prints
  // the generated password, so the console message is waiting before anyone
  // types anything.
  await ensureOwner();

  const params = await searchParams;
  const selectedTemplate = getCampaignTemplate(params.template);
  const templateCallbackUrl = selectedTemplate
    ? `/campaigns/new?template=${selectedTemplate.slug}`
    : null;
  const callbackUrl = params.callbackUrl ?? templateCallbackUrl ?? "/dashboard";
  const error = errorMessage(params.error, params.retry, params.left);

  return (
    <div className="min-h-screen flex items-center justify-center px-6">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-2xl font-semibold text-foreground">
            CommentDM
          </h1>
          <p className="text-muted text-sm leading-relaxed mt-2">
            {selectedTemplate
              ? `Войди, чтобы использовать шаблон «${selectedTemplate.title}».`
              : "Войди по своему паролю, затем подключи профессиональный аккаунт Instagram."}
          </p>
        </div>

        <div className="panel rounded p-8 shadow-black/40">
          {selectedTemplate && (
            <div className="mb-5 border border-accent/20 bg-accent/10 p-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-accent">
                Шаблон выбран
              </p>
              <p className="mt-2 text-sm font-semibold text-foreground">
                {selectedTemplate.title}
              </p>
            </div>
          )}

          {error && (
            <div
              role="alert"
              className="mb-5 border border-error/30 bg-error/10 p-4 text-sm text-error"
            >
              {error}
            </div>
          )}

          <form action={signInWithPassword} className="space-y-5">
            <input type="hidden" name="callbackUrl" value={callbackUrl} />
            <div className="space-y-2">
              <label
                htmlFor="password"
                className="block text-sm font-medium text-foreground"
              >
                Пароль
              </label>
              <input
                id="password"
                name="password"
                type="password"
                required
                autoComplete="current-password"
                autoFocus
                className="w-full px-4 py-3 rounded bg-surface border border-border text-sm text-foreground placeholder:text-zinc-500 focus:border-accent/40 focus:outline-none transition-colors"
              />
            </div>

            <button
              type="submit"
              className="w-full inline-flex items-center justify-center gap-2 rounded bg-accent px-6 py-3.5 text-sm font-semibold text-white shadow-indigo-500/25 transition-all hover:shadow-indigo-500/30"
            >
              Войти
            </button>
          </form>

          <p className="mt-6 text-xs leading-relaxed text-muted">
            У этой программы один владелец. Пароль был задан переменной
            OWNER_PASSWORD при установке или один раз выведен в консоль
            сервера при первом запуске.
          </p>
        </div>
      </div>
    </div>
  );
}
