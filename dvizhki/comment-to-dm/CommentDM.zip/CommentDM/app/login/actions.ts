"use server";

import { headers } from "next/headers";
import { redirect } from "next/navigation";
import {
  checkLoginRateLimit,
  clearLoginAttempts,
  registerFailedLogin,
} from "@/lib/auth/login-rate-limit";
import { verifyOwnerPassword } from "@/lib/auth/owner";
import { createSessionCookie } from "@/lib/auth/session";
import { getClientIp } from "@/lib/net/client-ip";
import { safeCallbackUrl } from "@/lib/net/safe-callback-url";

export async function signInWithPassword(formData: FormData): Promise<void> {
  const password = String(formData.get("password") ?? "");
  const callbackUrl = safeCallbackUrl(formData.get("callbackUrl"));
  const ip = getClientIp(await headers());

  // Checked before hashing: a locked-out client should not be able to make the
  // server run scrypt.
  const limit = await checkLoginRateLimit(ip);
  if (!limit.allowed) {
    redirect(
      `/login?error=locked&retry=${Math.ceil(limit.retryAfterSeconds / 60)}`
    );
  }

  const ownerId = await verifyOwnerPassword(password);

  if (!ownerId) {
    const failure = await registerFailedLogin(ip);
    if (!failure.allowed) {
      redirect(
        `/login?error=locked&retry=${Math.ceil(failure.retryAfterSeconds / 60)}`
      );
    }
    redirect(`/login?error=invalid&left=${failure.attemptsRemaining}`);
  }

  await clearLoginAttempts(ip);
  await createSessionCookie(ownerId);
  redirect(callbackUrl);
}
