import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CommentDM - автоответы в директ на комментарии Instagram",
  description:
    "Свой сервер для автоответов в директ на комментарии Instagram: человек пишет кодовое слово под постом или рилсом - получает сообщение в директ через официальный API Meta.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" className="h-full dark">
      <body className="min-h-full bg-background text-foreground font-sans antialiased">
        {children}
      </body>
    </html>
  );
}
