import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentWorkspaceId } from "@/lib/auth/session";
import { prisma } from "@/lib/db/client";
import {
  calculateCtr,
  classifyDmStatus,
  normalizeTopKeywords,
} from "@/lib/tracking/analytics";
import { buildTrackedUrl } from "@/lib/tracking/message";
import { generateTrackedLinkSlug } from "@/lib/tracking/server";
import { generateReportShareSlug } from "@/lib/reports/share";
import { getCurrentWorkspaceContext } from "@/lib/workspace-access";
import { MIN_PUBLIC_REPLY_VARIANTS } from "@/lib/automations/policy";

// A public reply is enabled with too few distinct variants to be worth
// sending: it would just repeat the same text under every matching comment.
// Shared by both schemas below so create and update enforce the same floor.
function hasEnoughReplyVariants(messages: string[]): boolean {
  const nonEmpty = messages.map((m) => m.trim()).filter(Boolean);
  return nonEmpty.length >= MIN_PUBLIC_REPLY_VARIANTS;
}

// --- Touch chain (цепочка касаний) --------------------------------------

/** More than this and the chain stops being a follow-up and becomes spam. */
const CHAIN_MAX_STEPS = 6;

/**
 * 23 hours. Meta's messaging window is 24h from the person's last message, so
 * the whole chain has to finish inside it with an hour of slack for retries
 * and polling lag — a step scheduled past the window can only ever fail.
 */
const CHAIN_MAX_TOTAL_DELAY_SECONDS = 82_800;

const chainStepSchema = z.object({
  position: z.number().int().min(0).max(CHAIN_MAX_STEPS - 1),
  delaySeconds: z
    .number()
    .int()
    .min(0, "Задержка шага не может быть отрицательной"),
  message: z
    .string()
    .min(1, "Текст шага не может быть пустым")
    .max(1000, "Текст шага - не длиннее 1000 знаков"),
});

type ChainStepInput = z.infer<typeof chainStepSchema>;

// Positions are the delivery order, so they must be dense and start at 0: a
// gap or a duplicate would leave the dispatcher waiting on a step nobody
// wrote (and a duplicate can't even be stored — see @@unique in the schema).
function chainPositionsAreSequential(steps: ChainStepInput[]): boolean {
  const positions = [...steps.map((s) => s.position)].sort((a, b) => a - b);
  return positions.every((position, index) => position === index);
}

function chainTotalDelaySeconds(steps: ChainStepInput[]): number {
  return steps.reduce((total, step) => total + step.delaySeconds, 0);
}

/**
 * Every JourneyState, listed so the counts in GET always carry all seven keys
 * with an explicit zero. A reader then never has to tell "no journeys in this
 * state" apart from "this state wasn't counted".
 */
const JOURNEY_STATES = [
  "GATE_SENT",
  "ACTIVE",
  "DONE",
  "EXPIRED",
  "STOPPED",
  "SKIPPED",
  "FAILED",
] as const;

type JourneyCounts = Record<(typeof JOURNEY_STATES)[number], number> & {
  total: number;
};

function emptyJourneyCounts(): JourneyCounts {
  const counts = { total: 0 } as JourneyCounts;
  for (const state of JOURNEY_STATES) counts[state] = 0;
  return counts;
}

const CHAIN_SEQUENCE_ERROR =
  "Шаги цепочки должны идти подряд с нуля, без пропусков и повторов";
const CHAIN_WINDOW_ERROR =
  "Вся цепочка должна укладываться в 23 часа - у Meta окно на ответ 24 часа, а шаг за его пределами уже не уйдёт";
const CHAIN_NEEDS_STEPS_ERROR =
  "Цепочка включена, но шагов нет - добавь хотя бы один шаг или выключи цепочку";
// Why this is a hard refusal and not a warning: with buttons in the first
// message the person taps the button instead of writing back, the 24h window
// never opens, and the chain has nowhere to go. Stated in the plan as Б6.
const CHAIN_NO_BUTTONS_ERROR =
  "Цепочка не работает вместе с кнопками-ссылками: первое сообщение должно быть обычным текстом, иначе человек нажмёт кнопку вместо ответа и окно для цепочки не откроется";

// This list is read-your-writes (created/imported campaigns must show up
// immediately), so never cache it at the route or CDN layer.
export const dynamic = "force-dynamic";

// Exported so the safe-defaults + validation behavior can be unit tested
// directly (see __tests__/automations-schema.test.ts) without standing up
// the full request/Prisma/auth pipeline this route otherwise needs.
export const createAutomationSchema = z
  .object({
    name: z.string().min(1).max(100),
    goal: z.string().min(1).max(120).optional().nullable(),
    instagramAccountId: z.string().min(1).optional().nullable(),
    postId: z.string().min(1).optional().nullable(),
    postUrl: z.string().url().optional().nullable(),
    pendingNextReel: z.boolean().optional().default(false),
    matchAnyPost: z.boolean().optional().default(false),
    keywords: z.array(z.string().min(1).max(50)).max(10).optional().default([]),
    matchAnyWord: z.boolean().optional().default(false),
    dmMessage: z.string().min(1).max(1000),
    linkButtonLabel: z.string().max(20).optional().nullable(),
    publicReplyEnabled: z.boolean().optional().default(false),
    publicReplyMessage: z.string().max(1000).optional().nullable(),
    publicReplyMessages: z
      .array(z.string().max(1000))
      .max(10)
      .optional()
      .default([]),
    // Empty string means "no tracked link"; a URL sets one.
    trackedDestinationUrl: z
      .union([z.string().url(), z.literal("")])
      .optional()
      .nullable(),
    // Optional second tracked link, rendered as a second DM button.
    secondaryDestinationUrl: z
      .union([z.string().url(), z.literal("")])
      .optional()
      .nullable(),
    secondaryButtonLabel: z.string().max(20).optional().nullable(),
    isActive: z.boolean().optional().default(true),
    wholeWordMatch: z.boolean().optional().default(true),
    chainEnabled: z.boolean().optional().default(false),
    chainSteps: z
      .array(chainStepSchema)
      .max(CHAIN_MAX_STEPS, `В цепочке максимум ${CHAIN_MAX_STEPS} шагов`)
      .optional()
      .default([]),
  })
  // A campaign must target a specific post, any post, or the next reel.
  .refine(
    (d) => d.matchAnyPost || d.pendingNextReel || Boolean(d.postId),
    { message: "Выбери, какие посты запускают кампанию", path: ["postId"] }
  )
  // And it must match either specific words or any word.
  .refine((d) => d.matchAnyWord || d.keywords.length >= 1, {
    message: "Добавь хотя бы одно ключевое слово или выбери «любое слово»",
    path: ["keywords"],
  })
  // Public reply, when turned on, needs enough variants that replies don't
  // all read identically under the post — see lib/automations/policy.ts.
  .refine(
    (d) => {
      if (!d.publicReplyEnabled) return true;
      const list =
        d.publicReplyMessages.length > 0
          ? d.publicReplyMessages
          : d.publicReplyMessage
            ? [d.publicReplyMessage]
            : [];
      return hasEnoughReplyVariants(list);
    },
    {
      message: `Добавь минимум ${MIN_PUBLIC_REPLY_VARIANTS} разных варианта публичного ответа, чтобы они не выглядели одинаково`,
      path: ["publicReplyMessages"],
    }
  )
  .refine((d) => chainPositionsAreSequential(d.chainSteps), {
    message: CHAIN_SEQUENCE_ERROR,
    path: ["chainSteps"],
  })
  .refine(
    (d) => chainTotalDelaySeconds(d.chainSteps) <= CHAIN_MAX_TOTAL_DELAY_SECONDS,
    { message: CHAIN_WINDOW_ERROR, path: ["chainSteps"] }
  )
  .refine((d) => !d.chainEnabled || d.chainSteps.length >= 1, {
    message: CHAIN_NEEDS_STEPS_ERROR,
    path: ["chainSteps"],
  })
  // The buttons refusal (Б6) is enforced here for create and again in PATCH
  // against the links already in the database, so a chain can never be turned
  // on for a campaign that still has buttons in its first message.
  .refine(
    (d) => !d.chainEnabled || (!d.trackedDestinationUrl && !d.secondaryDestinationUrl),
    { message: CHAIN_NO_BUTTONS_ERROR, path: ["chainEnabled"] }
  );

export const updateAutomationSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  goal: z.string().min(1).max(120).optional().nullable(),
  postId: z.string().min(1).optional().nullable(),
  postUrl: z.string().url().optional().nullable(),
  pendingNextReel: z.boolean().optional(),
  matchAnyPost: z.boolean().optional(),
  keywords: z.array(z.string().min(1).max(50)).max(10).optional(),
  matchAnyWord: z.boolean().optional(),
  dmMessage: z.string().min(1).max(1000).optional(),
  linkButtonLabel: z.string().max(20).optional().nullable(),
  publicReplyEnabled: z.boolean().optional(),
  publicReplyMessage: z.string().max(1000).optional().nullable(),
  publicReplyMessages: z.array(z.string().max(1000)).max(10).optional(),
  isActive: z.boolean().optional(),
  wholeWordMatch: z.boolean().optional(),
  reportShareEnabled: z.boolean().optional(),
  chainEnabled: z.boolean().optional(),
  // Undefined leaves the stored chain alone; an array replaces it wholesale
  // (see PATCH — deleteMany + createMany in one transaction).
  chainSteps: z
    .array(chainStepSchema)
    .max(CHAIN_MAX_STEPS, `В цепочке максимум ${CHAIN_MAX_STEPS} шагов`)
    .optional(),
  // Empty string clears the tracked link; a URL updates/creates it; undefined
  // leaves it unchanged.
  trackedDestinationUrl: z
    .union([z.string().url(), z.literal("")])
    .optional()
    .nullable(),
  // Same semantics for the optional second tracked link / DM button.
  secondaryDestinationUrl: z
    .union([z.string().url(), z.literal("")])
    .optional()
    .nullable(),
  secondaryButtonLabel: z.string().max(20).optional().nullable(),
})
  // Same floor as create, but only enforceable when the request actually
  // supplies the variants list alongside enabling it — a partial update that
  // only flips publicReplyEnabled without touching publicReplyMessages is
  // left alone here (the existing DB row's own list was already validated
  // when it was written).
  .refine(
    (d) => {
      if (d.publicReplyEnabled !== true) return true;
      if (d.publicReplyMessages === undefined) return true;
      return hasEnoughReplyVariants(d.publicReplyMessages);
    },
    {
      message: `Добавь минимум ${MIN_PUBLIC_REPLY_VARIANTS} разных варианта публичного ответа, чтобы они не выглядели одинаково`,
      path: ["publicReplyMessages"],
    }
  )
  .refine(
    (d) => d.chainSteps === undefined || chainPositionsAreSequential(d.chainSteps),
    { message: CHAIN_SEQUENCE_ERROR, path: ["chainSteps"] }
  )
  .refine(
    (d) =>
      d.chainSteps === undefined ||
      chainTotalDelaySeconds(d.chainSteps) <= CHAIN_MAX_TOTAL_DELAY_SECONDS,
    { message: CHAIN_WINDOW_ERROR, path: ["chainSteps"] }
  )
  // Only enforceable here when the request supplies the steps alongside the
  // switch. A partial update that flips chainEnabled on its own is checked by
  // the PATCH handler against the steps already stored — same rule, but it
  // needs the database to answer it.
  .refine(
    (d) => d.chainEnabled !== true || d.chainSteps === undefined || d.chainSteps.length >= 1,
    { message: CHAIN_NEEDS_STEPS_ERROR, path: ["chainSteps"] }
  )
  .refine(
    (d) =>
      d.chainEnabled !== true ||
      (!d.trackedDestinationUrl && !d.secondaryDestinationUrl),
    { message: CHAIN_NO_BUTTONS_ERROR, path: ["chainEnabled"] }
  );

export async function GET(request: NextRequest) {
  const workspaceId = await getCurrentWorkspaceId();
  if (!workspaceId) {
    return NextResponse.json(
      { success: false, error: "Не авторизован" },
      { status: 401 }
    );
  }
  const instagramAccountId =
    request.nextUrl.searchParams.get("instagramAccountId");
  const accountFilter =
    instagramAccountId && instagramAccountId !== "all"
      ? { instagramAccountId }
      : {};

  const automations = await prisma.automation.findMany({
    where: { workspaceId, ...accountFilter },
    include: {
      instagramAccount: {
        select: { username: true, instagramId: true },
      },
      _count: {
        select: { dmLogs: true },
      },
      trackedLinks: {
        select: {
          id: true,
          slug: true,
          label: true,
          destinationUrl: true,
          _count: { select: { clicks: true } },
        },
        orderBy: { createdAt: "asc" },
      },
      // The builder reads the chain back from here when it opens a campaign
      // for editing — without it, saving would write an empty chain over a
      // real one. Ordered, because position is the delivery order.
      chainSteps: {
        select: {
          id: true,
          position: true,
          delaySeconds: true,
          message: true,
        },
        orderBy: { position: "asc" },
      },
    },
    orderBy: { createdAt: "desc" },
  });

  const automationsWithReports = await Promise.all(
    automations.map(async (automation) => {
      if (automation.reportShareSlug) return automation;

      const updated = await prisma.automation.update({
        where: { id: automation.id },
        data: { reportShareSlug: generateReportShareSlug() },
        select: { reportShareSlug: true },
      });

      return {
        ...automation,
        reportShareSlug: updated.reportShareSlug,
      };
    })
  );

  const [statusCounts, clickCounts, keywordCounts, journeyCounts] =
    await Promise.all([
      prisma.dmLog.groupBy({
        by: ["automationId", "status"],
        where: { workspaceId },
        _count: { _all: true },
      }),
      prisma.linkClick.groupBy({
        by: ["automationId"],
        where: { workspaceId },
        _count: { _all: true },
      }),
      prisma.dmLog.groupBy({
        by: ["automationId", "matchedKeyword"],
        where: { workspaceId, matchedKeyword: { not: null } },
        _count: { _all: true },
      }),
      // One grouped query for the whole list, not one per campaign: the chain
      // panel shows these counts for every card at once.
      prisma.subscriberJourney.groupBy({
        by: ["automationId", "state"],
        where: { workspaceId },
        _count: { _all: true },
      }),
    ]);

  const analytics = new Map<
    string,
    {
      sent: number;
      skipped: number;
      failed: number;
      clicks: number;
      topKeywords: { keyword: string; count: number }[];
    }
  >();

  const journeys = new Map<string, JourneyCounts>();

  for (const automation of automationsWithReports) {
    analytics.set(automation.id, {
      sent: 0,
      skipped: 0,
      failed: 0,
      clicks: 0,
      topKeywords: [],
    });
    journeys.set(automation.id, emptyJourneyCounts());
  }

  for (const row of journeyCounts) {
    const item = journeys.get(row.automationId);
    if (!item) continue;
    const count = row._count._all;
    item[row.state] += count;
    item.total += count;
  }

  for (const row of statusCounts) {
    const item = analytics.get(row.automationId);
    if (!item) continue;
    // Тот же разбор статуса, что у дашборда (lib/tracking/analytics.ts), а не
    // своя копия условий: копия уже разъехалась - здесь стояло
    // `=== "FAILED"`, и терминальный отказ FAILED_PERMANENT не попадал НИ В
    // ОДНУ корзину карточки, хотя дашборд на той же установке считал его
    // префиксом. Владелец видел две разные цифры «не дошло» на одном экране.
    const bucket = classifyDmStatus(row.status);
    if (bucket) item[bucket] += row._count._all;
  }

  for (const row of clickCounts) {
    const item = analytics.get(row.automationId);
    if (item) item.clicks = row._count._all;
  }

  for (const automation of automationsWithReports) {
    const item = analytics.get(automation.id);
    if (!item) continue;
    item.topKeywords = normalizeTopKeywords(
      keywordCounts
        .filter((row) => row.automationId === automation.id)
        .map((row) => ({
          matchedKeyword: row.matchedKeyword,
          _count: row._count._all,
        })),
      3
    );
  }

  return NextResponse.json(
    {
    success: true,
    data: automationsWithReports.map((automation) => {
      const item = analytics.get(automation.id) ?? {
        sent: 0,
        skipped: 0,
        failed: 0,
        clicks: 0,
        topKeywords: [],
      };

      return {
        ...automation,
        trackedLinks: automation.trackedLinks.map((link) => ({
          ...link,
          trackedUrl: buildTrackedUrl(link.slug),
        })),
        analytics: {
          ...item,
          ctr: calculateCtr(item.clicks, item.sent),
        },
        // How many people are in this campaign's chain and where they stand.
        journeys: journeys.get(automation.id) ?? emptyJourneyCounts(),
      };
    }),
    },
    { headers: { "Cache-Control": "no-store" } }
  );
}

export async function POST(request: NextRequest) {
  const context = await getCurrentWorkspaceContext();
  if (!context) {
    return NextResponse.json(
      { success: false, error: "Не авторизован" },
      { status: 401 }
    );
  }

  const workspaceId = context.workspaceId;

  const body = await request.json();
  const parsed = createAutomationSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      {
        success: false,
        error: "Некорректные данные",
        details: parsed.error.flatten(),
      },
      { status: 400 }
    );
  }

  const requestedInstagramAccountId =
    parsed.data.instagramAccountId && parsed.data.instagramAccountId !== "all"
      ? parsed.data.instagramAccountId
      : null;

  const [workspace, instagramAccount] = await Promise.all([
    prisma.workspace.findUnique({
      where: { id: workspaceId },
      select: { id: true },
    }),
    requestedInstagramAccountId
      ? prisma.instagramAccount.findFirst({
          where: { id: requestedInstagramAccountId, workspaceId },
        })
      : prisma.instagramAccount.findFirst({
          where: { workspaceId },
          orderBy: { connectedAt: "desc" },
        }),
  ]);

  if (!workspace) {
    return NextResponse.json(
      { success: false, error: "Рабочее пространство не найдено" },
      { status: 404 }
    );
  }

  if (!instagramAccount) {
    return NextResponse.json(
      { success: false, error: "Сначала подключи Instagram, потом можно создавать кампании" },
      { status: 400 }
    );
  }

  const { trackedDestinationUrl, secondaryDestinationUrl, secondaryButtonLabel } =
    parsed.data;

  // The primary link's button title comes from `linkButtonLabel`; the second
  // link stores its own button title in the tracked link's `label` field.
  const linkCreates: {
    workspaceId: string;
    slug: string;
    label: string;
    destinationUrl: string;
  }[] = [];
  if (trackedDestinationUrl) {
    linkCreates.push({
      workspaceId,
      slug: generateTrackedLinkSlug(),
      label: "Основная ссылка кампании",
      destinationUrl: trackedDestinationUrl,
    });
  }
  if (secondaryDestinationUrl) {
    linkCreates.push({
      workspaceId,
      slug: generateTrackedLinkSlug(),
      label: secondaryButtonLabel?.trim() || "Открыть ссылку",
      destinationUrl: secondaryDestinationUrl,
    });
  }

  const { pendingNextReel, matchAnyPost, matchAnyWord } = parsed.data;
  // A post is only stored for the "specific post" trigger.
  const isSpecificPost = !pendingNextReel && !matchAnyPost;
  const publicReplyList = (
    parsed.data.publicReplyMessages.length > 0
      ? parsed.data.publicReplyMessages
      : parsed.data.publicReplyMessage
        ? [parsed.data.publicReplyMessage]
        : []
  )
    .map((m) => m.trim())
    .filter(Boolean);

  const automation = await prisma.automation.create({
    data: {
      name: parsed.data.name,
      goal: parsed.data.goal,
      // A next-reel campaign has no post yet; the cron binds it once a reel is posted.
      postId: isSpecificPost ? parsed.data.postId : null,
      postUrl: isSpecificPost ? parsed.data.postUrl : null,
      pendingNextReel,
      matchAnyPost,
      keywords: matchAnyWord ? [] : parsed.data.keywords,
      matchAnyWord,
      dmMessage: parsed.data.dmMessage,
      linkButtonLabel: parsed.data.linkButtonLabel || null,
      publicReplyEnabled: parsed.data.publicReplyEnabled,
      publicReplyMessages: parsed.data.publicReplyEnabled
        ? publicReplyList
        : [],
      publicReplyMessage: parsed.data.publicReplyEnabled
        ? publicReplyList[0] ?? parsed.data.publicReplyMessage ?? null
        : null,
      isActive: parsed.data.isActive,
      wholeWordMatch: parsed.data.wholeWordMatch,
      chainEnabled: parsed.data.chainEnabled,
      workspaceId,
      instagramAccountId: instagramAccount.id,
      reportShareSlug: generateReportShareSlug(),
      ...(linkCreates.length > 0
        ? { trackedLinks: { create: linkCreates } }
        : {}),
      // Nested create so the campaign and its chain land in one statement —
      // there is no moment where a chain campaign exists with no steps.
      ...(parsed.data.chainSteps.length > 0
        ? {
            chainSteps: {
              create: parsed.data.chainSteps.map((step) => ({
                position: step.position,
                delaySeconds: step.delaySeconds,
                message: step.message,
              })),
            },
          }
        : {}),
    },
    include: {
      trackedLinks: true,
      chainSteps: { orderBy: { position: "asc" } },
    },
  });

  return NextResponse.json(
    { success: true, data: automation },
    { status: 201 }
  );
}

export async function PATCH(request: NextRequest) {
  const context = await getCurrentWorkspaceContext();
  if (!context) {
    return NextResponse.json(
      { success: false, error: "Не авторизован" },
      { status: 401 }
    );
  }

  const workspaceId = context.workspaceId;

  const automationId = request.nextUrl.searchParams.get("id");
  if (!automationId) {
    return NextResponse.json(
      { success: false, error: "Не указан ID кампании" },
      { status: 400 }
    );
  }

  const body = await request.json();
  const parsed = updateAutomationSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      {
        success: false,
        error: "Некорректные данные",
        details: parsed.error.flatten(),
      },
      { status: 400 }
    );
  }

  const existing = await prisma.automation.findFirst({
    where: { id: automationId, workspaceId },
  });

  if (!existing) {
    return NextResponse.json(
      { success: false, error: "Кампания не найдена" },
      { status: 404 }
    );
  }

  // chainSteps is pulled out by hand alongside the tracked-link fields: none
  // of them are columns on Automation, and the spread below goes straight into
  // prisma.automation.update.
  const {
    trackedDestinationUrl,
    secondaryDestinationUrl,
    secondaryButtonLabel,
    chainSteps,
    ...automationData
  } = parsed.data;

  // The chain rules that need the database to answer them. The schema already
  // refused a request that sends the switch and the offending data together;
  // this catches the partial update that only flips the switch.
  const chainWillBeOn = automationData.chainEnabled ?? existing.chainEnabled;

  if (chainWillBeOn) {
    const stepCount =
      chainSteps !== undefined
        ? chainSteps.length
        : await prisma.sequenceStep.count({ where: { automationId } });

    if (stepCount === 0) {
      return NextResponse.json(
        { success: false, error: CHAIN_NEEDS_STEPS_ERROR },
        { status: 400 }
      );
    }

    // Buttons already stored count too — unless this same request clears them.
    const storedLinks = await prisma.trackedLink.findMany({
      where: { automationId },
      orderBy: { createdAt: "asc" },
      select: { id: true },
    });
    const clearedCount =
      (trackedDestinationUrl === "" && storedLinks.length > 0 ? 1 : 0) +
      (secondaryDestinationUrl === "" && storedLinks.length > 1 ? 1 : 0);

    if (storedLinks.length - clearedCount > 0) {
      return NextResponse.json(
        { success: false, error: CHAIN_NO_BUTTONS_ERROR },
        { status: 400 }
      );
    }
  }

  // Keep dependent fields consistent: any-word clears keywords.
  if (automationData.matchAnyWord === true) automationData.keywords = [];
  // Any-post / next-reel campaigns carry no specific post.
  if (automationData.matchAnyPost === true || automationData.pendingNextReel === true) {
    automationData.postId = null;
    automationData.postUrl = null;
  }
  // Keep the public-reply variations list and the legacy single field in sync.
  if (automationData.publicReplyMessages !== undefined) {
    const list = automationData.publicReplyMessages
      .map((m) => m.trim())
      .filter(Boolean);
    automationData.publicReplyMessages = list;
    automationData.publicReplyMessage = list[0] ?? null;
  }
  if (automationData.publicReplyEnabled === false) {
    automationData.publicReplyMessages = [];
    automationData.publicReplyMessage = null;
  }

  // A chain is replaced whole, never patched row by row: positions are unique
  // per campaign, so renumbering in place would collide with the rows still
  // there. deleteMany + createMany inside one transaction means a reader never
  // sees a half-written chain, and a failure leaves the old one intact.
  const updated =
    chainSteps === undefined
      ? await prisma.automation.update({
          where: { id: automationId },
          data: automationData,
          include: { chainSteps: { orderBy: { position: "asc" } } },
        })
      : await prisma.$transaction(async (tx) => {
          await tx.sequenceStep.deleteMany({ where: { automationId } });
          if (chainSteps.length > 0) {
            await tx.sequenceStep.createMany({
              data: chainSteps.map((step) => ({
                automationId,
                position: step.position,
                delaySeconds: step.delaySeconds,
                message: step.message,
              })),
            });
          }
          return tx.automation.update({
            where: { id: automationId },
            data: automationData,
            include: { chainSteps: { orderBy: { position: "asc" } } },
          });
        });

  // Update, create, or clear the campaign's primary tracked link when a
  // destination URL was supplied. `undefined` means "leave it alone".
  if (trackedDestinationUrl !== undefined && trackedDestinationUrl !== null) {
    const primaryLink = await prisma.trackedLink.findFirst({
      where: { automationId },
      orderBy: { createdAt: "asc" },
    });

    if (trackedDestinationUrl === "") {
      if (primaryLink) {
        await prisma.trackedLink.delete({ where: { id: primaryLink.id } });
      }
    } else if (primaryLink) {
      await prisma.trackedLink.update({
        where: { id: primaryLink.id },
        data: { destinationUrl: trackedDestinationUrl },
      });
    } else {
      await prisma.trackedLink.create({
        data: {
          workspaceId,
          automationId,
          slug: generateTrackedLinkSlug(),
          label: "Основная ссылка кампании",
          destinationUrl: trackedDestinationUrl,
        },
      });
    }
  }

  // Update, create, or clear the campaign's second tracked link. It is always
  // the link at index [1] (ordered by createdAt), and its `label` holds the
  // second button's title.
  if (secondaryDestinationUrl !== undefined && secondaryDestinationUrl !== null) {
    const links = await prisma.trackedLink.findMany({
      where: { automationId },
      orderBy: { createdAt: "asc" },
    });
    const secondaryLink = links[1];
    const secondaryLabel = secondaryButtonLabel?.trim() || "Открыть ссылку";

    if (secondaryDestinationUrl === "") {
      if (secondaryLink) {
        await prisma.trackedLink.delete({ where: { id: secondaryLink.id } });
      }
    } else if (secondaryLink) {
      await prisma.trackedLink.update({
        where: { id: secondaryLink.id },
        data: { destinationUrl: secondaryDestinationUrl, label: secondaryLabel },
      });
    } else {
      await prisma.trackedLink.create({
        data: {
          workspaceId,
          automationId,
          slug: generateTrackedLinkSlug(),
          label: secondaryLabel,
          destinationUrl: secondaryDestinationUrl,
        },
      });
    }
  }

  return NextResponse.json({ success: true, data: updated });
}

export async function DELETE(request: NextRequest) {
  const context = await getCurrentWorkspaceContext();
  if (!context) {
    return NextResponse.json(
      { success: false, error: "Не авторизован" },
      { status: 401 }
    );
  }

  const workspaceId = context.workspaceId;

  const automationId = request.nextUrl.searchParams.get("id");
  if (!automationId) {
    return NextResponse.json(
      { success: false, error: "Не указан ID кампании" },
      { status: 400 }
    );
  }

  const existing = await prisma.automation.findFirst({
    where: { id: automationId, workspaceId },
  });

  if (!existing) {
    return NextResponse.json(
      { success: false, error: "Кампания не найдена" },
      { status: 404 }
    );
  }

  await prisma.automation.delete({ where: { id: automationId } });

  return NextResponse.json({ success: true, data: { deleted: true } });
}
