import { NextResponse } from "next/server";
import { runFullHealthCheck } from "@/lib/ops/health-checks";

export const runtime = "nodejs";
// Health must reflect live state (worker heartbeat, queue depth), never a
// cached response, or it reports stale worker start times.
export const dynamic = "force-dynamic";

/**
 * Public, unauthenticated by design (curl'd by Meta / uptime monitors — see
 * F1). That is exactly why it answers with nothing but a status word: error
 * text, queue counts, and worker heartbeats are infrastructure detail that
 * hands a stranger a map of what to attack. The same checks with the actual
 * detail are behind the owner's session at GET /api/admin/diagnostics.
 */
export async function GET() {
  const { healthy } = await runFullHealthCheck();

  return NextResponse.json(
    { status: healthy ? "ok" : "degraded" },
    { status: healthy ? 200 : 503 }
  );
}
