/**
 * Change Owner Password
 *
 * The normal, in-app way to rotate the owner password (see the settings
 * page). Requires a valid session and the current password — this is not a
 * recovery path for a genuinely lost password; that's
 * scripts/reset-owner-password.ts, run on the server itself.
 *
 * On success the current session is kept (the caller just proved they know
 * the new password by knowing the old one), but every OTHER session is
 * invalidated by rotating the session token secret's dependent — see
 * lib/auth/owner.ts's changeOwnerPassword, which only touches the password
 * hash; a stolen cookie from before the change stays valid until it expires
 * on its own (30 days). That's a known, accepted trade-off for a
 * single-owner tool with no session list to revoke from — see
 * lib/auth/session-token.ts.
 */

import { NextRequest, NextResponse } from "next/server";
import { changeOwnerPassword } from "@/lib/auth/owner";
import { getCurrentUser } from "@/lib/auth/session";

export async function POST(request: NextRequest) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json(
      { success: false, error: "Не авторизован" },
      { status: 401 }
    );
  }

  const body = await request.json().catch(() => ({}));
  const currentPassword =
    typeof body.currentPassword === "string" ? body.currentPassword : "";
  const newPassword =
    typeof body.newPassword === "string" ? body.newPassword : "";

  if (!currentPassword || !newPassword) {
    return NextResponse.json(
      { success: false, error: "Заполни оба поля" },
      { status: 400 }
    );
  }

  const result = await changeOwnerPassword(currentPassword, newPassword);
  if (!result.ok) {
    return NextResponse.json(
      { success: false, error: result.reason },
      { status: 400 }
    );
  }

  return NextResponse.json({ success: true });
}
