/**
 * Sign Out
 *
 * Clears the session cookie and sends the browser back to the login form.
 *
 * GET is here on purpose, not just POST: it is the escape hatch for a cookie
 * whose user row no longer exists (a self-hoster who reset the database while
 * still holding a valid signed cookie). The dashboard layout redirects here
 * instead of straight to /login, which the proxy would bounce back — a loop.
 */

import { NextRequest, NextResponse } from "next/server";
import { sessionCookieOptions } from "@/lib/auth/session-cookie";

function signOutResponse(request: NextRequest): NextResponse {
  // 303 so a form POST turns into a GET on /login.
  const response = NextResponse.redirect(new URL("/login", request.url), 303);
  response.cookies.set({ ...sessionCookieOptions(0), value: "" });
  return response;
}

export async function POST(request: NextRequest) {
  return signOutResponse(request);
}

export async function GET(request: NextRequest) {
  return signOutResponse(request);
}
