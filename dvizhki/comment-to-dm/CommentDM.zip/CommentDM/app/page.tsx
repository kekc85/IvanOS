import { redirect } from "next/navigation";

// The marketing site that used to live here is gone: this build ships to one
// person who already knows what it is. The root path just sends them into
// the app — the dashboard layout itself bounces to /login if there is no
// session.
export default function RootPage() {
  redirect("/dashboard");
}
