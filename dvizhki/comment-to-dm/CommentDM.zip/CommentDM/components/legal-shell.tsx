import Link from "next/link";

interface LegalShellProps {
  title: string;
  description: string;
  /** Full, already-formatted line — the shell does not prepend anything of
   * its own, so a caller writing for a non-Russian audience (see
   * app/meta-review/page.tsx) can supply an English line without ending up
   * with a mixed-language sentence. */
  updatedAt: string;
  /** Defaults to Russian — every real subscriber-facing legal page
   * (/privacy, /terms, /data-deletion) is Russian. app/meta-review/page.tsx
   * is the one exception (its audience is Meta's App Review team, not a
   * subscriber) and passes "Sign in" explicitly. */
  signInLabel?: string;
  children: React.ReactNode;
}

export default function LegalShell({
  title,
  description,
  updatedAt,
  signInLabel = "Войти",
  children,
}: LegalShellProps) {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <header className="border-b border-white/10">
        <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-5">
          <Link href="/" className="flex items-center gap-3">
            <span className="text-lg font-bold text-white">commentdm</span>
          </Link>
          <Link
            href="/login"
            className="text-sm font-semibold text-zinc-300 transition hover:text-white"
          >
            {signInLabel}
          </Link>
        </div>
      </header>

      <article className="mx-auto max-w-3xl px-5 py-14">
        <p className="text-sm font-semibold uppercase text-cyan-200">
          {updatedAt}
        </p>
        <h1 className="mt-4 text-4xl font-black text-white sm:text-5xl">
          {title}
        </h1>
        <p className="mt-5 text-base leading-8 text-zinc-300">{description}</p>
        <div className="mt-10 space-y-8 text-sm leading-7 text-zinc-300">
          {children}
        </div>
      </article>
    </main>
  );
}
