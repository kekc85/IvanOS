/**
 * Status label for DM status. Plain text; color carries the state.
 */

const statusConfig: Record<string, { text: string; label: string }> = {
  SENT: { text: "text-success", label: "Отправлено" },
  FAILED: { text: "text-error", label: "Ошибка" },
  // Отдельная подпись, а не «Ошибка»: разница для владельца не в тяжести, а в
  // том, ждать ли повтора. Тут ждать нечего - см. lib/queue/send-failure.ts.
  FAILED_PERMANENT: { text: "text-error", label: "Отправить нельзя" },
  PENDING: { text: "text-warning", label: "Ожидает" },
  SKIPPED_DEDUP: { text: "text-muted", label: "Дубликат" },
  SKIPPED_RATE_LIMIT: { text: "text-warning", label: "Лимит запросов" },
  SKIPPED_PLAN_LIMIT: { text: "text-warning", label: "Пропущено" },
  SKIPPED_NO_MATCH: { text: "text-muted", label: "Нет совпадения" },
};

interface StatusBadgeProps {
  status: string;
}

export default function StatusBadge({ status }: StatusBadgeProps) {
  const config = statusConfig[status] ?? statusConfig.PENDING;

  return (
    <span className={`shrink-0 whitespace-nowrap text-sm ${config.text}`}>
      {config.label}
    </span>
  );
}
