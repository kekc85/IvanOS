"use client";

/**
 * Campaign Builder
 *
 * Two-pane campaign editor: a control panel on the left and a live phone
 * preview on the right. Used for both creating and editing a campaign.
 *
 * A campaign is trigger scope (specific / any / next post), match mode
 * (specific words / any word), the DM text with its tracked link buttons, and
 * the public reply.
 */

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import AccountSelect, { type AccountOption } from "@/components/account-select";
import PostPicker from "@/components/post-picker";
import CampaignPreview, { type PreviewTab } from "@/components/campaign-preview";
import { readCache, writeCache } from "@/lib/client-cache";
import {
  IMPORT_QUEUE_KEY,
  IMPORT_ACCOUNT_KEY,
  type ImportRow,
} from "@/lib/import-queue";
import { MIN_PUBLIC_REPLY_VARIANTS } from "@/lib/automations/policy";
import {
  CHAIN_MAX_STEPS,
  CHAIN_MAX_TOTAL_DELAY_SECONDS,
  CHAIN_STEP_MAX_LENGTH,
  type ChainStepDraft,
  type ChainStepPayload,
  type DelayUnit,
  buildChainStepsPayload,
  chainStepLabel,
  emptyChainStepDraft,
  formatDurationShort,
  stepsToDrafts,
  totalChainDelaySeconds,
  validateChainDrafts,
} from "@/components/chain-utils";

type TriggerScope = "specific" | "any" | "next";
type MatchMode = "specific" | "any";

interface LoadedCampaign {
  id: string;
  name: string;
  postId: string | null;
  postUrl: string | null;
  pendingNextReel: boolean;
  matchAnyPost: boolean;
  keywords: string[];
  matchAnyWord: boolean;
  dmMessage: string;
  linkButtonLabel: string | null;
  publicReplyEnabled: boolean;
  publicReplyMessage: string | null;
  publicReplyMessages: string[];
  isActive: boolean;
  instagramAccountId: string;
  trackedLinks?: { destinationUrl: string; label?: string | null }[];
  chainEnabled?: boolean;
  chainSteps?: ChainStepPayload[];
}

interface CampaignBuilderProps {
  mode: "new" | "edit";
  campaignId?: string;
}

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-3">
      <h2 className="text-sm font-semibold text-foreground">{title}</h2>
      {children}
    </div>
  );
}

function Radio({
  checked,
  onSelect,
  children,
}: {
  checked: boolean;
  onSelect: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      className={`flex w-full items-center gap-3 rounded-lg border px-3 py-2.5 text-left text-sm transition-colors ${
        checked ? "border-accent bg-accent/5" : "border-border hover:border-border-hover"
      }`}
    >
      <span
        className={`grid h-4 w-4 shrink-0 place-items-center rounded-full border ${
          checked ? "border-accent" : "border-zinc-500"
        }`}
      >
        {checked && <span className="h-2 w-2 rounded-full bg-accent" />}
      </span>
      <span className="flex-1 text-foreground">{children}</span>
    </button>
  );
}

function Toggle({
  on,
  onToggle,
}: {
  on: boolean;
  onToggle: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onToggle}
      className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${
        on ? "bg-accent" : "bg-zinc-300"
      }`}
    >
      <span
        className={`absolute top-1 h-4 w-4 rounded-full bg-white transition-transform ${
          on ? "left-6" : "left-1"
        }`}
      />
    </button>
  );
}

export default function CampaignBuilder({ mode, campaignId }: CampaignBuilderProps) {
  const router = useRouter();

  const [loading, setLoading] = useState(mode === "edit");
  const [notFound, setNotFound] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [name, setName] = useState("");
  const [accounts, setAccounts] = useState<AccountOption[]>([]);
  const [selectedAccountId, setSelectedAccountId] = useState("");

  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [isActive, setIsActive] = useState(true);

  const [triggerScope, setTriggerScope] = useState<TriggerScope>("specific");
  const [postId, setPostId] = useState<string | null>(null);
  const [postUrl, setPostUrl] = useState<string | null>(null);
  const [postThumb, setPostThumb] = useState<string | null>(null);
  const [postCaption, setPostCaption] = useState("");

  // Post IDs already tied to another automation on this account, so the picker
  // can flag them and the user knows not to double-assign. Maps postId ->
  // the campaign name using it (for the tooltip).
  const [usedPosts, setUsedPosts] = useState<Record<string, string>>({});

  const [matchMode, setMatchMode] = useState<MatchMode>("specific");
  const [keywordText, setKeywordText] = useState("");

  const [publicReplyEnabled, setPublicReplyEnabled] = useState(false);
  const [publicReplyMessages, setPublicReplyMessages] = useState<string[]>([""]);

  const [dmMessage, setDmMessage] = useState("");
  const [linkOpen, setLinkOpen] = useState(false);
  const [trackedDestinationUrl, setTrackedDestinationUrl] = useState("");
  const [linkButtonLabel, setLinkButtonLabel] = useState("Открыть ссылку");
  const [secondLinkOpen, setSecondLinkOpen] = useState(false);
  const [secondaryDestinationUrl, setSecondaryDestinationUrl] = useState("");
  const [secondaryButtonLabel, setSecondaryButtonLabel] = useState("Открыть ссылку");

  // Touch chain. Off by default, so a campaign built the old way keeps the old
  // single-DM form exactly as it was.
  const [chainEnabled, setChainEnabled] = useState(false);
  const [chainSteps, setChainSteps] = useState<ChainStepDraft[]>([]);

  const [previewTab, setPreviewTab] = useState<PreviewTab>("dm");

  // CSV import queue. When present, each save advances to the next row instead
  // of returning to the campaigns list.
  const [importQueue, setImportQueue] = useState<ImportRow[] | null>(null);
  const [importTotal, setImportTotal] = useState(0);

  const keywords = useMemo(
    () =>
      keywordText
        .split(",")
        .map((k) => k.trim())
        .filter(Boolean),
    [keywordText]
  );

  // Fetch the connected account's real avatar for the preview (cache-first so
  // it shows instantly on a return visit instead of a blank circle).
  useEffect(() => {
    if (!selectedAccountId) return;
    let cancelled = false;
    const cacheKey = `ig-avatar:${selectedAccountId}`;
    const cached = readCache<string | null>(cacheKey, 30 * 60 * 1000);
    // Hydrating state from cache is a legitimate effect use here.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (cached.data !== null) setAvatarUrl(cached.data);

    const params = new URLSearchParams({ instagramAccountId: selectedAccountId });
    fetch(`/api/instagram/profile?${params}`)
      .then((r) => r.json())
      .then((d) => {
        if (cancelled) return;
        const url = d.success ? d.data.profilePictureUrl ?? null : null;
        setAvatarUrl(url);
        writeCache(cacheKey, url);
      })
      .catch(() => {
        if (!cancelled && cached.data === null) setAvatarUrl(null);
      });
    return () => {
      cancelled = true;
    };
  }, [selectedAccountId]);

  // Load accounts (both modes need them for the preview username + selector).
  useEffect(() => {
    fetch("/api/dashboard/stats")
      .then((r) => r.json())
      .then((payload) => {
        if (!payload.success) return;
        const next: AccountOption[] = payload.data.instagramAccounts ?? [];
        setAccounts(next);
        setSelectedAccountId(
          (prev) => prev || payload.data.selectedInstagramAccountId || next[0]?.id || ""
        );
      })
      .catch(() => setAccounts([]));
  }, []);

  // Prefill when editing.
  useEffect(() => {
    if (mode !== "edit" || !campaignId) return;
    fetch("/api/automations", { cache: "no-store" })
      .then((r) => r.json())
      .then((payload) => {
        if (!payload.success) return setNotFound(true);
        const c = (payload.data as LoadedCampaign[]).find((x) => x.id === campaignId);
        if (!c) return setNotFound(true);
        setName(c.name);
        setSelectedAccountId(c.instagramAccountId);
        setTriggerScope(
          c.matchAnyPost ? "any" : c.pendingNextReel ? "next" : "specific"
        );
        setPostId(c.postId);
        setPostUrl(c.postUrl);
        setMatchMode(c.matchAnyWord ? "any" : "specific");
        setKeywordText(c.keywords.join(", "));
        setPublicReplyEnabled(c.publicReplyEnabled);
        setPublicReplyMessages(
          c.publicReplyMessages?.length
            ? c.publicReplyMessages
            : c.publicReplyMessage
              ? [c.publicReplyMessage]
              : [""]
        );
        setDmMessage(c.dmMessage);
        setLinkButtonLabel(c.linkButtonLabel ?? "Открыть ссылку");
        setIsActive(c.isActive);
        const link = c.trackedLinks?.[0]?.destinationUrl ?? "";
        setTrackedDestinationUrl(link);
        setLinkOpen(Boolean(link));
        const secondLink = c.trackedLinks?.[1];
        setSecondaryDestinationUrl(secondLink?.destinationUrl ?? "");
        setSecondaryButtonLabel(secondLink?.label ?? "Открыть ссылку");
        setSecondLinkOpen(Boolean(secondLink?.destinationUrl));
        // Without reading the stored steps back, the next save would write an
        // empty chain over a working one.
        setChainEnabled(Boolean(c.chainEnabled));
        setChainSteps(stepsToDrafts(c.chainSteps ?? []));
      })
      .catch(() => setNotFound(true))
      .finally(() => setLoading(false));
  }, [mode, campaignId]);

  // Track which posts on the selected account are already assigned to an
  // automation, so the picker can highlight them. The campaign being edited is
  // excluded — its own post should read as selected, not "taken".
  useEffect(() => {
    if (!selectedAccountId) return;
    let cancelled = false;
    fetch("/api/automations", { cache: "no-store" })
      .then((r) => r.json())
      .then((payload) => {
        if (cancelled || !payload.success) return;
        const map: Record<string, string> = {};
        for (const a of payload.data as LoadedCampaign[]) {
          if (!a.postId) continue;
          if (a.instagramAccountId !== selectedAccountId) continue;
          if (mode === "edit" && a.id === campaignId) continue;
          map[a.postId] = a.name;
        }
        setUsedPosts(map);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [selectedAccountId, mode, campaignId]);

  // Prefill the editable fields from one queued import row. The reel is left
  // unset so the user picks it per row.
  function prefillFromRow(row: ImportRow) {
    setName(row.name ?? "");
    setTriggerScope("specific");
    setPostId(null);
    setPostUrl(null);
    setPostThumb(null);
    setPostCaption("");
    setMatchMode("specific");
    setKeywordText((row.keywords ?? []).join(", "));
    setDmMessage(row.dmMessage ?? "");
    setPublicReplyEnabled(Boolean(row.publicReply));
    setPublicReplyMessages(row.publicReply ? [row.publicReply] : [""]);
    const link = row.trackedUrl ?? "";
    setTrackedDestinationUrl(link);
    setLinkOpen(Boolean(link));
    // A CSV row carries no chain, so the previous row's chain must not stick.
    setChainEnabled(false);
    setChainSteps([]);
    setError(null);
  }

  // Pick up a staged CSV import (new mode only) and prefill the first row.
  /* eslint-disable react-hooks/set-state-in-effect */
  useEffect(() => {
    if (mode !== "new") return;
    try {
      const raw = window.localStorage.getItem(IMPORT_QUEUE_KEY);
      const acct = window.localStorage.getItem(IMPORT_ACCOUNT_KEY);
      if (!raw) return;
      const queue = JSON.parse(raw) as ImportRow[];
      if (!Array.isArray(queue) || queue.length === 0) return;
      setImportQueue(queue);
      setImportTotal(queue.length);
      if (acct) setSelectedAccountId(acct);
      prefillFromRow(queue[0]);
    } catch {
      // ignore a malformed queue
    }
  }, [mode]);
  /* eslint-enable react-hooks/set-state-in-effect */

  const username =
    accounts.find((a) => a.id === selectedAccountId)?.username ?? "yourbrand";

  function handlePostSelect(
    id: string,
    url?: string,
    thumb?: string,
    caption?: string
  ) {
    setPostId(id);
    setPostUrl(url ?? null);
    setPostThumb(thumb ?? null);
    setPostCaption(caption ?? "");
  }

  function ensureLinkToken() {
    setDmMessage((cur) => (cur.includes("{link}") ? cur : `${cur.trim()} {link}`.trim()));
  }

  // Turning the chain on with nothing in it would show an empty editor, so the
  // payload slot (position 0) is seeded. Turning it off keeps whatever was
  // typed: the switch is a switch, not a delete button.
  function toggleChain() {
    setChainEnabled((on) => {
      const next = !on;
      if (next && chainSteps.length === 0) setChainSteps([emptyChainStepDraft()]);
      return next;
    });
  }

  function addChainStep() {
    setChainSteps((prev) =>
      prev.length >= CHAIN_MAX_STEPS ? prev : [...prev, emptyChainStepDraft()]
    );
  }

  function removeChainStep(index: number) {
    setChainSteps((prev) => prev.filter((_, i) => i !== index));
  }

  function updateChainStep(index: number, patch: Partial<ChainStepDraft>) {
    setChainSteps((prev) =>
      prev.map((step, i) => (i === index ? { ...step, ...patch } : step))
    );
  }

  const chainTotalSeconds = totalChainDelaySeconds(chainSteps);
  const chainOverWindow = chainTotalSeconds > CHAIN_MAX_TOTAL_DELAY_SECONDS;
  const chainPreviewSteps = useMemo(
    () => buildChainStepsPayload(chainSteps, chainEnabled),
    [chainSteps, chainEnabled]
  );

  async function handleSubmit(activeValue: boolean) {
    setError(null);

    if (!selectedAccountId) return setError("Сначала подключи аккаунт Instagram.");
    if (triggerScope === "specific" && !postId)
      return setError("Выбери пост или рилс, на который будет реагировать кампания.");
    if (matchMode === "specific" && keywords.length === 0)
      return setError("Добавь хотя бы одно ключевое слово или выбери «любое слово».");
    if (!dmMessage.trim()) return setError("Добавь сообщение в директ со ссылкой.");
    if (publicReplyEnabled) {
      const variantCount = publicReplyMessages
        .map((m) => m.trim())
        .filter(Boolean).length;
      if (variantCount < MIN_PUBLIC_REPLY_VARIANTS) {
        return setError(
          `Добавь минимум ${MIN_PUBLIC_REPLY_VARIANTS} разных варианта публичного ответа, чтобы они не выглядели одинаково.`
        );
      }
    }
    if (chainEnabled) {
      const chainProblem = validateChainDrafts(chainSteps);
      if (chainProblem) return setError(chainProblem);
    }

    setSaving(true);

    const payload = {
      name: name.trim() || `Campaign for @${username}`,
      instagramAccountId: selectedAccountId,
      postId: triggerScope === "specific" ? postId : null,
      postUrl: triggerScope === "specific" ? postUrl : null,
      matchAnyPost: triggerScope === "any",
      pendingNextReel: triggerScope === "next",
      matchAnyWord: matchMode === "any",
      keywords: matchMode === "any" ? [] : keywords,
      dmMessage,
      publicReplyEnabled,
      publicReplyMessages: publicReplyEnabled
        ? publicReplyMessages.map((m) => m.trim()).filter(Boolean)
        : [],
      // A chain campaign sends no buttons: a link would pull the person out of
      // the chat instead of making them answer, and the 24h window never opens.
      // Sending an empty string here also clears links a campaign already had.
      trackedDestinationUrl: chainEnabled ? "" : trackedDestinationUrl.trim() || "",
      linkButtonLabel: linkButtonLabel.trim() || "Открыть ссылку",
      secondaryDestinationUrl: chainEnabled ? "" : secondaryDestinationUrl.trim() || "",
      secondaryButtonLabel: secondaryButtonLabel.trim() || "Открыть ссылку",
      isActive: activeValue,
      chainEnabled,
      chainSteps: buildChainStepsPayload(chainSteps, chainEnabled),
    };

    try {
      const res =
        mode === "new"
          ? await fetch("/api/automations", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(payload),
            })
          : await fetch(`/api/automations?id=${campaignId}`, {
              method: "PATCH",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(payload),
            });
      const data = await res.json();
      if (data.success) {
        // The post we just assigned is now in use. Reflect it immediately so
        // the picker flags it on the next imported row — the fetch that builds
        // this map doesn't re-run while the builder stays mounted through the
        // import queue.
        if (triggerScope === "specific" && postId) {
          const assignedPostId = postId;
          setUsedPosts((prev) => ({ ...prev, [assignedPostId]: payload.name }));
        }
        // Importing: advance to the next queued row instead of leaving.
        if (importQueue && importQueue.length > 1) {
          const remaining = importQueue.slice(1);
          try {
            window.localStorage.setItem(
              IMPORT_QUEUE_KEY,
              JSON.stringify(remaining)
            );
          } catch {
            // ignore
          }
          setImportQueue(remaining);
          prefillFromRow(remaining[0]);
          setSaving(false);
          if (typeof window !== "undefined") window.scrollTo({ top: 0 });
          return;
        }
        if (importQueue) {
          try {
            window.localStorage.removeItem(IMPORT_QUEUE_KEY);
            window.localStorage.removeItem(IMPORT_ACCOUNT_KEY);
          } catch {
            // ignore
          }
        }
        // refresh() busts the router cache so the list reflects the save
        // instead of landing on a stale (empty) campaigns page.
        router.push("/campaigns");
        router.refresh();
      } else {
        // Surface the specific field that failed validation instead of a
        // generic "Неверное значение".
        const fieldErrors = data.details?.fieldErrors as
          | Record<string, string[]>
          | undefined;
        const firstField = fieldErrors && Object.keys(fieldErrors)[0];
        setError(
          firstField
            ? `${firstField}: ${fieldErrors[firstField][0]}`
            : data.error ?? "Не удалось сохранить кампанию"
        );
        if (typeof window !== "undefined")
          window.scrollTo({ top: 0, behavior: "smooth" });
      }
    } catch {
      setError("Не удалось сохранить кампанию");
    } finally {
      setSaving(false);
    }
  }

  // Skip the current imported row without saving a campaign for it, advancing
  // to the next one (or finishing the import if it was the last).
  function skipRow() {
    if (!importQueue) return;
    setError(null);
    if (importQueue.length > 1) {
      const remaining = importQueue.slice(1);
      try {
        window.localStorage.setItem(IMPORT_QUEUE_KEY, JSON.stringify(remaining));
      } catch {
        // ignore
      }
      setImportQueue(remaining);
      prefillFromRow(remaining[0]);
      if (typeof window !== "undefined") window.scrollTo({ top: 0 });
      return;
    }
    // Last row skipped — finish the import.
    try {
      window.localStorage.removeItem(IMPORT_QUEUE_KEY);
      window.localStorage.removeItem(IMPORT_ACCOUNT_KEY);
    } catch {
      // ignore
    }
    router.push("/campaigns");
    router.refresh();
  }

  if (loading) {
    return <div className="panel h-64 rounded" />;
  }

  if (notFound) {
    return (
      <div className="panel rounded p-8 text-center">
        <p className="text-sm text-muted">Кампания не найдена.</p>
        <button
          onClick={() => router.push("/campaigns")}
          className="mt-4 rounded border border-border px-4 py-2 text-sm text-muted hover:text-foreground"
        >
          Назад к кампаниям
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {importQueue && (
        <div className="rounded border border-accent/30 bg-accent/5 px-4 py-3 text-sm">
          <span className="font-medium text-foreground">
            Импорт: {importTotal - importQueue.length + 1} из {importTotal}.
          </span>{" "}
          <span className="text-muted">
            Поля заполнены из твоего CSV-файла. Выбери рилс, поправь что нужно
            и сохрани, чтобы перейти к следующей записи - или нажми «Пропустить»,
            если эта не нужна.
          </span>
        </div>
      )}

      {/* Top bar */}
      <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-3">
        <div className="flex min-w-0 items-center gap-3">
          {mode === "edit" ? (
            <>
              <span className="truncate text-sm font-semibold text-foreground">
                {name || "Кампания без названия"}
              </span>
              <span
                className={`rounded px-2 py-0.5 text-xs font-semibold ${
                  isActive ? "bg-success/15 text-success" : "bg-zinc-500/15 text-muted"
                }`}
              >
                {isActive ? "ЗАПУЩЕНА" : "НА ПАУЗЕ"}
              </span>
            </>
          ) : (
            <span className="text-sm text-muted">Новая кампания</span>
          )}
        </div>
        <div className="ml-auto flex items-center gap-2">
          {importQueue && (
            <button
              type="button"
              onClick={skipRow}
              disabled={saving}
              className="rounded-lg border border-border px-4 py-2 text-sm font-medium text-muted hover:text-foreground disabled:opacity-50"
            >
              {importQueue.length > 1 ? "Пропустить" : "Пропустить и закончить"}
            </button>
          )}
          {mode === "edit" &&
            (isActive ? (
              <button
                type="button"
                onClick={() => handleSubmit(false)}
                disabled={saving}
                className="rounded-lg border border-border px-4 py-2 text-sm font-medium text-muted hover:text-foreground disabled:opacity-50"
              >
                Остановить
              </button>
            ) : (
              <button
                type="button"
                onClick={() => handleSubmit(true)}
                disabled={saving}
                className="rounded-lg border border-border px-4 py-2 text-sm font-medium text-muted hover:text-foreground disabled:opacity-50"
              >
                Запустить
              </button>
            ))}
          <button
            type="button"
            onClick={() => handleSubmit(mode === "new" ? true : isActive)}
            disabled={saving}
            className="rounded-lg bg-accent px-5 py-2 text-sm font-medium text-white hover:bg-accent-hover disabled:opacity-50"
          >
            {saving ? "Сохраняю…" : mode === "new" ? "Запустить" : "Сохранить изменения"}
          </button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[300px_1fr] lg:gap-8">
      {/* Left: controls */}
      <div className="space-y-8">
        {error && (
          <div className="rounded border border-error/20 bg-error/10 p-3 text-sm text-error">
            {error}
          </div>
        )}

        <div className="space-y-3">
          <label className="text-sm font-semibold text-foreground">
            Название кампании{" "}
            <span className="font-normal text-muted">(необязательно)</span>
          </label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="например, Гайд для подписчиков"
            className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-sm text-foreground placeholder:text-zinc-500 focus:border-accent/40 focus:outline-none"
            maxLength={100}
          />
          {accounts.length > 1 && (
            <div className="pt-2">
              <AccountSelect
                accounts={accounts}
                value={selectedAccountId}
                onChange={(id) => {
                  setSelectedAccountId(id);
                  setPostId(null);
                  setPostUrl(null);
                  setPostThumb(null);
                }}
                includeAll={false}
                label="Аккаунт Instagram"
              />
            </div>
          )}
        </div>

        <Section title="Когда кто-то комментирует">
          <Radio
            checked={triggerScope === "specific"}
            onSelect={() => setTriggerScope("specific")}
          >
            конкретный пост или рилс
          </Radio>
          {triggerScope === "specific" && (
            <div className="rounded-lg border border-border p-2">
              <PostPicker
                selectedPostId={postId}
                instagramAccountId={selectedAccountId}
                usedPostIds={usedPosts}
                onSelect={handlePostSelect}
              />
            </div>
          )}
          <Radio
            checked={triggerScope === "any"}
            onSelect={() => setTriggerScope("any")}
          >
            любой пост или рилс
          </Radio>
          {triggerScope === "any" && (
            <p className="rounded-lg border border-warning/30 bg-warning/10 px-3 py-2 text-xs text-warning">
              Рискованно: отвечать под всеми постами сразу - частая причина
              жалоб на спам и ограничений от Instagram. Выбирай конкретный
              пост, когда это возможно.
            </p>
          )}
          <Radio
            checked={triggerScope === "next"}
            onSelect={() => setTriggerScope("next")}
          >
            следующий пост или рилс
          </Radio>
        </Section>

        <Section title="И в комментарии есть">
          <Radio
            checked={matchMode === "specific"}
            onSelect={() => setMatchMode("specific")}
          >
            конкретное слово или слова
          </Radio>
          {matchMode === "specific" && (
            <div className="space-y-1">
              <input
                value={keywordText}
                onChange={(e) => setKeywordText(e.target.value)}
                placeholder="Впиши слово или несколько слов"
                className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-sm text-foreground placeholder:text-zinc-500 focus:border-accent/40 focus:outline-none"
              />
              <p className="text-xs text-muted">Раздели слова запятыми</p>
            </div>
          )}
          <Radio
            checked={matchMode === "any"}
            onSelect={() => setMatchMode("any")}
          >
            любое слово
          </Radio>
          <div className="flex items-center justify-between rounded-lg border border-border px-3 py-2.5">
            <span className="text-sm text-foreground">
              отвечать на их комментарии под постом
            </span>
            <Toggle
              on={publicReplyEnabled}
              onToggle={() => setPublicReplyEnabled(!publicReplyEnabled)}
            />
          </div>
          {publicReplyEnabled && (
            <div className="space-y-2">
              <p className="rounded-lg border border-warning/30 bg-warning/10 px-3 py-2 text-xs text-warning">
                Рискованно: один и тот же ответ под множеством комментариев
                выглядит как автоматика и может привести к ограничениям на
                аккаунт. Добавь ниже минимум {MIN_PUBLIC_REPLY_VARIANTS}{" "}
                разных варианта.
              </p>
              {publicReplyMessages.map((msg, i) => (
                <div key={i} className="flex items-center gap-2">
                  <input
                    value={msg}
                    onChange={(e) =>
                      setPublicReplyMessages((prev) =>
                        prev.map((m, idx) => (idx === i ? e.target.value : m))
                      )
                    }
                    placeholder="Отправил(а) тебе сообщение в директ! 📩"
                    maxLength={1000}
                    className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-sm text-foreground placeholder:text-zinc-500 focus:border-accent/40 focus:outline-none"
                  />
                  {publicReplyMessages.length > 1 && (
                    <button
                      type="button"
                      onClick={() =>
                        setPublicReplyMessages((prev) =>
                          prev.filter((_, idx) => idx !== i)
                        )
                      }
                      className="shrink-0 px-2 text-muted hover:text-error"
                      aria-label="Удалить ответ"
                    >
                      ✕
                    </button>
                  )}
                </div>
              ))}
              {publicReplyMessages.length < 10 && (
                <button
                  type="button"
                  onClick={() =>
                    setPublicReplyMessages((prev) => [...prev, ""])
                  }
                  className="text-xs font-medium text-accent hover:underline"
                >
                  + Добавить ещё один ответ
                </button>
              )}
              <p className="text-xs text-muted">
                Каждый раз случайно выбирается один вариант, поэтому ответы
                не выглядят одинаковыми.
              </p>
            </div>
          )}
        </Section>

        <Section title="Они получат">
          <div className="rounded-lg border border-border p-3 space-y-2">
            <span className="text-sm text-foreground">
              {chainEnabled
                ? "Первое сообщение (гейт) - просит человека ответить"
                : "сообщение в директ со ссылкой"}
            </span>
            <textarea
              value={dmMessage}
              onChange={(e) => setDmMessage(e.target.value)}
              placeholder="Напиши сообщение"
              rows={3}
              className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-sm text-foreground placeholder:text-zinc-500 focus:border-accent/40 focus:outline-none resize-none"
              maxLength={1000}
            />
            {chainEnabled ? (
              <div className="space-y-2">
                <p className="rounded-lg border border-border bg-surface px-3 py-2 text-xs text-muted">
                  Кнопки в цепочке не работают: ссылка увела бы человека, не
                  открыв окно переписки. Ссылку дашь в «Выдаче» - обычным
                  текстом, после того как человек ответит.
                </p>
                {(trackedDestinationUrl.trim() || secondaryDestinationUrl.trim()) && (
                  <p className="rounded-lg border border-warning/30 bg-warning/10 px-3 py-2 text-xs text-warning">
                    Кнопки, которые уже стоят у этой кампании, снимутся при
                    сохранении.
                  </p>
                )}
                <input
                  value={trackedDestinationUrl}
                  disabled
                  placeholder="Ссылка-кнопка выключена цепочкой"
                  className="w-full cursor-not-allowed rounded-lg border border-border bg-surface px-3 py-2 text-sm text-muted opacity-60"
                />
              </div>
            ) : linkOpen ? (
              <div className="space-y-2">
                <input
                  value={trackedDestinationUrl}
                  onChange={(e) => setTrackedDestinationUrl(e.target.value)}
                  onBlur={ensureLinkToken}
                  placeholder="https://твоя-ссылка.ru/предложение"
                  className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-sm text-foreground placeholder:text-zinc-500 focus:border-accent/40 focus:outline-none"
                />
                <input
                  value={linkButtonLabel}
                  onChange={(e) => setLinkButtonLabel(e.target.value)}
                  placeholder="Текст на кнопке (например, Открыть ссылку)"
                  maxLength={20}
                  className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-sm text-foreground placeholder:text-zinc-500 focus:border-accent/40 focus:outline-none"
                />
                {secondLinkOpen ? (
                  <div className="space-y-2 border-t border-border pt-2">
                    <input
                      value={secondaryDestinationUrl}
                      onChange={(e) => setSecondaryDestinationUrl(e.target.value)}
                      placeholder="https://твоя-ссылка.ru/вторая"
                      className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-sm text-foreground placeholder:text-zinc-500 focus:border-accent/40 focus:outline-none"
                    />
                    <input
                      value={secondaryButtonLabel}
                      onChange={(e) => setSecondaryButtonLabel(e.target.value)}
                      placeholder="Текст на второй кнопке"
                      maxLength={20}
                      className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-sm text-foreground placeholder:text-zinc-500 focus:border-accent/40 focus:outline-none"
                    />
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setSecondLinkOpen(true)}
                    className="w-full rounded-lg border border-border py-2 text-sm text-muted hover:text-foreground"
                  >
                    + Добавить вторую ссылку
                  </button>
                )}
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setLinkOpen(true)}
                className="w-full rounded-lg border border-border py-2 text-sm text-muted hover:text-foreground"
              >
                + Добавить ссылку
              </button>
            )}
            <p className="text-xs text-muted">
              {chainEnabled ? (
                <>{"{username}"} подставляет имя подписчика.</>
              ) : (
                <>
                  {"{link}"} вставляет отслеживаемую ссылку; {"{username}"}{" "}
                  подставляет имя подписчика.
                </>
              )}
            </p>
          </div>
        </Section>

        <Section title="Цепочка касаний">
          <div className="flex items-center justify-between gap-3 rounded-lg border border-border px-3 py-2.5">
            <span className="text-sm text-foreground">
              включить цепочку вместо одного сообщения
            </span>
            <Toggle on={chainEnabled} onToggle={toggleChain} />
          </div>
          <p className="text-xs text-muted">
            Вместо одного сообщения - серия: первое сообщение просит ответить,
            после ответа человека уходит выдача и касания по таймеру.
          </p>

          {chainEnabled && (
            <div className="space-y-3">
              {chainSteps.map((step, i) => (
                <div
                  key={i}
                  className="space-y-2 rounded-lg border border-border p-3"
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-sm font-medium text-foreground">
                      {chainStepLabel(i)}
                    </span>
                    {chainSteps.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeChainStep(i)}
                        className="shrink-0 px-1 text-muted hover:text-error"
                        aria-label={`Удалить ${chainStepLabel(i)}`}
                      >
                        ✕
                      </button>
                    )}
                  </div>

                  <textarea
                    value={step.message}
                    onChange={(e) => updateChainStep(i, { message: e.target.value })}
                    placeholder={
                      i === 0
                        ? "То, за чем человек пришёл: ссылка, гайд, доступ"
                        : "Напиши касание"
                    }
                    rows={3}
                    maxLength={CHAIN_STEP_MAX_LENGTH}
                    className="w-full resize-none rounded-lg border border-border bg-surface px-3 py-2 text-sm text-foreground placeholder:text-zinc-500 focus:border-accent/40 focus:outline-none"
                  />
                  <p className="text-right text-xs text-muted">
                    {step.message.length} / {CHAIN_STEP_MAX_LENGTH}
                  </p>

                  {i === 0 ? (
                    <p className="text-xs text-muted">
                      Уходит сразу, как только человек ответит на первое
                      сообщение.
                    </p>
                  ) : (
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted">через</span>
                      <input
                        type="number"
                        min={0}
                        value={step.delayAmount}
                        onChange={(e) =>
                          updateChainStep(i, { delayAmount: e.target.value })
                        }
                        className="w-20 rounded-lg border border-border bg-surface px-3 py-2 text-sm text-foreground focus:border-accent/40 focus:outline-none"
                      />
                      <select
                        value={step.delayUnit}
                        onChange={(e) =>
                          updateChainStep(i, {
                            delayUnit: e.target.value as DelayUnit,
                          })
                        }
                        className="rounded-lg border border-border bg-surface px-3 py-2 text-sm text-foreground focus:border-accent/40 focus:outline-none"
                      >
                        <option value="minutes">минуты</option>
                        <option value="hours">часы</option>
                      </select>
                      <span className="text-xs text-muted">
                        после предыдущего
                      </span>
                    </div>
                  )}
                </div>
              ))}

              {chainSteps.length < CHAIN_MAX_STEPS && (
                <button
                  type="button"
                  onClick={addChainStep}
                  className="w-full rounded-lg border border-border py-2 text-sm text-muted hover:text-foreground"
                >
                  + Добавить касание
                </button>
              )}

              <p
                className={`text-xs ${
                  chainOverWindow ? "font-medium text-error" : "text-muted"
                }`}
              >
                Вся цепочка уложится за {formatDurationShort(chainTotalSeconds)}{" "}
                из 23 ч окна
                {chainOverWindow
                  ? " - это дольше окна Meta, последние касания уже не уйдут"
                  : ""}
              </p>
              <p className="text-xs text-muted">
                В шагах цепочки ссылку пиши прямо в тексте: {"{link}"} и{" "}
                {"{username}"} здесь не подставляются.
              </p>
            </div>
          )}
        </Section>
      </div>

      {/* Right: preview */}
      <div>
        <p className="mb-4 text-sm text-muted">Предпросмотр</p>
        <div className="flex justify-center lg:sticky lg:top-6 lg:block">
          <CampaignPreview
            tab={previewTab}
            onTabChange={setPreviewTab}
            username={username}
            avatarUrl={avatarUrl}
            postThumb={postThumb}
            caption={postCaption}
            sampleComment={keywords[0] ?? ""}
            publicReplyEnabled={publicReplyEnabled}
            publicReplyMessage={publicReplyMessages.find((m) => m.trim()) ?? ""}
            revealMessage={dmMessage}
            chainEnabled={chainEnabled}
            chainSteps={chainPreviewSteps}
            hasLink={!chainEnabled && Boolean(trackedDestinationUrl.trim())}
            linkButtonLabel={linkButtonLabel || "Открыть ссылку"}
            linkUrl={
              chainEnabled ? undefined : trackedDestinationUrl.trim() || undefined
            }
            hasSecondLink={
              !chainEnabled &&
              secondLinkOpen &&
              Boolean(secondaryDestinationUrl.trim())
            }
            secondLinkButtonLabel={secondaryButtonLabel || "Открыть ссылку"}
          />
        </div>
      </div>
      </div>
    </div>
  );
}
