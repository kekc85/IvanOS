/**
 * Touch chain — pure helpers shared by the builder, the preview and the
 * campaign detail page.
 *
 * The database stores one number per step (delaySeconds), but nobody writing a
 * follow-up thinks in seconds: they think "через 10 минут" or "через 2 часа".
 * So the form keeps a draft (amount + unit) and these functions translate in
 * both directions. Everything here is deliberately free of React, so the rules
 * that decide what gets saved can be tested directly.
 *
 * The limits mirror app/api/automations/route.ts on purpose: the API is still
 * the authority and refuses anything wrong, the form just says it in Russian
 * before the user hits save.
 */

/** More than this and the chain stops being a follow-up and becomes spam. */
export const CHAIN_MAX_STEPS = 6;

/**
 * 23 hours. Meta's messaging window is 24h from the person's last message, so
 * the whole chain has to finish inside it with an hour of slack.
 */
export const CHAIN_MAX_TOTAL_DELAY_SECONDS = 82_800;

/** Same ceiling as dmMessage and every other message field in the API. */
export const CHAIN_STEP_MAX_LENGTH = 1000;

export type DelayUnit = "minutes" | "hours";

/** One step as the form holds it while the user is typing. */
export interface ChainStepDraft {
  message: string;
  /** Raw text, not a number: the field has to survive being emptied mid-edit. */
  delayAmount: string;
  delayUnit: DelayUnit;
}

/** One step as the API sends and receives it. */
export interface ChainStepPayload {
  position: number;
  delaySeconds: number;
  message: string;
}

const UNIT_SECONDS: Record<DelayUnit, number> = {
  minutes: 60,
  hours: 3600,
};

export function emptyChainStepDraft(): ChainStepDraft {
  return { message: "", delayAmount: "10", delayUnit: "minutes" };
}

/**
 * Position 0 is the payload the person came for — it goes out the moment they
 * answer, so its delay is always zero no matter what the draft says. Every
 * other position waits after the one before it.
 */
export function draftDelaySeconds(draft: ChainStepDraft, position: number): number {
  if (position === 0) return 0;
  const amount = Number.parseInt(draft.delayAmount, 10);
  if (!Number.isFinite(amount) || amount <= 0) return 0;
  return amount * UNIT_SECONDS[draft.delayUnit];
}

/**
 * Seconds back into something a person can read: whole hours stay hours, the
 * rest becomes minutes. 5400 seconds is shown as 90 минут rather than "1.5 ч",
 * because the field takes one number and one unit.
 */
export function secondsToDraftDelay(seconds: number): {
  delayAmount: string;
  delayUnit: DelayUnit;
} {
  const safe = Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds) : 0;
  if (safe > 0 && safe % 3600 === 0) {
    return { delayAmount: String(safe / 3600), delayUnit: "hours" };
  }
  return { delayAmount: String(Math.round(safe / 60)), delayUnit: "minutes" };
}

/** Stored steps (already ordered by position) into form drafts. */
export function stepsToDrafts(steps: ChainStepPayload[]): ChainStepDraft[] {
  return [...steps]
    .sort((a, b) => a.position - b.position)
    .map((step) => ({
      message: step.message,
      ...secondsToDraftDelay(step.delaySeconds),
    }));
}

/**
 * Drafts into what the API stores. Positions are renumbered densely from zero
 * — the API rejects gaps, and the dispatcher would stall on a position nobody
 * wrote.
 *
 * With the chain switched off, blank steps are dropped instead of failing
 * validation: someone who turned the chain off shouldn't be blocked from
 * saving by a half-typed follow-up they no longer use.
 */
export function buildChainStepsPayload(
  drafts: ChainStepDraft[],
  chainEnabled: boolean
): ChainStepPayload[] {
  const source = chainEnabled
    ? drafts
    : drafts.filter((draft) => draft.message.trim().length > 0);

  return source.slice(0, CHAIN_MAX_STEPS).map((draft, index) => ({
    position: index,
    delaySeconds: draftDelaySeconds(draft, index),
    message: draft.message.trim(),
  }));
}

/** How long the whole chain takes, counted the same way the API counts it. */
export function totalChainDelaySeconds(drafts: ChainStepDraft[]): number {
  return drafts.reduce(
    (total, draft, index) => total + draftDelaySeconds(draft, index),
    0
  );
}

function pluralRu(count: number, forms: [string, string, string]): string {
  const abs = Math.abs(count) % 100;
  const tail = abs % 10;
  if (abs > 10 && abs < 20) return forms[2];
  if (tail > 1 && tail < 5) return forms[1];
  if (tail === 1) return forms[0];
  return forms[2];
}

/** Compact duration for the running total: «22 ч 10 мин», «45 мин». */
export function formatDurationShort(seconds: number): string {
  const safe = Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds) : 0;
  const hours = Math.floor(safe / 3600);
  const minutes = Math.round((safe % 3600) / 60);
  if (hours === 0) return `${minutes} мин`;
  if (minutes === 0) return `${hours} ч`;
  return `${hours} ч ${minutes} мин`;
}

/** Spoken delay for the preview separators: «через 10 минут», «через 2 часа». */
export function formatDelayRu(seconds: number): string {
  const safe = Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds) : 0;
  if (safe === 0) return "сразу";
  const hours = Math.floor(safe / 3600);
  const minutes = Math.round((safe % 3600) / 60);
  const parts: string[] = [];
  if (hours > 0) parts.push(`${hours} ${pluralRu(hours, ["час", "часа", "часов"])}`);
  if (minutes > 0)
    parts.push(`${minutes} ${pluralRu(minutes, ["минуту", "минуты", "минут"])}`);
  return `через ${parts.join(" ")}`;
}

/** What each slot is called in the interface. */
export function chainStepLabel(position: number): string {
  return position === 0 ? "Выдача (сразу после ответа)" : `Касание ${position + 1}`;
}

/**
 * The client-side mirror of the API's chain rules, in Russian. Returns the
 * first problem or null. The API still checks all of this — this only saves
 * the user a round trip and a translated error.
 */
export function validateChainDrafts(drafts: ChainStepDraft[]): string | null {
  if (drafts.length === 0) {
    return "Цепочка включена, но шагов нет - добавь хотя бы один шаг или выключи цепочку";
  }
  if (drafts.length > CHAIN_MAX_STEPS) {
    return `В цепочке максимум ${CHAIN_MAX_STEPS} шагов`;
  }

  for (let index = 0; index < drafts.length; index += 1) {
    const draft = drafts[index];
    const message = draft.message.trim();
    if (!message) {
      return `«${chainStepLabel(index)}»: впиши текст сообщения`;
    }
    if (message.length > CHAIN_STEP_MAX_LENGTH) {
      return `«${chainStepLabel(index)}»: текст длиннее ${CHAIN_STEP_MAX_LENGTH} знаков`;
    }
  }

  if (totalChainDelaySeconds(drafts) > CHAIN_MAX_TOTAL_DELAY_SECONDS) {
    return "Вся цепочка должна укладываться в 23 часа - у Meta окно на ответ 24 часа, а шаг за его пределами уже не уйдёт";
  }

  return null;
}
