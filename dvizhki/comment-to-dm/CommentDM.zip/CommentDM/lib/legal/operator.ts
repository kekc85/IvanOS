/**
 * Identifies who actually operates a given install for the legal pages
 * (app/privacy, app/terms, app/data-deletion).
 *
 * This is self-hosted software: whoever installed it, on whatever server
 * they pay for, is the data controller for everyone who comments on their
 * connected Instagram account. This repository's authors are not that
 * person and cannot be named as the operator on someone else's install —
 * so these values come from the owner's own .env, with an explicit,
 * visible fallback when they have not set them yet rather than a silent
 * guess or a name that isn't theirs.
 */

export function getLegalOperatorName(): string {
  const value = process.env.LEGAL_ENTITY_NAME?.trim();
  return value && value.length > 0
    ? value
    : "владелец этого инструмента (LEGAL_ENTITY_NAME не задан в .env)";
}

export function getLegalContactEmail(): string | null {
  const value = process.env.LEGAL_CONTACT_EMAIL?.trim();
  return value && value.length > 0 ? value : null;
}

export function getLegalContactLine(): string {
  const email = getLegalContactEmail();
  return email
    ? email
    : "контакт не указан — владельцу нужно задать LEGAL_CONTACT_EMAIL в .env";
}
