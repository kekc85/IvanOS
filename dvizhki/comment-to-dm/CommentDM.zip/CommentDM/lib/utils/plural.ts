/**
 * Русские формы числа: 1 ошибка / 2 ошибки / 5 ошибок.
 *
 * Живёт в lib/, а не рядом с интерфейсом, ровно по одной причине: то же самое
 * согласование нужно диагностике (`npm run doctor`), которая крутится в
 * терминале на сервере и ничего из app/ или components/ импортировать не
 * может - те файлы клиентские. Держать в докторе свою копию правил значило бы
 * третью копию одного правила на репозиторий.
 */
export function pluralRu(
  n: number,
  one: string,
  few: string,
  many: string
): string {
  const abs = Math.abs(n);
  const mod10 = abs % 10;
  const mod100 = abs % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && !(mod100 >= 12 && mod100 <= 14)) return few;
  return many;
}
