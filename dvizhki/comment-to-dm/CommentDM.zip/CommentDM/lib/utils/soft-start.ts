/**
 * Soft Start
 *
 * A freshly connected Instagram account that immediately sends at full
 * volume looks exactly like a bot to Instagram's abuse systems: no history,
 * no organic activity, then a burst of DMs and comment replies. For the
 * first SOFT_START_WINDOW_HOURS after an account connects, both rate
 * limiters (private replies and public comment replies) quarter their
 * normal hourly cap. Once the window passes, the account "graduates" to its
 * full cap automatically — no action needed from the student.
 *
 * Deliberately dependency-free (no Redis, no Prisma) so both the server-side
 * rate limiter and client-side UI banners can import it directly.
 */

export const SOFT_START_WINDOW_HOURS = 72;
export const SOFT_START_DIVISOR = 4; // 25% of the normal cap while warming up

const SOFT_START_WINDOW_MS = SOFT_START_WINDOW_HOURS * 60 * 60 * 1000;

function toTimestamp(connectedAt: Date | string | null | undefined): number | null {
  if (!connectedAt) return null;
  const time =
    connectedAt instanceof Date ? connectedAt.getTime() : new Date(connectedAt).getTime();
  return Number.isNaN(time) ? null : time;
}

/**
 * True while the account is still inside its 72-hour soft-start window.
 * An account with no known connection time is treated as NOT in soft start
 * (fails open to the normal cap) rather than silently capping it forever.
 */
export function isAccountInSoftStart(
  connectedAt: Date | string | null | undefined,
  now: Date = new Date()
): boolean {
  const connectedTime = toTimestamp(connectedAt);
  if (connectedTime === null) return false;
  return now.getTime() - connectedTime < SOFT_START_WINDOW_MS;
}

/**
 * The hourly cap to actually enforce: quartered during soft start, the
 * documented/normal cap otherwise. Always at least 1 so the cap never
 * collapses to zero for a very low baseMax.
 */
export function softStartCap(
  baseMax: number,
  connectedAt: Date | string | null | undefined,
  now: Date = new Date()
): number {
  return isAccountInSoftStart(connectedAt, now)
    ? Math.max(1, Math.floor(baseMax / SOFT_START_DIVISOR))
    : baseMax;
}

/** Whole hours left in the soft-start window, for display in the UI. */
export function softStartHoursRemaining(
  connectedAt: Date | string | null | undefined,
  now: Date = new Date()
): number {
  const connectedTime = toTimestamp(connectedAt);
  if (connectedTime === null) return 0;
  const msRemaining = SOFT_START_WINDOW_MS - (now.getTime() - connectedTime);
  return msRemaining > 0 ? Math.ceil(msRemaining / (60 * 60 * 1000)) : 0;
}
