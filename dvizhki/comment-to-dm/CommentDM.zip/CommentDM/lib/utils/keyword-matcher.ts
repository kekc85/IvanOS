/**
 * Keyword Matcher
 *
 * Matches comment text against a set of keywords with support for:
 * - Case-insensitive matching
 * - Whole-word or partial matching
 * - Multi-keyword OR logic (any match = true)
 * - Emoji and special character stripping
 */

export interface KeywordMatchResult {
  matched: boolean;
  matchedKeyword: string | null;
}

/**
 * Strip emojis and special characters from text, keeping only
 * alphanumeric characters and whitespace.
 */
export function stripSpecialCharacters(text: string): string {
  // Remove emoji ranges and other special unicode chars.
  // Replacement is a SPACE, not "": an emoji glued straight onto a word
  // ("хочу🙏команды" — everyday in Russian comments) would otherwise fuse the
  // neighbours into "хочукоманды" and kill the whole-word match. Repeated
  // spaces (including the ones a multi-codepoint emoji leaves behind) are
  // collapsed by the \s+ pass below, so spaced-out emojis are unaffected.
  return text
    .replace(
      /[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F1E0}-\u{1F1FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{FE00}-\u{FE0F}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{200D}\u{20E3}]/gu,
      " "
    )
    // Keep letters and digits of ANY alphabet (Cyrillic included), plus "_"
    // and whitespace. Plain \w is ASCII-only and would erase every Russian
    // letter, so the unicode property classes are load-bearing here.
    .replace(/[^\p{L}\p{N}_\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Characters that count as "inside a word" for whole-word matching.
 * Mirrors what stripSpecialCharacters keeps, so the boundary check stays
 * consistent with the cleaned text (and, unlike \b, works for Cyrillic).
 */
const WORD_CHAR_CLASS = "[\\p{L}\\p{N}_]";

/**
 * Check if a comment text matches any of the given keywords.
 *
 * @param commentText - The raw comment text to check
 * @param keywords - Array of keywords to match against
 * @param wholeWordMatch - If true, keyword must be a standalone word.
 *                         If false, partial matches are allowed (e.g. "linking" matches "link")
 * @returns Match result with the first matched keyword (if any)
 */
export function matchKeywords(
  commentText: string,
  keywords: string[],
  wholeWordMatch: boolean = true
): KeywordMatchResult {
  if (!commentText || keywords.length === 0) {
    return { matched: false, matchedKeyword: null };
  }

  const cleanedText = stripSpecialCharacters(commentText).toLowerCase();

  if (!cleanedText) {
    return { matched: false, matchedKeyword: null };
  }

  for (const keyword of keywords) {
    const cleanedKeyword = stripSpecialCharacters(keyword).toLowerCase();

    if (!cleanedKeyword) continue;

    if (wholeWordMatch) {
      // Build a regex for whole-word matching
      const escapedKeyword = cleanedKeyword.replace(
        /[.*+?^${}()|[\]\\]/g,
        "\\$&"
      );
      // \b is an ASCII-only boundary — it never fires around Cyrillic.
      // Lookbehind/lookahead on "not a word char" is the unicode-safe equivalent.
      const regex = new RegExp(
        `(?<!${WORD_CHAR_CLASS})${escapedKeyword}(?!${WORD_CHAR_CLASS})`,
        "iu"
      );
      if (regex.test(cleanedText)) {
        return { matched: true, matchedKeyword: keyword };
      }
    } else {
      // Partial match — keyword substring exists anywhere in the cleaned text
      if (cleanedText.includes(cleanedKeyword)) {
        return { matched: true, matchedKeyword: keyword };
      }
    }
  }

  return { matched: false, matchedKeyword: null };
}
