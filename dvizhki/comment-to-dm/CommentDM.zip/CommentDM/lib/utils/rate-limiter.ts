/**
 * Rate Limiter
 *
 * Redis-based rate limiter for Instagram private replies.
 *
 * The cap matches Meta's documented limit for this exact call: 750 private
 * replies per hour per Instagram professional account, for comments on posts
 * and reels. Exceeding it risks 429s and app-level restrictions, so the worker
 * requeues rather than pushing through.
 * https://developers.facebook.com/docs/graph-api/overview/rate-limiting/
 *
 * Note this is a hard ceiling with no headroom. If Meta throttles before the
 * documented limit, or other calls on the same account share the bucket, lower
 * this value.
 */

import Redis from "ioredis";
import { softStartCap } from "./soft-start";

const RATE_LIMIT_MAX = 750; // private replies per hour, per Meta's documented cap
const RATE_LIMIT_WINDOW = 3600; // 1 hour in seconds
const REQUEUE_DELAY_MS = 30 * 60 * 1000; // 30 minutes
const MAX_REQUEUE_ATTEMPTS = 3;

/**
 * Public comment-reply cap — a second, separate limiter from the private-reply
 * one above. It has its own Redis key (`rate:comment:*`) and its own ceiling;
 * it never shares state with the private-reply counter.
 *
 * Meta does not publish a distinct Graph API rate limit for comment replies
 * the way it does for private replies (RATE_LIMIT_MAX above). Public replies
 * are riskier than private ones even at the same volume: they're visible
 * under the post to everyone (including anyone who reports spam), and dozens
 * of near-identical replies posted in an hour is a textbook automation
 * signature. So this cap is set to a fifth of the private-reply cap as a
 * deliberate safety margin, not derived from a documented number. Lower it
 * further if an account still gets flagged; do not raise it toward
 * RATE_LIMIT_MAX.
 */
const COMMENT_REPLY_RATE_LIMIT_MAX = 150; // public comment replies per hour, per account
const COMMENT_REPLY_RATE_LIMIT_WINDOW = 3600; // 1 hour in seconds

/**
 * Touch-chain cap — a third bucket, again with its own Redis key
 * (`rate:chain:*`) and its own ceiling, sharing state with neither of the two
 * above.
 *
 * Why not simply reuse the private-reply bucket: chain steps and GATEs are
 * different jobs competing for the same account. A GATE is the *only* moment
 * Meta lets us open a conversation at all — miss it and that person is gone
 * for good. A chain step is a follow-up to a conversation already open, and
 * postponing it by half an hour costs nothing. Put both on one counter and a
 * busy chain day burns the 750/hour ceiling that GATEs depend on, so new
 * commenters get nothing while old ones get their fourth message. Separate
 * buckets mean chains can only ever exhaust chains.
 *
 * 200/hour is a deliberate ceiling, not a documented Meta number: these are
 * unsolicited-looking follow-ups into private inboxes, the exact shape of
 * traffic Instagram's abuse systems watch. Soft start quarters it for a new
 * account like everywhere else.
 */
const CHAIN_RATE_LIMIT_MAX = 200; // chain step sends per hour, per account
const CHAIN_RATE_LIMIT_WINDOW = 3600; // 1 hour in seconds

let redis: Redis | null = null;

function getRedis(): Redis {
  if (!redis) {
    redis = new Redis(process.env.REDIS_URL!, {
      maxRetriesPerRequest: null, // required by BullMQ
    });
  }
  return redis;
}

export interface RateLimitResult {
  allowed: boolean;
  currentCount: number;
  remainingDMs: number;
  shouldRequeue: boolean;
  requeueDelayMs: number;
  shouldSkip: boolean;
  reserved: boolean;
}

const RESERVE_DM_SLOT_SCRIPT = `
local current = tonumber(redis.call("GET", KEYS[1]) or "0")
local max = tonumber(ARGV[1])
local ttl = tonumber(ARGV[2])

if current >= max then
  return {0, current, 0}
end

local next_count = redis.call("INCR", KEYS[1])
if next_count == 1 then
  redis.call("EXPIRE", KEYS[1], ttl)
end

return {1, next_count, max - next_count}
`;

function toScriptNumber(value: unknown): number {
  if (typeof value === "number") return value;
  if (typeof value === "string") return Number.parseInt(value, 10);
  return 0;
}

function blockedResult(
  count: number,
  requeueAttempt: number
): RateLimitResult {
  if (requeueAttempt >= MAX_REQUEUE_ATTEMPTS) {
    return {
      allowed: false,
      currentCount: count,
      remainingDMs: 0,
      shouldRequeue: false,
      requeueDelayMs: 0,
      shouldSkip: true,
      reserved: false,
    };
  }

  return {
    allowed: false,
    currentCount: count,
    remainingDMs: 0,
    shouldRequeue: true,
    requeueDelayMs: REQUEUE_DELAY_MS,
    shouldSkip: false,
    reserved: false,
  };
}

/**
 * Check if an Instagram account is within its DM rate limit.
 *
 * Uses a Redis counter with a 1-hour TTL per account.
 * Key pattern: `rate:dm:{instagramAccountId}`
 *
 * @param instagramAccountId - The Instagram account ID to check
 * @param requeueAttempt - How many times this job has been requeued (0 = first attempt)
 * @returns Rate limit result with action recommendations
 */
export async function checkRateLimit(
  instagramAccountId: string,
  requeueAttempt: number = 0
): Promise<RateLimitResult> {
  const client = getRedis();
  const key = `rate:dm:${instagramAccountId}`;

  const currentCount = await client.get(key);
  const count = currentCount ? parseInt(currentCount, 10) : 0;

  if (count >= RATE_LIMIT_MAX) {
    // Over the limit
    if (requeueAttempt >= MAX_REQUEUE_ATTEMPTS) {
      // Exceeded max requeue attempts — skip this DM
      return {
        allowed: false,
        currentCount: count,
        remainingDMs: 0,
        shouldRequeue: false,
        requeueDelayMs: 0,
        shouldSkip: true,
        reserved: false,
      };
    }

    return {
      allowed: false,
      currentCount: count,
      remainingDMs: 0,
      shouldRequeue: true,
      requeueDelayMs: REQUEUE_DELAY_MS,
      shouldSkip: false,
      reserved: false,
    };
  }

  return {
    allowed: true,
    currentCount: count,
    remainingDMs: RATE_LIMIT_MAX - count,
    shouldRequeue: false,
    requeueDelayMs: 0,
    shouldSkip: false,
    reserved: false,
  };
}

/**
 * Atomically reserve a DM send slot for an Instagram account.
 * This is the worker-safe path; it prevents concurrent jobs from all passing
 * the rate-limit check before any of them increments the Redis counter.
 *
 * `connectedAt` is optional and additive: omit it (as every call site did
 * before soft start existed) and this behaves exactly as before, capped at
 * RATE_LIMIT_MAX. Pass the account's connection timestamp and, for its first
 * 72 hours, the effective cap is quartered instead — see lib/utils/soft-start.ts.
 */
export async function reserveDMSlot(
  instagramAccountId: string,
  requeueAttempt: number = 0,
  connectedAt?: Date | string | null
): Promise<RateLimitResult> {
  const client = getRedis();
  const key = `rate:dm:${instagramAccountId}`;
  const max = softStartCap(RATE_LIMIT_MAX, connectedAt);

  const result = await client.eval(
    RESERVE_DM_SLOT_SCRIPT,
    1,
    key,
    max,
    RATE_LIMIT_WINDOW
  );
  const values = Array.isArray(result) ? result : [];
  const allowedFlag = toScriptNumber(values[0]);
  const count = toScriptNumber(values[1]);
  const remaining = toScriptNumber(values[2]);

  if (allowedFlag !== 1) {
    return blockedResult(count, requeueAttempt);
  }

  return {
    allowed: true,
    currentCount: count,
    remainingDMs: remaining,
    shouldRequeue: false,
    requeueDelayMs: 0,
    shouldSkip: false,
    reserved: true,
  };
}

/**
 * Atomically reserve a public comment-reply slot for an Instagram account.
 * Separate counter, separate key, separate ceiling from reserveDMSlot above
 * — exhausting one never blocks or interacts with the other. The worker must
 * call this BEFORE posting a public reply (lib/queue/dm-worker.ts), the same
 * way it calls reserveDMSlot before sending a private reply.
 */
export async function reserveCommentReplySlot(
  instagramAccountId: string,
  requeueAttempt: number = 0,
  connectedAt?: Date | string | null
): Promise<RateLimitResult> {
  const client = getRedis();
  const key = `rate:comment:${instagramAccountId}`;
  const max = softStartCap(COMMENT_REPLY_RATE_LIMIT_MAX, connectedAt);

  const result = await client.eval(
    RESERVE_DM_SLOT_SCRIPT,
    1,
    key,
    max,
    COMMENT_REPLY_RATE_LIMIT_WINDOW
  );
  const values = Array.isArray(result) ? result : [];
  const allowedFlag = toScriptNumber(values[0]);
  const count = toScriptNumber(values[1]);
  const remaining = toScriptNumber(values[2]);

  if (allowedFlag !== 1) {
    return blockedResult(count, requeueAttempt);
  }

  return {
    allowed: true,
    currentCount: count,
    remainingDMs: remaining,
    shouldRequeue: false,
    requeueDelayMs: 0,
    shouldSkip: false,
    reserved: true,
  };
}

/**
 * Atomically reserve a touch-chain step slot for an Instagram account.
 * Third counter, third key, third ceiling — see CHAIN_RATE_LIMIT_MAX above for
 * why chain steps must not draw from the private-reply bucket that GATEs need.
 * The chain dispatcher (lib/chain/step-dispatcher.ts) calls this BEFORE it
 * advances the journey's position, so a refused slot postpones the step
 * instead of consuming it.
 */
export async function reserveChainSlot(
  instagramAccountId: string,
  requeueAttempt: number = 0,
  connectedAt?: Date | string | null
): Promise<RateLimitResult> {
  const client = getRedis();
  const key = `rate:chain:${instagramAccountId}`;
  const max = softStartCap(CHAIN_RATE_LIMIT_MAX, connectedAt);

  const result = await client.eval(
    RESERVE_DM_SLOT_SCRIPT,
    1,
    key,
    max,
    CHAIN_RATE_LIMIT_WINDOW
  );
  const values = Array.isArray(result) ? result : [];
  const allowedFlag = toScriptNumber(values[0]);
  const count = toScriptNumber(values[1]);
  const remaining = toScriptNumber(values[2]);

  if (allowedFlag !== 1) {
    return blockedResult(count, requeueAttempt);
  }

  return {
    allowed: true,
    currentCount: count,
    remainingDMs: remaining,
    shouldRequeue: false,
    requeueDelayMs: 0,
    shouldSkip: false,
    reserved: true,
  };
}

/**
 * Backwards-compatible helper for tests and admin scripts.
 * Prefer reserveDMSlot in workers.
 */
export async function incrementDMCounter(
  instagramAccountId: string
): Promise<number> {
  const result = await reserveDMSlot(instagramAccountId, MAX_REQUEUE_ATTEMPTS);
  return result.currentCount;
}

/**
 * Get the current DM count for an Instagram account.
 */
export async function getCurrentDMCount(
  instagramAccountId: string
): Promise<number> {
  const client = getRedis();
  const key = `rate:dm:${instagramAccountId}`;
  const count = await client.get(key);
  return count ? parseInt(count, 10) : 0;
}

/**
 * Reset the rate limiter for an account (useful for testing).
 */
export async function resetRateLimit(
  instagramAccountId: string
): Promise<void> {
  const client = getRedis();
  const key = `rate:dm:${instagramAccountId}`;
  await client.del(key);
}

// Export constants for use in tests
export {
  RATE_LIMIT_MAX,
  RATE_LIMIT_WINDOW,
  REQUEUE_DELAY_MS,
  MAX_REQUEUE_ATTEMPTS,
  COMMENT_REPLY_RATE_LIMIT_MAX,
  COMMENT_REPLY_RATE_LIMIT_WINDOW,
  CHAIN_RATE_LIMIT_MAX,
  CHAIN_RATE_LIMIT_WINDOW,
};
