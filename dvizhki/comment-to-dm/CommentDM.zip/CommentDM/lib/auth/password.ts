/**
 * Owner Password Hashing
 *
 * scrypt from Node's standard library — no extra dependency, and the tuning
 * parameters are stored inside the hash string so a future cost bump can still
 * verify old hashes.
 *
 * Stored format: scrypt$N$r$p$<saltBase64Url>$<keyBase64Url>
 */

import { randomBytes, scrypt, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";

const scryptAsync = promisify(scrypt) as (
  password: string | Buffer,
  salt: string | Buffer,
  keylen: number,
  options: { N: number; r: number; p: number; maxmem: number }
) => Promise<Buffer>;

// Cost parameters. N=16384 is the OWASP baseline for scrypt and stays well
// under a second on the small VPS this fork is meant to run on.
const SCRYPT_N = 16384;
const SCRYPT_R = 8;
const SCRYPT_P = 1;
// Node's default maxmem (32 MB) is just under what N=16384,r=8 asks for.
const SCRYPT_MAXMEM = 64 * 1024 * 1024;
const KEY_LENGTH = 64;
const SALT_LENGTH = 16;

export const MIN_PASSWORD_LENGTH = 8;

/**
 * Passwords that a bot will try in its first hundred guesses. A self-hosted
 * install is exposed to the open internet the moment it gets a domain, so the
 * app refuses to start on any of these instead of warning about them.
 */
const BLOCKED_PASSWORDS = new Set(
  [
    "123456",
    "1234567",
    "12345678",
    "123456789",
    "1234567890",
    "password",
    "password1",
    "password123",
    "passw0rd",
    "qwerty",
    "qwerty123",
    "qwertyuiop",
    "admin",
    "admin123",
    "administrator",
    "root",
    "letmein",
    "welcome",
    "welcome1",
    "iloveyou",
    "monkey",
    "dragon",
    "sunshine",
    "princess",
    "football",
    "baseball",
    "abc123",
    "abcd1234",
    "111111",
    "000000",
    "changeme",
    "secret",
    "commentdm",
    "instagram",
    "test1234",
  ].map((value) => value.toLowerCase())
);

export type PasswordCheck = { ok: true } | { ok: false; reason: string };

/**
 * Validates a password an installer supplied. Returns the reason instead of
 * throwing so the caller decides between refusing to boot and rendering a
 * form error.
 */
export function checkPasswordPolicy(password: string): PasswordCheck {
  if (password.length < MIN_PASSWORD_LENGTH) {
    return {
      ok: false,
      reason: `Пароль должен быть не короче ${MIN_PASSWORD_LENGTH} символов`,
    };
  }

  if (BLOCKED_PASSWORDS.has(password.toLowerCase())) {
    return {
      ok: false,
      reason: "Этот пароль в списке самых угадываемых - выбери другой",
    };
  }

  return { ok: true };
}

export function assertPasswordAllowed(password: string): void {
  const result = checkPasswordPolicy(password);
  if (!result.ok) {
    throw new Error(result.reason);
  }
}

export function isPasswordBlocked(password: string): boolean {
  return BLOCKED_PASSWORDS.has(password.toLowerCase());
}

export async function hashPassword(password: string): Promise<string> {
  assertPasswordAllowed(password);

  const salt = randomBytes(SALT_LENGTH);
  const key = await scryptAsync(password, salt, KEY_LENGTH, {
    N: SCRYPT_N,
    r: SCRYPT_R,
    p: SCRYPT_P,
    maxmem: SCRYPT_MAXMEM,
  });

  return [
    "scrypt",
    SCRYPT_N,
    SCRYPT_R,
    SCRYPT_P,
    salt.toString("base64url"),
    key.toString("base64url"),
  ].join("$");
}

/**
 * Constant-time verification. A malformed or empty stored hash returns false
 * rather than throwing, so a half-written row cannot turn into a 500 on the
 * login form.
 */
export async function verifyPassword(
  password: string,
  storedHash: string | null | undefined
): Promise<boolean> {
  if (!storedHash) return false;

  const parts = storedHash.split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;

  const N = Number.parseInt(parts[1], 10);
  const r = Number.parseInt(parts[2], 10);
  const p = Number.parseInt(parts[3], 10);
  if (!Number.isFinite(N) || !Number.isFinite(r) || !Number.isFinite(p)) {
    return false;
  }

  const salt = Buffer.from(parts[4], "base64url");
  const expected = Buffer.from(parts[5], "base64url");
  if (salt.length === 0 || expected.length === 0) return false;

  let actual: Buffer;
  try {
    actual = await scryptAsync(password, salt, expected.length, {
      N,
      r,
      p,
      maxmem: SCRYPT_MAXMEM,
    });
  } catch {
    return false;
  }

  if (actual.length !== expected.length) return false;
  return timingSafeEqual(actual, expected);
}

/**
 * Password generated when the installer did not supply one. Printed to the
 * console exactly once, at the moment the owner row is created.
 */
export function generatePassword(): string {
  return randomBytes(18).toString("base64url");
}
