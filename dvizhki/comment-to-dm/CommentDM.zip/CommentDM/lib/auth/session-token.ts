/**
 * Session Token
 *
 * A session is a signed value in an httpOnly cookie — no session table, no
 * lookup on every request. The payload carries the owner's user id and an
 * absolute expiry; the signature is HMAC-SHA256 over the encoded payload with
 * SESSION_SECRET.
 *
 * Format: <base64url(json)>.<base64url(hmac)>
 *
 * This module stays free of next/headers and Prisma so it can be unit tested
 * as plain crypto.
 */

import { createHmac, timingSafeEqual } from "node:crypto";

export const SESSION_COOKIE_NAME = "commentdm_session";
export const SESSION_MAX_AGE_SECONDS = 30 * 24 * 60 * 60; // 30 days

export type SessionPayload = {
  /** User.id of the signed-in owner */
  sub: string;
  /** Issued at, epoch milliseconds */
  iat: number;
  /** Absolute expiry, epoch milliseconds */
  exp: number;
};

function sign(payload: string, secret: string): string {
  return createHmac("sha256", secret).update(payload).digest("base64url");
}

export function createSessionToken(
  userId: string,
  secret: string,
  maxAgeSeconds: number = SESSION_MAX_AGE_SECONDS,
  now: number = Date.now()
): string {
  const payload: SessionPayload = {
    sub: userId,
    iat: now,
    exp: now + maxAgeSeconds * 1000,
  };
  const encoded = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${encoded}.${sign(encoded, secret)}`;
}

/**
 * Returns the payload only when the signature matches and the token has not
 * expired. Every other outcome — missing, malformed, tampered, stale — is a
 * null, so callers never have to tell them apart.
 */
export function verifySessionToken(
  token: string | null | undefined,
  secret: string,
  now: number = Date.now()
): SessionPayload | null {
  if (!token) return null;

  const separator = token.lastIndexOf(".");
  if (separator <= 0) return null;

  const encoded = token.slice(0, separator);
  const signature = token.slice(separator + 1);
  if (!encoded || !signature) return null;

  const expected = sign(encoded, secret);
  const signatureBuffer = Buffer.from(signature);
  const expectedBuffer = Buffer.from(expected);
  if (
    signatureBuffer.length !== expectedBuffer.length ||
    !timingSafeEqual(signatureBuffer, expectedBuffer)
  ) {
    return null;
  }

  let payload: SessionPayload;
  try {
    payload = JSON.parse(Buffer.from(encoded, "base64url").toString("utf8"));
  } catch {
    return null;
  }

  if (
    !payload ||
    typeof payload.sub !== "string" ||
    payload.sub.length === 0 ||
    typeof payload.exp !== "number"
  ) {
    return null;
  }

  if (payload.exp <= now) return null;

  return payload;
}
