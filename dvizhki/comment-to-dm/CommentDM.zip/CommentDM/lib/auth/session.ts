/**
 * Session Cookie
 *
 * Reads and writes the signed session cookie, and resolves it to the owner
 * row. Replaces what NextAuth used to provide: `auth()` becomes
 * `getCurrentUser()`, and `getCurrentUserId()` keeps its name and contract so
 * lib/workspace-access.ts does not change shape.
 */

import { cookies } from "next/headers";
import { prisma } from "@/lib/db/client";
import { getSessionSecret } from "@/lib/env";
import { getOrCreateSingleWorkspace } from "@/lib/workspace";
import { sessionCookieOptions } from "@/lib/auth/session-cookie";
import {
  SESSION_COOKIE_NAME,
  SESSION_MAX_AGE_SECONDS,
  createSessionToken,
  verifySessionToken,
} from "@/lib/auth/session-token";

export { SESSION_COOKIE_NAME, SESSION_MAX_AGE_SECONDS };

export type CurrentUser = {
  id: string;
  email: string | null;
  name: string | null;
};

export async function createSessionCookie(userId: string): Promise<void> {
  const cookieStore = await cookies();
  cookieStore.set({
    ...sessionCookieOptions(SESSION_MAX_AGE_SECONDS),
    value: createSessionToken(userId, getSessionSecret()),
  });
}

export async function destroySessionCookie(): Promise<void> {
  const cookieStore = await cookies();
  cookieStore.set({
    ...sessionCookieOptions(0),
    value: "",
  });
}

/**
 * The user id carried by a valid session cookie. Does not touch the database:
 * the signature is the proof.
 */
export async function getCurrentUserId(): Promise<string | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE_NAME)?.value;
  const payload = verifySessionToken(token, getSessionSecret());
  return payload?.sub ?? null;
}

/**
 * The owner row behind the session. Returns null when the cookie points at a
 * user that no longer exists, so a wiped database logs the stale cookie out
 * instead of throwing on a foreign key.
 */
export async function getCurrentUser(): Promise<CurrentUser | null> {
  const userId = await getCurrentUserId();
  if (!userId) return null;

  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { id: true, email: true, name: true },
  });

  return user ?? null;
}

export async function getCurrentWorkspaceId(): Promise<string | null> {
  const user = await getCurrentUser();
  if (!user) return null;

  const workspace = await getOrCreateSingleWorkspace();
  return workspace.id;
}
