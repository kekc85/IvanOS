/**
 * Owner Bootstrap
 *
 * One instance, one owner. NextAuth's Prisma adapter used to be the only thing
 * that ever inserted a `User` row; with it gone, this module is the single
 * writer. It has to run before anything touches a workspace, because
 * `Workspace.ownerId` and `WorkspaceMember.userId` are foreign keys onto that
 * row — on a fresh database the first request would otherwise fail on a
 * constraint rather than on a login form.
 *
 * The password comes from OWNER_PASSWORD at install time. If it is absent and
 * the database is empty, a random one is generated, its hash is stored, and
 * the plaintext is printed to the console exactly once — at creation, never
 * again.
 *
 * OWNER_PASSWORD matters only for that first boot. Once an owner row exists,
 * the stored hash is the sole source of truth — this module never rehashes
 * an existing owner from the environment again. The previous behavior
 * treated OWNER_PASSWORD as an ongoing override (checked and, on mismatch,
 * re-applied on every single start), which meant the real password had to
 * live in .env in plain text for as long as the instance ran, and any script
 * or backup that captured that file captured the password with it. Changing
 * the password now goes through changeOwnerPassword below (wired to
 * Настройки in the dashboard); a genuinely lost password goes through the
 * recovery script, scripts/reset-owner-password.ts, run on the server itself.
 */

import { prisma } from "@/lib/db/client";
import {
  assertPasswordAllowed,
  checkPasswordPolicy,
  generatePassword,
  hashPassword,
  verifyPassword,
} from "@/lib/auth/password";

export type OwnerRecord = {
  id: string;
  email: string | null;
  passwordHash: string | null;
};

export type ChangePasswordResult = { ok: true } | { ok: false; reason: string };

const DEFAULT_OWNER_EMAIL = "owner@localhost";

// Two requests can land on an empty database at the same time. Caching the
// in-flight promise keeps the create (and the one-time console print) single.
let bootstrapPromise: Promise<OwnerRecord> | null = null;

function readOwnerPassword(): string | null {
  const value = process.env.OWNER_PASSWORD;
  if (!value) return null;
  return value;
}

function readOwnerEmail(): string {
  const value = process.env.OWNER_EMAIL?.trim();
  return value && value.length > 0 ? value.toLowerCase() : DEFAULT_OWNER_EMAIL;
}

function announceGeneratedPassword(email: string, password: string): void {
  const banner = [
    "",
    "-".repeat(72),
    "  CommentDM - создан аккаунт владельца",
    "",
    `  Логин:  ${email}`,
    `  Пароль: ${password}`,
    "",
    "  Пароль показан один раз. В базе данных хранится только его хеш - но",
    "  эта строка уходит в системный журнал (journalctl) и остаётся там.",
    "  Сохрани пароль сейчас, а после первого входа смени его в Настройках:",
    "  это сделает старый пароль (тот, что уже в логах) бесполезным.",
    "-".repeat(72),
    "",
  ].join("\n");
  console.log(banner);
}

async function bootstrapOwner(): Promise<OwnerRecord> {
  const existing = await prisma.user.findFirst({
    orderBy: { createdAt: "asc" },
    select: { id: true, email: true, passwordHash: true },
  });

  // The stored hash is the sole source of truth once an owner row exists —
  // see the module doc for why OWNER_PASSWORD is not consulted again here.
  if (existing) return existing;

  const configuredPassword = readOwnerPassword();
  // A password out of the environment is refused before it can ever be
  // stored, so a self-hoster cannot boot an internet-facing instance on
  // "admin" and find out later.
  if (configuredPassword) {
    assertPasswordAllowed(configuredPassword);
  }

  const email = readOwnerEmail();
  const password = configuredPassword ?? generatePassword();
  const passwordHash = await hashPassword(password);

  const created = await prisma.user.create({
    data: {
      email,
      name: "Владелец",
      passwordHash,
    },
    select: { id: true, email: true, passwordHash: true },
  });

  if (!configuredPassword) {
    announceGeneratedPassword(email, password);
  }

  return created;
}

/**
 * Idempotent. Safe to call on every login attempt and on the login page
 * render; the create happens only on an empty database.
 */
export function ensureOwner(): Promise<OwnerRecord> {
  if (!bootstrapPromise) {
    bootstrapPromise = bootstrapOwner().catch((error) => {
      // A failed bootstrap must not be cached, or a transient database outage
      // would wedge login for the lifetime of the process.
      bootstrapPromise = null;
      throw error;
    });
  }
  return bootstrapPromise;
}

/** Test seam: drops the memoized bootstrap. */
export function resetOwnerBootstrapCache(): void {
  bootstrapPromise = null;
}

/**
 * Checks a submitted password against the owner's stored hash.
 * Returns the owner id on success, null on any failure.
 */
export async function verifyOwnerPassword(
  password: string
): Promise<string | null> {
  if (!password) return null;

  const owner = await ensureOwner();
  const matches = await verifyPassword(password, owner.passwordHash);
  return matches ? owner.id : null;
}

/**
 * The normal, in-app way to change the owner password (see the settings
 * page). Requires the current password — this is not a recovery path for a
 * genuinely lost password; that's scripts/reset-owner-password.ts, run on
 * the server itself, outside the web session entirely.
 */
export async function changeOwnerPassword(
  currentPassword: string,
  newPassword: string
): Promise<ChangePasswordResult> {
  const owner = await ensureOwner();

  const matches = await verifyPassword(currentPassword, owner.passwordHash);
  if (!matches) {
    return { ok: false, reason: "Текущий пароль неверен" };
  }

  const policy = checkPasswordPolicy(newPassword);
  if (!policy.ok) {
    return { ok: false, reason: policy.reason };
  }

  const passwordHash = await hashPassword(newPassword);
  await prisma.user.update({
    where: { id: owner.id },
    data: { passwordHash },
  });

  return { ok: true };
}
