/**
 * Session Cookie Attributes
 *
 * One place decides how the cookie is flagged, so the login action, the
 * sign-out route and anything added later cannot drift apart on `secure` or
 * `sameSite`.
 */

import { getBaseUrl } from "@/lib/env";
import {
  SESSION_COOKIE_NAME,
  SESSION_MAX_AGE_SECONDS,
} from "@/lib/auth/session-token";

/**
 * Secure follows the scheme the app is actually served on. Forcing it on would
 * silently drop the cookie on a plain-http localhost, which is where every
 * self-hoster starts before a domain and TLS exist.
 */
export function usesSecureCookie(): boolean {
  return getBaseUrl().startsWith("https://");
}

export function sessionCookieOptions(
  maxAge: number = SESSION_MAX_AGE_SECONDS
) {
  return {
    name: SESSION_COOKIE_NAME,
    httpOnly: true,
    sameSite: "lax" as const,
    secure: usesSecureCookie(),
    path: "/",
    maxAge,
  };
}
