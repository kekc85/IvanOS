/**
 * Login Rate Limit
 *
 * One owner, one password, a public URL — the login form is the only thing an
 * attacker can hammer. Failures are counted per client IP in Redis (already a
 * dependency of the queue) and the form locks for the rest of the window once
 * the budget is spent.
 *
 * The IP itself is never written to Redis, only a salted hash of it.
 */

import { createHash } from "node:crypto";
import Redis from "ioredis";
import { getSessionSecret } from "@/lib/env";

export const LOGIN_MAX_ATTEMPTS = 5;
export const LOGIN_WINDOW_SECONDS = 15 * 60; // 15 minutes

let redis: Redis | null = null;

function getRedis(): Redis {
  if (!redis) {
    redis = new Redis(process.env.REDIS_URL!, {
      maxRetriesPerRequest: null, // required by BullMQ, shared connection style
    });
  }
  return redis;
}

function attemptKey(ipAddress: string | null | undefined): string {
  // No fallback constant: a salt baked into every install of this fork would
  // let anyone precompute the hash for a given IP across every self-hosted
  // instance. An empty SESSION_SECRET fails loudly instead (see lib/env.ts).
  const salt = getSessionSecret();
  const source = ipAddress && ipAddress.length > 0 ? ipAddress : "unknown";
  const digest = createHash("sha256")
    .update(`${salt}:${source}`)
    .digest("hex")
    .slice(0, 32);
  return `login:fail:${digest}`;
}

export type LoginRateLimitResult = {
  allowed: boolean;
  attemptsUsed: number;
  attemptsRemaining: number;
  retryAfterSeconds: number;
};

function toCount(value: string | null): number {
  if (!value) return 0;
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) ? parsed : 0;
}

/**
 * Asked before the password is even hashed, so a locked-out client cannot use
 * the login form to burn CPU on scrypt.
 */
export async function checkLoginRateLimit(
  ipAddress: string | null | undefined
): Promise<LoginRateLimitResult> {
  const client = getRedis();
  const key = attemptKey(ipAddress);

  const attemptsUsed = toCount(await client.get(key));
  if (attemptsUsed < LOGIN_MAX_ATTEMPTS) {
    return {
      allowed: true,
      attemptsUsed,
      attemptsRemaining: LOGIN_MAX_ATTEMPTS - attemptsUsed,
      retryAfterSeconds: 0,
    };
  }

  const ttl = await client.ttl(key);
  return {
    allowed: false,
    attemptsUsed,
    attemptsRemaining: 0,
    // -1 (no expiry) and -2 (no key) both mean "no useful number to show".
    retryAfterSeconds: ttl > 0 ? ttl : LOGIN_WINDOW_SECONDS,
  };
}

/**
 * Records a failed attempt. The window starts at the first failure and is not
 * extended by later ones, so a locked-out client always gets out after
 * LOGIN_WINDOW_SECONDS.
 */
export async function registerFailedLogin(
  ipAddress: string | null | undefined
): Promise<LoginRateLimitResult> {
  const client = getRedis();
  const key = attemptKey(ipAddress);

  const attemptsUsed = await client.incr(key);
  if (attemptsUsed === 1) {
    await client.expire(key, LOGIN_WINDOW_SECONDS);
  }

  const allowed = attemptsUsed < LOGIN_MAX_ATTEMPTS;
  return {
    allowed,
    attemptsUsed,
    attemptsRemaining: allowed ? LOGIN_MAX_ATTEMPTS - attemptsUsed : 0,
    retryAfterSeconds: allowed ? 0 : LOGIN_WINDOW_SECONDS,
  };
}

/** Clears the counter after a successful sign-in. */
export async function clearLoginAttempts(
  ipAddress: string | null | undefined
): Promise<void> {
  const client = getRedis();
  await client.del(attemptKey(ipAddress));
}
