/**
 * Renders a Finding[] two ways: human text for a terminal, or JSON for a
 * student's Claude Code session to parse and act on directly (`--json`,
 * scripts/doctor.ts). Both read the exact same data — nothing is computed
 * only for one of the two output modes.
 */
import { SECTION, type Finding, type FindingLevel } from "./types";

const ICON: Record<FindingLevel, string> = {
  ok: "✅",
  warn: "⚠️",
  error: "❌",
};

// Fixed order so the report always reads top-to-bottom in the order a
// student should actually fix things: nothing works until the environment
// is right, then the database, then Redis, then the worker, then tokens,
// then whether it's all actually doing anything.
const SECTION_ORDER = [
  SECTION.ENV,
  SECTION.DATABASE,
  SECTION.REDIS,
  SECTION.WORKER,
  SECTION.TOKENS,
  SECTION.ACTIVITY,
  SECTION.CHAIN,
];

/**
 * "5 мин назад" / "3 ч назад" / "2 дн назад" — the one way every check names
 * a moment in time, so two sections never describe the same age differently.
 */
export function formatAgo(date: Date): string {
  const ms = Date.now() - date.getTime();
  const minutes = Math.round(ms / 60_000);
  if (minutes < 60) return `${minutes} мин назад`;
  const hours = Math.round(minutes / 60);
  if (hours < 48) return `${hours} ч назад`;
  const days = Math.round(hours / 24);
  return `${days} дн назад`;
}

/** The same scale as formatAgo, but as a length of time: "3 ч", "2 дн". */
export function formatDuration(ms: number): string {
  const minutes = Math.round(ms / 60_000);
  if (minutes < 60) return `${minutes} мин`;
  const hours = Math.round(minutes / 60);
  if (hours < 48) return `${hours} ч`;
  return `${Math.round(hours / 24)} дн`;
}

function groupBySection(findings: Finding[]): Map<string, Finding[]> {
  const groups = new Map<string, Finding[]>();
  for (const section of SECTION_ORDER) groups.set(section, []);
  for (const finding of findings) {
    if (!groups.has(finding.section)) groups.set(finding.section, []);
    groups.get(finding.section)!.push(finding);
  }
  return groups;
}

export interface DoctorSummary {
  ok: number;
  warn: number;
  error: number;
}

export function summarize(findings: Finding[]): DoctorSummary {
  return {
    ok: findings.filter((f) => f.level === "ok").length,
    warn: findings.filter((f) => f.level === "warn").length,
    error: findings.filter((f) => f.level === "error").length,
  };
}

function formatFinding(finding: Finding): string {
  const codeSuffix = finding.code ? ` [${finding.code}]` : "";
  const lines = [`${ICON[finding.level]} ${finding.message}${codeSuffix}`];
  if (finding.detail) {
    lines.push(`   Что случилось: ${finding.detail}`);
  }
  if (finding.command) {
    lines.push(`   Что сделать: ${finding.command}`);
  }
  return lines.join("\n");
}

export function formatHuman(findings: Finding[]): string {
  const groups = groupBySection(findings);
  const summary = summarize(findings);
  const blocks: string[] = [];

  for (const [section, sectionFindings] of groups) {
    if (sectionFindings.length === 0) continue;
    blocks.push(`\n${section}\n${"─".repeat(section.length)}`);
    blocks.push(sectionFindings.map(formatFinding).join("\n\n"));
  }

  const headline =
    summary.error > 0
      ? `❌ Найдено проблем: ${summary.error}, предупреждений: ${summary.warn}`
      : summary.warn > 0
        ? `⚠️ Всё работает, но есть ${summary.warn} предупреждение(й)`
        : `✅ Всё в порядке`;

  return [headline, ...blocks, ""].join("\n");
}

export interface DoctorReport {
  ok: boolean;
  generatedAt: string;
  summary: DoctorSummary;
  findings: Finding[];
}

export function toReport(findings: Finding[]): DoctorReport {
  const summary = summarize(findings);
  return {
    ok: summary.error === 0,
    generatedAt: new Date().toISOString(),
    summary,
    findings,
  };
}

export function formatJson(findings: Finding[]): string {
  return JSON.stringify(toReport(findings), null, 2);
}
