/**
 * Is the background process (worker/dm-worker.ts) actually alive, and — the
 * failure this repo has actually hit — is it running with the same
 * ENCRYPTION_KEY as whatever `.env` doctor itself was launched with.
 *
 * Reads the heartbeat with doctor's own bounded Redis client
 * (lib/doctor/redis-client.ts), not lib/ops/worker-health.ts's
 * getWorkerHealth() — that one goes through getRedisConnection(), which has
 * no connect timeout and would hang this check forever against a dead Redis.
 * The key name, TTL, and payload shape are still the real ones the worker
 * writes (imported from lib/ops/worker-health.ts), so this reads the exact
 * same heartbeat — just through a connection that knows how to give up.
 */
import {
  WORKER_HEALTH_KEY,
  WORKER_HEARTBEAT_TTL_SECONDS,
  type WorkerHeartbeat,
} from "@/lib/ops/worker-health";
import { withDoctorRedis } from "../redis-client";
import { CODES, SECTION, error, ok, warn, type Finding } from "../types";

function formatAge(ageMs: number): string {
  const seconds = Math.round(ageMs / 1000);
  if (seconds < 60) return `${seconds} сек назад`;
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `${minutes} мин назад`;
  const hours = Math.round(minutes / 60);
  return `${hours} ч назад`;
}

function parseHeartbeat(raw: string | null): WorkerHeartbeat | null {
  if (!raw) return null;
  try {
    return JSON.parse(raw) as WorkerHeartbeat;
  } catch {
    return null;
  }
}

const START_COMMAND =
  "npm run worker   # или, если установлено через install.sh: sudo systemctl status commentdm-worker";

/**
 * The same heartbeat, reduced to the two facts another check needs about the
 * background process rather than about the person reading the report: is it
 * alive right now, and when did this particular process start.
 *
 * checks/chain.ts needs both. "Alive" alone cannot tell a stalled chain
 * contour from a quiet one — the chain contours only write to the journal
 * when something happens, so silence is normal. What is not normal is
 * silence since the worker started: every contour logs one line on its first
 * pass, so `startedAt` is what turns "no events" into a verdict.
 */
export interface WorkerLiveness {
  alive: boolean;
  startedAt: Date | null;
}

export async function readWorkerLiveness(
  redisUrl: string
): Promise<WorkerLiveness> {
  const heartbeat = parseHeartbeat(
    await withDoctorRedis(redisUrl, (client) => client.get(WORKER_HEALTH_KEY))
  );

  if (!heartbeat) return { alive: false, startedAt: null };

  const ageMs = Date.now() - new Date(heartbeat.checkedAt).getTime();
  const startedAt = heartbeat.startedAt ? new Date(heartbeat.startedAt) : null;

  return {
    alive: Number.isFinite(ageMs) && ageMs <= WORKER_HEARTBEAT_TTL_SECONDS * 1000,
    startedAt:
      startedAt && !Number.isNaN(startedAt.getTime()) ? startedAt : null,
  };
}

/**
 * `currentKeyFingerprint` is doctor's own view of ENCRYPTION_KEY (see
 * getEncryptionKeyFingerprint in lib/env.ts) — pass `null` if the env check
 * already failed on a missing/placeholder key, so this doesn't pile a second,
 * confusing finding on top of that one.
 */
export async function checkWorker(
  redisUrl: string,
  currentKeyFingerprint: string | null
): Promise<Finding[]> {
  const result = await withDoctorRedis(redisUrl, (client) =>
    client.get(WORKER_HEALTH_KEY)
  );

  if (result === null) {
    // Either Redis itself is unreachable (already reported by checkRedisAndQueue)
    // or the key genuinely isn't set. Either way, the worker cannot be
    // confirmed alive.
    return [
      error(SECTION.WORKER, CODES.WORKER_DOWN, "Фоновый процесс не отвечает", {
        detail:
          "Нет ни одной отметки \"я жив\" от фонового процесса. Либо он не запущен, либо не может достучаться до Redis.",
        command: START_COMMAND,
      }),
    ];
  }

  const heartbeat = parseHeartbeat(result);
  if (!heartbeat) {
    return [
      error(SECTION.WORKER, CODES.WORKER_DOWN, "Фоновый процесс не отвечает", {
        detail: "Отметка о работе фонового процесса повреждена или не найдена.",
        command: START_COMMAND,
      }),
    ];
  }

  const ageMs = Date.now() - new Date(heartbeat.checkedAt).getTime();
  const findings: Finding[] = [];

  if (ageMs > WORKER_HEARTBEAT_TTL_SECONDS * 1000) {
    findings.push(
      error(SECTION.WORKER, CODES.WORKER_DOWN, "Фоновый процесс не отвечает", {
        detail: `Последний раз давал знать о себе ${formatAge(ageMs)} (pid ${heartbeat.pid}${heartbeat.hostname ? `, ${heartbeat.hostname}` : ""}). Похоже, он остановился.`,
        command: START_COMMAND,
      })
    );
  } else {
    findings.push(
      ok(
        SECTION.WORKER,
        "Фоновый процесс жив",
        `Последний раз отвечал ${formatAge(ageMs)} (pid ${heartbeat.pid}${heartbeat.hostname ? `, ${heartbeat.hostname}` : ""})`
      )
    );

    // Only worth comparing keys while the heartbeat is fresh — a stale one is
    // already flagged above, and its fingerprint could be an old process's.
    if (currentKeyFingerprint !== null) {
      if (!heartbeat.encryptionKeyFingerprint) {
        findings.push(
          warn(
            SECTION.WORKER,
            CODES.ENCRYPTION_KEY_MISMATCH,
            "Не удалось проверить, совпадает ли ключ шифрования у фонового процесса",
            {
              detail:
                "Фоновый процесс запущен старой версией и не публикует отпечаток своего ключа. Перезапусти его после обновления кода.",
              command: START_COMMAND,
            }
          )
        );
      } else if (heartbeat.encryptionKeyFingerprint !== currentKeyFingerprint) {
        findings.push(
          error(
            SECTION.WORKER,
            CODES.ENCRYPTION_KEY_MISMATCH,
            "Ключ шифрования у фонового процесса не совпадает с текущим .env",
            {
              detail:
                "Приложение и фоновый процесс расшифровывают токены Instagram разными ключами. Пока это не исправлено, отправки будут молча проваливаться. Обычно это значит, что .env поменяли, но фоновый процесс не перезапустили.",
              command:
                "npm run worker   # перезапусти фоновый процесс, чтобы он подхватил текущий .env",
            }
          )
        );
      } else {
        findings.push(
          ok(SECTION.WORKER, "Ключ шифрования у приложения и фонового процесса совпадает")
        );
      }
    }
  }

  return findings;
}
