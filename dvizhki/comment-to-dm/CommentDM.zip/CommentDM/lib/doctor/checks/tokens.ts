/**
 * The core self-diagnosis this tool exists for: not "is there a token in the
 * database" but "does it still decrypt, and does Meta still accept it".
 *
 * Two separate failure points, checked in order, because they need two
 * different fixes:
 *  1. decryptToken throws → the stored ciphertext doesn't match the current
 *     ENCRYPTION_KEY (see checks/worker.ts for the usual cause: the key
 *     changed and this account was connected under the old one). No amount
 *     of reconnecting on Instagram's side fixes this — the student must
 *     disconnect and reconnect the account here so it gets re-encrypted
 *     under the current key.
 *  2. decrypts fine, but Meta rejects the plaintext token → Instagram itself
 *     revoked or expired it (password change, app uninstalled, 60 days up).
 *     Reconnecting on Instagram's side *does* fix this.
 * A network failure or a Meta-side error (rate limit, 5xx, unreachable) is
 * neither of those — see classifyMetaError, which is what keeps this tool
 * from telling a student to "fix" something that is actually broken on
 * Meta's end.
 */
import {
  getUserInfo,
  MetaApiError,
  PermissionError,
  RateLimitError,
  TokenExpiredError,
} from "@/lib/meta/client";
import { decryptToken } from "@/lib/meta/oauth";
import type { DoctorPrisma } from "../prisma-loader";
import { DoctorTimeoutError, withTimeout } from "../timeout";
import { CODES, SECTION, error, ok, warn, type Finding } from "../types";

const META_CALL_TIMEOUT_MS = 5000;

export function classifyMetaError(username: string, err: unknown): Finding {
  if (err instanceof DoctorTimeoutError) {
    return warn(
      SECTION.TOKENS,
      CODES.META_UNREACHABLE,
      `Не получилось достучаться до Meta для @${username}`,
      {
        detail: "Это не у тебя сломалось, это Meta (или сеть до неё) не ответила вовремя. Попробуй ещё раз чуть позже.",
        command: "curl -sI https://graph.instagram.com   # проверь, отвечает ли Meta вообще",
      }
    );
  }

  if (err instanceof TokenExpiredError) {
    return error(
      SECTION.TOKENS,
      CODES.TOKEN_REJECTED_BY_META,
      `Токен Instagram для @${username} больше не работает`,
      {
        detail: "Meta отозвала доступ — обычно это смена пароля аккаунта, отключение приложения в настройках Instagram, или 60 дней без продления.",
        command: "Зайди в Настройки этой программы и нажми «Подключить заново» для аккаунта @" + username,
      }
    );
  }

  if (err instanceof PermissionError) {
    return error(
      SECTION.TOKENS,
      CODES.TOKEN_REJECTED_BY_META,
      `Meta отказала в доступе для @${username}`,
      {
        detail: "Аккаунт подключён без нужных разрешений — обычно это значит, что его подключали до того, как разрешения поменялись.",
        command: "Зайди в Настройки этой программы и нажми «Подключить заново» для аккаунта @" + username,
      }
    );
  }

  if (err instanceof RateLimitError) {
    return warn(
      SECTION.TOKENS,
      CODES.META_UNREACHABLE,
      `Meta сейчас ограничивает запросы для @${username}`,
      {
        detail: "Это не у тебя сломалось, это Meta придерживает частоту запросов (rate limit). Само пройдёт — как правило, в течение часа.",
      }
    );
  }

  if (err instanceof MetaApiError) {
    return warn(
      SECTION.TOKENS,
      CODES.META_UNREACHABLE,
      `Meta вернула ошибку для @${username}, которую не получилось точно распознать`,
      {
        detail: `Код ${err.code}${err.subcode ? `/${err.subcode}` : ""}: ${err.message}. Похоже на временный сбой на стороне Meta, а не на поломку в настройке.`,
      }
    );
  }

  const message = err instanceof Error ? err.message : String(err);
  return warn(
    SECTION.TOKENS,
    CODES.META_UNREACHABLE,
    `Не получилось соединиться с Meta для @${username}`,
    {
      detail: `Это не у тебя сломалось в настройке аккаунта — похоже на сетевую проблему или недоступность Meta: ${message}`,
      command: "curl -sI https://graph.instagram.com   # проверь, отвечает ли Meta вообще",
    }
  );
}

interface AccountRow {
  id: string;
  username: string;
  accessToken: string;
}

export async function checkAccountsTokens(prisma: DoctorPrisma): Promise<Finding[]> {
  let accounts: AccountRow[];
  try {
    accounts = await withTimeout(
      prisma.instagramAccount.findMany({
        select: { id: true, username: true, accessToken: true },
      }),
      5000,
      "Load Instagram accounts"
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return [
      error(SECTION.TOKENS, CODES.DATABASE_UNREACHABLE, "Не удалось прочитать подключённые аккаунты", {
        detail: message,
      }),
    ];
  }

  if (accounts.length === 0) {
    return [
      ok(
        SECTION.TOKENS,
        "Пока не подключено ни одного аккаунта Instagram",
        "Это не поломка — просто нечего проверять, пока не подключишь аккаунт в интерфейсе.",
        CODES.NO_ACCOUNTS_CONNECTED
      ),
    ];
  }

  const findings: Finding[] = [];

  for (const account of accounts) {
    let plaintext: string;
    try {
      plaintext = decryptToken(account.accessToken);
    } catch {
      findings.push(
        error(
          SECTION.TOKENS,
          CODES.TOKEN_UNDECRYPTABLE,
          `Сохранённый токен для @${account.username} не расшифровывается текущим ключом`,
          {
            detail:
              "ENCRYPTION_KEY в .env отличается от ключа, которым был зашифрован этот токен при подключении. Расшифровать его текущим ключом невозможно — только переподключить аккаунт.",
            command: `Зайди в Настройки этой программы, отключи и заново подключи аккаунт @${account.username}`,
          }
        )
      );
      continue;
    }

    try {
      const user = await withTimeout(
        getUserInfo(plaintext),
        META_CALL_TIMEOUT_MS,
        `Meta /me for @${account.username}`
      );
      findings.push(
        ok(
          SECTION.TOKENS,
          `Токен для @${account.username} расшифровывается и принят Meta`,
          `Подтверждено живым запросом к Meta: ${user.username}${user.followers_count !== undefined ? `, подписчиков: ${user.followers_count}` : ""}`
        )
      );
    } catch (err) {
      findings.push(classifyMetaError(account.username, err));
    }
  }

  return findings;
}
