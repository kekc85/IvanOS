/**
 * Database reachability and migration state.
 *
 * Split into three independent findings on purpose: "the generated client
 * doesn't exist" (a student who hasn't run `npm ci` / build yet), "Postgres
 * isn't answering" (wrong DATABASE_URL, or Postgres isn't running), and
 * "Postgres answers but the schema is behind" (migrations never applied, or
 * applied against a database that got reset) are three different fixes and
 * should never be flattened into one vague "database problem".
 */
import { readdirSync } from "node:fs";
import { join } from "node:path";
import type { DoctorPrisma } from "../prisma-loader";
import { withTimeout } from "../timeout";
import { CODES, SECTION, error, ok, type Finding } from "../types";

const DB_TIMEOUT_MS = 3000;

export function checkPrismaClientMissing(): Finding {
  return error(
    SECTION.DATABASE,
    CODES.PRISMA_CLIENT_MISSING,
    "Клиент базы данных Prisma не собран",
    {
      detail:
        "Программа не может говорить с базой данных, пока не сгенерирован её клиент из схемы. Это одноразовый шаг после установки или обновления зависимостей.",
      command: "npm run db:generate",
    }
  );
}

export async function checkDatabaseReachable(
  prisma: DoctorPrisma
): Promise<Finding> {
  try {
    await withTimeout(
      prisma.$queryRaw`SELECT 1`,
      DB_TIMEOUT_MS,
      "Database SELECT 1"
    );
    return ok(SECTION.DATABASE, "База данных отвечает");
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return error(SECTION.DATABASE, CODES.DATABASE_UNREACHABLE, "База данных не отвечает", {
      detail: message,
      command:
        "sudo systemctl status postgresql   # проверь, что Postgres запущен, и что DATABASE_URL в .env правильный",
    });
  }
}

interface MigrationRow {
  migration_name: string;
  finished_at: Date | null;
}

/**
 * Reads the migration folder names shipped in this checkout and compares
 * them against `_prisma_migrations` in the live database. Deliberately raw
 * SQL instead of shelling out to `prisma migrate status` — that subprocess
 * is slow to spawn and its text output isn't something to parse reliably;
 * this is the same table Prisma itself reads for that command.
 */
export async function checkMigrations(
  prisma: DoctorPrisma,
  migrationsDir: string = join(process.cwd(), "prisma", "migrations")
): Promise<Finding> {
  let expected: string[];
  try {
    expected = readdirSync(migrationsDir, { withFileTypes: true })
      .filter((entry) => entry.isDirectory())
      .map((entry) => entry.name);
  } catch {
    // No migrations folder in this checkout at all — nothing to verify against.
    return ok(SECTION.DATABASE, "Папка миграций не найдена, проверять нечего");
  }

  if (expected.length === 0) {
    return ok(SECTION.DATABASE, "Папка миграций пуста, проверять нечего");
  }

  let applied: MigrationRow[];
  try {
    applied = await withTimeout(
      prisma.$queryRaw<
        MigrationRow[]
      >`SELECT migration_name, finished_at FROM _prisma_migrations`,
      DB_TIMEOUT_MS,
      "Migration status query"
    );
  } catch {
    // Table doesn't exist yet (brand-new database) or query failed — either
    // way, nothing is confirmed applied.
    applied = [];
  }

  const appliedNames = new Set(
    applied.filter((row) => row.finished_at !== null).map((row) => row.migration_name)
  );
  const missing = expected.filter((name) => !appliedNames.has(name));

  if (missing.length === 0) {
    return ok(
      SECTION.DATABASE,
      "Миграции применены",
      `${expected.length} из ${expected.length}`
    );
  }

  return error(
    SECTION.DATABASE,
    CODES.MIGRATIONS_PENDING,
    "Схема базы данных отстаёт от кода",
    {
      detail: `Не применено: ${missing.join(", ")}`,
      command: "npm run db:migrate",
    }
  );
}
