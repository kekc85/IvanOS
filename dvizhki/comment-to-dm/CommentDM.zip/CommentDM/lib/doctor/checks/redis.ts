/**
 * Redis reachability and how deep the DM send queue has piled up.
 *
 * Uses doctor's own bounded connection (lib/doctor/redis-client.ts), never
 * lib/queue/client.ts's getRedisConnection() — that one is built with
 * `maxRetriesPerRequest: null` for BullMQ's sake and, with a dead Redis,
 * simply never gives up. See redis-client.ts's module comment for the full
 * story.
 */
import { Queue } from "bullmq";
import { withDoctorRedis } from "../redis-client";
import { CODES, SECTION, error, ok, warn, type Finding } from "../types";

// A handful of waiting jobs is normal churn; tens of them sitting idle
// usually means the worker is down or stuck, not that traffic is heavy —
// this tool sends DMs one comment at a time, never in bulk.
const WAITING_BACKLOG_WARN = 50;
const FAILED_BACKLOG_WARN = 20;

export async function checkRedisAndQueue(redisUrl: string): Promise<Finding[]> {
  const findings: Finding[] = [];

  const result = await withDoctorRedis(redisUrl, async (client) => {
    const pong = await client.ping();
    findings.push(ok(SECTION.REDIS, "Redis отвечает", pong));

    const queue = new Queue("dm-processing", { connection: client });
    try {
      const counts = await queue.getJobCounts("waiting", "active", "delayed", "failed");
      const backlog = (counts.waiting ?? 0) + (counts.delayed ?? 0);
      const failed = counts.failed ?? 0;

      if (backlog > WAITING_BACKLOG_WARN || failed > FAILED_BACKLOG_WARN) {
        findings.push(
          warn(
            SECTION.REDIS,
            CODES.QUEUE_BACKLOG,
            "В очереди отправки скопилось много задач",
            {
              detail: `Ждут: ${counts.waiting ?? 0}, отложены: ${counts.delayed ?? 0}, в работе: ${counts.active ?? 0}, провалились: ${failed}. Обычно это значит, что фоновый процесс стоит или не успевает.`,
              command: "npm run -s doctor -- --json | grep E-08   # проверь, жив ли фоновый процесс",
            }
          )
        );
      } else {
        findings.push(
          ok(
            SECTION.REDIS,
            "Очередь отправки в порядке",
            `Ждут: ${counts.waiting ?? 0}, отложены: ${counts.delayed ?? 0}, в работе: ${counts.active ?? 0}, провалились: ${failed}`
          )
        );
      }
    } finally {
      await queue.close().catch(() => {});
    }
  });

  if (result === null && findings.length === 0) {
    return [
      error(SECTION.REDIS, CODES.REDIS_UNREACHABLE, "Redis не отвечает", {
        detail: "Без Redis не работает ни очередь отправки, ни отметки о том, что фоновый процесс жив.",
        command: "sudo systemctl status redis-server   # проверь, что Redis запущен, и что REDIS_URL в .env правильный",
      }),
    ];
  }

  return findings;
}
