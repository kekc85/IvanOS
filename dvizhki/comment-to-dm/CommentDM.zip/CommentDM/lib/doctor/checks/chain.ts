/**
 * Цепочки касаний: движутся ли они, и не срываются ли скопом.
 *
 * Цепочка — единственная часть системы, которая продолжает писать человеку
 * ПОСЛЕ первого сообщения (lib/chain/conversation-poller.ts узнаёт, что
 * человек ответил, lib/chain/step-dispatcher.ts шлёт следующие шаги). Оба
 * контура живут интервалами внутри фонового процесса и наружу видны ровно
 * двумя способами: строками в журнале операционных событий и состоянием
 * журнеев в базе. Эта проверка читает и то, и другое.
 *
 * Главная ловушка здесь — та же, что у опроса комментариев (см.
 * checks/activity.ts): контуры цепочки пишут в журнал ТОЛЬКО когда есть что
 * сообщить (кто-то ответил, ушёл шаг, закрылось окно) плюс один раз на первом
 * проходе после запуска. Значит «давно ничего не писал» само по себе не
 * поломка: при живом фоновом процессе это чаще всего значит, что сейчас
 * просто никто не идёт по цепочке. Отсюда два честных сигнала вместо наивной
 * проверки возраста записи:
 *   - контур не отметился в журнале НИ РАЗУ с момента запуска фонового
 *     процесса (первый проход обязан был написать) — контур не запустился;
 *   - в базе лежат журнеи, которым пора отправлять шаг, а шаг не ушёл —
 *     диспетчер стоит. Это доказательство, а не догадка: очередь шагов
 *     разбирается каждые 30 секунд.
 */
import { formatAgo, formatDuration } from "../format";
import type { DoctorPrisma } from "../prisma-loader";
import { withTimeout } from "../timeout";
import { CODES, SECTION, error, ok, warn, type Finding } from "../types";
import type { WorkerLiveness } from "./worker";

const QUERY_TIMEOUT_MS = 5000;
/** Диспетчер ходит каждые 30 секунд, опрос диалогов — каждые 90. */
const STALE_MS = 15 * 60 * 1000;
/** Фоновый процесс только поднялся — первые проходы ещё впереди. */
const STARTUP_GRACE_MS = 5 * 60 * 1000;
const STATS_WINDOW_DAYS = 7;
const FAILED_SHARE_THRESHOLD = 0.2;
/** Ниже этого числа доля сорвавшихся — статистический шум, а не сигнал. */
const MIN_TOTAL_FOR_SHARE = 5;

const RESTART_COMMAND =
  "sudo systemctl restart commentdm-worker   # или, если запускаешь вручную: npm run worker";

const JOURNAL_COMMAND =
  'psql "$DATABASE_URL" -c "SELECT \\"createdAt\\", message FROM \\"OperationalEvent\\" WHERE message LIKE \'Цепочка%\' ORDER BY \\"createdAt\\" DESC LIMIT 20"';

const STUCK_JOURNEYS_COMMAND =
  'psql "$DATABASE_URL" -c "SELECT id, \\"automationId\\", \\"nextStepPosition\\", \\"updatedAt\\" FROM \\"SubscriberJourney\\" WHERE state = \'ACTIVE\' AND \\"nextStepDueAt\\" IS NULL ORDER BY \\"updatedAt\\" DESC LIMIT 20"';

interface Contour {
  label: string;
  /** Начало строки, которую этот контур пишет в журнал. */
  prefix: string;
}

const CONTOURS: Contour[] = [
  { label: "Диспетчер шагов", prefix: "Цепочка: проход диспетчера" },
  { label: "Опрос диалогов", prefix: "Цепочка: опрос диалогов" },
];

const STATE_LABELS: Record<string, string> = {
  GATE_SENT: "ждут ответа",
  ACTIVE: "идут",
  DONE: "дошли до конца",
  EXPIRED: "закрыты окном",
  STOPPED: "человек попросил остановиться",
  SKIPPED: "пропущены",
  FAILED: "сорвались",
};

async function checkContourFreshness(
  prisma: DoctorPrisma,
  worker: WorkerLiveness | null,
  contour: Contour
): Promise<Finding> {
  const event = await withTimeout(
    prisma.operationalEvent.findFirst({
      where: { source: "WORKER", message: { startsWith: contour.prefix } },
      orderBy: { createdAt: "desc" },
    }),
    QUERY_TIMEOUT_MS,
    `Last chain event lookup (${contour.label})`
  );

  if (!worker || !worker.alive) {
    // Раздел «Фоновый процесс» уже сказал об этом громко. Второй раз кричать
    // тем же голосом значит увести новичка чинить цепочку вместо процесса.
    return ok(
      SECTION.CHAIN,
      `${contour.label}: проверять нечего, пока фоновый процесс не отвечает`,
      "Цепочка движется только внутри фонового процесса. Сначала раздел «Фоновый процесс» выше."
    );
  }

  if (event && Date.now() - event.createdAt.getTime() <= STALE_MS) {
    return ok(
      SECTION.CHAIN,
      `${contour.label} отработал ${formatAgo(event.createdAt)}`,
      event.message
    );
  }

  if (!worker.startedAt) {
    // Старая сборка фонового процесса не сообщает момент запуска — отличить
    // «тихо» от «встал» отсюда нечем, поэтому предупреждение, а не ошибка.
    return warn(
      SECTION.CHAIN,
      CODES.CHAIN_STALLED,
      `${contour.label} давно ничего не писал в журнал`,
      {
        detail: event
          ? `Последняя запись: ${formatAgo(event.createdAt)}. Фоновый процесс не сообщает, когда он стартовал (запущен старой версией кода), поэтому отличить «тихо, потому что никто не идёт по цепочке» от «контур встал» отсюда нельзя. Перезапусти его - и эта проверка станет точной.`
          : `Записей от этого контура нет вообще, а фоновый процесс не сообщает, когда он стартовал (запущен старой версией кода). Перезапусти его - и эта проверка станет точной.`,
        command: RESTART_COMMAND,
      }
    );
  }

  const uptimeMs = Date.now() - worker.startedAt.getTime();

  if (uptimeMs < STARTUP_GRACE_MS) {
    return ok(
      SECTION.CHAIN,
      `${contour.label}: фоновый процесс только запустился`,
      `Он поднялся ${formatDuration(uptimeMs)} назад - дай ему несколько минут и прогони проверку ещё раз.`
    );
  }

  const loggedSinceStart =
    event !== null && event.createdAt.getTime() >= worker.startedAt.getTime();

  if (!loggedSinceStart) {
    return error(
      SECTION.CHAIN,
      CODES.CHAIN_STALLED,
      `${contour.label} не запустился внутри фонового процесса`,
      {
        detail: `Фоновый процесс работает уже ${formatDuration(uptimeMs)}, но этот контур ни разу не отметился в журнале с момента его запуска - а первый проход он записывает всегда. Пока это так, сообщения цепочки никому не уходят.`,
        command: RESTART_COMMAND,
      }
    );
  }

  return ok(
    SECTION.CHAIN,
    `${contour.label}: тихо, последняя запись ${formatAgo(event!.createdAt)}`,
    "Контуры цепочки пишут в журнал только когда есть что сообщить: кто-то ответил, ушёл шаг, закрылось окно. При живом фоновом процессе тишина значит, что сейчас просто никто не идёт по цепочке."
  );
}

/**
 * Два разных способа для цепочки встать, и оба видны только из базы.
 *
 * Первый - журней в ACTIVE, которому пора было отправить шаг больше 15 минут
 * назад. Очередь шагов разбирается каждые 30 секунд, так что «пора» дольше
 * четверти часа - это уже не задержка, а остановка диспетчера.
 *
 * Второй тише и хуже: журней в ACTIVE, у которого срок следующего шага ПУСТ.
 * Диспетчер ищет по `nextStepDueAt <= now`, и NULL под это условие не попадает
 * никогда - такой журней не подберёт ни один проход, сколько ни перезапускай
 * процесс. Человек остаётся без остатка цепочки, а раздел, смотрящий только на
 * просроченные сроки, при этом рапортует «застрявших шагов нет».
 */
async function checkStuckSteps(
  prisma: DoctorPrisma,
  worker: WorkerLiveness | null
): Promise<Finding[]> {
  if (!worker || !worker.alive) return [];

  const cutoff = new Date(Date.now() - STALE_MS);

  const [overdue, stranded] = await Promise.all([
    withTimeout(
      prisma.subscriberJourney.count({
        where: {
          state: "ACTIVE",
          nextStepDueAt: { lt: cutoff },
        },
      }),
      QUERY_TIMEOUT_MS,
      "Overdue chain steps"
    ),
    withTimeout(
      prisma.subscriberJourney.count({
        where: {
          state: "ACTIVE",
          nextStepDueAt: null,
          updatedAt: { lt: cutoff },
        },
      }),
      QUERY_TIMEOUT_MS,
      "Stranded chain journeys"
    ),
  ]);

  const findings: Finding[] = [];

  if (overdue > 0) {
    findings.push(
      error(SECTION.CHAIN, CODES.CHAIN_STALLED, "Шаги цепочки не уходят", {
        detail: `${overdue} человек(а) ждут следующего сообщения цепочки дольше 15 минут. Диспетчер разбирает очередь каждые 30 секунд, так что такая задержка значит, что он не работает. У Meta на переписку есть только сутки от последнего сообщения человека - чем дольше это стоит, тем больше цепочек закроется по окну.`,
        command: RESTART_COMMAND,
      })
    );
  }

  if (stranded > 0) {
    findings.push(
      error(SECTION.CHAIN, CODES.CHAIN_STALLED, "Застрявшая цепочка", {
        detail: `${stranded} цепочек(и) числятся идущими, но срок следующего шага у них пуст, и в базе их никто не трогал дольше 15 минут. Диспетчер выбирает журнеи по наступившему сроку, а пустой срок не наступает никогда - такую цепочку не сдвинет даже перезапуск фонового процесса. Обычно это след сбоя ровно между отправкой шага и отметкой о ней.`,
        command: STUCK_JOURNEYS_COMMAND,
      })
    );
  }

  if (findings.length > 0) return findings;

  return [
    ok(
      SECTION.CHAIN,
      "Застрявших шагов нет",
      "Никто не ждёт следующего сообщения цепочки дольше 15 минут, зависших без срока цепочек тоже нет."
    ),
  ];
}

async function checkJourneyOutcomes(prisma: DoctorPrisma): Promise<Finding> {
  const since = new Date(Date.now() - STATS_WINDOW_DAYS * 24 * 60 * 60 * 1000);

  const grouped = await withTimeout(
    prisma.subscriberJourney.groupBy({
      by: ["state"],
      where: { createdAt: { gte: since } },
      _count: { _all: true },
    }),
    QUERY_TIMEOUT_MS,
    "Chain journey states"
  );

  const total = grouped.reduce((sum, row) => sum + row._count._all, 0);

  if (total === 0) {
    return ok(
      SECTION.CHAIN,
      "За последние 7 дней в цепочку никто не заходил",
      "Цепочка включена, но ни один человек в неё не попал. Если комментарии с кодовым словом были, смотри раздел «Опрос комментариев и отправки» - до цепочки дело просто не доходит."
    );
  }

  const breakdown = [...grouped]
    .sort((a, b) => b._count._all - a._count._all)
    .map((row) => `${STATE_LABELS[row.state] ?? row.state}: ${row._count._all}`)
    .join(", ");

  const failed =
    grouped.find((row) => row.state === "FAILED")?._count._all ?? 0;

  if (total >= MIN_TOTAL_FOR_SHARE && failed / total > FAILED_SHARE_THRESHOLD) {
    return warn(
      SECTION.CHAIN,
      CODES.CHAIN_STALLED,
      "Слишком много цепочек срывается",
      {
        detail: `За 7 дней в цепочку зашли ${total} человек(а), сорвалось ${failed} (${Math.round((failed / total) * 100)}%). Разбивка: ${breakdown}. Причину каждая сорвавшаяся цепочка записала в журнал операционных событий - смотри там или на странице «Диагностика» (/diagnostics) в интерфейсе. Страница «Журнал отправок» (/logs) тут не поможет: в ней DmLog, кому и когда ушло сообщение, без причин срыва цепочек.`,
        command: JOURNAL_COMMAND,
      }
    );
  }

  // Доля на трёх журнеях ничего не значит, но молчать тут нельзя: у новой
  // установки первые люди и есть вся статистика, и «сорвались все трое»
  // выглядело бы зелёным разделом ровно тогда, когда контур не работает
  // вообще. Поэтому предупреждение, а не ошибка: одна сорвавшаяся цепочка на
  // старте - это ещё и просто человек, закрывший окно.
  if (total < MIN_TOTAL_FOR_SHARE && failed > 0) {
    return warn(
      SECTION.CHAIN,
      CODES.CHAIN_STALLED,
      "Цепочек мало, но срывы есть",
      {
        detail: `За 7 дней в цепочку зашли всего ${total} человек(а), и ${failed} из них сорвалось. Доли на таких числах не о чем говорить, поэтому это не приговор контуру - но причину каждая сорвавшаяся цепочка записала в журнал операционных событий, и на старте её стоит прочитать. Разбивка: ${breakdown}.`,
        command: JOURNAL_COMMAND,
      }
    );
  }

  return ok(SECTION.CHAIN, `Цепочек за последние 7 дней: ${total}`, breakdown);
}

/**
 * `worker` — состояние фонового процесса из checks/worker.ts. `null`, если
 * его вообще не проверяли (нет REDIS_URL): тогда проверка не делает вид, что
 * знает, жив он или нет.
 */
export async function checkChain(
  prisma: DoctorPrisma,
  worker: WorkerLiveness | null
): Promise<Finding[]> {
  try {
    const chainCampaigns = await withTimeout(
      prisma.automation.count({ where: { chainEnabled: true } }),
      QUERY_TIMEOUT_MS,
      "Chain campaign count"
    );

    // Ни одной кампании с цепочкой - раздел говорит это одной строкой и
    // замолкает. Тишина была бы хуже: раздел без находок вообще не попадает в
    // отчёт (см. format.ts), и это читается как «не проверяли».
    if (chainCampaigns === 0) {
      return [
        ok(
          SECTION.CHAIN,
          "Цепочки не используются",
          "Ни в одной кампании цепочка касаний не включена - проверять нечего."
        ),
      ];
    }

    const [contours, stuck, outcomes] = await Promise.all([
      Promise.all(
        CONTOURS.map((contour) => checkContourFreshness(prisma, worker, contour))
      ),
      checkStuckSteps(prisma, worker),
      checkJourneyOutcomes(prisma),
    ]);

    return [...contours, ...stuck, outcomes];
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return [
      warn(
        SECTION.CHAIN,
        CODES.CHAIN_STALLED,
        "Не удалось проверить цепочки касаний",
        { detail: message }
      ),
    ];
  }
}
