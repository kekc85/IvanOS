/**
 * Is anything actually happening: has the comment sweep run recently, and
 * are the DMs it queues actually going out.
 *
 * The comment sweep (lib/polling/comment-reconciler.ts) only writes an
 * OperationalEvent when it finds something worth logging (a match, a stale
 * comment, an error) — a quiet sweep with nothing to report writes nothing,
 * by design (see recordSweep there). So "no sweep event yet" is read here as
 * "hasn't found anything to act on", not as "broken" — checks/worker.ts's
 * heartbeat is what actually answers "is polling running at all".
 *
 * Token refresh (lib/ops/token-refresh-job.ts), by contrast, writes one
 * OperationalEvent on every run, success or failure — that file's own
 * comment names this as the contract `npm run doctor` reads, so staleness
 * here really does mean the job stopped firing.
 */
import { pluralRu } from "@/lib/utils/plural";
import { formatAgo } from "../format";
import type { DoctorPrisma } from "../prisma-loader";
import { withTimeout } from "../timeout";
import { CODES, SECTION, ok, warn, type Finding } from "../types";

const QUERY_TIMEOUT_MS = 5000;
const DAY_MS = 24 * 60 * 60 * 1000;
// Token refresh runs once a day; give it a generous window before flagging.
const TOKEN_REFRESH_STALE_MS = 36 * 60 * 60 * 1000;

async function checkPollingActivity(
  prisma: DoctorPrisma,
  accountCount: number
): Promise<Finding | null> {
  const event = await withTimeout(
    prisma.operationalEvent.findFirst({
      where: { source: "SYSTEM", message: { startsWith: "Comment sweep" } },
      orderBy: { createdAt: "desc" },
    }),
    QUERY_TIMEOUT_MS,
    "Last comment sweep lookup"
  );

  if (event) {
    return ok(
      SECTION.ACTIVITY,
      `Опрос комментариев последний раз что-то нашёл ${formatAgo(event.createdAt)}`,
      event.message
    );
  }

  // Not null: without this, an install with zero connected accounts loses
  // the entire "Опрос комментариев и отправки" section from the report
  // (format.ts skips a section with no findings), which reads as "this
  // wasn't checked" rather than the true "nothing to check yet" (MEDIUM-6).
  if (accountCount === 0) {
    return ok(
      SECTION.ACTIVITY,
      "Опрос комментариев: нечего проверять",
      "Ни одного аккаунта Instagram ещё не подключено - подключи хотя бы один в Настройках, и опрос начнёт работать."
    );
  }

  return ok(
    SECTION.ACTIVITY,
    "Опрос комментариев ещё не находил подходящих комментариев",
    "Это нормально, если аккаунт подключили недавно или ни один комментарий пока не подошёл под условия автоматизации. Если фоновый процесс жив (см. раздел «Фоновый процесс»), опрос идёт по расписанию в фоне.",
    CODES.POLLING_SILENT
  );
}

async function checkTokenRefreshFreshness(prisma: DoctorPrisma): Promise<Finding | null> {
  const event = await withTimeout(
    prisma.operationalEvent.findFirst({
      where: { source: "TOKEN_REFRESH", message: { startsWith: "Token refresh run:" } },
      orderBy: { createdAt: "desc" },
    }),
    QUERY_TIMEOUT_MS,
    "Last token refresh lookup"
  );

  if (!event) return null; // Worker hasn't been up long enough yet; not an error on its own.

  const ageMs = Date.now() - event.createdAt.getTime();
  if (ageMs > TOKEN_REFRESH_STALE_MS) {
    return warn(
      SECTION.ACTIVITY,
      CODES.POLLING_SILENT,
      "Проверка сроков токенов давно не запускалась",
      {
        detail: `Последний раз: ${formatAgo(event.createdAt)}. Она должна запускаться раз в сутки фоновым процессом — если её давно не было, токены могут молча просрочиться.`,
        command: "npm run worker   # проверь, что фоновый процесс запущен",
      }
    );
  }

  return ok(SECTION.ACTIVITY, `Проверка сроков токенов прошла ${formatAgo(event.createdAt)}`, event.message);
}

async function checkRecentSends(
  prisma: DoctorPrisma,
  accountCount: number
): Promise<Finding | null> {
  // Same reasoning as checkPollingActivity above (MEDIUM-6): report "nothing
  // to check" explicitly rather than silently dropping this finding, which
  // would make the whole section vanish when it's the only one left.
  if (accountCount === 0) {
    return ok(
      SECTION.ACTIVITY,
      "Отправки: нечего проверять",
      "Ни одного аккаунта Instagram ещё не подключено - отправлять пока нечем."
    );
  }

  const since = new Date(Date.now() - DAY_MS);
  const grouped = await withTimeout(
    prisma.dmLog.groupBy({
      by: ["status"],
      where: { createdAt: { gte: since } },
      _count: { _all: true },
    }),
    QUERY_TIMEOUT_MS,
    "Recent DM send counts"
  );

  const total = grouped.reduce((sum, row) => sum + row._count._all, 0);
  if (total === 0) {
    return ok(SECTION.ACTIVITY, "Отправок за последние сутки не было", "Ни одного совпавшего комментария за последние 24 часа.");
  }

  const sent = grouped.find((row) => row.status === "SENT")?._count._all ?? 0;
  // Два разных провала, и владельцу важна именно разница: обычный FAILED
  // система повторит сама, FAILED_PERMANENT не повторит никогда (закрытый
  // директ, удалённый комментарий - см. lib/queue/send-failure.ts). Второе
  // чинится не на сервере, поэтому и в отчёте стоит отдельной цифрой.
  const retryable = grouped.find((row) => row.status === "FAILED")?._count._all ?? 0;
  const permanent =
    grouped.find((row) => row.status === "FAILED_PERMANENT")?._count._all ?? 0;
  const failed = retryable + permanent;
  const permanentNote =
    permanent > 0
      ? `, из них ${permanent} ${pluralRu(permanent, "не уйдёт", "не уйдут", "не уйдут")} никогда (у человека закрыт директ, комментарий удалён или приватный ответ уже израсходован - такие отправки система больше не повторяет)`
      : "";

  if (failed > 0 && failed >= sent) {
    const reasons = await withTimeout(
      prisma.dmLog.groupBy({
        by: ["errorMessage"],
        where: {
          createdAt: { gte: since },
          status: { in: ["FAILED", "FAILED_PERMANENT"] },
        },
        _count: { _all: true },
      }),
      QUERY_TIMEOUT_MS,
      "Recent DM failure reasons"
    );

    const reasonLines = reasons
      .sort((a, b) => b._count._all - a._count._all)
      .slice(0, 3)
      .map((row) => `${row._count._all}× ${row.errorMessage ?? "причина не записана"}`)
      .join("; ");

    return warn(
      SECTION.ACTIVITY,
      CODES.SEND_FAILURE_RATE,
      "Много неудачных отправок за последние сутки",
      {
        detail: `Успешно: ${sent}, провалилось: ${failed}${permanentNote}. Частые причины: ${reasonLines}`,
        command: "npm run -s doctor -- --json   # раздел «Шифрование и токены» обычно объясняет причину",
      }
    );
  }

  return ok(
    SECTION.ACTIVITY,
    "Отправки за последние сутки в порядке",
    `Успешно: ${sent}, провалилось: ${failed}${permanentNote}`
  );
}

export async function checkActivity(
  prisma: DoctorPrisma,
  accountCount: number
): Promise<Finding[]> {
  try {
    const [polling, tokenRefresh, sends] = await Promise.all([
      checkPollingActivity(prisma, accountCount),
      checkTokenRefreshFreshness(prisma),
      checkRecentSends(prisma, accountCount),
    ]);

    return [polling, tokenRefresh, sends].filter((f): f is Finding => f !== null);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return [
      warn(SECTION.ACTIVITY, CODES.POLLING_SILENT, "Не удалось проверить историю опроса и отправок", {
        detail: message,
      }),
    ];
  }
}
