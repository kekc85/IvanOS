/**
 * Everything the app needs before it can even start, straight from the
 * `.env` doctor itself was launched with (`npm run doctor` loads it the same
 * way `npm run worker` does — see package.json's `--env-file=.env`). Reuses
 * lib/env.ts's serverEnvSchema (the same schema instrumentation.ts gates
 * boot on) so "flagged as fake or missing" here means the exact same thing
 * it does when the app itself refuses to boot on one — but the wording is
 * doctor's own Russian, not zod's raw English `issue.message` (that used to
 * leak straight into this Russian CLI/UI verbatim).
 *
 * INSTAGRAM_APP_ID / INSTAGRAM_APP_SECRET get a second, separate pass below
 * (checkInstagramCredentials) rather than living inside serverEnvSchema
 * itself: that schema gates the app's boot, and the app has to be reachable
 * — login, Settings — before a self-hoster can even see where to paste real
 * Meta credentials in. install.sh writes INSTAGRAM_APP_ID=your-instagram-app-id
 * as a non-empty stand-in precisely so the app boots with it; doctor is
 * where that stand-in gets caught instead of being silently reported as
 * fine (see MEDIUM-5 — previously the placeholder detector only reached
 * SESSION_SECRET and ENCRYPTION_KEY, so a fresh install with untouched
 * Instagram credentials still got a clean "Всё в порядке").
 */
import { isPlaceholderSecret, serverEnvSchema } from "@/lib/env";
import { CODES, SECTION, error, ok, warn, type Finding } from "../types";

const GENERATE_SECRET_COMMAND = "openssl rand -hex 32";

// Which of serverEnvSchema's fields are secrets we placeholder-check, and
// the plain-Russian explanation for each kind of failure — this is what
// replaces parsing zod's English issue.message text.
const SECRET_LIKE_FIELDS = new Set(["SESSION_SECRET", "ENCRYPTION_KEY"]);

function missingOrInvalidDetail(name: string): string {
  switch (name) {
    case "APP_URL":
      return "должен быть полным адресом с протоколом, например https://example.com";
    case "SESSION_SECRET":
      return "должен быть длиной не менее 16 символов - сгенерируй случайную строку";
    case "DATABASE_URL":
      return "не должен быть пустым";
    case "REDIS_URL":
      return "не должен быть пустым";
    case "ENCRYPTION_KEY":
      return "должен быть строкой из 64 шестнадцатеричных символов (32 байта)";
    case "INSTAGRAM_APP_ID":
    case "INSTAGRAM_APP_SECRET":
      return "не должен быть пустым";
    default:
      return "значение не прошло проверку";
  }
}

const INSTAGRAM_CREDENTIAL_VARS = [
  "INSTAGRAM_APP_ID",
  "INSTAGRAM_APP_SECRET",
] as const;

function checkInstagramCredentials(env: NodeJS.ProcessEnv): Finding | null {
  const stillPlaceholder = INSTAGRAM_CREDENTIAL_VARS.filter((name) => {
    const value = env[name];
    return typeof value === "string" && isPlaceholderSecret(value);
  });

  if (stillPlaceholder.length === 0) return null;

  // warn, not error: unlike SESSION_SECRET/ENCRYPTION_KEY, a placeholder
  // here does not stop the app from starting or from doing anything except
  // connecting Instagram — see the module doc. Also keeps
  // runDoctor()'s envOk gate (lib/doctor/run.ts) from treating "Instagram
  // not configured yet" as "the whole environment is broken" and skipping
  // every check downstream of it.
  return warn(
    SECTION.ENV,
    CODES.ENV_PLACEHOLDER,
    `${stillPlaceholder.join(", ")} ещё содержит пример из .env.example, а не настоящее значение из кабинета разработчика Meta`,
    {
      detail:
        "Подключение Instagram не заработает, пока здесь стоит заглушка - приложение при этом запускается нормально, это не блокирует старт.",
      command: `nano .env  # вставь настоящие ${stillPlaceholder.join(" и ")} из https://developers.facebook.com`,
    }
  );
}

export function checkEnv(env: NodeJS.ProcessEnv = process.env): Finding[] {
  const result = serverEnvSchema.safeParse(env);
  const instagramFinding = checkInstagramCredentials(env);

  if (result.success) {
    if (instagramFinding) return [instagramFinding];
    return [
      ok(
        SECTION.ENV,
        "Все переменные окружения на месте и не похожи на примеры",
        "Проверены: APP_URL, SESSION_SECRET, DATABASE_URL, REDIS_URL, ENCRYPTION_KEY, INSTAGRAM_APP_ID, INSTAGRAM_APP_SECRET"
      ),
    ];
  }

  const seen = new Set<string>();
  const findings = result.error.issues
    .map((issue) => issue.path.join(".") || "(переменная окружения)")
    .filter((name) => {
      // A single field (e.g. ENCRYPTION_KEY failing both its regex and its
      // placeholder refine) can produce more than one zod issue — one
      // finding per variable is enough for a human reading this list.
      if (seen.has(name)) return false;
      seen.add(name);
      return true;
    })
    .map((name) => {
      const rawValue = env[name];
      const isPlaceholder =
        SECRET_LIKE_FIELDS.has(name) &&
        typeof rawValue === "string" &&
        isPlaceholderSecret(rawValue);

      if (isPlaceholder) {
        return error(
          SECTION.ENV,
          CODES.ENV_PLACEHOLDER,
          `${name} всё ещё содержит пример из .env.example, а не настоящее значение`,
          {
            detail:
              "Со значением-примером все установки этой программы делят один и тот же секрет - это небезопасно.",
            command: `${GENERATE_SECRET_COMMAND}  # вставь результат в .env как ${name}`,
          }
        );
      }

      return error(
        SECTION.ENV,
        CODES.ENV_MISSING,
        `${name} не задана или задана неправильно`,
        {
          detail: missingOrInvalidDetail(name),
          command: `nano .env  # добавь строку ${name}=...`,
        }
      );
    });

  return instagramFinding ? [...findings, instagramFinding] : findings;
}
