/**
 * Doctor's own Redis connection — deliberately NOT lib/queue/client.ts's
 * getRedisConnection(). That helper is configured with
 * `maxRetriesPerRequest: null` because BullMQ requires it for blocking
 * commands, and ioredis's default reconnect strategy retries forever with
 * growing backoff. Reused here, a dead Redis would make every doctor check
 * that touches it hang indefinitely instead of reporting "Redis не отвечает"
 * — the opposite of what a self-help tool is for.
 *
 * This client instead gives up after one attempt within a short window, so a
 * down Redis fails fast and every dependent check (heartbeat, queue depth)
 * degrades to "could not check" rather than freezing the whole run.
 */
import Redis from "ioredis";
import { withTimeout } from "./timeout";

export const REDIS_CONNECT_TIMEOUT_MS = 2000;

export function createDoctorRedis(url: string): Redis {
  return new Redis(url, {
    // BullMQ's own requirement (see lib/queue/client.ts) — harmless here since
    // we bound the connect attempt ourselves and always disconnect after.
    maxRetriesPerRequest: null,
    lazyConnect: true,
    connectTimeout: REDIS_CONNECT_TIMEOUT_MS,
    // Stop after the first failed attempt instead of ioredis's default
    // infinite exponential backoff.
    retryStrategy: () => null,
    reconnectOnError: () => false,
  });
}

/**
 * Connects, runs `fn` with the live client, and always tears the connection
 * down afterwards — success, failure, or timeout. Returns `null` if the
 * connection could not be established within the timeout, so callers can
 * treat "unreachable" as a plain, expected outcome rather than a thrown error
 * to catch everywhere.
 */
export async function withDoctorRedis<T>(
  url: string,
  fn: (client: Redis) => Promise<T>
): Promise<T | null> {
  const client = createDoctorRedis(url);
  // ioredis logs ECONNREFUSED to stderr by default even with retryStrategy
  // returning null; swallow so a down Redis doesn't spray noise above the
  // report.
  client.on("error", () => {});

  try {
    await withTimeout(client.connect(), REDIS_CONNECT_TIMEOUT_MS, "Redis connect");
    return await fn(client);
  } catch {
    return null;
  } finally {
    client.disconnect();
  }
}
