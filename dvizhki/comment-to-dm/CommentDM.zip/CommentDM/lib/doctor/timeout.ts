/**
 * Bounds a promise that might otherwise hang forever — the exact trap this
 * tool exists to avoid falling into itself. Both the shared Redis helper
 * (lib/queue/client.ts, `maxRetriesPerRequest: null`) and a plain `fetch` to
 * Meta have no built-in ceiling: point either at something that never
 * answers and the check just sits there instead of reporting "unreachable".
 *
 * Every network-touching check in lib/doctor/checks/* wraps its call in this
 * so a dead Redis, a dead Postgres, or a dead Meta API produces a finding
 * within `ms`, not a doctor run that never finishes.
 */
export class DoctorTimeoutError extends Error {
  constructor(label: string, ms: number) {
    super(`${label} timed out after ${ms}ms`);
    this.name = "DoctorTimeoutError";
  }
}

export function withTimeout<T>(
  promise: Promise<T>,
  ms: number,
  label: string
): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new DoctorTimeoutError(label, ms)), ms);
    // Never block process exit on this timer alone.
    timer.unref?.();

    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (err) => {
        clearTimeout(timer);
        reject(err);
      }
    );
  });
}
