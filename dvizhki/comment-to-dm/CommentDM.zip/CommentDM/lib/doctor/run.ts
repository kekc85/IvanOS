/**
 * Orchestrates every check into one Finding[]. Each stage is wrapped so an
 * unexpected crash in one check (a bug in doctor itself, not the thing it's
 * checking) still produces a report instead of the whole command dying with
 * a stack trace — the one situation this tool must never do to a student.
 */
import { getEncryptionKeyFingerprint } from "@/lib/env";
import { checkAccountsTokens } from "./checks/tokens";
import { checkActivity } from "./checks/activity";
import { checkChain } from "./checks/chain";
import {
  checkDatabaseReachable,
  checkMigrations,
  checkPrismaClientMissing,
} from "./checks/database";
import { checkEnv } from "./checks/env";
import { checkRedisAndQueue } from "./checks/redis";
import { checkWorker, readWorkerLiveness, type WorkerLiveness } from "./checks/worker";
import { loadDoctorPrisma, type DoctorPrisma } from "./prisma-loader";
import { SECTION, type Finding } from "./types";

async function safely(section: string, run: () => Promise<Finding[]>): Promise<Finding[]> {
  try {
    return await run();
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return [
      {
        level: "warn",
        section,
        message: `Эту проверку не удалось выполнить: ${message}`,
      },
    ];
  }
}

export async function runDoctor(): Promise<Finding[]> {
  const findings: Finding[] = [];

  // 1. Environment — everything else assumes these are readable.
  const envFindings = checkEnv();
  findings.push(...envFindings);
  // "error" only, not "every finding is ok": checkEnv can also return a
  // "warn" for Instagram credentials still being placeholders (see
  // checks/env.ts), which does not stop the app from booting and must not
  // stop the rest of doctor's checks from running either.
  const envOk = envFindings.every((f) => f.level !== "error");

  let currentKeyFingerprint: string | null = null;
  if (envOk) {
    try {
      currentKeyFingerprint = getEncryptionKeyFingerprint();
    } catch {
      currentKeyFingerprint = null;
    }
  }

  // 2. Database — lazy-load the generated Prisma client so a fresh checkout
  // that hasn't run `prisma generate` yet gets one clear finding instead of
  // crashing doctor at import time.
  const prisma: DoctorPrisma | null = await loadDoctorPrisma();
  let dbReachable = false;

  if (!prisma) {
    findings.push(checkPrismaClientMissing());
  } else {
    const reachable = await safely(SECTION.DATABASE, async () => [
      await checkDatabaseReachable(prisma),
    ]);
    findings.push(...reachable);
    dbReachable = reachable[0]?.level === "ok";

    if (dbReachable) {
      findings.push(...(await safely(SECTION.DATABASE, async () => [await checkMigrations(prisma)])));
    }
  }

  // 3. Redis + worker — only meaningful once REDIS_URL itself is confirmed
  // present and not a placeholder (env section above already says so if not).
  const redisUrl = process.env.REDIS_URL;
  // Остаётся null, если Redis не настроен: тогда проверка цепочек честно не
  // знает, жив фоновый процесс или нет, и не выносит по нему вердиктов.
  let workerLiveness: WorkerLiveness | null = null;
  if (redisUrl) {
    findings.push(...(await safely(SECTION.REDIS, () => checkRedisAndQueue(redisUrl))));
    findings.push(
      ...(await safely(SECTION.WORKER, () => checkWorker(redisUrl, currentKeyFingerprint)))
    );
    workerLiveness = await readWorkerLiveness(redisUrl).catch(() => null);
  }

  // 4. Tokens + activity — need a live database.
  if (prisma && dbReachable) {
    const [tokenFindings, accountCount] = await (async () => {
      const result = await safely(SECTION.TOKENS, () => checkAccountsTokens(prisma));
      let count = 0;
      try {
        count = await prisma.instagramAccount.count();
      } catch {
        count = 0;
      }
      return [result, count] as const;
    })();

    findings.push(...tokenFindings);
    findings.push(...(await safely(SECTION.ACTIVITY, () => checkActivity(prisma, accountCount))));
    findings.push(
      ...(await safely(SECTION.CHAIN, () => checkChain(prisma, workerLiveness)))
    );
  }

  // Doctor is a one-shot CLI, not the long-lived app — hold the process open
  // no longer than it takes to print the report.
  if (prisma) {
    await prisma.$disconnect().catch(() => {});
  }

  return findings;
}
