/**
 * Loads the Prisma client the way every other check needs it, without ever
 * letting a missing one crash the whole doctor run.
 *
 * `app/generated/prisma` is gitignored (see prisma/schema.prisma's
 * `output`) and only exists after `prisma generate` has run — which a
 * student who cloned the repo but hasn't run `npm run build` / `npm ci`
 * (their postinstall) yet won't have. lib/db/client.ts imports that
 * generated module at the top of the file, so a *static* `import { prisma }
 * from "@/lib/db/client"` anywhere in doctor would fail module resolution
 * before a single check runs, taking down every other check with it — env
 * validation included, which is exactly the thing a student needs to see
 * first.
 *
 * A dynamic `import()` turns that same failure into a rejected promise this
 * function can catch, so the rest of doctor still runs and reports the
 * missing client as one clear, fixable finding instead of a stack trace.
 */
import type { PrismaClient } from "@/app/generated/prisma/client";

export type DoctorPrisma = PrismaClient;

// Overridable in tests so "the generated client doesn't exist" and "it does"
// can both be exercised without touching the real filesystem or generated
// output.
export type PrismaImporter = () => Promise<{ prisma: DoctorPrisma }>;

const defaultImporter: PrismaImporter = () =>
  import("@/lib/db/client") as unknown as Promise<{ prisma: DoctorPrisma }>;

export async function loadDoctorPrisma(
  importer: PrismaImporter = defaultImporter
): Promise<DoctorPrisma | null> {
  try {
    const mod = await importer();
    return mod.prisma;
  } catch {
    return null;
  }
}
