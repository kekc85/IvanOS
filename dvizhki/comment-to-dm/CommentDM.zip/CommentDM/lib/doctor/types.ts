/**
 * Shared vocabulary for `npm run doctor` (see scripts/doctor.ts).
 *
 * Every check returns a list of Findings instead of throwing or printing —
 * that is what lets the CLI render the same data as human-readable text or
 * as `--json` for a student's Claude Code session to parse and act on.
 *
 * Problem codes (E-01..E-16) are stable identifiers, not free text — phase 15
 * (`ЛЕЧЕНИЕ.md`) documents the fix for each one under its code. Do not renumber
 * an existing code once it ships; add a new one instead.
 */

export type FindingLevel = "ok" | "warn" | "error";

export interface Finding {
  /** Stable problem code, e.g. "E-09". Undefined for a plain "ok" with nothing to fix. */
  code?: string;
  level: FindingLevel;
  /** Human section heading the finding is grouped under (Russian, shown as-is). */
  section: string;
  /** One-line, jargon-free description of what's wrong (or confirmed fine). */
  message: string;
  /** What actually happened, in plain language — the "why" under `message`. */
  detail?: string;
  /** A copy-pasteable shell command that fixes or investigates the problem. */
  command?: string;
}

export const SECTION = {
  ENV: "Окружение",
  DATABASE: "База данных",
  REDIS: "Redis и очередь",
  WORKER: "Фоновый процесс",
  TOKENS: "Шифрование и токены Instagram",
  ACTIVITY: "Опрос комментариев и отправки",
  CHAIN: "Цепочки касаний",
} as const;

/** Problem codes in the order phase 15's ЛЕЧЕНИЕ.md documents them. */
export const CODES = {
  ENV_MISSING: "E-01",
  ENV_PLACEHOLDER: "E-02",
  PRISMA_CLIENT_MISSING: "E-03",
  DATABASE_UNREACHABLE: "E-04",
  MIGRATIONS_PENDING: "E-05",
  REDIS_UNREACHABLE: "E-06",
  QUEUE_BACKLOG: "E-07",
  WORKER_DOWN: "E-08",
  ENCRYPTION_KEY_MISMATCH: "E-09",
  TOKEN_UNDECRYPTABLE: "E-10",
  TOKEN_REJECTED_BY_META: "E-11",
  META_UNREACHABLE: "E-12",
  NO_ACCOUNTS_CONNECTED: "E-13",
  POLLING_SILENT: "E-14",
  SEND_FAILURE_RATE: "E-15",
  CHAIN_STALLED: "E-16",
} as const;

export function ok(
  section: string,
  message: string,
  detail?: string,
  code?: string
): Finding {
  return { level: "ok", section, message, detail, code };
}

export function warn(
  section: string,
  code: string,
  message: string,
  opts: { detail?: string; command?: string } = {}
): Finding {
  return { level: "warn", section, code, message, ...opts };
}

export function error(
  section: string,
  code: string,
  message: string,
  opts: { detail?: string; command?: string } = {}
): Finding {
  return { level: "error", section, code, message, ...opts };
}
