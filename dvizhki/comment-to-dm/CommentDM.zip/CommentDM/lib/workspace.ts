/**
 * The Single Workspace
 *
 * One instance, one owner, one workspace. The multi-tenant shape is still in
 * the schema — `Workspace` carries the usage counters and every campaign, log
 * and tracked link hangs off it — but nothing may ever produce a second row.
 *
 * That is the whole point of this module. The previous version created a
 * workspace *per user* and keyed the lookup on the caller's id, so any session
 * carrying an unknown user id minted a fresh, empty tenant. Here the lookup has
 * no user filter at all: whoever asks, the answer is the same workspace.
 */

import type { Workspace } from "@/app/generated/prisma/client";
import { ensureOwner } from "@/lib/auth/owner";
import { prisma } from "@/lib/db/client";

const WORKSPACE_NAME = "Мой аккаунт";

// Two requests can land on an empty database at once. Caching the in-flight
// promise keeps the create single — the same guard lib/auth/owner.ts uses for
// the owner row, and for the same reason.
let creationPromise: Promise<Workspace> | null = null;

async function createSingleWorkspace(): Promise<Workspace> {
  const owner = await ensureOwner();

  // Re-check inside the memoized path: the owner bootstrap above awaits, and a
  // concurrent request may have finished the create while we waited.
  const existing = await prisma.workspace.findFirst({
    orderBy: { createdAt: "asc" },
  });
  if (existing) return existing;

  return prisma.workspace.create({
    data: {
      name: WORKSPACE_NAME,
      ownerId: owner.id,
      members: {
        create: {
          userId: owner.id,
        },
      },
    },
  });
}

/**
 * The workspace. Idempotent: creates it only on an empty database, and only
 * ever one.
 */
export async function getOrCreateSingleWorkspace(): Promise<Workspace> {
  const existing = await prisma.workspace.findFirst({
    orderBy: { createdAt: "asc" },
  });
  if (existing) return existing;

  if (!creationPromise) {
    creationPromise = createSingleWorkspace().finally(() => {
      creationPromise = null;
    });
  }

  return creationPromise;
}

/** Test seam: drops the memoized in-flight create. */
export function resetSingleWorkspaceCache(): void {
  creationPromise = null;
}
