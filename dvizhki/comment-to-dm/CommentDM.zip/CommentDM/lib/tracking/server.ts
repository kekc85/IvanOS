import { createHash, randomBytes } from "node:crypto";
import { getSessionSecret } from "@/lib/env";
import { getClientIp } from "@/lib/net/client-ip";

export function generateTrackedLinkSlug() {
  return randomBytes(7).toString("base64url");
}

/**
 * Hashes a click's IP with SESSION_SECRET as salt. No fallback constant: a
 * hash salted with a value baked into every install of this fork would be
 * reversible by brute force across every install, which defeats the point
 * of hashing. An empty secret fails loudly instead (getSessionSecret throws)
 * rather than silently falling back to something every self-hoster shares.
 */
export function hashClickIp(ipAddress: string | null | undefined) {
  if (!ipAddress) return null;

  const salt = getSessionSecret();
  return createHash("sha256").update(`${salt}:${ipAddress}`).digest("hex");
}

export { getClientIp as getRequestIp };
