const SKIPPED_PREFIX = "SKIPPED_";
const FAILED_PREFIX = "FAILED";

export interface StatusCountRow {
  status: string;
  _count: number | { status?: number; _all?: number };
}

export interface KeywordCountRow {
  matchedKeyword: string | null;
  _count: number | { matchedKeyword?: number; _all?: number };
}

function getCount(value: StatusCountRow["_count"] | KeywordCountRow["_count"]) {
  if (typeof value === "number") return value;
  if ("status" in value && typeof value.status === "number") {
    return value.status;
  }
  if ("matchedKeyword" in value && typeof value.matchedKeyword === "number") {
    return value.matchedKeyword;
  }
  return value._all ?? 0;
}

export function calculateCtr(clicks: number, sent: number) {
  if (sent <= 0) return 0;
  // Raw clicks can exceed sends (repeat clicks, link-preview bots hitting the
  // tracked URL), which makes a "rate" over 100% — cap it so CTR stays sane.
  return Math.min(100, Number(((clicks / sent) * 100).toFixed(1)));
}

/** Корзина сводки, в которую попадает статус DmLog. null - ни в какую. */
export type DmStatusBucket = "sent" | "failed" | "skipped";

/**
 * Один разбор статуса на все счётчики отправок: и на дашборд, и на карточку
 * кампании в GET /api/automations.
 *
 * Отдельной экспортируемой функцией, а не копией условий в каждом месте,
 * потому что копия уже разъезжалась: дашборд считал FAILED_PERMANENT
 * префиксом, а карточка кампании сравнением `=== "FAILED"` - и на ОДНОЙ
 * установке две цифры «не дошло» отличались на число терминальных отказов.
 *
 * FAILED и FAILED_PERMANENT здесь одна корзина: разница между ними в праве на
 * повтор, а не в исходе для человека. Разделение по причинам живёт там, где
 * оно кому-то помогает, - в докторе (lib/doctor/checks/activity.ts).
 * Префиксом, как SKIPPED_, чтобы следующий терминальный статус не пришлось
 * вспоминать дописывать руками.
 */
export function classifyDmStatus(status: string): DmStatusBucket | null {
  if (status === "SENT") return "sent";
  if (status.startsWith(FAILED_PREFIX)) return "failed";
  if (status.startsWith(SKIPPED_PREFIX)) return "skipped";
  return null;
}

export function summarizeDmStatuses(rows: StatusCountRow[]) {
  return rows.reduce(
    (summary, row) => {
      const bucket = classifyDmStatus(row.status);
      if (bucket) summary[bucket] += getCount(row._count);
      return summary;
    },
    { sent: 0, skipped: 0, failed: 0 }
  );
}

export function normalizeTopKeywords(rows: KeywordCountRow[], limit = 5) {
  return rows
    .filter((row) => row.matchedKeyword)
    .map((row) => ({
      keyword: row.matchedKeyword as string,
      count: getCount(row._count),
    }))
    .sort((a, b) => b.count - a.count || a.keyword.localeCompare(b.keyword))
    .slice(0, limit);
}
