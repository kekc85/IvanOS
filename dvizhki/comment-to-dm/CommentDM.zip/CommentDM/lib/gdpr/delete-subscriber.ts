/**
 * Subscriber data erasure — the part of "right to be forgotten" that is a
 * database operation rather than a form.
 *
 * A follower is identifiable in this schema through DmLog.commenterId (a
 * stable Instagram-scoped id) and DmLog.commenterName (their username at
 * the time they commented, which can change or repeat). Matching against
 * either — see `matchWhere` — is what lets an operator run this with
 * whichever one they have on hand.
 *
 * What this reaches and what it does not:
 *   - DmLog: matched directly, but not deleted unconditionally. A DmLog row
 *     is also the polling reconciler's dedup marker for that comment (see
 *     lib/polling/comment-reconciler.ts and lib/queue/dm-worker.ts) —
 *     deleting it while the comment is still inside Meta's private-reply
 *     window would make the next sweep treat an already-answered comment as
 *     new and send a second DM to the exact person this request is trying
 *     to stop contact with. So a row is only deleted once it is outside
 *     that window (getDmLogDedupSafeCutoff in lib/gdpr/retention-config.ts);
 *     anything still inside it is left in place and reported as withheld —
 *     re-run this once the window passes to finish erasing it.
 *   - SubscriberJourney: matched and deleted unconditionally, and that
 *     deletion is what actually stops contact. A live chain (state
 *     GATE_SENT or ACTIVE) is a row here and nothing else: the dispatcher
 *     only sends to rows it finds (lib/chain/step-dispatcher.ts queries
 *     state ACTIVE with a due next step; the conversation poller only looks
 *     at GATE_SENT/ACTIVE rows), so removing the row is what guarantees the
 *     erased person gets no further step. No window guard here, unlike
 *     DmLog: a journey is not a dedup marker for any comment. Its
 *     @@unique([automationId, subscriberId]) is a re-entry lock, so deleting
 *     it does reopen entry — but re-entry needs a NEW comment from that
 *     person, and their existing comment is still covered by the DmLog rule
 *     above (or is already outside Meta's window, where the sweep skips it
 *     as stale anyway).
 *   - LinkClick: NOT reachable by this identifier. A click row carries a
 *     salted IP hash, a user agent, and a referrer — none of which are
 *     keyed to a commenter id or username anywhere in this schema (see
 *     app/r/[slug]/route.ts). There is no query that connects a specific
 *     subscriber to a specific click without inventing a correlation this
 *     data doesn't support. Those rows are anonymous by construction and
 *     age out on their own via the retention job (lib/ops/retention-job.ts).
 *   - OperationalEvent: not touched. The chain contours write counters and
 *     campaign names there, never the person's name or message text (see
 *     recordJourneyEvent in lib/chain/journey.ts), so there is no personal
 *     data left behind to erase — and this command's own audit row follows
 *     the same rule: counts only.
 */

import type { JourneyState } from "@/app/generated/prisma/client";
import { LIVE_JOURNEY_STATES } from "@/lib/chain/journey";
import { prisma } from "@/lib/db/client";
import { getDmLogDedupSafeCutoff } from "@/lib/gdpr/retention-config";

export interface SubscriberDmLogRow {
  id: string;
  commenterId: string;
  commenterName: string | null;
  commentId: string;
  createdAt: Date;
}

export interface SubscriberJourneyRow {
  id: string;
  subscriberId: string;
  commenterId: string | null;
  subscriberName: string | null;
  state: JourneyState;
  gateSentAt: Date;
  createdAt: Date;
}

export interface SubscriberErasurePreview {
  identifier: string;
  dmLogs: SubscriberDmLogRow[];
  dmLogsDeletableNow: number;
  dmLogsWithheld: number;
  journeys: SubscriberJourneyRow[];
  /** Of those journeys, how many are chains still running (GATE_SENT/ACTIVE). */
  journeysLive: number;
  linkClickNote: string;
}

export interface SubscriberErasureResult {
  dmLogsDeleted: number;
  dmLogsWithheld: number;
  journeysDeleted: number;
  /** Live chains that this erasure stopped by removing their row. */
  journeysStopped: number;
}

const LINK_CLICK_NOTE =
  "LinkClick rows carry no subscriber identity (only a salted IP hash, user agent, and referrer) — none can be matched to this identifier. They age out automatically via the retention job.";

function matchWhere(identifier: string) {
  return {
    OR: [
      { commenterId: identifier },
      { commenterName: { equals: identifier, mode: "insensitive" as const } },
    ],
  };
}

/**
 * The same three-way "whichever id the operator has on hand" match as
 * `matchWhere`, against the journey table's own column names. A journey knows
 * the person twice over — `subscriberId` in messaging space (the recipient_id
 * Meta returned on the GATE) and `commenterId` in comment space — and only one
 * of the two may be what arrived with the deletion request, so both are
 * matched, plus the display name as the last resort.
 */
function journeyMatchWhere(identifier: string) {
  return {
    OR: [
      { subscriberId: identifier },
      { commenterId: identifier },
      { subscriberName: { equals: identifier, mode: "insensitive" as const } },
    ],
  };
}

/**
 * Read-only: shows exactly what `eraseSubscriberData` would delete, so an
 * operator (or the CLI wrapper in scripts/delete-subscriber.ts) can confirm
 * identity before anything is removed.
 */
export async function previewSubscriberErasure(
  identifier: string
): Promise<SubscriberErasurePreview> {
  const trimmed = identifier.trim();

  const dmLogs = await prisma.dmLog.findMany({
    where: matchWhere(trimmed),
    select: {
      id: true,
      commenterId: true,
      commenterName: true,
      commentId: true,
      createdAt: true,
    },
    orderBy: { createdAt: "desc" },
  });

  const journeys = await prisma.subscriberJourney.findMany({
    where: journeyMatchWhere(trimmed),
    select: {
      id: true,
      subscriberId: true,
      commenterId: true,
      subscriberName: true,
      state: true,
      gateSentAt: true,
      createdAt: true,
    },
    orderBy: { createdAt: "desc" },
  });

  const safeCutoff = getDmLogDedupSafeCutoff();
  const dmLogsDeletableNow = dmLogs.filter(
    (row) => row.createdAt < safeCutoff
  ).length;
  const dmLogsWithheld = dmLogs.length - dmLogsDeletableNow;

  return {
    identifier: trimmed,
    dmLogs,
    dmLogsDeletableNow,
    dmLogsWithheld,
    journeys,
    journeysLive: journeys.filter((row) =>
      LIVE_JOURNEY_STATES.includes(row.state)
    ).length,
    linkClickNote: LINK_CLICK_NOTE,
  };
}

/**
 * Deletes everything `previewSubscriberErasure` reported as deletable now.
 * Records one OperationalEvent with counts only — never the identifier,
 * name, or comment text, since writing the erased person's PII into the
 * operational journal would recreate exactly what this just removed.
 *
 * Journeys go first, on purpose. Between the two deletes the chain contours
 * are still running, and the order decides what a badly timed crash leaves
 * behind: journeys-then-DmLog can only leave send-journal rows (no further
 * message can go out — the dispatcher has no row to send from), while the
 * reverse order could leave a live chain still messaging someone whose
 * DmLog history is already gone.
 */
export async function eraseSubscriberData(
  identifier: string
): Promise<SubscriberErasureResult> {
  const trimmed = identifier.trim();
  const preview = await previewSubscriberErasure(trimmed);
  const safeCutoff = getDmLogDedupSafeCutoff();

  const journeyResult = await prisma.subscriberJourney.deleteMany({
    where: journeyMatchWhere(trimmed),
  });

  const dmLogResult = await prisma.dmLog.deleteMany({
    where: { ...matchWhere(trimmed), createdAt: { lt: safeCutoff } },
  });

  const result: SubscriberErasureResult = {
    dmLogsDeleted: dmLogResult.count,
    dmLogsWithheld: preview.dmLogsWithheld,
    journeysDeleted: journeyResult.count,
    journeysStopped: preview.journeysLive,
  };

  await prisma.operationalEvent
    .create({
      data: {
        source: "SYSTEM",
        level: "INFO",
        message: `Subscriber erasure request processed: ${result.dmLogsDeleted} DM log(s) deleted, ${result.dmLogsWithheld} DM log(s) withheld (inside Meta's reply window; re-run the erasure command once it passes), ${result.journeysDeleted} chain journey(s) deleted of which ${result.journeysStopped} were live chains now stopped`,
        payload: { ...result },
      },
    })
    .catch(() => {});

  return result;
}
