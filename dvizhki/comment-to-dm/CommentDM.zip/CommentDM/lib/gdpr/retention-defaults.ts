/**
 * Retention day counts, split out from lib/gdpr/retention-config.ts so a
 * client component (the settings page's "what's stored" panel) can import
 * the plain numbers without pulling in that file's other import — the Meta
 * reply-window constant from lib/polling/comment-reconciler.ts, which
 * chains into the Prisma and BullMQ/Redis clients. Those are server-only;
 * bundling them into client-side JavaScript is either a build failure or,
 * worse, a silent bloat/leak, so this file intentionally has zero imports.
 *
 * These are also re-exported by retention-config.ts, which is the module
 * everything server-side (the retention job, the legal pages, the CLI
 * script) should actually import from.
 */

export const DEFAULT_DM_LOG_RETENTION_DAYS = 180;
export const DEFAULT_LINK_CLICK_RETENTION_DAYS = 30;
export const DEFAULT_OPERATIONAL_EVENT_RETENTION_DAYS = 14;
export const DEFAULT_CHAIN_JOURNEY_RETENTION_DAYS = 30;
// A chain journey row is also the "prohibit restart" lock (see
// lib/gdpr/retention-config.ts): while it lives, that person cannot enter the
// same campaign's chain a second time. This minimum is not about privacy, it
// is about not shredding live chains: the unanswered-GATE TTL alone is 48h,
// so anything under two days would start deleting rows the chain contours are
// still working with.
export const CHAIN_JOURNEY_MIN_RETENTION_DAYS = 2;
// DmLog is also the polling reconciler's dedup set (see
// lib/gdpr/retention-config.ts) — this buffer sits on top of Meta's
// private-reply window so a cleanup run can never delete a row the next
// sweep still needs to avoid sending a duplicate DM.
export const DM_LOG_SAFETY_BUFFER_HOURS = 24;
