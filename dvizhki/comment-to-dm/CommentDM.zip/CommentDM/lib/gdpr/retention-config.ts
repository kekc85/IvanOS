/**
 * Retention windows for the tables that accumulate one row per subscriber
 * interaction. Left alone, DmLog, LinkClick, and OperationalEvent grow
 * forever — a year in, a self-hoster is sitting on a multi-gigabyte database
 * that is, in effect, a permanent dossier on every follower who ever
 * commented.
 *
 * Defaults are deliberately uneven, longest to shortest:
 *   - DmLog is the send journal (who was messaged, when, with what) AND the
 *     polling reconciler's dedup set: a row keyed by (automationId,
 *     commentId) in a terminal send state — SENT, SKIPPED_DEDUP or
 *     FAILED_PERMANENT (or, for a campaign with the public reply on,
 *     publicReplySentAt set) — is what tells the next sweep "already
 *     handled, skip it" (see lib/polling/comment-reconciler.ts and
 *     lib/queue/dm-worker.ts). A
 *     student debugging "did this person get their DM" also wants months of
 *     history, not days. Both reasons push it long — and give it the floor
 *     below.
 *   - LinkClick is lower-stakes (a hashed IP, a user agent, a referrer) and
 *     only useful for near-term campaign tuning, so it gets a shorter life.
 *   - SubscriberJourney is one row per person per chain. Its window is a
 *     product decision, not a storage one: the row is also the "prohibit
 *     restart" lock, so its lifetime IS how long that person is barred from
 *     entering the same chain again (see getChainJourneyRetentionDays).
 *   - OperationalEvent is internal ops noise (worker health, job runs). It
 *     is useful for a week or two of debugging and worthless after that.
 *
 * Every value is overridable via .env for a self-hoster with different
 * requirements (a longer legal hold, a tighter privacy stance, etc) — except
 * DmLog, which has a floor (see below) that no override can go under, and
 * SubscriberJourney, which has a small minimum so a zero can't shred chains
 * that are still running.
 */

import { META_PRIVATE_REPLY_WINDOW_HOURS } from "@/lib/polling/comment-reconciler";
import {
  CHAIN_JOURNEY_MIN_RETENTION_DAYS,
  DEFAULT_CHAIN_JOURNEY_RETENTION_DAYS,
  DEFAULT_DM_LOG_RETENTION_DAYS,
  DEFAULT_LINK_CLICK_RETENTION_DAYS,
  DEFAULT_OPERATIONAL_EVENT_RETENTION_DAYS,
  DM_LOG_SAFETY_BUFFER_HOURS,
} from "@/lib/gdpr/retention-defaults";

export {
  CHAIN_JOURNEY_MIN_RETENTION_DAYS,
  DEFAULT_CHAIN_JOURNEY_RETENTION_DAYS,
  DEFAULT_DM_LOG_RETENTION_DAYS,
  DEFAULT_LINK_CLICK_RETENTION_DAYS,
  DEFAULT_OPERATIONAL_EVENT_RETENTION_DAYS,
  DM_LOG_SAFETY_BUFFER_HOURS,
};

// DmLog is the polling reconciler's dedup set (see
// lib/polling/comment-reconciler.ts and lib/queue/dm-worker.ts): a row whose
// status is SENT, SKIPPED_DEDUP or FAILED_PERMANENT (or, for campaigns with a
// public reply on, whose publicReplySentAt is set) tells the next sweep that
// comment is already handled. Delete that row while the comment is still
// inside Meta's private-reply window (META_PRIVATE_REPLY_WINDOW_HOURS, 168h
// by default) and the next sweep sees an "unhandled" comment that already
// matched a campaign — the subscriber gets a second DM for the same comment,
// or a dead comment starts burning a job every five minutes again.
// DM_LOG_SAFETY_BUFFER_HOURS (imported above) sits on top of the window so a
// slow cleanup run, or a self-hoster who widened the window, can't shave the
// margin down to nothing.

function readDays(envVar: string, fallbackDays: number): number {
  const raw = process.env[envVar];
  if (raw === undefined || raw.trim() === "") return fallbackDays;
  const parsed = Number(raw);
  if (!Number.isFinite(parsed) || parsed < 0) return fallbackDays;
  return parsed;
}

// The dedup safety floor itself, in hours: Meta's private-reply window plus
// a buffer. This is the one number that must never be shortened by
// configuration — it is what protects the send path, not a privacy knob.
function getDedupSafetyFloorHours(): number {
  return META_PRIVATE_REPLY_WINDOW_HOURS + DM_LOG_SAFETY_BUFFER_HOURS;
}

/**
 * Hours, not days: the floor is defined against Meta's window (also in
 * hours), and staying in the same unit avoids a lossy days-to-hours-and-back
 * round trip at the boundary.
 *
 * The configured DM_LOG_RETENTION_DAYS is honored only when it is already
 * past the floor. Below the floor, the floor wins — a self-hoster can make
 * this retention longer, never shorter than what the send path needs to
 * stay correct.
 */
export function getDmLogRetentionHours(): number {
  const configuredHours =
    readDays("DM_LOG_RETENTION_DAYS", DEFAULT_DM_LOG_RETENTION_DAYS) * 24;
  return Math.max(configuredHours, getDedupSafetyFloorHours());
}

export function getDmLogCutoff(now: Date = new Date()): Date {
  return new Date(now.getTime() - getDmLogRetentionHours() * 60 * 60 * 1000);
}

/**
 * The dedup floor alone, ignoring DM_LOG_RETENTION_DAYS — used by the GDPR
 * erasure path (lib/gdpr/delete-subscriber.ts), which wants to remove a
 * specific person's rows as soon as it is safe, not wait out the full
 * (usually much longer) configured retention window. A row older than this
 * cutoff can be deleted without risking a duplicate DM; a row newer than it
 * is withheld and clears later via the regular retention job once
 * getDmLogCutoff passes it.
 */
export function getDmLogDedupSafeCutoff(now: Date = new Date()): Date {
  return new Date(now.getTime() - getDedupSafetyFloorHours() * 60 * 60 * 1000);
}

export function getLinkClickRetentionDays(): number {
  return readDays("LINK_CLICK_RETENTION_DAYS", DEFAULT_LINK_CLICK_RETENTION_DAYS);
}

export function getOperationalEventRetentionDays(): number {
  return readDays(
    "OPERATIONAL_EVENT_RETENTION_DAYS",
    DEFAULT_OPERATIONAL_EVENT_RETENTION_DAYS
  );
}

/**
 * 30 дней = срок запрета повторного входа (Prohibit restart): пока строка
 * журнея живёт, человек не может войти в цепочку той же кампании второй раз;
 * удалили строку - вход снова открыт. Это осознанный компромисс, зафиксирован
 * в плане.
 *
 * Пола «как у DmLog» тут нет: журней не участвует в дедупе опроса
 * комментариев, так что укоротить его - не значит отправить кому-то второе
 * сообщение по тому же комментарию. Но минимум всё же есть
 * (CHAIN_JOURNEY_MIN_RETENTION_DAYS, двое суток = 48 часов TTL неотвеченного
 * GATE плюс сутки запаса): без него оператор мог бы выставить 0 и срезать
 * цепочки, которые прямо сейчас идут.
 */
export function getChainJourneyRetentionDays(): number {
  const configured = readDays(
    "CHAIN_JOURNEY_RETENTION_DAYS",
    DEFAULT_CHAIN_JOURNEY_RETENTION_DAYS
  );
  return Math.max(configured, CHAIN_JOURNEY_MIN_RETENTION_DAYS);
}

export function getChainJourneyCutoff(now: Date = new Date()): Date {
  return new Date(
    now.getTime() - getChainJourneyRetentionDays() * 24 * 60 * 60 * 1000
  );
}

export function getLinkClickCutoff(now: Date = new Date()): Date {
  return new Date(now.getTime() - getLinkClickRetentionDays() * 24 * 60 * 60 * 1000);
}

export function getOperationalEventCutoff(now: Date = new Date()): Date {
  return new Date(
    now.getTime() - getOperationalEventRetentionDays() * 24 * 60 * 60 * 1000
  );
}
