/**
 * Short-lived Redis claim on a single comment, used to stop two comment-poll
 * sweeps from enqueuing the same comment twice while the first job is still
 * queued or being processed.
 *
 * The race this closes: the reconciler (lib/polling/comment-reconciler.ts)
 * only knows a comment is "handled" once its DmLog row shows SENT or
 * publicReplySentAt — and that row isn't written until the queued job
 * actually runs (see lib/queue/dm-worker.ts). On a viral post the queue
 * (concurrency 5, see createDMWorker below) can take longer to drain than
 * COMMENT_POLL_INTERVAL_MS, so the next sweep still sees the comment as
 * "unhandled," enqueues it a second time, and both jobs can end up racing
 * through the public-reply/DM send at once — two identical replies under
 * the same comment.
 *
 * Why not a deterministic BullMQ job id (the obvious-looking fix): BullMQ's
 * own duplicate-id guard reaches into completed/failed jobs too (see
 * defaultJobOptions.removeOnComplete/removeOnFail in lib/queue/client.ts,
 * which deliberately retain recent jobs). A legitimate later retry — e.g.
 * the DM sent but the public reply failed, and a following sweep needs to
 * re-queue the very same comment id just to retry the reply — would
 * silently no-op instead of re-running. A claim is a separate, short-TTL
 * key: it blocks a second enqueue only while the first job is genuinely
 * still in flight, and clears the moment that job completes (see the
 * `worker.on("completed", ...)` handler in lib/queue/dm-worker.ts), so it
 * never blocks a legitimate later retry — only the race.
 *
 * The TTL is the safety net for a worker that crashes mid-job and never
 * fires "completed": it is set comfortably above the worst-case retry
 * backoff (BACKOFF_DELAYS in lib/queue/dm-worker.ts totals 65 minutes) so
 * it never expires out from under a job that is still legitimately retrying.
 */

import { getRedisConnection } from "@/lib/queue/client";

const CLAIM_PREFIX = "claim:comment:";
const CLAIM_TTL_SECONDS = Number(
  process.env.COMMENT_CLAIM_TTL_SECONDS ?? 90 * 60 // 90 minutes
);

function claimKey(instagramAccountId: string, commentId: string): string {
  return `${CLAIM_PREFIX}${instagramAccountId}:${commentId}`;
}

/**
 * Attempts to claim a comment before enqueuing it. Returns true when the
 * claim was acquired (safe to enqueue), false when another sweep already
 * holds it (the comment's earlier job is still in flight — skip it, the
 * next sweep after the claim clears will pick it up if it's still needed).
 */
export async function acquireCommentClaim(
  instagramAccountId: string,
  commentId: string
): Promise<boolean> {
  const result = await getRedisConnection().set(
    claimKey(instagramAccountId, commentId),
    "1",
    "EX",
    CLAIM_TTL_SECONDS,
    "NX"
  );
  return result === "OK";
}

export async function releaseCommentClaim(
  instagramAccountId: string,
  commentId: string
): Promise<void> {
  await getRedisConnection().del(claimKey(instagramAccountId, commentId));
}
