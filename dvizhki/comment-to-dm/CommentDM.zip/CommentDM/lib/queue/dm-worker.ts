import { Worker, type Job } from "bullmq";
import {
  getDMQueue,
  getRedisConnection,
  type DmQueueJob,
  type ProcessCommentJob,
} from "./client";
import { prisma } from "@/lib/db/client";
import {
  MetaApiError,
  RateLimitError,
  TokenExpiredError,
  sendCommentReply,
  sendPrivateReply,
  sendPrivateReplyWithLinkButton,
} from "@/lib/meta/client";
import { decryptToken } from "@/lib/meta/oauth";
import { releaseCommentClaim } from "@/lib/queue/comment-claim";
import { matchKeywords } from "@/lib/utils/keyword-matcher";
import { reserveCommentReplySlot, reserveDMSlot } from "@/lib/utils/rate-limiter";
import {
  releaseWorkspaceDMReservation,
  reserveWorkspaceDMSend,
} from "@/lib/billing/usage";
import { recordWorkerAlert } from "@/lib/ops/worker-health";
import {
  createGateJourney,
  findAnyJourneyForCampaign,
  findLiveJourneyByCommenter,
  markJourneySkipped,
  recordJourneyEvent,
  restartBlockedReason,
} from "@/lib/chain/journey";
import {
  buildTrackedUrl,
  renderMessageWithTracking,
  renderMessageWithoutLink,
} from "@/lib/tracking/message";
import {
  classifyPermanentSendFailure,
  isPermanentFailureMessage,
  PRIVATE_REPLY_ALREADY_USED,
} from "@/lib/queue/send-failure";

const BACKOFF_DELAYS = [5 * 60 * 1000, 15 * 60 * 1000, 45 * 60 * 1000];

function formatError(error: unknown): string {
  if (error instanceof MetaApiError) {
    return `Meta API Error ${error.code}: ${error.message}`;
  }
  if (error instanceof Error) {
    return error.message;
  }
  return "Unknown error";
}

/**
 * Отказ, который повтором простым текстом не лечится: Meta отказала разговору,
 * а не шаблону с кнопкой. Это ровно класс перманентных отказов из
 * lib/queue/send-failure.ts, и держать под него второй список значит однажды
 * пополнить один и забыть про другой. Повтор текстом тут не просто бесполезен:
 * он ещё и подменяет настоящую причину на «invalid for a private reply» -
 * первая попытка уже израсходовала единственный приватный ответ комментария.
 */
function isTemplateRejection(error: unknown): boolean {
  if (error instanceof TokenExpiredError || error instanceof RateLimitError) {
    return false;
  }
  return classifyPermanentSendFailure(error) === null;
}

/**
 * Тот же признак, по которому обычный путь не ретраит отправку текстом, но
 * прочитанный с другим смыслом: не «повторять нельзя», а «отправка уже была».
 */
function isPrivateReplyAlreadyUsed(error: unknown): boolean {
  if (error instanceof TokenExpiredError || error instanceof RateLimitError) {
    return false;
  }
  const message = error instanceof Error ? error.message : "";
  return PRIVATE_REPLY_ALREADY_USED.test(message);
}

type WorkerTrackedLink = {
  slug: string;
  label: string | null;
  destinationUrl: string;
};

/**
 * Build the tappable link buttons for a DM. The first link uses the campaign's
 * `linkButtonLabel`; each additional link uses its own stored `label`. Capped at
 * Meta's 3-button limit for a button template.
 */
function buildLinkButtons(
  trackedLinks: WorkerTrackedLink[],
  primaryLabel: string | null
): { title: string; url: string }[] {
  return trackedLinks.slice(0, 3).map((link, index) => ({
    url: buildTrackedUrl(link.slug),
    title: (index === 0 ? primaryLabel : link.label) || link.label || "Open link",
  }));
}

/**
 * Fallback text when Meta rejects the button template: render the primary link
 * inline, then append any extra tracked URLs on their own lines so no link is
 * lost.
 */
function buildInlineLinkFallback(
  message: string,
  commenterName: string | null | undefined,
  trackedLinks: WorkerTrackedLink[],
  bodyText: string
): string {
  const base =
    renderMessageWithTracking({ message, commenterName, trackedLinks }) ||
    bodyText;
  const extraUrls = trackedLinks.slice(1).map((link) => buildTrackedUrl(link.slug));
  return extraUrls.length > 0 ? `${base}\n${extraUrls.join("\n")}` : base;
}

/** Поля кампании, которых хватает, чтобы завести журней цепочки. */
type ChainAutomationRef = {
  id: string;
  workspaceId: string;
  instagramAccountId: string;
};

/**
 * Почему журней заводится задним числом, а не сразу после ушедшего GATE.
 *  - `none` — обычный путь: GATE только что ушёл, `recipient_id` на руках.
 *  - `retry` — джоба зашла повторно: DmLog уже SENT, а журнея нет.
 *  - `lost-write` — GATE ушёл в прошлой жизни воркера: Meta отвечает, что
 *    единственный приватный ответ на комментарий уже израсходован.
 * В обоих ремонтных случаях ответа Meta на руках нет, значит нет и
 * `recipient_id` — подписчик пишется по ID комментатора.
 */
type ChainJourneyRepair = "none" | "retry" | "lost-write";

const CHAIN_REPAIR_MESSAGES: Record<
  Exclude<ChainJourneyRepair, "none">,
  string
> = {
  retry:
    "Цепочка: журней восстановлен ретраем - GATE был отправлен раньше, а журней не записался; подписчик записан по ID комментатора",
  "lost-write":
    "Цепочка: журней восстановлен после сбоя записи - Meta ответила, что единственный приватный ответ на комментарий уже израсходован, значит GATE ушёл, а запись SENT не легла; подписчик записан по ID комментатора",
};

/**
 * Заводит журней цепочки после ушедшего GATE.
 *
 * Никогда не бросает наружу: DM уже доставлен, и сбой записи журнея не должен
 * ни ронять джобу, ни увести строку DmLog в FAILED — следующий проход опроса
 * увидел бы её как необработанную и отправил бы тому же человеку второй DM.
 * Не записалось - следующий заход по этому комментарию дочинит журней
 * (ретрай-дыра в processComment).
 */
async function recordChainGateJourney(
  automation: ChainAutomationRef,
  comment: {
    commentId: string;
    commenterId: string;
    commenterName?: string | null;
  },
  /**
   * `recipient_id` из ответа Meta — ID человека в пространстве сообщений.
   * null означает «его не было»: либо ответ пришёл без него, либо журней
   * чинится задним числом, когда ответа Meta уже нет на руках.
   */
  recipientId: string | null,
  repair: ChainJourneyRepair
): Promise<void> {
  // Подставлять ID комментатора вместо recipient_id — деградация, а не норма:
  // это ID из другого пространства, и написать по нему следующий шаг может не
  // выйти. Поэтому журней всё равно заводим (иначе цепочка теряется молча), но
  // с WARNING в журнале, чтобы владелец видел причину, если шаги не пойдут.
  const subscriberId = recipientId ?? comment.commenterId;

  try {
    await createGateJourney({
      workspaceId: automation.workspaceId,
      automationId: automation.id,
      instagramAccountId: automation.instagramAccountId,
      subscriberId,
      commenterId: comment.commenterId,
      subscriberName: comment.commenterName,
      commentId: comment.commentId,
    });

    if (repair !== "none") {
      await recordJourneyEvent({
        workspaceId: automation.workspaceId,
        level: "WARNING",
        message: CHAIN_REPAIR_MESSAGES[repair],
        payload: {
          automationId: automation.id,
          commentId: comment.commentId,
          subscriberId,
        },
      });
    } else if (!recipientId) {
      await recordJourneyEvent({
        workspaceId: automation.workspaceId,
        level: "WARNING",
        message:
          "Цепочка: Meta не вернула recipient_id на GATE - журней заведён по ID комментатора, следующие шаги могут не уйти",
        payload: {
          automationId: automation.id,
          commentId: comment.commentId,
          subscriberId,
        },
      });
    }
  } catch (error) {
    console.error(
      "[DM Worker] Failed to record chain journey:",
      formatError(error)
    );
    await recordJourneyEvent({
      workspaceId: automation.workspaceId,
      level: "WARNING",
      message: `Цепочка: журней не записался после GATE (${formatError(error)}) - следующий заход по этому комментарию его дочинит`,
      payload: {
        automationId: automation.id,
        commentId: comment.commentId,
        subscriberId,
      },
    });
  }
}

async function processComment(job: Job<ProcessCommentJob>): Promise<void> {
  const {
    instagramAccountId,
    commentId,
    commentText,
    commenterId,
    commenterName,
    mediaId,
  } = job.data;
  const requeueAttempt = job.data.requeueAttempt ?? 0;

  const automations = await prisma.automation.findMany({
    where: {
      // Match campaigns bound to this specific post, plus any-post campaigns.
      OR: [{ postId: mediaId }, { matchAnyPost: true }],
      isActive: true,
      instagramAccount: {
        instagramId: instagramAccountId,
      },
    },
    include: {
      instagramAccount: true,
      workspace: true,
      trackedLinks: {
        select: {
          slug: true,
          label: true,
          destinationUrl: true,
        },
        orderBy: { createdAt: "asc" },
      },
    },
    orderBy: { createdAt: "asc" },
  });

  for (const automation of automations) {
    // "Any word" campaigns fire on every comment; otherwise require a keyword hit.
    const matchResult = automation.matchAnyWord
      ? { matched: true, matchedKeyword: null }
      : matchKeywords(
          commentText,
          automation.keywords,
          automation.wholeWordMatch
        );

    if (!matchResult.matched) {
      continue;
    }

    const existingLog = await prisma.dmLog.findUnique({
      where: {
        automationId_commentId: {
          automationId: automation.id,
          commentId,
        },
      },
    });

    const alreadyDmd = existingLog?.status === "SENT";
    const alreadyPublicReplied = Boolean(existingLog?.publicReplySentAt);
    // Терминальный отказ прошлой попытки: директ закрыт, комментарий удалён,
    // приватный ответ израсходован. Отправлять по такой строке больше нечего
    // и никогда не будет - иначе комментарий гоняется все 144 часа окна
    // опроса (см. lib/queue/send-failure.ts). Публичный ответ это не
    // отменяет: он живёт своей ногой и ниже всё ещё имеет право на повтор.
    const dmPermanentlyFailed = existingLog?.status === "FAILED_PERMANENT";
    const needsDm = !alreadyDmd && !dmPermanentlyFailed;
    // Строку DmLog по этому комментарию заводит этот самый заход (ниже), а не
    // предыдущий. Отсюда два разных решения:
    //  - INFO гейта повторного входа пишем только при СОЗДАНИИ строки, иначе
    //    каждая повторная джоба добавляет в журнал строку про один и тот же
    //    отказ;
    //  - «единственный приватный ответ уже израсходован» считаем СВОЕЙ прошлой
    //    отправкой только когда строка уже была И несёт отметку обращения к
    //    Meta (см. priorSendAttempt ниже).
    const dmLogRowIsNew = existingLog === null;
    // Улика, без которой ответ Meta «invalid for a private reply» не значит,
    // что GATE ушёл ОТ НАС. Улика ровно одна и она фиксируется в момент
    // обращения к Meta: dmAttemptedAt, который UPDATE ставит прямо перед
    // вызовом отправки (ниже, в теле try). Пока его нет - до сети дело не
    // дошло, и никакой статус этого не заменяет.
    //
    // Почему не по статусу, как было раньше. PENDING пишется в НАЧАЛЕ каждого
    // захода и ещё раз при переочереди по часовому лимиту - в обоих случаях
    // Meta не звали вовсе. FAILED тоже ставится до всякой сети: «Нет токена
    // доступа», «Не удалось расшифровать токен», сорванный reserveDMSlot.
    // Считать такие строки уликой значит на удалённом комментарии выдать
    // фальшивый SENT и завести журней человеку, которому никогда ничего не
    // уходило, - и заодно запереть ему повторный вход на срок хранения
    // журнея. dmSentAt тут тоже не помощник: его ставит УСПЕХ, а спасать надо
    // как раз оборванный вызов.
    //
    // Второе условие - причина прошлого отказа НЕ из перманентного класса.
    // Отправка к Meta идёт с 30-секундным дедлайном (см. lib/meta/client.ts):
    // Meta успевает ДОСТАВИТЬ GATE, а наш fetch умирает по таймауту, строка
    // ложится FAILED с dmSentAt=null - вот это спасать надо. А FAILED
    // «invalid for a private reply» оставил прошлый заход, который сам улики
    // не нашёл и честно отказал: считать его уликой значит на втором заходе
    // выдать тот же фальшивый SENT. Тот же довод про весь перманентный класс:
    // «директ закрыт» и «вне окна» о доставке не свидетельствуют.
    const priorSendAttempt =
      existingLog !== null &&
      existingLog.dmAttemptedAt !== null &&
      !isPermanentFailureMessage(existingLog.errorMessage);

    // Ретрай-дыра: GATE уже помечен SENT, а журнея по этому комментарию нет —
    // значит между отправкой и записью что-то оборвалось (рестарт воркера,
    // сбой базы). Чиним журней здесь, НЕ отправляя DM повторно: единственный
    // приватный ответ, который Instagram разрешает на комментарий, уже
    // израсходован, а вторая попытка вернула бы «invalid for a private reply»
    // и увела строку в FAILED. Ищем по commentId, а не по subscriberId: какой
    // именно ID лёг в журней при первой отправке (recipient_id или ID
    // комментатора), отсюда не видно, а комментарий у журнея один.
    if (automation.chainEnabled && alreadyDmd) {
      const existingJourney = await prisma.subscriberJourney.findFirst({
        where: { automationId: automation.id, commentId },
        select: { id: true },
      });
      if (!existingJourney) {
        await recordChainGateJourney(
          automation,
          { commentId, commenterId, commenterName },
          null,
          "retry"
        );
      }
    }

    // Skip only when there is genuinely nothing left to do. A comment whose DM
    // already sent but whose public reply never posted (e.g. it hit a rate
    // limit) must still come back so the public reply can be retried.
    //
    // Терминальный отказ читается тут наравне с ушедшим DM: по нему отправка
    // закрыта так же навсегда, разница только в том, что человек ничего не
    // получил и получить уже не сможет.
    if (existingLog?.status === "SKIPPED_PLAN_LIMIT") continue;
    if (
      (alreadyDmd || dmPermanentlyFailed) &&
      (alreadyPublicReplied || !automation.publicReplyEnabled)
    ) {
      continue;
    }

    if (!automation.instagramAccount.accessToken) {
      await prisma.dmLog.upsert({
        where: {
          automationId_commentId: {
            automationId: automation.id,
            commentId,
          },
        },
        create: {
          workspaceId: automation.workspaceId,
          automationId: automation.id,
          instagramAccountId: automation.instagramAccountId,
          commenterId,
          commenterName,
          commentText,
          commentId,
          matchedKeyword: matchResult.matchedKeyword,
          status: "FAILED",
          errorMessage: "Нет токена доступа Instagram - переподключи аккаунт в настройках",
        },
        update: {
          status: "FAILED",
          errorMessage: "Нет токена доступа Instagram - переподключи аккаунт в настройках",
        },
      });
      continue;
    }

    let accessToken: string;
    try {
      accessToken = decryptToken(automation.instagramAccount.accessToken);
    } catch {
      await prisma.dmLog.upsert({
        where: {
          automationId_commentId: {
            automationId: automation.id,
            commentId,
          },
        },
        create: {
          workspaceId: automation.workspaceId,
          automationId: automation.id,
          instagramAccountId: automation.instagramAccountId,
          commenterId,
          commenterName,
          commentText,
          commentId,
          matchedKeyword: matchResult.matchedKeyword,
          status: "FAILED",
          errorMessage: "Не удалось расшифровать токен Instagram - переподключи аккаунт в настройках",
        },
        update: {
          status: "FAILED",
          errorMessage: "Не удалось расшифровать токен Instagram - переподключи аккаунт в настройках",
        },
      });
      continue;
    }

    // Ensure a log row exists before the public reply leg (which updates it).
    // Only (re)set PENDING when the DM will actually be attempted, so a prior
    // SENT is never clobbered while we come back just to retry the public reply.
    if (!existingLog) {
      await prisma.dmLog.create({
        data: {
          workspaceId: automation.workspaceId,
          automationId: automation.id,
          instagramAccountId: automation.instagramAccountId,
          commenterId,
          commenterName,
          commentText,
          commentId,
          matchedKeyword: matchResult.matchedKeyword,
          status: "PENDING",
          attempts: job.attemptsMade + 1,
        },
      });
    } else if (needsDm) {
      await prisma.dmLog.update({
        where: {
          automationId_commentId: { automationId: automation.id, commentId },
        },
        data: {
          status: "PENDING",
          attempts: job.attemptsMade + 1,
          matchedKeyword: matchResult.matchedKeyword,
          errorMessage: null,
        },
      });
    }

    // Public reply leg — decoupled from the DM and posted first so a DM failure
    // (e.g. a non-follower whose messaging is restricted) never suppresses it.
    // Idempotent across retries via publicReplySentAt.
    //
    // Gated behind its OWN rate limiter (reserveCommentReplySlot), checked
    // before sendCommentReply ever runs. This is the fix for the comment
    // reply previously going out unconditionally, ahead of and unrelated to
    // the DM leg's reserveDMSlot check below: once the account's hourly DM
    // cap was already exhausted, public replies kept firing anyway, because
    // nothing here had asked a limiter for permission first.
    const replyPool =
      automation.publicReplyMessages.length > 0
        ? automation.publicReplyMessages
        : automation.publicReplyMessage
          ? [automation.publicReplyMessage]
          : [];
    if (
      automation.publicReplyEnabled &&
      replyPool.length > 0 &&
      !existingLog?.publicReplySentAt
    ) {
      const commentRateLimit = await reserveCommentReplySlot(
        instagramAccountId,
        requeueAttempt,
        automation.instagramAccount.connectedAt
      );

      if (!commentRateLimit.allowed) {
        // Don't set publicReplySentAt: the comment stays eligible for a
        // retry on a later pass (either a fresh poll job or a re-run of this
        // one), it just isn't attempted again in *this* pass. Never throws —
        // a busy public-reply limiter must not fail the DM leg below.
        console.warn(
          "[DM Worker] Public comment reply skipped: hourly comment-reply rate limit reached"
        );
        await prisma.dmLog
          .update({
            where: {
              automationId_commentId: { automationId: automation.id, commentId },
            },
            data: {
              publicReplyError:
                "Hourly public-reply rate limit reached; will retry on the next pass",
            },
          })
          .catch(() => {});
      } else {
        try {
          const chosen = replyPool[Math.floor(Math.random() * replyPool.length)];
          const publicReply = renderMessageWithTracking({
            message: chosen,
            commenterName,
            trackedLinks: automation.trackedLinks,
          });
          await sendCommentReply(accessToken, commentId, publicReply);
          await prisma.dmLog.update({
            where: {
              automationId_commentId: { automationId: automation.id, commentId },
            },
            data: { publicReplySentAt: new Date(), publicReplyError: null },
          });
        } catch (error) {
          console.error(
            "[DM Worker] Public comment reply failed:",
            formatError(error)
          );
          await prisma.dmLog
            .update({
              where: {
                automationId_commentId: { automationId: automation.id, commentId },
              },
              data: { publicReplyError: formatError(error) },
            })
            .catch(() => {});
        }
      }
    }

    // DM already sent on an earlier pass; the public reply retry above was all
    // this run needed. Don't re-send the DM.
    if (!needsDm) continue;

    // Meta allows exactly ONE private reply per comment, ever — across every
    // campaign. When several campaigns match the same comment (duplicated
    // campaigns, or an any-post campaign overlapping a post-specific one), only
    // the first can deliver; the rest would fail with "The comment is invalid
    // for a private reply". Skip them explicitly instead of burning an API call
    // and logging a failure the user can do nothing about. The public reply
    // above still goes out per campaign — only the DM leg is deduped.
    const privateReplyUsedBy = await prisma.dmLog.findFirst({
      where: {
        commentId,
        status: "SENT",
        automationId: { not: automation.id },
      },
      select: { automation: { select: { name: true } } },
    });
    if (privateReplyUsedBy) {
      await prisma.dmLog.update({
        where: {
          automationId_commentId: { automationId: automation.id, commentId },
        },
        data: {
          status: "SKIPPED_DEDUP",
          matchedKeyword: matchResult.matchedKeyword,
          errorMessage: `Другая кампания (${privateReplyUsedBy.automation?.name ?? "неизвестна"}) уже отправила единственный приватный ответ, который Instagram разрешает на этот комментарий`,
        },
      });
      continue;
    }

    // Два предотправочных гейта цепочки, оба по ID комментатора: ID в
    // пространстве сообщений появится только в ответе Meta, то есть уже после
    // отправки, а решать надо до неё. Первый — про эту же кампанию (второй раз
    // в ту же цепочку не пускаем), второй — про соседние (одна живая цепочка
    // на человека). Обычный одиночный DM ни там, ни там не выход: у кампании с
    // цепочкой он и ЕСТЬ GATE, с которого начинается второй поток.
    if (automation.chainEnabled) {
      // «Prohibit restart» — в цепочку ОДНОЙ кампании человек входит один раз.
      // Гейт смотрит ЛЮБОЙ её журней по этому человеку, включая терминальный:
      // у завершённой цепочки живой строки нет, второй GATE «ответь словом X»
      // ушёл бы штатно, человек бы ответил — а опрос диалогов сверяет треды
      // только с живыми журнеями и этот ответ не увидит. Получится разговор в
      // пустоту, самый дорогой из возможных исходов: слово сказано, доверие
      // потрачено, не пришло ничего. Срок запрета = ретеншн журнеев.
      const priorJourney = await findAnyJourneyForCampaign(
        automation.id,
        commenterId
      );
      if (priorJourney) {
        const reason = restartBlockedReason(priorJourney.state);
        await prisma.dmLog.update({
          where: {
            automationId_commentId: {
              automationId: automation.id,
              commentId,
            },
          },
          data: {
            status: "SKIPPED_DEDUP",
            matchedKeyword: matchResult.matchedKeyword,
            errorMessage: reason,
          },
        });
        // INFO, а не WARNING: это штатный отказ по правилу, а не поломка.
        // Сам журней не трогаем ни одним полем — markJourneySkipped затёр бы
        // состояние прошлой цепочки (DONE стал бы SKIPPED) ради следа о том,
        // что она была; след и так есть, в строке DmLog и здесь.
        //
        // Пишем только когда строка DmLog заведена ЭТИМ заходом. Повторная
        // джоба по уже существующей строке ничего нового владельцу не
        // сообщает, а залить журнал одинаковыми INFO может быстро: причина
        // отказа лежит в самой строке DmLog и никуда не девается.
        if (dmLogRowIsNew) {
          await recordJourneyEvent({
            workspaceId: automation.workspaceId,
            level: "INFO",
            message: reason,
            payload: {
              automationId: automation.id,
              commentId,
              commenterId,
              journeyId: priorJourney.id,
              state: priorJourney.state,
            },
          });
        }
        continue;
      }

      // Один человек = одна живая цепочка на аккаунт. Если по нему прямо
      // сейчас идёт цепочка соседней кампании, вторую в то же 24-часовое окно
      // не запускаем: он получил бы два набора сообщений внахлёст.
      const liveJourney = await findLiveJourneyByCommenter(
        automation.instagramAccountId,
        commenterId
      );
      if (liveJourney) {
        const reason = `У этого человека уже идёт цепочка кампании «${liveJourney.automationName ?? "неизвестна"}» - вторую в то же окно не запускаем`;
        await prisma.dmLog.update({
          where: {
            automationId_commentId: {
              automationId: automation.id,
              commentId,
            },
          },
          data: {
            status: "SKIPPED_DEDUP",
            matchedKeyword: matchResult.matchedKeyword,
            errorMessage: reason,
          },
        });
        await markJourneySkipped({
          workspaceId: automation.workspaceId,
          automationId: automation.id,
          instagramAccountId: automation.instagramAccountId,
          // ID в пространстве сообщений неизвестен - GATE не уходил, отвечать
          // Meta было нечем. Кладём ID комментатора: строка нужна как след
          // «почему не пришло», писать по ней никто не будет.
          subscriberId: commenterId,
          commenterId,
          subscriberName: commenterName,
          commentId,
          failReason: reason,
        }).catch((error) => {
          console.error(
            "[DM Worker] Failed to record skipped chain journey:",
            formatError(error)
          );
        });
        continue;
      }
    }

    const usage = await reserveWorkspaceDMSend(automation.workspaceId);
    if (!usage.allowed) {
      await prisma.dmLog.update({
        where: {
          automationId_commentId: {
            automationId: automation.id,
            commentId,
          },
        },
        data: {
          status: "SKIPPED_PLAN_LIMIT",
          matchedKeyword: matchResult.matchedKeyword,
          errorMessage: `Достигнут месячный лимит сообщений (${usage.limit})`,
        },
      });
      continue;
    }

    let rateLimit;
    try {
      rateLimit = await reserveDMSlot(
        instagramAccountId,
        requeueAttempt,
        automation.instagramAccount.connectedAt
      );
    } catch (error) {
      await releaseWorkspaceDMReservation(
        automation.workspaceId,
        usage.periodStart
      );
      await prisma.dmLog.update({
        where: {
          automationId_commentId: {
            automationId: automation.id,
            commentId,
          },
        },
        data: {
          status: "FAILED",
          attempts: job.attemptsMade + 1,
          errorMessage: formatError(error),
        },
      });
      throw error;
    }

    if (!rateLimit.allowed) {
      await releaseWorkspaceDMReservation(
        automation.workspaceId,
        usage.periodStart
      );

      if (rateLimit.shouldSkip) {
        await prisma.dmLog.update({
          where: {
            automationId_commentId: {
              automationId: automation.id,
              commentId,
            },
          },
          data: {
            status: "SKIPPED_RATE_LIMIT",
            matchedKeyword: matchResult.matchedKeyword,
            errorMessage: "Упёрлись в часовой лимит отправки Instagram",
          },
        });
        continue;
      }

      if (rateLimit.shouldRequeue) {
        await prisma.dmLog.update({
          where: {
            automationId_commentId: {
              automationId: automation.id,
              commentId,
            },
          },
          data: {
            status: "PENDING",
            matchedKeyword: matchResult.matchedKeyword,
            errorMessage: "Упёрлись в часовой лимит, повтор запланирован",
          },
        });

        await getDMQueue().add(
          "process-comment",
          {
            ...job.data,
            requeueAttempt: requeueAttempt + 1,
          },
          {
            delay: rateLimit.requeueDelayMs,
            jobId: `comment_${instagramAccountId}_${commentId}_retry_${requeueAttempt + 1}`,
          }
        );
        continue;
      }
    }

    let gateRecipientId: string | null = null;
    // GATE, который на самом деле ушёл в прошлой жизни воркера: отправка
    // прошла, а строку SENT записать не успели.
    let gateDeliveredEarlier = false;
    try {
      // Отметка «мы дошли до Meta», и записать её надо ДО вызова, а не после:
      // весь смысл поля в том, чтобы пережить заход, который умер ВНУТРИ
      // отправки (таймаут 30с, рестарт воркера, падение процесса). После
      // вызова писать было бы нечего - процесса уже нет.
      //
      // Одним UPDATE'ом на все три ветки ниже (цепочка, кнопки, простой
      // текст): между этой строкой и первым сетевым вызовом любой ветки
      // остаётся только сборка текста сообщения - чистые функции без ввода-
      // вывода. Поле честное для всех веток, читает его пока только спасение
      // GATE у цепочки (priorSendAttempt выше); логику обычной ветки оно не
      // меняет.
      await prisma.dmLog.update({
        where: {
          automationId_commentId: { automationId: automation.id, commentId },
        },
        data: { dmAttemptedAt: new Date() },
      });

      if (automation.chainEnabled) {
        // Код-гейт, а не договорённость о данных: у кампании с цепочкой GATE
        // ВСЕГДА уходит простым текстом, даже если tracked-ссылки лежат у неё
        // в базе. API их вместе не сохраняет, но данные могли приехать до
        // этого кода или прямой правкой базы, а цена ошибки тут вся цепочка:
        // кнопка даёт человеку что нажать вместо того, чтобы ответить, ответа
        // нет - окно Meta не открылось - ни один шаг после GATE не уйдёт.
        // {link} в тексте остаться не может: API запрещает цепочку вместе с
        // tracked-ссылками, а без них подставлять в плейсхолдер нечего.
        const gateMessage = renderMessageWithTracking({
          message: automation.dmMessage,
          commenterName,
          trackedLinks: [],
        });
        try {
          const gateResult = await sendPrivateReply(
            accessToken,
            automation.instagramAccount.instagramId,
            commentId,
            gateMessage
          );
          // Единственное место, где мы узнаём ID человека в пространстве
          // сообщений: дальше цепочка пишет только по нему.
          gateRecipientId = gateResult?.recipient_id ?? null;
        } catch (gateError) {
          // Meta говорит, что единственный приватный ответ на этот комментарий
          // уже израсходован. Раз чужая кампания его не забирала (проверено
          // выше по DmLog) И по этой строке отправка уже начиналась
          // (priorSendAttempt — улика), забрали его мы сами: на прошлом заходе,
          // между ушедшим GATE и незаписанным SENT воркер умер. Считать это
          // провалом нельзя: строка ушла бы в FAILED и цепочка не завелась бы
          // НИКОГДА, потому что второй приватный ответ Meta уже не даст.
          // Поэтому трактуем как доставку: SENT ниже, журней чиним по ID
          // комментатора. Месячную квоту не возвращаем — сообщение человеку
          // доставлено.
          //
          // БЕЗ улики (первый заход по нетронутому комментарию) тот же ответ
          // Meta ничего не доказывает, а цена ошибки — человек с SENT и
          // журнеем, который не получил ничего, плюс закрытый повторный вход.
          // Тогда идём прежним честным путём отказа: FAILED, журнея нет,
          // джоба падает и ретраится.
          if (!isPrivateReplyAlreadyUsed(gateError) || !priorSendAttempt) {
            throw gateError;
          }

          console.log(
            "[DM Worker] GATE already delivered on an earlier run, recovering:",
            formatError(gateError)
          );
          gateDeliveredEarlier = true;
        }
      } else if (automation.trackedLinks.length > 0) {
        // Try button template first; if Meta rejects it, fall back to inline links.
        const bodyText =
          renderMessageWithoutLink({
            message: automation.dmMessage,
            commenterName,
          }) || "Here's your link:";
        const buttons = buildLinkButtons(
          automation.trackedLinks,
          automation.linkButtonLabel
        );

        try {
          await sendPrivateReplyWithLinkButton(
            accessToken,
            automation.instagramAccount.instagramId,
            commentId,
            bodyText,
            buttons
          );
        } catch (buttonError) {
          // Only a template rejection is worth retrying as text. Anything else
          // (closed window, comment already replied to) fails the same way and
          // would replace the real error with a misleading one.
          if (!isTemplateRejection(buttonError)) throw buttonError;

          console.log(
            "[DM Worker] Button template rejected, falling back to inline link:",
            formatError(buttonError)
          );
          const fallbackMessage = buildInlineLinkFallback(
            automation.dmMessage,
            commenterName,
            automation.trackedLinks,
            bodyText
          );
          try {
            await sendPrivateReply(
              accessToken,
              automation.instagramAccount.instagramId,
              commentId,
              fallbackMessage
            );
          } catch {
            // The first attempt consumed the comment's single private reply, so
            // this one reports "invalid for a private reply" no matter what the
            // underlying problem was. Surface the original rejection instead.
            throw buttonError;
          }
        }
      } else {
        const dmMessage = renderMessageWithTracking({
          message: automation.dmMessage,
          commenterName,
          trackedLinks: automation.trackedLinks,
        });
        await sendPrivateReply(
          accessToken,
          automation.instagramAccount.instagramId,
          commentId,
          dmMessage
        );
      }

      await prisma.dmLog.update({
        where: {
          automationId_commentId: {
            automationId: automation.id,
            commentId,
          },
        },
        data: {
          status: "SENT",
          dmSentAt: new Date(),
          errorMessage: null,
        },
      });
    } catch (error) {
      await releaseWorkspaceDMReservation(
        automation.workspaceId,
        usage.periodStart
      );

      // Перманентный отказ: повторять нечего ни сейчас, ни через сутки.
      // Строка получает терминальный статус - и опрос комментариев считает её
      // обработанной, и джоба завершается без исключения. Иначе один мёртвый
      // комментарий (закрытый директ, удалённый комментарий) 144 часа подряд
      // рожает по джобе за проход: ~288 падений и столько же строк ERROR,
      // которыми вычищается вся лента диагностики.
      const permanent = classifyPermanentSendFailure(error);
      if (permanent) {
        // Причина владельцу человеческим языком, следом дословный ответ Meta:
        // первое объясняет, второе позволяет опознать тот же отказ потом.
        const reason = `${permanent.reason} (${formatError(error)})`;
        await prisma.dmLog.update({
          where: {
            automationId_commentId: {
              automationId: automation.id,
              commentId,
            },
          },
          data: {
            status: "FAILED_PERMANENT",
            attempts: job.attemptsMade + 1,
            errorMessage: reason,
          },
        });
        // recordJourneyEvent - общая безопасная запись в журнал (никогда не
        // роняет вызывающего), а не что-то только про цепочки: своего второго
        // такого же писателя тут заводить незачем.
        await recordJourneyEvent({
          workspaceId: automation.workspaceId,
          level: "WARNING",
          message: `Отправка по комментарию невозможна и повторяться не будет: ${reason}`,
          payload: {
            automationId: automation.id,
            commentId,
            commenterId,
          },
        });
        // Не бросаем: ретраить нечего, а падение джобы стоило бы трёх попыток
        // BullMQ, трёх строк ERROR и удержанного до конца TTL клейма
        // комментария (он снимается только на «completed»). Соседние кампании
        // по тому же комментарию свой шанс при этом сохраняют.
        continue;
      }

      await prisma.dmLog.update({
        where: {
          automationId_commentId: {
            automationId: automation.id,
            commentId,
          },
        },
        data: {
          status: "FAILED",
          attempts: job.attemptsMade + 1,
          errorMessage: formatError(error),
        },
      });
      throw error;
    }

    // Журней заводим ПОСЛЕ фиксации SENT и ВНЕ её try/catch. Внутри его сбой
    // увёл бы строку в FAILED - а DM при этом уже доставлен, и следующий
    // проход опроса счёл бы комментарий необработанным и отправил второй.
    if (automation.chainEnabled) {
      await recordChainGateJourney(
        automation,
        { commentId, commenterId, commenterName },
        gateRecipientId,
        gateDeliveredEarlier ? "lost-write" : "none"
      );
    }
  }
}

async function processJob(job: Job<DmQueueJob>): Promise<void> {
  return processComment(job as Job<ProcessCommentJob>);
}

async function recordWorkerFailure(
  job: Job<DmQueueJob> | undefined,
  error: Error
) {
  try {
    const instagramAccountId = job?.data.instagramAccountId;
    const commentId =
      job && "commentId" in job.data ? job.data.commentId : null;
    const account = instagramAccountId
      ? await prisma.instagramAccount.findUnique({
          where: { instagramId: instagramAccountId },
          select: { workspaceId: true },
        })
      : null;

    await prisma.operationalEvent.create({
      data: {
        workspaceId: account?.workspaceId ?? null,
        source: "WORKER",
        level: "ERROR",
        message: `DM worker job ${job?.id ?? "unknown"} failed: ${error.message}`,
        payload: {
          jobId: job?.id ?? null,
          attemptsMade: job?.attemptsMade ?? null,
          instagramAccountId: instagramAccountId ?? null,
          commentId,
        },
      },
    });

    await recordWorkerAlert({
      level: "error",
      message: error.message,
      jobId: job?.id,
      instagramAccountId,
      commentId: commentId ?? undefined,
    });
  } catch (recordError) {
    console.error(
      "[DM Worker] Failed to record worker failure:",
      formatError(recordError)
    );
  }
}

export function createDMWorker(): Worker<DmQueueJob> {
  const worker = new Worker<DmQueueJob>(
    "dm-processing",
    processJob,
    {
      connection: getRedisConnection(),
      concurrency: 5,
      settings: {
        backoffStrategy: (attemptsMade: number) =>
          BACKOFF_DELAYS[Math.min(attemptsMade - 1, BACKOFF_DELAYS.length - 1)],
      },
    }
  );

  worker.on("completed", (job) => {
    console.log(`[DM Worker] Job ${job.id} completed`);
    // Release the comment claim taken in lib/polling/comment-reconciler.ts
    // before this job was enqueued — a later sweep is now free to re-queue
    // this comment if it's still legitimately unhandled (e.g. the public
    // reply is still pending). Only on "completed", not "failed": a job
    // mid-retry-backoff must stay claimed so a parallel sweep doesn't
    // enqueue a second, racing job for the same comment (see
    // lib/queue/comment-claim.ts for why "failed" isn't the right hook).
    void releaseCommentClaim(job.data.instagramAccountId, job.data.commentId).catch(
      (error) => {
        console.error(
          "[DM Worker] Failed to release comment claim:",
          formatError(error)
        );
      }
    );
  });

  worker.on("failed", (job, err) => {
    console.error(
      `[DM Worker] Job ${job?.id} failed (attempt ${job?.attemptsMade}):`,
      err.message
    );
    void recordWorkerFailure(job, err);
  });

  worker.on("error", (err) => {
    console.error("[DM Worker] Worker error:", err.message);
    void prisma.operationalEvent
      .create({
        data: {
          source: "WORKER",
          level: "ERROR",
          message: `DM worker process error: ${err.message}`,
          payload: { name: err.name },
        },
      })
      .catch((recordError) => {
        console.error(
          "[DM Worker] Failed to record worker process error:",
          formatError(recordError)
        );
      });
  });

  return worker;
}

