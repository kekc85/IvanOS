/**
 * Опрос диалогов: единственное место, где цепочка узнаёт, что человек ответил.
 *
 * Вебхуков у нас нет (это осознанный отказ от App Review, см. CLAUDE.md), а без
 * ответа человека цепочка не имеет права идти вообще: Meta разрешает писать
 * первым ровно один раз - приватным ответом на комментарий. Дальше окно
 * открывает только сам человек. Поэтому раз в полторы минуты этот проход
 * спрашивает у Meta список диалогов аккаунта и сверяет его с живыми журнеями.
 *
 * Нагрузка (В-A плана): ОДИН вызов getConversations на аккаунт за проход, а не
 * по вызову на тред. Превью последнего сообщения уже приезжает внутри списка
 * (`messages.limit(1){message,from,created_time}`, см. lib/meta/client.ts), и
 * этого хватает на все три вопроса прохода: кто написал последним, что он
 * написал и когда. getConversationMessages не дёргается ни разу - на аккаунте
 * с полусотней тредов это разница между ~40 и ~840 вызовами в час.
 *
 * Чего проход НЕ делает: не хранит переписку. Из превью в базу уезжают только
 * момент времени (якорь окна) и факт «человек попросил перестать» - сам текст
 * сообщения нигде не сохраняется.
 */

import { prisma } from "@/lib/db/client";
import {
  getConversations,
  MetaApiError,
  type InstagramConversation,
} from "@/lib/meta/client";
import { decryptToken } from "@/lib/meta/oauth";
import { matchKeywords } from "@/lib/utils/keyword-matcher";
import {
  LIVE_JOURNEY_STATES,
  recordJourneyEvent,
  soleWorkspaceId,
} from "@/lib/chain/journey";

/**
 * Слова, которыми человек просит перестать (реш.9 плана).
 *
 * Матчинг - по границам слова и без учёта регистра, через тот же
 * lib/utils/keyword-matcher, что и кодовые слова кампаний: он умеет кириллицу
 * (обычный \b на ней не срабатывает) и отклеивает эмодзи от слова. Поэтому
 * «Стоп!» и «стоп 🙏» останавливают цепочку, а «стопудово» - нет.
 */
export const CHAIN_STOP_WORDS = [
  "стоп",
  "хватит",
  "отстань",
  "отписаться",
  "отписка",
  "stop",
  "unsubscribe",
];

const STOP_REASON =
  "Человек попросил перестать писать - цепочка остановлена по стоп-слову";

/**
 * С какого возраста неотвеченный GATE начинает свидетельствовать против нас.
 *
 * Сам по себе тред без журнея - норма: в директе аккаунта лежат диалоги людей,
 * которые ни в какой цепочке не участвуют, и таких там большинство. Но тред
 * без журнея РЯДОМ с GATE, который висит без ответа дольше десяти минут, -
 * это уже другой разговор: похоже, человек ответил, а мы его не узнали.
 * Именно так выглядит главная непроверенная гипотеза контура: `subscriberId`
 * (ID в пространстве сообщений) и `commenterId` (ID под комментарием) на
 * конкретном аккаунте могут не совпасть ни с одним участником треда, и тогда
 * цепочка молча не стартует, а в журнале не остаётся ничего.
 */
const GATE_UNMATCHED_WARN_AGE_MS = 10 * 60 * 1000;

/**
 * Как часто эта тревога имеет право прозвучать.
 *
 * Оба её условия по отдельности — нормальное состояние живого аккаунта:
 * несопоставленные треды это посторонние диалоги в директе (их там
 * большинство), а «GATE ждёт ответа дольше десяти минут» — любой человек,
 * который просто ещё не ответил, при TTL гейта в 48 часов. Проход идёт каждые
 * 90 секунд, поэтому тревога «по состоянию» превращается в 40 WARNING в час на
 * ровном месте, и владелец перестаёт читать журнал ровно тогда, когда там
 * появится настоящая поломка. Поэтому тревога — про ПЕРЕХОД: не чаще раза в
 * полчаса и только когда висящих GATE стало БОЛЬШЕ, чем на прошлой тревоге.
 * Счётчики никуда не деваются — они и дальше едут в строке обычного прохода
 * как данные INFO.
 */
const UNMATCHED_ALARM_COOLDOWN_MS = 30 * 60 * 1000;

export interface ConversationPollResult {
  /** Аккаунтов, у которых есть живые журнеи (столько же вызовов к Meta). */
  accounts: number;
  /** Живых журнеев во всех этих аккаунтах на момент прохода. */
  journeys: number;
  /** GATE_SENT → ACTIVE: человек ответил, цепочка пошла. */
  activated: number;
  /** Живых журнеев остановлено по стоп-слову. */
  stopped: number;
  /** ACTIVE, у которых обновился якорь окна (человек написал ещё раз). */
  refreshed: number;
  /** Тредов, у которых впервые записан conversationId. */
  linked: number;
  /** Тредов вообще пришло от Meta за проход (по всем аккаунтам). */
  threadsSeen: number;
  /** Из них не сопоставлено ни с одним живым журнеем. */
  unmatched: number;
  errors: string[];
}

/** Живой журней глазами опроса - ровно те поля, по которым он решает. */
interface PollJourney {
  id: string;
  workspaceId: string;
  automationId: string;
  subscriberId: string;
  commenterId: string | null;
  conversationId: string | null;
  state: "GATE_SENT" | "ACTIVE";
  gateSentAt: Date;
  lastUserMessageAt: Date | null;
}

interface PollAccount {
  id: string;
  workspaceId: string;
  instagramId: string;
  username: string;
  accessToken: string;
}

function errMessage(error: unknown): string {
  if (error instanceof MetaApiError) return `Meta ${error.code}: ${error.message}`;
  if (error instanceof Error) return error.message;
  return "Unknown error";
}

function toDate(value: unknown): Date | null {
  if (value instanceof Date) return Number.isNaN(value.getTime()) ? null : value;
  if (typeof value === "string") {
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? null : parsed;
  }
  return null;
}

/** Просил ли человек перестать - по границам слова, регистр не важен. */
export function isStopWordMessage(text: string | null | undefined): boolean {
  if (!text) return false;
  return matchKeywords(text, CHAIN_STOP_WORDS, true).matched;
}

/**
 * Тред → журней.
 *
 * Совпадение ищется по ОБОИМ известным ID человека, и это не перестраховка.
 * `subscriberId` - это `recipient_id`, который Meta вернула на GATE (то самое
 * пространство сообщений, в которое мы потом пишем шаги), `commenterId` - ID
 * из-под комментария. Совпадут эти пространства на конкретном аккаунте или
 * нет, снаружи не документировано, а цена промаха - вся цепочка молча не
 * стартует. Поэтому принимаем любое из двух; какое сработало, видно по тому,
 * что журней вообще нашёлся.
 */
function matchJourney(
  conversation: InstagramConversation,
  bySubscriber: Map<string, PollJourney>,
  byCommenter: Map<string, PollJourney>
): PollJourney | null {
  const participants = conversation.participants?.data ?? [];
  for (const participant of participants) {
    if (!participant?.id) continue;
    const bySub = bySubscriber.get(participant.id);
    if (bySub) return bySub;
  }
  for (const participant of participants) {
    if (!participant?.id) continue;
    const byCom = byCommenter.get(participant.id);
    if (byCom) return byCom;
  }
  return null;
}

/**
 * Один проход по одному аккаунту: один вызов к Meta, дальше только база.
 * Ошибку наружу не пускает - её ловит вызывающий и продолжает по остальным
 * аккаунтам (задача 1.4): токен, протухший на одном аккаунте, не должен
 * останавливать цепочки на соседнем.
 */
async function pollAccount(
  account: PollAccount,
  journeys: PollJourney[],
  result: ConversationPollResult,
  now: Date
): Promise<void> {
  let accessToken: string;
  try {
    accessToken = decryptToken(account.accessToken);
  } catch {
    throw new Error("не удалось расшифровать токен доступа");
  }

  const conversations = await getConversations(accessToken, account.instagramId);

  const bySubscriber = new Map<string, PollJourney>();
  const byCommenter = new Map<string, PollJourney>();
  for (const journey of journeys) {
    if (!bySubscriber.has(journey.subscriberId)) {
      bySubscriber.set(journey.subscriberId, journey);
    }
    if (journey.commenterId && !byCommenter.has(journey.commenterId)) {
      byCommenter.set(journey.commenterId, journey);
    }
  }

  const handled = new Set<string>();

  for (const conversation of conversations) {
    result.threadsSeen += 1;
    const journey = matchJourney(conversation, bySubscriber, byCommenter);
    if (!journey) {
      // Не молчим, как раньше: несопоставленный тред сам по себе безобиден,
      // но именно в нём прячется ответ человека, чьи ID не совпали. Счётчик -
      // единственный след, по которому это видно снаружи (см.
      // GATE_UNMATCHED_WARN_AGE_MS).
      result.unmatched += 1;
      continue;
    }
    // Два треда на один журней (например, ID совпали в обоих пространствах) -
    // считаем только первый: он новее, список приходит от Meta свежим сверху.
    if (handled.has(journey.id)) continue;
    handled.add(journey.id);

    // Ссылка на тред - факт о журнее, а не про сообщение: пишем при первом
    // же матче, даже если отвечать человек ещё не начал. Дальше по ней видно,
    // какой именно диалог принадлежит цепочке.
    const linkConversation =
      conversation.id && journey.conversationId !== conversation.id;

    const preview = conversation.messages?.data?.[0];
    const fromId = preview?.from?.id;
    const createdAt = toDate(preview?.created_time);
    const fromHuman = Boolean(fromId) && fromId !== account.instagramId;
    const isNew =
      createdAt !== null && createdAt.getTime() > journey.gateSentAt.getTime();

    if (!fromHuman || !isNew || createdAt === null) {
      if (linkConversation) {
        await prisma.subscriberJourney.update({
          where: { id: journey.id },
          data: { conversationId: conversation.id },
        });
        result.linked += 1;
      }
      continue;
    }

    const linkData = linkConversation ? { conversationId: conversation.id } : {};
    if (linkConversation) result.linked += 1;

    if (isStopWordMessage(preview?.message)) {
      await prisma.subscriberJourney.update({
        where: { id: journey.id },
        data: {
          ...linkData,
          state: "STOPPED",
          lastUserMessageAt: createdAt,
          nextStepDueAt: null,
          failReason: STOP_REASON,
          completedAt: now,
        },
      });
      result.stopped += 1;
      await recordJourneyEvent({
        workspaceId: journey.workspaceId,
        level: "WARNING",
        message: `Цепочка остановлена: человек попросил перестать (@${account.username})`,
        payload: {
          journeyId: journey.id,
          automationId: journey.automationId,
          subscriberId: journey.subscriberId,
        },
      });
      continue;
    }

    if (journey.state === "GATE_SENT") {
      // Момент ответа - это одновременно и якорь окна Meta, и якорь всего
      // расписания цепочки. Шаг 0 (ВЫДАЧА) ставится на тот же момент, то есть
      // «сразу»: человек только что попросил, ждать ему нечего.
      await prisma.subscriberJourney.update({
        where: { id: journey.id },
        data: {
          ...linkData,
          state: "ACTIVE",
          lastUserMessageAt: createdAt,
          nextStepDueAt: createdAt,
        },
      });
      result.activated += 1;
      await recordJourneyEvent({
        workspaceId: journey.workspaceId,
        level: "INFO",
        message: `Цепочка пошла: человек ответил на GATE, окно открыто (@${account.username})`,
        payload: {
          journeyId: journey.id,
          automationId: journey.automationId,
          subscriberId: journey.subscriberId,
          lastUserMessageAt: createdAt.toISOString(),
        },
      });
      continue;
    }

    // ACTIVE: человек написал ещё раз. Освежаем ТОЛЬКО якорь окна - он
    // продлевает право писать. Расписание не трогаем: оно якорится на момент
    // активации, и перекладывать его на каждое новое сообщение значило бы
    // отодвигать M1/M2/M3 у самых разговорчивых - тех, кто как раз ждёт
    // ответа больше всех.
    if (
      !journey.lastUserMessageAt ||
      createdAt.getTime() > journey.lastUserMessageAt.getTime()
    ) {
      await prisma.subscriberJourney.update({
        where: { id: journey.id },
        data: { ...linkData, lastUserMessageAt: createdAt },
      });
      result.refreshed += 1;
    } else if (linkConversation) {
      await prisma.subscriberJourney.update({
        where: { id: journey.id },
        data: linkData,
      });
    }
  }
}

/**
 * Первый проход после старта воркера пишет строку в журнал, даже когда делать
 * было нечего. Дальше молчит, пока нечего сказать (тот же принцип, что у
 * recordSweep в lib/polling/comment-reconciler.ts): владельцу нужно уметь
 * убедиться, что контур цепочек поднялся, но не читать 960 строк «ноль» в
 * сутки.
 */
let passesRun = 0;

/** Момент последней поднятой тревоги про несопоставленные треды. */
let lastAlarmAt: number | null = null;
/**
 * Сколько висящих GATE было на той тревоге. Планка, выше которой нужно
 * подняться, чтобы прозвучала следующая; когда число падает ниже — планка
 * опускается вместе с ним, иначе один всплеск запирал бы тревогу навсегда.
 */
let lastAlarmStaleGates = 0;

/** Только для тестов: забыть, что первый проход уже был. */
export function resetConversationPollLogState(): void {
  passesRun = 0;
  lastAlarmAt = null;
  lastAlarmStaleGates = 0;
}

/** Один проход опроса диалогов по всем аккаунтам с живыми журнеями. */
export async function pollConversations(
  now: Date = new Date()
): Promise<ConversationPollResult> {
  const result: ConversationPollResult = {
    accounts: 0,
    journeys: 0,
    activated: 0,
    stopped: 0,
    refreshed: 0,
    linked: 0,
    threadsSeen: 0,
    unmatched: 0,
    errors: [],
  };

  passesRun += 1;
  const isFirstPass = passesRun === 1;

  /** Воркспейс для строки прохода: берётся с первого же аккаунта прохода. */
  let workspaceId: string | null = null;

  // Аккаунты берём от журнеев, а не наоборот: спрашивать диалоги у аккаунта,
  // на котором нет ни одной живой цепочки, незачем - сверять его ответы не с
  // чем.
  const accountRefs = await prisma.subscriberJourney.findMany({
    where: { state: { in: LIVE_JOURNEY_STATES } },
    distinct: ["instagramAccountId"],
    select: { instagramAccountId: true },
  });
  const accountIds = accountRefs.map((row) => row.instagramAccountId);

  if (accountIds.length > 0) {
    const accounts = (await prisma.instagramAccount.findMany({
      where: { id: { in: accountIds } },
      select: {
        id: true,
        workspaceId: true,
        instagramId: true,
        username: true,
        accessToken: true,
      },
    })) as PollAccount[];
    result.accounts = accounts.length;
    workspaceId = accounts[0]?.workspaceId ?? null;

    for (const account of accounts) {
      const journeys = (await prisma.subscriberJourney.findMany({
        where: {
          instagramAccountId: account.id,
          state: { in: LIVE_JOURNEY_STATES },
        },
        select: {
          id: true,
          workspaceId: true,
          automationId: true,
          subscriberId: true,
          commenterId: true,
          conversationId: true,
          state: true,
          gateSentAt: true,
          lastUserMessageAt: true,
        },
      })) as PollJourney[];
      result.journeys += journeys.length;
      if (journeys.length === 0) continue;

      try {
        await pollAccount(account, journeys, result, now);
      } catch (error) {
        // Аккаунт упал - остальные аккаунты проход всё равно доходит (1.4).
        const detail = errMessage(error);
        result.errors.push(`@${account.username}: ${detail}`);
        await recordJourneyEvent({
          workspaceId: account.workspaceId,
          level: "WARNING",
          message: `Цепочка: опрос диалогов @${account.username} не удался (${detail}) - остальные аккаунты опрошены, следующий проход повторит`,
          payload: {
            instagramAccountId: account.id,
            journeys: journeys.length,
          },
        });
      }
    }
  }

  // Треды без журнея тревожны только в паре с висящими GATE: без второго
  // признака это обычные диалоги посторонних людей, и кричать о них каждые
  // полторы минуты значит приучить владельца не читать журнал.
  let staleGates = 0;
  // Ноль в staleGates значит две разные вещи: «посчитали, их нет» и «не
  // посчитали». Различает их только этот флаг — без него упавший счёт
  // (база моргнула) выглядел бы как «стало меньше» и опускал планку тревоги
  // до нуля, а следующий же всплеск звучал бы как первый.
  let staleGatesMeasured = false;
  if (result.unmatched > 0) {
    try {
      staleGates = await prisma.subscriberJourney.count({
        where: {
          state: "GATE_SENT",
          gateSentAt: {
            lt: new Date(now.getTime() - GATE_UNMATCHED_WARN_AGE_MS),
          },
        },
      });
      staleGatesMeasured = true;
    } catch (error) {
      result.errors.push(`Подсчёт висящих GATE: ${errMessage(error)}`);
    }
  }
  // Само состояние «есть чужие треды и есть неотвеченные GATE» тревогой не
  // является (см. UNMATCHED_ALARM_COOLDOWN_MS): тревога — это переход.
  const alarmCondition = result.unmatched > 0 && staleGates > 0;
  // Планку опускаем только по ИЗМЕРЕННОМУ числу: и там, где считать было не
  // за чем (нет несопоставленных тредов), и там, где счёт бросил, ноль в
  // staleGates значит «не смотрели», а не «стало меньше».
  if (staleGatesMeasured && staleGates < lastAlarmStaleGates) {
    lastAlarmStaleGates = staleGates;
  }
  const cooledDown =
    lastAlarmAt === null || now.getTime() - lastAlarmAt >= UNMATCHED_ALARM_COOLDOWN_MS;
  const unmatchedAlarm =
    alarmCondition && cooledDown && staleGates > lastAlarmStaleGates;
  if (unmatchedAlarm) {
    lastAlarmAt = now.getTime();
    lastAlarmStaleGates = staleGates;
  }

  const hasActivity =
    result.activated > 0 ||
    result.stopped > 0 ||
    result.refreshed > 0 ||
    unmatchedAlarm ||
    result.errors.length > 0;

  if (hasActivity || isFirstPass) {
    const unmatchedNote =
      result.unmatched > 0
        ? `, тредов без журнея ${result.unmatched} из ${result.threadsSeen}`
        : "";
    // Одно предупреждение на проход, а не на тред: причина у всех одна.
    const alarmNote = unmatchedAlarm
      ? ` - и при этом ${staleGates} GATE ждут ответа дольше 10 минут, похоже человек ответил, а мы его не узнали (ID под комментарием и ID в переписке - разные пространства)`
      : "";
    await recordJourneyEvent({
      workspaceId: workspaceId ?? (await soleWorkspaceId()),
      level:
        result.errors.length > 0 || unmatchedAlarm ? "WARNING" : "INFO",
      message: `Цепочка: опрос диалогов - аккаунтов ${result.accounts}, живых журнеев ${result.journeys}, пошло ${result.activated}, остановлено ${result.stopped}, окно продлено ${result.refreshed}${unmatchedNote}${alarmNote}`,
      payload: {
        accounts: result.accounts,
        journeys: result.journeys,
        activated: result.activated,
        stopped: result.stopped,
        refreshed: result.refreshed,
        linked: result.linked,
        threadsSeen: result.threadsSeen,
        unmatched: result.unmatched,
        staleGates,
        errors: result.errors.length,
        firstPass: isFirstPass,
      },
    });
  }

  return result;
}
