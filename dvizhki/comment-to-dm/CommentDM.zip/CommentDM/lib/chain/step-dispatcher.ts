/**
 * Диспетчер шагов: единственное место, откуда уходят сообщения цепочки.
 *
 * Планировщика тут нет и быть не должно. Отложенная задача в очереди пережила
 * бы рестарт воркера, но не потерю Redis, а цепочка живёт сутки - за сутки
 * потерять Redis успевает любой VPS. Поэтому расписание целиком лежит в базе
 * (SubscriberJourney.nextStepDueAt), а этот проход раз в полминуты просто
 * спрашивает «кому пора» и отправляет.
 *
 * Три вещи, из-за которых код длиннее наивного «взял и отправил»:
 *
 * 1. Позиция сдвигается в базе ДО сетевого вызова (Б3). Рестарт ровно между
 *    «Meta приняла» и «мы записали» иначе означал бы второе M1 тому же
 *    человеку - а повторное сообщение бесит сильнее, чем пропущенное.
 *    Отправка не удалась - откатываем ровно то, что сдвинули.
 * 2. Время следующего шага считается от ПРЕЖНЕГО срока, а не от «сейчас»
 *    (В-C). Иначе каждая задержка ретрая накапливалась бы и съедала
 *    24-часовое окно Meta, в котором должна уместиться вся цепочка.
 * 3. За тик не больше CHAIN_DISPATCH_BATCH отправок (В-F). Воркер, лежавший
 *    час, иначе выстрелил бы всей накопившейся очередью разом - это ровно
 *    тот профиль трафика, на который Instagram реагирует ограничениями.
 */

import { prisma } from "@/lib/db/client";
import {
  MetaApiError,
  RateLimitError,
  isOutsideWindowError,
  sendDirectMessage,
} from "@/lib/meta/client";
import { decryptToken } from "@/lib/meta/oauth";
import { getRedisConnection } from "@/lib/queue/client";
import { reserveChainSlot } from "@/lib/utils/rate-limiter";
import {
  expireStaleGates,
  isWindowOpen,
  recordJourneyEvent,
  soleWorkspaceId,
} from "@/lib/chain/journey";

/**
 * Кэп отправок за один тик (В-F). Диспетчер ходит каждые 30 секунд, так что
 * даже полностью забитая очередь после долгого простоя разбирается со
 * скоростью ~20 сообщений в минуту, а не залпом.
 */
export const CHAIN_DISPATCH_BATCH = 10;

/**
 * Клейм на журней. Держится ровно на время обработки (снимается в finally),
 * а TTL - страховка на случай, если процесс умрёт с журнеем в руках: без неё
 * упавший воркер запер бы человеку цепочку навсегда.
 */
const CHAIN_CLAIM_PREFIX = "chain:claim:";
export const CHAIN_CLAIM_TTL_SECONDS = 10 * 60;

/**
 * На сколько отодвигается шаг, упершийся в лимит (наш собственный счётчик или
 * отказ Meta). Час - окно счётчика, полчаса - половина окна: к следующей
 * попытке место в корзине почти наверняка освободилось.
 */
export const CHAIN_RATE_LIMIT_BACKOFF_MS = 30 * 60 * 1000;

/**
 * Пауза перед повтором после НЕтерминальной ошибки отправки (сеть, пятисотка
 * Meta). Без неё три попытки сгорали бы за полторы минуты - три подряд тика
 * по 30 секунд, - и один сетевой всплеск хоронил бы остаток цепочки.
 *
 * Пять минут стоят сдвига расписания на 15 минут в худшем случае (три
 * попытки). Это внутри запаса: сумма задержек цепочки 22ч10м против окна в
 * 23.5ч. И сдвиг не может незаметно вынести шаг за окно - окно проверяется
 * перед каждой отправкой по своему якорю (lastUserMessageAt), а не по сроку
 * шага.
 */
export const CHAIN_STEP_RETRY_BACKOFF_MS = 5 * 60 * 1000;

/** Попыток на один шаг, после чего журней ложится FAILED. */
export const MAX_STEP_ATTEMPTS = 3;

const WINDOW_CLOSED_REASON =
  "Окно переписки закрылось - человек не писал дольше суток, дослать шаг Meta уже не даёт";

export interface ChainDispatchResult {
  /** GATE, закрытых по 48-часовому сроку в начале прохода. */
  gatesExpired: number;
  /** Журнеев, у которых наступил срок шага (не больше CHAIN_DISPATCH_BATCH). */
  due: number;
  /** Шагов реально отправлено. */
  sent: number;
  /** Журнеев дошло до конца цепочки. */
  completed: number;
  /** Журнеев закрыто закрытым окном. */
  expired: number;
  /** Журнеев отложено (свой лимит или отказ Meta по лимиту). */
  rateLimited: number;
  /** Журнеев пропущено: их держит другой проход. */
  claimed: number;
  /**
   * Журнеев пропущено по расхождению: пока брали клейм, их успел сдвинуть
   * другой проход, и снимок в руках устарел.
   */
  stale: number;
  /** Журнеев ушло в FAILED, исчерпав попытки. */
  failed: number;
  errors: string[];
}

interface DueJourney {
  id: string;
  workspaceId: string;
  automationId: string;
  instagramAccountId: string;
  subscriberId: string;
  lastUserMessageAt: Date | null;
  nextStepPosition: number;
  nextStepDueAt: Date | null;
  attempts: number;
  automation: { name: string | null } | null;
  instagramAccount: {
    id: string;
    instagramId: string;
    accessToken: string;
    connectedAt: Date | null;
  } | null;
}

interface ChainStep {
  position: number;
  delaySeconds: number;
  message: string;
}

/** Поля, по которым журней сверяется с собой же после взятия клейма. */
interface JourneyStamp {
  state: string;
  nextStepPosition: number;
  nextStepDueAt: Date | null;
}

/**
 * Сколько причин показать прямо в строке прохода и до какой длины их резать.
 * Две штуки отвечают на «а что сломалось» и не превращают строку журнала в
 * простыню: если причин больше, они всё равно однотипные.
 */
const REASONS_IN_SUMMARY = 2;
const REASON_MAX_CHARS = 120;

function errMessage(error: unknown): string {
  if (error instanceof MetaApiError) return `Meta ${error.code}: ${error.message}`;
  if (error instanceof Error) return error.message;
  return "Unknown error";
}

function claimKey(journeyId: string): string {
  return `${CHAIN_CLAIM_PREFIX}${journeyId}`;
}

/**
 * Занимает журней на время обработки. Гонка, которую это закрывает, узкая, но
 * настоящая: два процесса (или проход, начавшийся поверх подвисшего) читают
 * одну и ту же строку до того, как первый успел сдвинуть позицию, и оба
 * отправляют один шаг.
 */
export async function acquireChainClaim(journeyId: string): Promise<boolean> {
  const result = await getRedisConnection().set(
    claimKey(journeyId),
    "1",
    "EX",
    CHAIN_CLAIM_TTL_SECONDS,
    "NX"
  );
  return result === "OK";
}

export async function releaseChainClaim(journeyId: string): Promise<void> {
  await getRedisConnection().del(claimKey(journeyId));
}

/**
 * Первый проход после старта воркера пишет строку в журнал, даже если делать
 * было нечего, - тот же приём, что в conversation-poller.ts: владельцу нужно
 * уметь убедиться, что контур поднялся, не читая при этом 2880 строк «ноль» в
 * сутки.
 */
let passesRun = 0;

/** Только для тестов: забыть, что первый проход уже был. */
export function resetChainDispatchLogState(): void {
  passesRun = 0;
}

/** Отложить журней, не трогая позицию: срок никогда не уезжает в прошлое. */
function backoffFrom(previousDueAt: Date | null, now: Date, ms: number): Date {
  const base = Math.max(previousDueAt?.getTime() ?? 0, now.getTime());
  return new Date(base + ms);
}

/**
 * Тот ли это журней, каким мы прочитали его в пачку.
 *
 * Клейм закрывает гонку только вместе с этой сверкой. Пачка читается ДО
 * клейма, то есть в руках у прохода снимок: пока он стоял в очереди за
 * клеймом, второй воркер мог уже отправить этот шаг и сдвинуть позицию.
 * Отправка «по снимку» после этого - второе одинаковое сообщение человеку,
 * ровно то, ради чего позиция и сдвигается до сетевого вызова.
 */
function isSameJourneyStamp(
  snapshot: DueJourney,
  fresh: JourneyStamp | null
): boolean {
  if (!fresh) return false;
  if (fresh.state !== "ACTIVE") return false;
  if (fresh.nextStepPosition !== snapshot.nextStepPosition) return false;
  return (
    (fresh.nextStepDueAt?.getTime() ?? null) ===
    (snapshot.nextStepDueAt?.getTime() ?? null)
  );
}

/**
 * Причины отказов прямо в строке прохода.
 *
 * Без них строка врала наполовину: нетерминальный срыв (сеть, пятисотка Meta)
 * не увеличивает `failed`, поэтому владелец видел «сорвалось 0» рядом с
 * ненулевым errors в payload и шёл искать поломку, которой в строке нет.
 */
function reasonsSummary(errors: string[]): string {
  if (errors.length === 0) return "";
  const shown = errors
    .slice(0, REASONS_IN_SUMMARY)
    .map((reason) =>
      reason.length > REASON_MAX_CHARS
        ? `${reason.slice(0, REASON_MAX_CHARS)}...`
        : reason
    );
  const rest = errors.length - shown.length;
  return `; причины: ${shown.join(" | ")}${rest > 0 ? ` и ещё ${rest}` : ""}`;
}

/**
 * Воркспейс для строки прохода. Установка однопользовательская, воркспейс в
 * базе один - но строка, записанная без него, не попадает в отфильтрованную по
 * воркспейсу ленту «Журнал», то есть владелец её просто не увидит. Берём из
 * журнеев пачки, а когда пачка пустая - единственный воркспейс из базы (общий
 * soleWorkspaceId, один на все три контура цепочки), один раз за проход.
 */
async function passWorkspaceId(journeys: DueJourney[]): Promise<string | null> {
  const fromJourney = journeys.find((journey) => journey.workspaceId);
  if (fromJourney) return fromJourney.workspaceId;
  return soleWorkspaceId();
}

/**
 * Один проход диспетчера: закрыть просроченные GATE, забрать пачку журнеев,
 * которым пора, и отправить каждому его шаг.
 */
export async function dispatchChainSteps(
  now: Date = new Date()
): Promise<ChainDispatchResult> {
  const result: ChainDispatchResult = {
    gatesExpired: 0,
    due: 0,
    sent: 0,
    completed: 0,
    expired: 0,
    rateLimited: 0,
    claimed: 0,
    stale: 0,
    failed: 0,
    errors: [],
  };

  passesRun += 1;
  const isFirstPass = passesRun === 1;

  // Здесь, а не отдельным таймером: журнеи, на GATE которых никто не ответил,
  // копятся именно в кандидатах опроса, и закрывать их логично тем же
  // контуром, который цепочку и двигает (Б7).
  try {
    result.gatesExpired = await expireStaleGates(now);
  } catch (error) {
    result.errors.push(`Закрытие просроченных GATE: ${errMessage(error)}`);
  }

  const dueJourneys = (await prisma.subscriberJourney.findMany({
    where: { state: "ACTIVE", nextStepDueAt: { lte: now } },
    orderBy: { nextStepDueAt: "asc" },
    take: CHAIN_DISPATCH_BATCH,
    select: {
      id: true,
      workspaceId: true,
      automationId: true,
      instagramAccountId: true,
      subscriberId: true,
      lastUserMessageAt: true,
      nextStepPosition: true,
      nextStepDueAt: true,
      attempts: true,
      automation: { select: { name: true } },
      instagramAccount: {
        select: {
          id: true,
          instagramId: true,
          accessToken: true,
          connectedAt: true,
        },
      },
    },
  })) as DueJourney[];

  result.due = dueJourneys.length;

  // Шаги одной кампании и расшифрованный токен одного аккаунта нужны всей
  // пачке — читаем и расшифровываем по одному разу на проход.
  const stepsByAutomation = new Map<string, ChainStep[]>();
  const tokenByAccount = new Map<string, string | null>();

  for (const journey of dueJourneys) {
    let claimed = false;
    try {
      claimed = await acquireChainClaim(journey.id);
    } catch (error) {
      result.errors.push(`Клейм ${journey.id}: ${errMessage(error)}`);
      continue;
    }
    if (!claimed) {
      result.claimed += 1;
      continue;
    }

    try {
      // Перечитка под клеймом: только теперь мы одни, и только теперь видно,
      // не сдвинул ли журней кто-то другой между чтением пачки и клеймом.
      const fresh = (await prisma.subscriberJourney.findUnique({
        where: { id: journey.id },
        select: {
          state: true,
          nextStepPosition: true,
          nextStepDueAt: true,
        },
      })) as JourneyStamp | null;

      if (!isSameJourneyStamp(journey, fresh)) {
        // Журней уехал: другой проход отправил его шаг, человек ответил
        // стоп-словом, окно закрылось. Снимок в руках больше ничего не
        // описывает - отпускаем и идём дальше.
        result.stale += 1;
      } else {
        await dispatchOne(
          journey,
          now,
          result,
          stepsByAutomation,
          tokenByAccount
        );
      }
    } catch (error) {
      result.errors.push(`Журней ${journey.id}: ${errMessage(error)}`);
    } finally {
      // Снимаем сразу: TTL тут только страховка от смерти процесса. Держать
      // клейм до истечения значило бы, что человек получает не больше одного
      // шага в 10 минут, а M1 идёт ровно через 10.
      await releaseChainClaim(journey.id).catch(() => {});
    }
  }

  const hasActivity =
    result.sent > 0 ||
    result.completed > 0 ||
    result.expired > 0 ||
    result.failed > 0 ||
    result.rateLimited > 0 ||
    result.gatesExpired > 0 ||
    result.stale > 0 ||
    result.errors.length > 0;

  if (hasActivity || isFirstPass) {
    const staleNote =
      result.stale > 0 ? `, устарело ${result.stale} (успел другой проход)` : "";
    await recordJourneyEvent({
      workspaceId: await passWorkspaceId(dueJourneys),
      level:
        result.failed > 0 || result.errors.length > 0 ? "WARNING" : "INFO",
      message: `Цепочка: проход диспетчера - пора ${result.due}, отправлено ${result.sent}, дошло до конца ${result.completed}, закрыто окном ${result.expired}, отложено ${result.rateLimited}, сорвалось ${result.failed}${staleNote}${reasonsSummary(result.errors)}`,
      payload: { ...result, errors: result.errors.length },
    });
  }

  return result;
}

async function dispatchOne(
  journey: DueJourney,
  now: Date,
  result: ChainDispatchResult,
  stepsByAutomation: Map<string, ChainStep[]>,
  tokenByAccount: Map<string, string | null>
): Promise<void> {
  const campaign = journey.automation?.name ?? "неизвестна";

  // Гейт окна - первым делом. Всё, что ниже (лимитер, чтение шагов, отправка),
  // на закрытом окне гарантированно упрётся в отказ Meta, только дороже.
  if (!isWindowOpen(journey.lastUserMessageAt, now)) {
    await prisma.subscriberJourney.update({
      where: { id: journey.id },
      data: {
        state: "EXPIRED",
        nextStepDueAt: null,
        failReason: WINDOW_CLOSED_REASON,
        completedAt: now,
      },
    });
    result.expired += 1;
    await recordJourneyEvent({
      workspaceId: journey.workspaceId,
      level: "WARNING",
      message: `Цепочка «${campaign}» остановлена на шаге ${journey.nextStepPosition}: ${WINDOW_CLOSED_REASON}`,
      payload: {
        journeyId: journey.id,
        automationId: journey.automationId,
        position: journey.nextStepPosition,
      },
    });
    return;
  }

  // Шаг читается ДО резерва слота (и до расшифровки токена): журней, у
  // которого шагов больше нет, обязан закрыться, не потратив ни места в
  // часовой корзине аккаунта, ни живого токена. Иначе завершённые цепочки
  // выжигали бы лимит, на котором держатся живые.
  let steps = stepsByAutomation.get(journey.automationId);
  if (!steps) {
    steps = (await prisma.sequenceStep.findMany({
      where: { automationId: journey.automationId },
      orderBy: { position: "asc" },
      select: { position: true, delaySeconds: true, message: true },
    })) as ChainStep[];
    stepsByAutomation.set(journey.automationId, steps);
  }

  const step = steps.find((s) => s.position === journey.nextStepPosition);
  if (!step) {
    // Шагов больше нет - цепочка пройдена. Сюда же попадает журней кампании,
    // у которой цепочку укоротили на ходу: дальше слать нечего, и держать его
    // живым значит только мешать человеку войти в следующую кампанию. И сюда
    // же доезжает журней, чей последний шаг ушёл, но отметку DONE унёс сбой:
    // позиция у него уже за концом, срок прошедший - следующий тик закрывает.
    await prisma.subscriberJourney.update({
      where: { id: journey.id },
      data: { state: "DONE", nextStepDueAt: null, completedAt: now },
    });
    result.completed += 1;
    await recordJourneyEvent({
      workspaceId: journey.workspaceId,
      level: "INFO",
      message: `Цепочка «${campaign}» пройдена до конца`,
      payload: {
        journeyId: journey.id,
        automationId: journey.automationId,
        steps: steps.length,
      },
    });
    return;
  }

  const account = journey.instagramAccount;
  if (!account) {
    result.errors.push(`Журней ${journey.id}: аккаунт Instagram не найден`);
    return;
  }

  let accessToken = tokenByAccount.get(account.id);
  if (accessToken === undefined) {
    try {
      accessToken = decryptToken(account.accessToken);
    } catch {
      accessToken = null;
    }
    tokenByAccount.set(account.id, accessToken);
    if (!accessToken) {
      await recordJourneyEvent({
        workspaceId: journey.workspaceId,
        level: "WARNING",
        message:
          "Цепочка: не удалось расшифровать токен аккаунта - шаги по нему стоят (см. npm run doctor, раздел ключа шифрования)",
        payload: { instagramAccountId: account.id },
      });
    }
  }
  if (!accessToken) {
    result.errors.push(`Журней ${journey.id}: токен аккаунта не расшифровался`);
    return;
  }

  // Своя корзина лимитера: цепочки не должны выжигать 750 приватных ответов
  // в час, на которых держится сам GATE (В-B). Резерв берётся ДО сдвига
  // позиции - отказ лимитера не должен выглядеть как потраченный шаг.
  const slot = await reserveChainSlot(account.instagramId, 0, account.connectedAt);
  if (!slot.allowed) {
    await prisma.subscriberJourney.update({
      where: { id: journey.id },
      data: {
        nextStepDueAt: backoffFrom(
          journey.nextStepDueAt,
          now,
          CHAIN_RATE_LIMIT_BACKOFF_MS
        ),
      },
    });
    result.rateLimited += 1;
    await recordJourneyEvent({
      workspaceId: journey.workspaceId,
      level: "WARNING",
      message: `Цепочка «${campaign}»: часовой лимит отправок аккаунта исчерпан, шаг ${journey.nextStepPosition} отложен на 30 минут`,
      payload: {
        journeyId: journey.id,
        position: journey.nextStepPosition,
        currentCount: slot.currentCount,
      },
    });
    return;
  }

  const nextStep = steps.find((s) => s.position === journey.nextStepPosition + 1);
  const previousDueAt = journey.nextStepDueAt;
  const previousPosition = journey.nextStepPosition;
  const previousAttempts = journey.attempts;

  // Срок следующего шага считается от ПРЕЖНЕГО срока, а не от «сейчас»:
  // расписание якорится на момент ответа человека и не ползёт от того, что
  // проход подобрал журней на полминуты позже (В-C).
  //
  // На ПОСЛЕДНЕМ шаге срок не обнуляется, а остаётся прежним. Пустой срок тут
  // ставится только вместе с DONE, уже после успешной отправки: иначе сбой
  // ровно между этой записью и отметкой DONE оставлял бы ACTIVE с пустым
  // сроком - журней, которого не подберёт ни один следующий проход (диспетчер
  // ищет по nextStepDueAt <= now, и NULL под это условие не попадает никогда).
  // С прежним сроком тот же сбой оставляет ACTIVE с прошедшим сроком, и
  // следующий тик спокойно доводит журней до DONE.
  const nextDueAt = nextStep
    ? new Date(
        (previousDueAt?.getTime() ?? now.getTime()) + nextStep.delaySeconds * 1000
      )
    : previousDueAt;

  await prisma.subscriberJourney.update({
    where: { id: journey.id },
    data: {
      nextStepPosition: previousPosition + 1,
      nextStepDueAt: nextDueAt,
      // Счётчик попыток относится к конкретному шагу: перешли к следующему -
      // начинаем с нуля.
      attempts: 0,
    },
  });

  try {
    await sendDirectMessage(
      accessToken,
      account.instagramId,
      journey.subscriberId,
      step.message
    );
  } catch (error) {
    await handleSendFailure(error, {
      journey,
      campaign,
      now,
      result,
      previousPosition,
      previousDueAt,
      previousAttempts,
    });
    return;
  }

  result.sent += 1;

  if (!nextStep) {
    await prisma.subscriberJourney.update({
      where: { id: journey.id },
      data: { state: "DONE", nextStepDueAt: null, completedAt: now },
    });
    result.completed += 1;
  }

  await recordJourneyEvent({
    workspaceId: journey.workspaceId,
    level: "INFO",
    message: nextStep
      ? `Цепочка «${campaign}»: шаг ${previousPosition} отправлен, следующий в ${nextDueAt?.toISOString() ?? "-"}`
      : `Цепочка «${campaign}»: шаг ${previousPosition} отправлен, это был последний`,
    payload: {
      journeyId: journey.id,
      automationId: journey.automationId,
      position: previousPosition,
      last: !nextStep,
    },
  });
}

interface SendFailureContext {
  journey: DueJourney;
  campaign: string;
  now: Date;
  result: ChainDispatchResult;
  previousPosition: number;
  previousDueAt: Date | null;
  previousAttempts: number;
}

/**
 * Разбор отказа отправки. Общее у всех трёх веток - откат позиции: шаг не
 * ушёл, значит человек на нём и стоит. Разница в том, стоит ли пробовать ещё.
 */
async function handleSendFailure(
  error: unknown,
  ctx: SendFailureContext
): Promise<void> {
  const {
    journey,
    campaign,
    now,
    result,
    previousPosition,
    previousDueAt,
    previousAttempts,
  } = ctx;
  const detail = errMessage(error);

  // Окно закрылось между проверкой и отправкой. Терминально по своей природе:
  // открыть его может только сам человек, следующим сообщением, - ретраи
  // здесь не «ещё попытка», а гарантированно потраченные вызовы (Б2).
  if (isOutsideWindowError(error)) {
    await prisma.subscriberJourney.update({
      where: { id: journey.id },
      data: {
        state: "EXPIRED",
        nextStepPosition: previousPosition,
        nextStepDueAt: null,
        attempts: previousAttempts,
        failReason: WINDOW_CLOSED_REASON,
        completedAt: now,
      },
    });
    result.expired += 1;
    await recordJourneyEvent({
      workspaceId: journey.workspaceId,
      level: "WARNING",
      message: `Цепочка «${campaign}» остановлена на шаге ${previousPosition}: Meta закрыла окно переписки (${detail})`,
      payload: {
        journeyId: journey.id,
        automationId: journey.automationId,
        position: previousPosition,
      },
    });
    return;
  }

  // Лимит Meta - не вина человека и не вина шага: попытки не жжём, просто
  // отодвигаем.
  if (error instanceof RateLimitError) {
    await prisma.subscriberJourney.update({
      where: { id: journey.id },
      data: {
        nextStepPosition: previousPosition,
        nextStepDueAt: backoffFrom(previousDueAt, now, CHAIN_RATE_LIMIT_BACKOFF_MS),
        attempts: previousAttempts,
      },
    });
    result.rateLimited += 1;
    await recordJourneyEvent({
      workspaceId: journey.workspaceId,
      level: "WARNING",
      message: `Цепочка «${campaign}»: Meta ответила лимитом, шаг ${previousPosition} отложен на 30 минут (${detail})`,
      payload: {
        journeyId: journey.id,
        automationId: journey.automationId,
        position: previousPosition,
      },
    });
    return;
  }

  const attempts = previousAttempts + 1;
  const exhausted = attempts >= MAX_STEP_ATTEMPTS;

  await prisma.subscriberJourney.update({
    where: { id: journey.id },
    data: {
      nextStepPosition: previousPosition,
      nextStepDueAt: exhausted
        ? null
        : backoffFrom(previousDueAt, now, CHAIN_STEP_RETRY_BACKOFF_MS),
      attempts,
      ...(exhausted
        ? {
            state: "FAILED" as const,
            failReason: `Шаг ${previousPosition} не ушёл за ${MAX_STEP_ATTEMPTS} попытки: ${detail}`,
            completedAt: now,
          }
        : {}),
    },
  });

  if (exhausted) {
    result.failed += 1;
    await recordJourneyEvent({
      workspaceId: journey.workspaceId,
      level: "WARNING",
      message: `Цепочка «${campaign}» сорвалась на шаге ${previousPosition}: ${MAX_STEP_ATTEMPTS} попытки подряд не прошли (${detail})`,
      payload: {
        journeyId: journey.id,
        automationId: journey.automationId,
        position: previousPosition,
        attempts,
      },
    });
    return;
  }

  result.errors.push(`Журней ${journey.id}: ${detail}`);
}
