import { prisma } from "@/lib/db/client";
import { getChainJourneyRetentionDays } from "@/lib/gdpr/retention-config";
import type {
  JourneyState,
  SubscriberJourney,
} from "@/app/generated/prisma/client";

/**
 * Состояния, в которых цепочка ЖИВА: по человеку ещё будут уходить сообщения.
 * Всё остальное (DONE/EXPIRED/STOPPED/SKIPPED/FAILED) — терминально и по нему
 * никто больше ничего не отправит.
 */
export const LIVE_JOURNEY_STATES: JourneyState[] = ["GATE_SENT", "ACTIVE"];

export function isLiveJourneyState(state: JourneyState): boolean {
  return LIVE_JOURNEY_STATES.includes(state);
}

/**
 * Окно Meta на переписку — 24 часа от последнего сообщения человека. Мы
 * считаем его 23.5, оставляя 30 минут запаса, и запас этот не про
 * перестраховку: якорь `lastUserMessageAt` — это момент, когда мы УВИДЕЛИ
 * сообщение опросом диалогов (до 90 секунд позже правды), сама отправка
 * занимает ещё время, а шаг, ушедший на 23:59:50, — монетка, которую мы
 * проигрываем молча: Meta отвечает «outside of allowed window», журней ложится
 * EXPIRED, и человек не получает ничего вместо последнего касания.
 */
export const MESSAGING_WINDOW_MS = 23.5 * 60 * 60 * 1000;

/**
 * TTL неотвеченного GATE (Б7). Через 48 часов молчания человек уже не ответит,
 * а строка GATE_SENT остаётся кандидатом опроса диалогов навсегда: поллер
 * каждые 90 секунд сверяет живые журнеи с тредами аккаунта, и без этого срока
 * список живых копится месяцами. 48 часов, а не 24, — чтобы человек, который
 * ответил под конец вторых суток, всё-таки попал в цепочку.
 */
export const GATE_TTL_MS = 48 * 60 * 60 * 1000;

const GATE_TTL_REASON =
  "GATE остался без ответа дольше 48 часов - окно переписки так и не открылось";

type JourneyEventPayload = Record<string, string | number | boolean | null>;

/**
 * Один формат записи в журнал операционных событий для всей цепочки — по
 * образцу recordSweep в lib/polling/comment-reconciler.ts. Как и там, запись
 * журнала никогда не роняет вызывающего: журней важнее следа о журнее.
 */
export async function recordJourneyEvent(input: {
  workspaceId?: string | null;
  level: "INFO" | "WARNING";
  message: string;
  payload?: JourneyEventPayload;
}): Promise<void> {
  await prisma.operationalEvent
    .create({
      data: {
        workspaceId: input.workspaceId ?? null,
        source: "WORKER",
        level: input.level,
        message: input.message,
        payload: input.payload ?? undefined,
      },
    })
    .catch(() => {});
}

/** Журней, найденный гейтом: чего хватает, чтобы объяснить отказ. */
export interface JourneyRef {
  id: string;
  automationId: string;
  state: JourneyState;
  /** Имя кампании, чья цепочка заняла человека, — его видит владелец в логе. */
  automationName: string | null;
}

/**
 * Тот же вид, когда гейт искал только по живым состояниям. Отдельное имя
 * оставлено сознательно: по нему в коде видно, что строка гарантированно
 * живая, — в отличие от findAnyJourneyForCampaign, где она может быть
 * терминальной.
 */
export type LiveJourneyRef = JourneyRef;

const LIVE_JOURNEY_SELECT = {
  id: true,
  automationId: true,
  state: true,
  automation: { select: { name: true } },
} as const;

type LiveJourneyRow = {
  id: string;
  automationId: string;
  state: JourneyState;
  automation?: { name: string } | null;
};

function toLiveJourneyRef(row: LiveJourneyRow | null): JourneyRef | null {
  if (!row) return null;
  return {
    id: row.id,
    automationId: row.automationId,
    state: row.state,
    automationName: row.automation?.name ?? null,
  };
}

/**
 * Идёт ли по этому человеку живая цепочка на этом аккаунте — по ЛЮБОЙ
 * кампании (Б4). Один человек = одна живая цепочка на аккаунт: две кампании,
 * стартовавшие в одно 24-часовое окно, налили бы ему восемь сообщений вместо
 * четырёх, и он ушёл бы жать «пожаловаться», а не по ссылке.
 */
export async function findLiveJourney(
  instagramAccountId: string,
  subscriberId: string
): Promise<LiveJourneyRef | null> {
  const row = (await prisma.subscriberJourney.findFirst({
    where: {
      instagramAccountId,
      subscriberId,
      state: { in: LIVE_JOURNEY_STATES },
    },
    select: LIVE_JOURNEY_SELECT,
  })) as LiveJourneyRow | null;

  return toLiveJourneyRef(row);
}

export async function hasLiveJourney(
  instagramAccountId: string,
  subscriberId: string
): Promise<boolean> {
  return (await findLiveJourney(instagramAccountId, subscriberId)) !== null;
}

/**
 * Тот же гейт, но заданный на шаг раньше — по ID комментатора.
 *
 * Так приходится потому, что два ID у человека разные и узнаются в разные
 * моменты: ID в пространстве сообщений (`subscriberId`) Meta возвращает
 * только В ОТВЕТ на отправленный GATE, а решать «слать ли GATE» надо ДО
 * отправки. Поэтому журней хранит оба, а предотправочный гейт спрашивает по
 * тому, который уже есть в джобе.
 */
export async function findLiveJourneyByCommenter(
  instagramAccountId: string,
  commenterId: string
): Promise<LiveJourneyRef | null> {
  const row = (await prisma.subscriberJourney.findFirst({
    where: {
      instagramAccountId,
      commenterId,
      state: { in: LIVE_JOURNEY_STATES },
    },
    select: LIVE_JOURNEY_SELECT,
  })) as LiveJourneyRow | null;

  return toLiveJourneyRef(row);
}

export async function hasLiveJourneyByCommenter(
  instagramAccountId: string,
  commenterId: string
): Promise<boolean> {
  return (
    (await findLiveJourneyByCommenter(instagramAccountId, commenterId)) !== null
  );
}

/**
 * Журней ЭТОЙ кампании по этому человеку почти в любом состоянии —
 * терминальные (DONE/EXPIRED/STOPPED/FAILED) тоже. Это и есть «Prohibit
 * restart», заданный на предотправочном гейте.
 *
 * Единственное исключение — SKIPPED, и оно не про аккуратность, а про
 * человека: строка SKIPPED значит, что GATE ему НЕ уходил (гейт отказал,
 * потому что в тот момент по нему шла цепочка соседней кампании). Он попросил
 * материал и не получил ничего; запереть его после этого на срок хранения
 * журнея — наказать за чужую цепочку. Во всех остальных состояниях GATE был
 * отправлен, и повторный вход закрыт по канону.
 *
 * Гейт по живым состояниям тут не годится, и это не педантизм, а дыра, через
 * которую человек проваливается молча: у того, чья цепочка ЗАВЕРШИЛАСЬ, живого
 * журнея нет, и на тот же комментарий с тем же словом ему второй раз уходит
 * GATE «ответь словом X». Он отвечает — а опрос диалогов сверяет треды только
 * с живыми журнеями, терминальную строку он не смотрит, и ответ уходит в
 * пустоту: ни выдачи, ни касаний, ни следа. Пока строка живёт (ретеншн
 * журнеев, см. getChainJourneyRetentionDays), повторный вход закрыт; удалили
 * строку по сроку — вход открыт снова.
 *
 * Ищем по ОБОИМ ID человека: до отправки GATE на руках только ID из
 * пространства комментариев, а в старой строке мог лежать либо он же
 * (commenterId), либо recipient_id из ответа Meta (subscriberId) — какой
 * именно, отсюда не видно. Журнеи, записанные до появления колонки
 * commenterId, находятся как раз второй половиной условия.
 */
export async function findAnyJourneyForCampaign(
  automationId: string,
  personId: string
): Promise<JourneyRef | null> {
  const row = (await prisma.subscriberJourney.findFirst({
    where: {
      automationId,
      // SKIPPED — единственное состояние, при котором GATE не уходил, значит
      // и запирать человека не за что (см. пояснение выше).
      state: { not: "SKIPPED" },
      OR: [{ commenterId: personId }, { subscriberId: personId }],
    },
    select: LIVE_JOURNEY_SELECT,
    // Строк может быть больше одной (человек мог войти по обоим ID в разное
    // время): для отказа важна самая свежая — её состояние владелец и увидит.
    orderBy: { createdAt: "desc" },
  })) as LiveJourneyRow | null;

  return toLiveJourneyRef(row);
}

/**
 * Текст отказа повторного входа — один на строку DmLog и на запись в журнал,
 * чтобы владелец читал в двух местах одно и то же. Срок берём из настройки
 * хранения журнеев: именно она и ЕСТЬ срок запрета, отдельной константы под
 * него нет и быть не должно.
 */
export function restartBlockedReason(state: JourneyState): string {
  return `Цепочка этой кампании уже была у этого человека (состояние ${state}) - повторный вход закрыт до истечения ${getChainJourneyRetentionDays()} дней хранения журнея`;
}

export interface CreateGateJourneyInput {
  workspaceId: string;
  automationId: string;
  instagramAccountId: string;
  /**
   * ID человека в пространстве сообщений — `recipient_id` из ответа Meta на
   * GATE. Только по нему цепочке можно писать дальше.
   */
  subscriberId: string;
  /** Он же в пространстве комментариев — на нём стоит предотправочный гейт. */
  commenterId?: string | null;
  subscriberName?: string | null;
  commentId: string;
  now?: Date;
}

export interface CreateGateJourneyResult {
  journey: SubscriberJourney;
  /** false = журней уже был; его НЕ пересоздали и НЕ сбросили. */
  created: boolean;
}

/**
 * Заводит журней после ушедшего GATE — и никогда не падает на дубле (Б5).
 *
 * Дубль тут норма, а не авария: человек написал под постом второй комментарий
 * с тем же словом, или проход опроса пришёл повторно. Уникальный ключ
 * (automationId, subscriberId) — это и есть «Prohibit restart»: пока строка
 * живёт, повторный вход в ту же цепочку закрыт. Поэтому существующий журней
 * возвращается как есть — не пересоздаётся и не сбрасывается на начало, иначе
 * второй комментарий откатывал бы человека к первому шагу с уже полученными
 * сообщениями.
 */
export async function createGateJourney(
  input: CreateGateJourneyInput
): Promise<CreateGateJourneyResult> {
  const now = input.now ?? new Date();
  const where = {
    automationId_subscriberId: {
      automationId: input.automationId,
      subscriberId: input.subscriberId,
    },
  };

  const existing = await prisma.subscriberJourney.findUnique({ where });
  if (existing) {
    await recordJourneyEvent({
      workspaceId: input.workspaceId,
      level: "INFO",
      message: `Цепочка: повторный вход, журней уже есть (состояние ${existing.state}) - оставляем как есть`,
      payload: {
        automationId: input.automationId,
        subscriberId: input.subscriberId,
        commentId: input.commentId,
        state: existing.state,
      },
    });
    return { journey: existing, created: false };
  }

  // upsert, а не create: между чтением выше и записью сюда параллельная джоба
  // (тот же человек, второй комментарий) могла успеть вставить строку. upsert
  // по тому же уникальному ключу разруливает гонку внутри базы и не бросает
  // P2002 — джоба GATE не должна падать из-за повторного комментария.
  const journey = await prisma.subscriberJourney.upsert({
    where,
    create: {
      workspaceId: input.workspaceId,
      automationId: input.automationId,
      instagramAccountId: input.instagramAccountId,
      subscriberId: input.subscriberId,
      commenterId: input.commenterId ?? null,
      subscriberName: input.subscriberName ?? null,
      commentId: input.commentId,
      state: "GATE_SENT",
      gateSentAt: now,
      nextStepPosition: 0,
    },
    // Гонку проиграли — чужую строку не трогаем ни одним полем.
    update: {},
  });

  // Строка наша, если в ней стоит ровно наша метка времени: у чужой (той, что
  // уже лежала) gateSentAt старше.
  const created =
    journey.gateSentAt instanceof Date &&
    journey.gateSentAt.getTime() === now.getTime();

  await recordJourneyEvent({
    workspaceId: input.workspaceId,
    level: "INFO",
    message: created
      ? "Цепочка: GATE отправлен, журней заведён"
      : "Цепочка: повторный вход, журней уже есть - оставляем как есть",
    payload: {
      automationId: input.automationId,
      subscriberId: input.subscriberId,
      commentId: input.commentId,
      created,
    },
  });

  return { journey, created };
}

export interface MarkJourneySkippedInput extends CreateGateJourneyInput {
  /** Почему цепочка не стартовала — этот текст владелец читает в логе. */
  failReason: string;
}

/**
 * Пишет видимый след «цепочка не стартовала и вот почему».
 *
 * Без этой строки отказ гейта выглядел бы как пропажа: DM не ушёл, журнея
 * нет, в интерфейсе пусто. SKIPPED — это ответ на вопрос владельца «а почему
 * этому человеку ничего не пришло».
 */
export async function markJourneySkipped(
  input: MarkJourneySkippedInput
): Promise<SubscriberJourney> {
  const now = input.now ?? new Date();
  const where = {
    automationId_subscriberId: {
      automationId: input.automationId,
      subscriberId: input.subscriberId,
    },
  };

  const existing = await prisma.subscriberJourney.findUnique({ where });
  if (existing && isLiveJourneyState(existing.state)) {
    // Под этим же ключом лежит ЖИВАЯ цепочка — скорее всего она и есть
    // причина отказа. Затирать её на SKIPPED значит убить живую цепочку ради
    // следа о том, что она живая.
    await recordJourneyEvent({
      workspaceId: input.workspaceId,
      level: "WARNING",
      message: `Цепочка не стартовала: ${input.failReason} (живой журней под тем же ключом не трогаем)`,
      payload: {
        automationId: input.automationId,
        subscriberId: input.subscriberId,
        commentId: input.commentId,
        state: existing.state,
      },
    });
    return existing;
  }

  const journey = await prisma.subscriberJourney.upsert({
    where,
    create: {
      workspaceId: input.workspaceId,
      automationId: input.automationId,
      instagramAccountId: input.instagramAccountId,
      subscriberId: input.subscriberId,
      commenterId: input.commenterId ?? null,
      subscriberName: input.subscriberName ?? null,
      commentId: input.commentId,
      state: "SKIPPED",
      // GATE не уходил, но gateSentAt в схеме обязателен: для SKIPPED это
      // метка момента, когда цепочка отказалась стартовать.
      gateSentAt: now,
      failReason: input.failReason,
      completedAt: now,
    },
    update: {
      state: "SKIPPED",
      failReason: input.failReason,
      completedAt: now,
    },
  });

  await recordJourneyEvent({
    workspaceId: input.workspaceId,
    level: "WARNING",
    message: `Цепочка не стартовала: ${input.failReason}`,
    payload: {
      automationId: input.automationId,
      subscriberId: input.subscriberId,
      commentId: input.commentId,
    },
  });

  return journey;
}

/**
 * Единственный воркспейс установки. Один на все три контура цепочки (журней,
 * опрос диалогов, диспетчер шагов) — раньше эта же функция лежала копией в
 * каждом файле. Установка однопользовательская, строка Workspace в базе ровно
 * одна (см. CLAUDE.md), поэтому запрос без условий тут не догадка, а прямое
 * чтение факта.
 *
 * Зачем вообще проставлять воркспейс в строке журнала. Операционные события
 * владелец читает на странице «Диагностика» (`/diagnostics`), а не в «Журнале
 * отправок» (`/logs` — там DmLog, кому и когда ушло сообщение). Лента
 * диагностики берёт и строки без воркспейса (`OR: [{ workspaceId },
 * { workspaceId: null }]`), так что проставленный воркспейс — это не про
 * «увидит или нет», а про то, чтобы строка принадлежала установке, а не
 * висела ничьей.
 */
export async function soleWorkspaceId(): Promise<string | null> {
  try {
    const row = await prisma.workspace.findFirst({ select: { id: true } });
    return row?.id ?? null;
  } catch {
    return null;
  }
}

/**
 * Закрывает GATE, на которые никто не ответил за 48 часов (Б7). Возвращает,
 * сколько журнеев закрыл, — счётчик нужен вызывающему (диспетчеру) для лога,
 * потому что тихий проход тут ничего не пишет.
 */
export async function expireStaleGates(now: Date = new Date()): Promise<number> {
  const cutoff = new Date(now.getTime() - GATE_TTL_MS);

  const result = await prisma.subscriberJourney.updateMany({
    where: {
      state: "GATE_SENT",
      gateSentAt: { lt: cutoff },
    },
    data: {
      state: "EXPIRED",
      failReason: GATE_TTL_REASON,
      completedAt: now,
    },
  });

  const count = result?.count ?? 0;
  if (count > 0) {
    // Пишем только когда что-то закрыли — по образцу recordSweep: тихий
    // проход не должен засорять журнал строкой «ноль».
    //
    // Воркспейс проставляем, а не оставляем пустым: все остальные строки
    // цепочки (диспетчер, опрос диалогов, гейты воркера) идут с ним, и одна
    // ничья строка посреди них выпадает из любой выборки по установке. Берём
    // единственный воркспейс, а не воркспейс закрытых журнеев: updateMany
    // возвращает только счётчик, и перечитывать ради этого уже закрытые
    // строки дороже, чем прочитать единственную строку Workspace.
    await recordJourneyEvent({
      workspaceId: await soleWorkspaceId(),
      level: "WARNING",
      message: `Цепочка: ${count} GATE закрыт(о) по сроку - ответа не было дольше 48 часов`,
      payload: { expired: count, ttlHours: GATE_TTL_MS / 3600000 },
    });
  }

  return count;
}

/**
 * Открыто ли окно переписки к моменту `now`.
 *
 * Без якоря (`lastUserMessageAt` пуст) окно НЕ открыто: человек нам ещё не
 * писал, значит писать ему первым нельзя — это и есть смысл GATE.
 */
export function isWindowOpen(
  lastUserMessageAt: Date | null | undefined,
  now: Date = new Date()
): boolean {
  if (!lastUserMessageAt) return false;
  return now.getTime() - lastUserMessageAt.getTime() < MESSAGING_WINDOW_MS;
}
