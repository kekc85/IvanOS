/**
 * Comment reconciliation (the only path from a comment to a DM).
 *
 * This sweep is what discovers comments: the tool polls the Graph API instead
 * of receiving pushed events, so no extended Meta permission is required.
 *
 * This sweep is deliberately narrow. For each active campaign it looks only at
 * that campaign's post, only at recent comments, and acts on a comment ONLY when
 * both are true:
 *   1. the comment matches the campaign keyword, and
 *   2. the account owner has not already replied to it.
 * The reply check reads the comment's actual replies on Instagram, so a comment
 * you (or the tool) already answered is skipped — the poll never re-touches
 * handled comments. Each sweep is capped so it can never flood the comment API
 * (which Instagram rate-limits aggressively, error 368).
 *
 * It runs on an interval in the worker process (see worker/dm-worker.ts) —
 * there is no external scheduler on a plain VPS to fire it instead. Matching
 * and sending run through the worker's processComment, so rate limiting and
 * logging happen in one place.
 *
 * Known limitation, handled not fixed: comments removed by Instagram's Hidden
 * Words / spam filter may not be returned by the Graph API at all. Disable that
 * filter on the account to widen results.
 */

import { prisma } from "@/lib/db/client";
import { getDMQueue } from "@/lib/queue/client";
import { acquireCommentClaim } from "@/lib/queue/comment-claim";
import {
  getRecentMediaComments,
  getUserMedia,
  MetaApiError,
  type InstagramComment,
} from "@/lib/meta/client";
import { decryptToken } from "@/lib/meta/oauth";
import { matchKeywords } from "@/lib/utils/keyword-matcher";

// Only consider comments from the last several days — older ones are outside
// Instagram's private-reply window anyway, so a DM to them would just fail.
// Meta's window is 7 days (168h); 144h claims most of it while leaving
// headroom so a comment doesn't cross the boundary while it's sitting in the
// send queue (see META_PRIVATE_REPLY_WINDOW_HOURS below, which is the actual
// enforced cutoff).
const LOOKBACK_HOURS = Number(process.env.COMMENT_POLL_LOOKBACK_HOURS ?? 144);
// Hard cap on how many new comments a single campaign can enqueue per sweep, so
// a viral post drains gradually instead of bursting into the comment API.
const MAX_NEW_PER_SWEEP = Number(process.env.COMMENT_POLL_MAX_PER_SWEEP ?? 30);
// For "any post" campaigns, how many recent posts to scan.
const RECENT_MEDIA_LIMIT = 10;
// The actual Meta-enforced cutoff: a private reply to a comment older than
// this is rejected outright. LOOKBACK_HOURS keeps the sweep from fetching
// comments past this in the first place, but a comment can still age past it
// between being fetched and being sent if the send queue is backed up (a
// viral post can take hours to drain at MAX_NEW_PER_SWEEP per pass). Checked
// again here, right before a comment is queued, so a doomed send is skipped
// with a clear reason instead of attempted and failing against the Graph API.
// Exported so lib/gdpr/retention-config.ts can enforce the same floor on
// DmLog cleanup and on GDPR erasure — DmLog is this sweep's dedup set (a
// SENT or SKIPPED_DEDUP row, or a set publicReplySentAt, means "already
// handled"), and deleting a row still inside this window makes the next sweep
// treat an already-answered comment as new (see that file for the full story).
export const META_PRIVATE_REPLY_WINDOW_HOURS = Number(
  process.env.META_PRIVATE_REPLY_WINDOW_HOURS ?? 168
);

interface SweepStat {
  campaign: string;
  keywords: string;
  matched: number;
  alreadyReplied: number;
  skippedTooOld: number;
  enqueued: number;
  alreadyQueued: number;
  truncated: boolean;
  droppedForCapacity: number;
  errors: string[];
}

function errMessage(error: unknown): string {
  if (error instanceof MetaApiError) return `Meta ${error.code}: ${error.message}`;
  if (error instanceof Error) return error.message;
  return "Unknown error";
}

/** One reconciliation pass across every active campaign. */
export async function reconcileComments(): Promise<void> {
  const automations = await prisma.automation.findMany({
    where: { isActive: true },
    select: {
      id: true,
      name: true,
      postId: true,
      matchAnyPost: true,
      matchAnyWord: true,
      keywords: true,
      wholeWordMatch: true,
      publicReplyEnabled: true,
      workspaceId: true,
      instagramAccount: {
        select: {
          id: true,
          instagramId: true,
          username: true,
          accessToken: true,
        },
      },
    },
  });

  const sinceMs = Date.now() - LOOKBACK_HOURS * 60 * 60 * 1000;
  const tokenCache = new Map<string, string | null>();

  for (const automation of automations) {
    const stat = await sweepCampaign(automation, sinceMs, tokenCache).catch(
      (error): SweepStat => ({
        campaign: automation.name,
        keywords: automation.keywords.join(","),
        matched: 0,
        alreadyReplied: 0,
        skippedTooOld: 0,
        enqueued: 0,
        alreadyQueued: 0,
        truncated: false,
        droppedForCapacity: 0,
        errors: [errMessage(error)],
      })
    );
    await recordSweep(automation.workspaceId, stat);
  }
}

async function sweepCampaign(
  automation: {
    id: string;
    name: string;
    postId: string | null;
    matchAnyPost: boolean;
    matchAnyWord: boolean;
    keywords: string[];
    wholeWordMatch: boolean;
    publicReplyEnabled: boolean;
    instagramAccount: {
      id: string;
      instagramId: string;
      username: string;
      accessToken: string;
    };
  },
  sinceMs: number,
  tokenCache: Map<string, string | null>
): Promise<SweepStat> {
  const account = automation.instagramAccount;
  const stat: SweepStat = {
    campaign: automation.name,
    keywords: automation.matchAnyWord
      ? "(any word)"
      : automation.keywords.join(","),
    matched: 0,
    alreadyReplied: 0,
    skippedTooOld: 0,
    enqueued: 0,
    alreadyQueued: 0,
    truncated: false,
    droppedForCapacity: 0,
    errors: [],
  };

  // Decrypt the account token once per sweep.
  let accessToken = tokenCache.get(account.id);
  if (accessToken === undefined) {
    try {
      accessToken = decryptToken(account.accessToken);
    } catch {
      accessToken = null;
    }
    tokenCache.set(account.id, accessToken);
  }
  if (!accessToken) {
    stat.errors.push("Failed to decrypt access token");
    return stat;
  }

  // Which media this campaign covers: its own post, or the recent feed if it
  // matches any post.
  const mediaIds: string[] = [];
  if (automation.postId) {
    mediaIds.push(automation.postId);
  } else if (automation.matchAnyPost) {
    try {
      const media = await getUserMedia(accessToken, RECENT_MEDIA_LIMIT);
      mediaIds.push(...media.map((m) => m.id));
    } catch (error) {
      stat.errors.push(`Media list: ${errMessage(error)}`);
    }
  }
  if (mediaIds.length === 0) return stat;

  const queue = getDMQueue();

  for (const mediaId of mediaIds) {
    let comments: InstagramComment[];
    try {
      comments = await getRecentMediaComments(accessToken, mediaId, sinceMs);
    } catch (error) {
      stat.errors.push(`Comments ${mediaId}: ${errMessage(error)}`);
      continue;
    }

    // Keep only comments that (a) aren't the account's own, (b) match the
    // keyword, and (c) have no reply from the account owner yet.
    const needsAction = comments.filter((c) => {
      const authorId = c.from?.id;
      if (!authorId || authorId === account.instagramId) return false;

      const matched = automation.matchAnyWord
        ? true
        : matchKeywords(c.text ?? "", automation.keywords, automation.wholeWordMatch)
            .matched;
      if (!matched) return false;
      stat.matched += 1;

      const ownerReplied = (c.replies?.data ?? []).some(
        (r) => r.from?.id === account.instagramId
      );
      if (ownerReplied) {
        stat.alreadyReplied += 1;
        return false;
      }
      return true;
    });
    if (needsAction.length === 0) continue;

    // Second guard against races: skip comments this campaign has already fully
    // handled. "Fully handled" depends on the campaign: if it posts a public
    // reply, the completion signal is publicReplySentAt (a DM alone is not
    // enough — the reply still has to land); otherwise a SENT DM is enough. This
    // is what lets a comment whose DM sent but whose public reply failed come
    // back and retry the reply.
    //
    // SKIPPED_DEDUP and FAILED_PERMANENT count as handled just like SENT, and
    // that is not a nicety — without them this sweep re-enqueues the same
    // comment every five minutes for the whole LOOKBACK_HOURS window (~1700
    // jobs and ~1700 journal lines per person). Both are written when the DM
    // leg is closed for this comment, for good:
    //   - SKIPPED_DEDUP: another campaign has already spent the single
    //     private reply Instagram allows on it (spent forever), or the
    //     chain's restart/one-live-chain gate refused this person;
    //   - FAILED_PERMANENT: Meta refused for a reason no retry can clear —
    //     the person's DMs are closed, the comment is gone, the single
    //     private reply is used up (see lib/queue/send-failure.ts for the
    //     list and why each entry is irreversible).
    // Nothing this sweep can do changes any of that within its own window:
    // the lookback is 144h, while the journey row that holds the chain gates
    // lives 30 days by default, so the comment ages out of the sweep long
    // before any lock could lift. A person who was held back re-enters by
    // commenting again — a new comment with its own row, not this one
    // retried. An ordinary FAILED is deliberately NOT here: that one means
    // "didn't work this time" (network, Meta 5xx, an aborted call), and
    // bringing it back is exactly what should happen.
    // Including the cross-campaign refusal ("one live chain per person"): it is
    // final for THIS comment, and a new comment from that person opens a new
    // way in, because the SKIPPED journey it wrote does not lock the chain's
    // restart gate (see findAnyJourneyForCampaign in lib/chain/journey.ts).
    // Both statuses are only in the DM-completion branch, and that branch is
    // the whole of this guard's reach. Said honestly: the limit works only
    // when the public reply SUCCEEDS. For a campaign with the public reply on,
    // completion is publicReplySentAt and nothing else — so a public reply
    // that keeps failing (comment deleted, comment-reply limiter permanently
    // full) leaves the row unstamped and this comment comes back every sweep
    // for the whole window. What that costs is bounded: processComment never
    // re-sends the DM on a terminal row (SENT / FAILED_PERMANENT), so those
    // passes retry the public reply and nothing else. Still a known gap, not
    // a solved problem — a permanently failing public reply has no terminal
    // state of its own yet.
    const handled = await prisma.dmLog.findMany({
      where: {
        automationId: automation.id,
        commentId: { in: needsAction.map((c) => c.id) },
        ...(automation.publicReplyEnabled
          ? { publicReplySentAt: { not: null } }
          : { status: { in: ["SENT", "SKIPPED_DEDUP", "FAILED_PERMANENT"] } }),
      },
      select: { commentId: true },
    });
    const handledSet = new Set(handled.map((h) => h.commentId));

    // Drop anything already past Meta's private-reply window before it ever
    // reaches the queue — sending would just burn an API call to learn what
    // we already know. Counted and logged explicitly (see recordSweep) so a
    // student sees "N skipped, too old" instead of a silent gap.
    const windowCutoffMs = Date.now() - META_PRIVATE_REPLY_WINDOW_HOURS * 60 * 60 * 1000;
    const eligible = needsAction
      .filter((c) => !handledSet.has(c.id))
      .filter((c) => {
        if (Date.parse(c.timestamp) >= windowCutoffMs) return true;
        stat.skippedTooOld += 1;
        console.warn(
          `[comment-reconciler] skipping comment ${c.id}: past Meta's ${META_PRIVATE_REPLY_WINDOW_HOURS}h private-reply window`
        );
        return false;
      })
      // Oldest first, so whoever commented earliest gets answered first.
      .sort((a, b) => Date.parse(a.timestamp) - Date.parse(b.timestamp));

    // Capped so a viral post drains gradually instead of bursting into the
    // comment API. Anything left over stays unhandled comments on Instagram
    // (not lost — the next sweep picks them up), but a student watching the
    // dashboard has no way to see that without this counter.
    const fresh = eligible.slice(0, MAX_NEW_PER_SWEEP);
    if (eligible.length > fresh.length) {
      stat.truncated = true;
      stat.droppedForCapacity += eligible.length - fresh.length;
    }

    for (const c of fresh) {
      // No deterministic jobId here: a retained completed/failed job from an
      // earlier sweep would otherwise be treated as a duplicate and silently
      // drop this add, so a legitimate later retry would never run. The DmLog
      // guards above (owner-reply + handledSet) already cover the normal
      // case; what they can't see is a comment whose earlier job is still
      // queued or running RIGHT NOW, because its DmLog row doesn't exist
      // until that job actually runs. acquireCommentClaim closes exactly
      // that gap on a viral post where the queue hasn't drained between
      // sweeps — see lib/queue/comment-claim.ts for the full story and why
      // this is a separate, short-TTL mechanism rather than a BullMQ jobId.
      const claimed = await acquireCommentClaim(account.instagramId, c.id);
      if (!claimed) {
        stat.alreadyQueued += 1;
        continue;
      }
      await queue.add("process-comment", {
        instagramAccountId: account.instagramId,
        commentId: c.id,
        commentText: c.text ?? "",
        commenterId: c.from!.id,
        commenterName: c.from?.username,
        mediaId,
      });
      stat.enqueued += 1;
    }
  }

  return stat;
}

async function recordSweep(
  workspaceId: string,
  stat: SweepStat
): Promise<void> {
  // Only log when something happened or something went wrong — including a
  // truncated pass or stale-comment skips, both silent-looking states a
  // student would otherwise have no way to notice from the dashboard.
  const hasActivity =
    stat.enqueued > 0 ||
    stat.alreadyQueued > 0 ||
    stat.errors.length > 0 ||
    stat.skippedTooOld > 0 ||
    stat.truncated;
  if (!hasActivity) return;

  const truncatedNote = stat.truncated
    ? `, ${stat.droppedForCapacity} left for next sweep (sweep capacity reached)`
    : "";
  const staleNote =
    stat.skippedTooOld > 0
      ? `, ${stat.skippedTooOld} skipped (past Meta's ${META_PRIVATE_REPLY_WINDOW_HOURS}h reply window)`
      : "";
  // alreadyQueued: a comment whose earlier job from a previous sweep is
  // still in flight (see lib/queue/comment-claim.ts) — expected on a viral
  // post where the queue hasn't drained yet, not an error, but worth
  // surfacing so a student sees why "enqueued" is lower than "matched".
  const queuedNote =
    stat.alreadyQueued > 0
      ? `, ${stat.alreadyQueued} already queued from an earlier sweep`
      : "";

  await prisma.operationalEvent
    .create({
      data: {
        workspaceId,
        source: "SYSTEM",
        level:
          stat.errors.length > 0 || stat.truncated || stat.skippedTooOld > 0
            ? "WARNING"
            : "INFO",
        message: `Comment sweep "${stat.campaign}" [${stat.keywords}]: ${stat.enqueued} enqueued, ${stat.matched} matched, ${stat.alreadyReplied} already replied${staleNote}${truncatedNote}${queuedNote}`,
        payload: { ...stat },
      },
    })
    .catch(() => {});
}
