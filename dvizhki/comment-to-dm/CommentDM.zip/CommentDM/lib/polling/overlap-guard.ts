/**
 * Keeps a function that runs on a fixed interval (see worker/dm-worker.ts,
 * the comment-poll timer) from having two invocations in flight at once.
 * Standalone from the per-comment claim in lib/queue/comment-claim.ts (which
 * closes the deeper race of two sweeps re-enqueuing the same comment while
 * its job is still queued) — this is the outer, cheap guard: a sweep that
 * is itself slow (many campaigns, many Graph API calls) should finish
 * before the next tick starts a second one on top of it.
 */
export type OverlapGuardOutcome = "ran" | "skipped";

export function createOverlapGuard() {
  let running = false;

  return async function runGuarded(
    fn: () => Promise<void>
  ): Promise<OverlapGuardOutcome> {
    if (running) return "skipped";
    running = true;
    try {
      await fn();
      return "ran";
    } finally {
      running = false;
    }
  };
}
