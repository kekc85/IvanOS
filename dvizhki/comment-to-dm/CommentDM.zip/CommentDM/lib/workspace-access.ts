import type { Workspace } from "@/app/generated/prisma/client";
import { getCurrentUser } from "@/lib/auth/session";
import { getOrCreateSingleWorkspace } from "@/lib/workspace";

export type WorkspaceContext = {
  userId: string;
  workspaceId: string;
  workspace: Workspace;
};

/**
 * Resolves the caller to the single workspace, or to null when there is no
 * valid session behind the request.
 *
 * There are no roles: the instance has exactly one account, so there is nobody
 * to grade against anybody. The only question left is whether the session
 * points at a real user row — `getCurrentUser` answers that against the
 * database, which is what stops a validly signed cookie carrying a stale or
 * forged user id from being treated as the owner.
 */
export async function getCurrentWorkspaceContext(): Promise<WorkspaceContext | null> {
  const user = await getCurrentUser();
  if (!user) return null;

  const workspace = await getOrCreateSingleWorkspace();

  return {
    userId: user.id,
    workspaceId: workspace.id,
    workspace,
  };
}
