import { createHash } from "node:crypto";
import { z } from "zod";

const HEX_32_BYTE = /^[a-f0-9]{64}$/i;

function readEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(`${name} environment variable is required`);
  }
  return value;
}

export function requireEnv(name: string): string {
  return readEnv(name);
}

export function getBaseUrl(): string {
  return process.env.APP_URL ?? "http://localhost:3000";
}

// Values copied straight out of .env.example (or an equally lazy stand-in)
// that a self-hoster could paste into .env and start the app without a
// single complaint. Every install would then share the same encryption key
// or session secret. Checked case-insensitively, whitespace-trimmed.
const KNOWN_PLACEHOLDER_VALUES = new Set(
  [
    "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
    "replace-with-a-strong-random-secret",
    "replace-with-a-random-secret",
    "changeme",
    "change-me",
    "change_me",
    "replaceme",
    "replace-me",
    "replace_me",
    "your-secret-here",
    "your-secret",
    "secret",
    "password",
    // The exact stand-ins install.sh writes (and .env.example ships) for the
    // two Meta app credentials — see lib/doctor/checks/env.ts and MEDIUM-5:
    // without these, a fresh install passed doctor's "all good" straight
    // through on values that were never real.
    "your-instagram-app-id",
    "your-instagram-app-secret",
  ].map((value) => value.toLowerCase())
);

/**
 * Catches the shapes a copy-pasted placeholder tends to take: a value lifted
 * verbatim from .env.example / this codebase's docs (including install.sh's
 * own stand-ins for the Meta app credentials), a value with effectively no
 * entropy (one character repeated, e.g. the "aaaa…" or "0000…" a human types
 * to get past a required-field check), or the generic "your-x-here" shape
 * neither list above enumerates by name.
 */
export function isPlaceholderSecret(value: string): boolean {
  const normalized = value.trim().toLowerCase();
  if (normalized.length === 0) return false;
  if (KNOWN_PLACEHOLDER_VALUES.has(normalized)) return true;
  if (/^(.)\1*$/.test(normalized)) return true; // one character, repeated
  if (/change[-_]?me|replace[-_]?me/.test(normalized)) return true;
  if (/^your[-_].+[-_](id|secret|key|token|here)$/.test(normalized)) return true;
  return false;
}

function assertNotPlaceholder(name: string, value: string): void {
  if (isPlaceholderSecret(value)) {
    throw new Error(
      `${name} is set to a placeholder value copied from .env.example. ` +
        `Generate a real one: openssl rand -hex 32`
    );
  }
}

export function getEncryptionKeyHex(): string {
  const value = readEnv("ENCRYPTION_KEY");
  if (!HEX_32_BYTE.test(value)) {
    throw new Error("ENCRYPTION_KEY must be a 32-byte hex string");
  }
  assertNotPlaceholder("ENCRYPTION_KEY", value);
  return value;
}

/**
 * The one place SESSION_SECRET is read as an actual secret (signing session
 * cookies and OAuth state, salting IP hashes). Centralized so every caller
 * gets the same "missing" and "placeholder" checks instead of each one
 * reaching for `process.env.SESSION_SECRET` with its own fallback.
 */
export function getSessionSecret(): string {
  const value = readEnv("SESSION_SECRET");
  assertNotPlaceholder("SESSION_SECRET", value);
  return value;
}

// Env vars that must be present before an Instagram OAuth round trip can even
// start. Checked up front so a self-hoster with a half-filled .env gets the
// variable names back instead of an unhandled throw from requireEnv().
const INSTAGRAM_OAUTH_ENV = [
  "INSTAGRAM_APP_ID",
  "INSTAGRAM_APP_SECRET",
  "ENCRYPTION_KEY",
  "SESSION_SECRET",
] as const;

export function getMissingInstagramOAuthEnv(): string[] {
  return INSTAGRAM_OAUTH_ENV.filter((name) => {
    const value = process.env[name];
    if (!value) return true;
    // A malformed key fails later inside encryptToken, after the user has
    // already round-tripped through Meta — catch the bad format here instead.
    if (name === "ENCRYPTION_KEY" && !HEX_32_BYTE.test(value)) return true;
    // Every one of these four is a value install.sh (or a copy-pasted
    // .env.example) can leave behind unfilled — a placeholder here is just
    // as unusable as an empty string, see MEDIUM-5.
    return isPlaceholderSecret(value);
  });
}

/**
 * A short, non-secret fingerprint of the encryption key — safe to publish
 * (e.g. in the worker's Redis heartbeat, see lib/ops/worker-health.ts) so a
 * second process (the app, or `npm run doctor`) can tell "same key as me" from
 * "different key" without either side ever transmitting the real key. This is
 * how doctor catches the app and the worker drifting onto two different
 * ENCRYPTION_KEY values — the actual failure mode that silently breaks every
 * connected account (see lib/doctor/checks/worker.ts).
 */
export function getEncryptionKeyFingerprint(): string {
  return createHash("sha256").update(getEncryptionKeyHex()).digest("hex").slice(0, 16);
}

export function getMetaGraphApiVersion(): string {
  return process.env.META_GRAPH_API_VERSION ?? "v25.0";
}

export const serverEnvSchema = z.object({
  APP_URL: z.string().url(),
  SESSION_SECRET: z
    .string()
    .min(16)
    .refine((value) => !isPlaceholderSecret(value), {
      message:
        "looks like a placeholder value copied from .env.example — generate a real one with: openssl rand -hex 32",
    }),
  DATABASE_URL: z.string().min(1),
  REDIS_URL: z.string().min(1),
  ENCRYPTION_KEY: z
    .string()
    .regex(HEX_32_BYTE, "must be a 32-byte hex string")
    .refine((value) => !isPlaceholderSecret(value), {
      message:
        "looks like a placeholder value copied from .env.example — generate a real one with: openssl rand -hex 32",
    }),
  // Deliberately NOT placeholder-checked here, unlike SESSION_SECRET and
  // ENCRYPTION_KEY above: this schema is what instrumentation.ts's
  // validateCoreEnv() gates the entire app's boot on. The app is fully
  // usable — login, dashboard, settings — without Instagram connected yet;
  // a self-hoster has to be able to reach Settings to see how to fill these
  // in in the first place, which a boot-time refusal would make impossible.
  // The placeholder check for these two still exists (isPlaceholderSecret),
  // it's just applied where it belongs: doctor's checkEnv (a second,
  // non-blocking pass — see lib/doctor/checks/env.ts) and
  // getMissingInstagramOAuthEnv (which gates the "Connect Instagram" button
  // itself, not the app).
  INSTAGRAM_APP_ID: z.string().min(1),
  INSTAGRAM_APP_SECRET: z.string().min(1),
});

/**
 * Parses every variable a fresh install needs before it can serve a request.
 * Called once at process startup (app instrumentation, worker entrypoint) so
 * a half-filled .env fails immediately with the missing/invalid variable
 * named, instead of surfacing later as an unrelated crash mid-request.
 */
export function validateCoreEnv() {
  const result = serverEnvSchema.safeParse(process.env);
  if (result.success) return result.data;

  const problems = result.error.issues
    .map((issue) => `  - ${issue.path.join(".") || "(root)"}: ${issue.message}`)
    .join("\n");
  throw new Error(
    `Invalid or missing environment configuration. Fix .env and restart:\n${problems}`
  );
}
