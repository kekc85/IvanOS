/**
 * Only same-origin paths are accepted as a post-login destination, so a
 * crafted ?callbackUrl= cannot bounce the owner off the instance (see
 * app/login/actions.ts, the only caller).
 *
 * Pulled out of that file rather than defined inline: it's a "use server"
 * file, where every export becomes a Server Action and has to be async —
 * this is a plain synchronous helper, and needs to be importable by a test
 * without pulling in next/headers and next/navigation along with it.
 *
 * MEDIUM-8: a lone "//" prefix isn't the only way to spell a protocol-
 * relative URL. Some browsers normalize a backslash right after the leading
 * slash into another forward slash, so "/\evil.com" becomes "//evil.com" by
 * the time it's actually navigated to — a raw `raw.startsWith("//")` check
 * never sees that, because the string never contains a literal "//" until
 * the browser rewrites it. Normalizing backslashes to slashes here first
 * closes the whole class instead of just the one literal spelling.
 */
export function safeCallbackUrl(value: FormDataEntryValue | null): string {
  const raw = typeof value === "string" ? value : "";
  if (!raw.startsWith("/")) return "/dashboard";
  const normalized = raw.replace(/\\/g, "/");
  if (normalized.startsWith("//")) return "/dashboard";
  return raw;
}
