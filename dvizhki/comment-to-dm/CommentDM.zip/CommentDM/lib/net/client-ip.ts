/**
 * Client IP
 *
 * `X-Forwarded-For` is a header the connecting client sends, so it can send
 * anything it likes — including someone else's address. That header only
 * becomes trustworthy at the point a reverse proxy appends its own observed
 * peer to it, which is why it must be read from the *proxy* end of the
 * chain, not the client end.
 *
 * This fork is one instance behind one reverse proxy (Caddy, installed by
 * install.sh, listening on loopback with the app port firewalled off from
 * the internet). Under that topology the proxy always appends its own
 * observed peer as the last entry, so entries are walked from the right:
 * every trailing hop that is itself a trusted-proxy address is skipped, and
 * the first hop that is not is the real client. Everything to its left is
 * whatever that client claimed and is never trusted.
 *
 * Next.js's App Router route handlers do not expose the raw TCP peer
 * address (no `request.socket`), so this is the best signal available at
 * this layer — it depends on the network-level assumption above holding
 * (the app port is not directly reachable from the internet).
 *
 * TRUSTED_PROXIES is a comma-separated list of IPs / CIDR ranges. Defaults
 * to loopback plus the private ranges a reverse proxy on the same box or
 * the same private network would use — which matches the one-VPS install.
 */

const DEFAULT_TRUSTED_PROXIES =
  "127.0.0.1/32,::1/128,10.0.0.0/8,172.16.0.0/12,192.168.0.0/16";

const BIG_ZERO = BigInt(0);
const BIG_ONE = BigInt(1);
const BIG_EIGHT = BigInt(8);
const BIG_SIXTEEN = BigInt(16);
const BIG_0XFFFF = BigInt(0xffff);

function parseIpv4(ip: string): bigint | null {
  const parts = ip.split(".");
  if (parts.length !== 4) return null;
  let result = BIG_ZERO;
  for (const part of parts) {
    if (!/^\d{1,3}$/.test(part)) return null;
    const n = Number(part);
    if (n > 255) return null;
    result = (result << BIG_EIGHT) | BigInt(n);
  }
  return result;
}

/** Minimal RFC 4291 parser: handles "::" compression and dotted-quad tails. */
function parseIpv6(ip: string): bigint | null {
  const withoutZone = ip.split("%")[0] ?? ip;

  const expandV4Tail = (parts: string[]): string[] | null => {
    if (parts.length === 0) return parts;
    const last = parts[parts.length - 1];
    if (!last.includes(".")) return parts;
    const v4 = parseIpv4(last);
    if (v4 === null) return null;
    const hi = ((v4 >> BIG_SIXTEEN) & BIG_0XFFFF).toString(16);
    const lo = (v4 & BIG_0XFFFF).toString(16);
    return [...parts.slice(0, -1), hi, lo];
  };

  let headParts: string[];
  let tailParts: string[];

  const doubleColonIndex = withoutZone.indexOf("::");
  if (doubleColonIndex !== -1) {
    const head = withoutZone.slice(0, doubleColonIndex);
    const tail = withoutZone.slice(doubleColonIndex + 2);
    headParts = head ? head.split(":") : [];
    tailParts = tail ? tail.split(":") : [];
  } else {
    headParts = withoutZone.split(":");
    tailParts = [];
  }

  const expandedHead = expandV4Tail(headParts);
  const expandedTail = expandV4Tail(tailParts);
  if (expandedHead === null || expandedTail === null) return null;

  let fullParts: string[];
  if (doubleColonIndex !== -1) {
    const missing = 8 - (expandedHead.length + expandedTail.length);
    if (missing < 0) return null;
    fullParts = [...expandedHead, ...Array(missing).fill("0"), ...expandedTail];
  } else {
    fullParts = expandedHead;
  }

  if (fullParts.length !== 8) return null;

  let result = BIG_ZERO;
  for (const part of fullParts) {
    if (!/^[0-9a-fA-F]{1,4}$/.test(part) && part !== "") return null;
    const n = part === "" ? 0 : Number.parseInt(part, 16);
    result = (result << BIG_SIXTEEN) | BigInt(n);
  }
  return result;
}

function parseIp(ip: string): { value: bigint; bits: number } | null {
  const trimmed = ip.trim();
  if (trimmed.includes(":")) {
    const value = parseIpv6(trimmed);
    return value === null ? null : { value, bits: 128 };
  }
  const value = parseIpv4(trimmed);
  return value === null ? null : { value, bits: 32 };
}

type TrustedRange = { network: bigint; bits: number; prefix: number };

function parseCidr(entry: string): TrustedRange | null {
  const [address, prefixRaw] = entry.trim().split("/");
  if (!address) return null;
  const parsed = parseIp(address);
  if (!parsed) return null;
  const prefix = prefixRaw !== undefined ? Number.parseInt(prefixRaw, 10) : parsed.bits;
  if (!Number.isInteger(prefix) || prefix < 0 || prefix > parsed.bits) return null;

  const shift = BigInt(parsed.bits - prefix);
  const fullMask = (BIG_ONE << BigInt(parsed.bits)) - BIG_ONE;
  const mask = shift === BIG_ZERO ? fullMask : ~((BIG_ONE << shift) - BIG_ONE);
  return { network: parsed.value & mask & fullMask, bits: parsed.bits, prefix };
}

export function parseTrustedProxies(raw: string): TrustedRange[] {
  return raw
    .split(",")
    .map((entry) => entry.trim())
    .filter(Boolean)
    .map(parseCidr)
    .filter((range): range is TrustedRange => range !== null);
}

let cachedRanges: TrustedRange[] | null = null;
let cachedRawValue: string | null = null;

function getTrustedRanges(): TrustedRange[] {
  const raw = process.env.TRUSTED_PROXIES ?? DEFAULT_TRUSTED_PROXIES;
  if (cachedRanges && cachedRawValue === raw) return cachedRanges;
  cachedRanges = parseTrustedProxies(raw);
  cachedRawValue = raw;
  return cachedRanges;
}

/** Test seam: env var caching would otherwise leak between test cases. */
export function resetTrustedProxiesCache(): void {
  cachedRanges = null;
  cachedRawValue = null;
}

export function isTrustedProxyIp(
  ip: string,
  ranges: TrustedRange[] = getTrustedRanges()
): boolean {
  const parsed = parseIp(ip);
  if (!parsed) return false;
  return ranges.some((range) => {
    if (range.bits !== parsed.bits) return false;
    const shift = BigInt(range.bits - range.prefix);
    const fullMask = (BIG_ONE << BigInt(range.bits)) - BIG_ONE;
    const mask = shift === BIG_ZERO ? fullMask : ~((BIG_ONE << shift) - BIG_ONE);
    return (parsed.value & mask & fullMask) === range.network;
  });
}

export type HeaderLike = { get(name: string): string | null };

/**
 * Resolves the request's client IP, trusting `X-Forwarded-For` only for the
 * trailing hops that are themselves inside TRUSTED_PROXIES. Returns null
 * when no usable, untrusted address can be found — callers already treat a
 * null IP as "unknown" rather than guessing.
 *
 * Takes the headers object directly (Request#headers, or next/headers's
 * `await headers()`) so it works the same from a route handler and from a
 * server action.
 */
export function getClientIp(headers: HeaderLike): string | null {
  const ranges = getTrustedRanges();
  const forwardedFor = headers.get("x-forwarded-for");

  if (forwardedFor) {
    const hops = forwardedFor
      .split(",")
      .map((hop) => hop.trim())
      .filter(Boolean);

    for (let i = hops.length - 1; i >= 0; i--) {
      if (!isTrustedProxyIp(hops[i], ranges)) {
        return hops[i];
      }
    }
    // Every hop matched a trusted proxy — nothing left that identifies an
    // actual client (e.g. the proxy talking to itself on a health check).
    return null;
  }

  const direct = headers.get("x-real-ip") ?? headers.get("cf-connecting-ip");
  return direct ?? null;
}
