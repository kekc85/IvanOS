import { randomBytes } from "node:crypto";

// The slug is still stamped on every campaign, but nothing serves it: the
// public /reports/[shareSlug] page is gone. Keeping the column filled means a
// later opt-in feature does not have to backfill.
export function generateReportShareSlug() {
  return randomBytes(9).toString("base64url");
}
