/**
 * Retention Cleanup Job
 *
 * Deletes rows past their configured retention window from the four tables
 * that grow one row per subscriber interaction: DmLog, LinkClick,
 * SubscriberJourney, and OperationalEvent. See lib/gdpr/retention-config.ts
 * for the windows themselves and why they differ.
 *
 * SubscriberJourney is the one table here where "old" is not enough on its
 * own: only finished chains (DONE/EXPIRED/STOPPED/SKIPPED/FAILED) are
 * cleaned. A GATE_SENT or ACTIVE row is a chain still running, and deleting
 * it would silently drop the person mid-sequence — those are closed by the
 * chain's own TTL machinery instead (expireStaleGates in
 * lib/chain/journey.ts, the window guard in lib/chain/step-dispatcher.ts),
 * which moves them into a terminal state first. Only then do they age out
 * here.
 *
 * DmLog gets a floor the others don't: it is also the polling reconciler's
 * dedup set (lib/polling/comment-reconciler.ts, lib/queue/dm-worker.ts), and
 * deleting a row still inside Meta's private-reply window makes the next
 * sweep treat an already-answered comment as new — a subscriber gets a
 * second DM for a comment they already got one for. getDmLogCutoff enforces
 * a floor at that window plus a safety buffer regardless of the configured
 * value, so this job cannot be misconfigured into causing that.
 *
 * Runs as an interval in the worker process alongside the other periodic
 * jobs (see worker/dm-worker.ts). Every run — deletions or not — writes one
 * OperationalEvent with the counts, which is what lets a self-hoster (or
 * `npm run doctor` in phase 11) confirm cleanup is actually happening rather
 * than silently not firing.
 */

import type { JourneyState } from "@/app/generated/prisma/client";
import { prisma } from "@/lib/db/client";
import {
  getChainJourneyCutoff,
  getDmLogCutoff,
  getLinkClickCutoff,
  getOperationalEventCutoff,
} from "@/lib/gdpr/retention-config";

/**
 * Terminal states only — the states nothing will ever send from again. Spelled
 * out rather than derived as "everything except the live ones" so that adding
 * a new live state to the enum can never quietly enroll it into deletion here.
 */
const FINISHED_JOURNEY_STATES: JourneyState[] = [
  "DONE",
  "EXPIRED",
  "STOPPED",
  "SKIPPED",
  "FAILED",
];

export interface RetentionCleanupSummary {
  dmLogsDeleted: number;
  linkClicksDeleted: number;
  chainJourneysDeleted: number;
  operationalEventsDeleted: number;
}

export async function runRetentionCleanupJob(): Promise<RetentionCleanupSummary> {
  const now = new Date();

  const [dmLogResult, linkClickResult, chainJourneyResult] = await Promise.all([
    prisma.dmLog.deleteMany({
      where: { createdAt: { lt: getDmLogCutoff(now) } },
    }),
    prisma.linkClick.deleteMany({
      where: { createdAt: { lt: getLinkClickCutoff(now) } },
    }),
    // createdAt, not completedAt: the window this enforces is "how long after
    // entering is that person barred from entering again", and entry is what
    // createdAt records. The two are never far apart anyway — a chain runs at
    // most ~22h, an unanswered GATE closes after 48h.
    prisma.subscriberJourney.deleteMany({
      where: {
        state: { in: FINISHED_JOURNEY_STATES },
        createdAt: { lt: getChainJourneyCutoff(now) },
      },
    }),
  ]);

  // OperationalEvent cleanup runs after the others, and does not delete the
  // summary row this run is about to write — that row is what proves this
  // pass ran at all, and clearing the table right before adding the proof
  // it ran would be a pointless race against the next reader.
  const operationalEventResult = await prisma.operationalEvent.deleteMany({
    where: { createdAt: { lt: getOperationalEventCutoff(now) } },
  });

  const summary: RetentionCleanupSummary = {
    dmLogsDeleted: dmLogResult.count,
    linkClicksDeleted: linkClickResult.count,
    chainJourneysDeleted: chainJourneyResult.count,
    operationalEventsDeleted: operationalEventResult.count,
  };

  await prisma.operationalEvent
    .create({
      data: {
        source: "SYSTEM",
        level: "INFO",
        message: `Retention cleanup run: ${summary.dmLogsDeleted} DM log(s), ${summary.linkClicksDeleted} link click(s), ${summary.chainJourneysDeleted} chain journey(s), ${summary.operationalEventsDeleted} operational event(s) deleted`,
        payload: { ...summary },
      },
    })
    .catch(() => {});

  return summary;
}
