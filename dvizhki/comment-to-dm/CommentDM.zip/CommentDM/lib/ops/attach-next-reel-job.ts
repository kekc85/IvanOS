/**
 * Attach-Next-Reel Job
 *
 * Binds "next reel" campaigns to a real post.
 *
 * Instagram never announces a newly published media, so we poll: for
 * every campaign awaiting the creator's next reel, find the earliest reel that
 * was posted after the campaign was created and attach the campaign to it.
 * Runs on an interval inside the worker process (see worker/dm-worker.ts) — the
 * campaign goes live within one interval of the reel being posted.
 */

import { prisma } from "@/lib/db/client";
import { getUserMedia, type InstagramMedia } from "@/lib/meta/client";
import { decryptToken } from "@/lib/meta/oauth";

function isReel(media: InstagramMedia): boolean {
  return media.media_product_type === "REELS";
}

export interface AttachNextReelSummary {
  checked: number;
  bound: number;
  failedAccounts: number;
}

export async function runAttachNextReelJob(): Promise<AttachNextReelSummary> {
  const pending = await prisma.automation.findMany({
    where: { pendingNextReel: true },
    include: { instagramAccount: true },
  });

  // Group by connected account so we fetch each account's media only once.
  const byAccount = new Map<
    string,
    { account: (typeof pending)[number]["instagramAccount"]; automations: typeof pending }
  >();
  for (const automation of pending) {
    const key = automation.instagramAccountId;
    const entry = byAccount.get(key);
    if (entry) entry.automations.push(automation);
    else byAccount.set(key, { account: automation.instagramAccount, automations: [automation] });
  }

  let bound = 0;
  let checked = 0;
  const failures: string[] = [];
  let firstWorkspaceId: string | null = null;

  for (const { account, automations } of byAccount.values()) {
    checked += automations.length;
    if (firstWorkspaceId === null && automations.length > 0) {
      firstWorkspaceId = automations[0].workspaceId;
    }
    if (!account?.accessToken) continue;

    let reels: InstagramMedia[];
    try {
      const token = decryptToken(account.accessToken);
      const media = await getUserMedia(token, 25);
      reels = media
        .filter(isReel)
        .sort(
          (a, b) =>
            new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
        );
    } catch (err) {
      failures.push(account.id);
      console.error("[attach-next-reel] media fetch failed", account.id, err);
      continue;
    }

    for (const automation of automations) {
      // The "next" reel = the earliest one posted after the campaign was created.
      const nextReel = reels.find(
        (reel) => new Date(reel.timestamp) > automation.createdAt
      );
      if (!nextReel) continue;

      await prisma.automation.update({
        where: { id: automation.id },
        data: {
          postId: nextReel.id,
          postUrl: nextReel.permalink ?? null,
          pendingNextReel: false,
        },
      });
      bound += 1;
    }
  }

  // One entry per run so self-diagnostics can see this job is alive, even on a
  // day where nothing was pending.
  await prisma.operationalEvent
    .create({
      data: {
        workspaceId: firstWorkspaceId,
        source: "WORKER",
        level: failures.length > 0 ? "WARNING" : "INFO",
        message: `Attach-next-reel run: ${checked} pending checked, ${bound} bound, ${failures.length} account(s) failed`,
        payload: { checked, bound, failedAccounts: failures.length },
      },
    })
    .catch(() => {});

  return { checked, bound, failedAccounts: failures.length };
}
