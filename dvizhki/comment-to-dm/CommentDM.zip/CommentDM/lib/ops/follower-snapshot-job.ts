/**
 * Follower Snapshot Job
 *
 * Records one follower total per connected account per day.
 *
 * Instagram retains only ~30 days of account insights, so this job is the only
 * source of longer-range follower history. Missing a run loses that day
 * permanently — there is no way to backfill beyond the insights window.
 */

import { prisma } from "@/lib/db/client";
import { decryptToken } from "@/lib/meta/oauth";
import { getUserInfo } from "@/lib/meta/client";
import {
  backfillFollowerHistory,
  recordFollowerSnapshot,
} from "@/lib/reports/follower-history";

export interface FollowerSnapshotSummary {
  accounts: number;
  recorded: number;
  backfilled: number;
  failures: Array<{ username: string; reason: string }>;
}

export async function runFollowerSnapshotJob(): Promise<FollowerSnapshotSummary> {
  const accounts = await prisma.instagramAccount.findMany({
    where: { accessToken: { not: "" } },
    select: {
      id: true,
      workspaceId: true,
      username: true,
      instagramId: true,
      accessToken: true,
    },
  });

  let recorded = 0;
  let backfilled = 0;
  const failures: Array<{ username: string; reason: string }> = [];

  for (const account of accounts) {
    try {
      const token = decryptToken(account.accessToken);
      const info = await getUserInfo(token);

      if (typeof info.followers_count !== "number") {
        failures.push({
          username: account.username,
          reason: "followers_count not returned",
        });
        continue;
      }

      await recordFollowerSnapshot(account.id, info.followers_count);
      recorded += 1;

      // First time we see this account, try to recover the last 30 days.
      const existing = await prisma.followerSnapshot.count({
        where: { instagramAccountId: account.id },
      });
      if (existing <= 1) {
        backfilled += await backfillFollowerHistory(
          account.id,
          token,
          account.instagramId,
          info.followers_count
        );
      }
    } catch (err) {
      const reason = err instanceof Error ? err.message : "Unknown error";
      failures.push({ username: account.username, reason });
      await prisma.operationalEvent
        .create({
          data: {
            source: "SYSTEM",
            level: "WARNING",
            workspaceId: account.workspaceId,
            message: "Follower snapshot failed",
            payload: { username: account.username, reason },
          },
        })
        .catch(() => {});
    }
  }

  // One entry per run so self-diagnostics can see this job is alive.
  await prisma.operationalEvent
    .create({
      data: {
        workspaceId: accounts[0]?.workspaceId ?? null,
        source: "WORKER",
        level: failures.length > 0 ? "WARNING" : "INFO",
        message: `Follower snapshot run: ${accounts.length} account(s), ${recorded} recorded, ${backfilled} backfilled day(s), ${failures.length} failed`,
        payload: { accounts: accounts.length, recorded, backfilled, failures },
      },
    })
    .catch(() => {});

  return { accounts: accounts.length, recorded, backfilled, failures };
}
