/**
 * Token Refresh Job
 *
 * Instagram long-lived tokens die after 60 days. Miss this job for two months
 * straight and every connected account goes silent with no user-facing error —
 * the polling reconciler just starts getting 401s from the Graph API. This is
 * why it used to be a daily Vercel cron; on a VPS nothing calls that route, so
 * it now runs as an interval inside the worker process (see worker/dm-worker.ts).
 *
 * Also resets each workspace's monthly DM usage counter — piggybacking on
 * this job (rather than a separate one) because both are "once a day,
 * cheap, no urgency about the exact minute" housekeeping.
 */

import { prisma } from "@/lib/db/client";
import { decryptToken, encryptToken } from "@/lib/meta/oauth";
import { refreshLongLivedToken } from "@/lib/meta/client";

const DAYS_BEFORE_EXPIRY = 10;

export interface TokenRefreshResult {
  instagramAccountId: string;
  username: string;
  status: "refreshed" | "failed";
  error?: string;
}

export interface TokenRefreshSummary {
  totalProcessed: number;
  workspacesReset: number;
  refreshed: number;
  failed: number;
  results: TokenRefreshResult[];
}

/**
 * Refreshes every Instagram token within `DAYS_BEFORE_EXPIRY` of expiring, and
 * resets any workspace's usage counter that has rolled into a new month.
 * Never throws for an individual account failure — those are recorded in
 * `results` and in the operational event journal, and the sweep continues.
 */
export async function runTokenRefreshJob(): Promise<TokenRefreshSummary> {
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() + DAYS_BEFORE_EXPIRY);
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

  const usageReset = await prisma.workspace.updateMany({
    where: { usagePeriodStart: { lt: monthStart } },
    data: {
      usagePeriodStart: monthStart,
      dmsSentThisPeriod: 0,
    },
  });

  const accountsToRefresh = await prisma.instagramAccount.findMany({
    where: {
      accessToken: { not: "" },
      tokenExpiresAt: {
        not: null,
        lte: cutoffDate,
      },
    },
    select: {
      id: true,
      workspaceId: true,
      username: true,
      accessToken: true,
    },
  });

  const results: TokenRefreshResult[] = [];

  for (const account of accountsToRefresh) {
    try {
      const currentToken = decryptToken(account.accessToken);
      const { accessToken: newToken, expiresIn } =
        await refreshLongLivedToken(currentToken);
      const encryptedToken = encryptToken(newToken);
      const newExpiry = new Date(Date.now() + expiresIn * 1000);

      await prisma.instagramAccount.update({
        where: { id: account.id },
        data: {
          accessToken: encryptedToken,
          tokenExpiresAt: newExpiry,
        },
      });

      results.push({
        instagramAccountId: account.id,
        username: account.username,
        status: "refreshed",
      });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Unknown error";
      await prisma.operationalEvent
        .create({
          data: {
            workspaceId: account.workspaceId,
            source: "TOKEN_REFRESH",
            level: "ERROR",
            message: `Token refresh failed for @${account.username}: ${errorMessage}`,
            payload: {
              instagramAccountId: account.id,
              username: account.username,
            },
          },
        })
        .catch(() => {});

      results.push({
        instagramAccountId: account.id,
        username: account.username,
        status: "failed",
        error: errorMessage,
      });
    }
  }

  const refreshed = results.filter((r) => r.status === "refreshed").length;
  const failed = results.filter((r) => r.status === "failed").length;

  // One entry per run, success or not — this is the token expiry alarm.
  // Self-diagnostics (doctor) reads the most recent OperationalEvent whose
  // source is TOKEN_REFRESH and message starts with "Token refresh run:" to
  // tell "the worker is up but this job hasn't fired" from "it's fired and
  // failing" from "it's fired and healthy".
  await prisma.operationalEvent
    .create({
      data: {
        workspaceId: accountsToRefresh[0]?.workspaceId ?? null,
        source: "TOKEN_REFRESH",
        level: failed > 0 ? "WARNING" : "INFO",
        message: `Token refresh run: ${accountsToRefresh.length} due, ${refreshed} refreshed, ${failed} failed, ${usageReset.count} workspace(s) usage reset`,
        payload: { totalProcessed: accountsToRefresh.length, refreshed, failed, workspacesReset: usageReset.count },
      },
    })
    .catch(() => {});

  return {
    totalProcessed: accountsToRefresh.length,
    workspacesReset: usageReset.count,
    refreshed,
    failed,
    results,
  };
}
