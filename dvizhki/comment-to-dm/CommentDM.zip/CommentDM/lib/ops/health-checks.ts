/**
 * Health Checks
 *
 * Shared by two routes with very different audiences:
 *   - GET /api/health — public, no session. Meta/uptime monitors hit this;
 *     it must answer with nothing more than "ok" or "degraded" (see
 *     app/api/health/route.ts for why: error text and job counts are
 *     infrastructure detail an anonymous caller has no business seeing).
 *   - GET /api/admin/diagnostics — behind the owner's session, and where the
 *     actual error messages / counts belong.
 *
 * One set of checks, two routes deciding how much of the result to show.
 */

import { prisma } from "@/lib/db/client";
import { getDMQueue, getRedisConnection } from "@/lib/queue/client";
import { getWorkerHealth, type WorkerHealth } from "@/lib/ops/worker-health";

export type CheckStatus = "ok" | "error";

export interface HealthCheck {
  status: CheckStatus;
  detail?: string;
}

export async function checkDatabase(): Promise<HealthCheck> {
  try {
    await prisma.$queryRaw`SELECT 1`;
    return { status: "ok" };
  } catch (error) {
    return {
      status: "error",
      detail: error instanceof Error ? error.message : "Не удалось проверить базу данных",
    };
  }
}

export async function checkRedis(): Promise<HealthCheck> {
  try {
    const pong = await getRedisConnection().ping();
    return { status: pong === "PONG" ? "ok" : "error", detail: pong };
  } catch (error) {
    return {
      status: "error",
      detail: error instanceof Error ? error.message : "Не удалось проверить Redis",
    };
  }
}

export async function checkQueue(): Promise<HealthCheck & { counts?: unknown }> {
  try {
    const counts = await getDMQueue().getJobCounts(
      "waiting",
      "active",
      "delayed",
      "failed"
    );
    return { status: "ok", counts };
  } catch (error) {
    return {
      status: "error",
      detail: error instanceof Error ? error.message : "Не удалось проверить очередь",
    };
  }
}

export interface FullHealthReport {
  healthy: boolean;
  database: HealthCheck;
  redis: HealthCheck;
  queue: HealthCheck & { counts?: unknown };
  worker: WorkerHealth | { healthy: false; heartbeat: null; ageMs: null; error: string };
}

export async function runFullHealthCheck(): Promise<FullHealthReport> {
  const [database, redis, queue, worker] = await Promise.all([
    checkDatabase(),
    checkRedis(),
    checkQueue(),
    getWorkerHealth().catch((error) => ({
      healthy: false as const,
      heartbeat: null,
      ageMs: null,
      error: error instanceof Error ? error.message : "Не удалось проверить фоновый процесс",
    })),
  ]);

  const healthy =
    database.status === "ok" &&
    redis.status === "ok" &&
    queue.status === "ok" &&
    worker.healthy;

  return { healthy, database, redis, queue, worker };
}
