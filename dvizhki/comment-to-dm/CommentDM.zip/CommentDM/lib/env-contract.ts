/**
 * Env contract check — run by `npm run update` (scripts/check-env-contract.ts)
 * between the build and the migration step.
 *
 * Phases 2, 3 and 6 each changed the set of environment variables this app
 * needs (SESSION_SECRET/ENCRYPTION_KEY replacing NextAuth's variables, then
 * LEGAL_ENTITY_NAME/LEGAL_CONTACT_EMAIL, then the polling tuning knobs). A
 * student who updates months later has an old `.env` that predates some of
 * those additions. `git pull` + `npm ci` + `next build` all succeed on that
 * old `.env` — the failure only shows up when the app actually starts and
 * `validateCoreEnv()` (lib/env.ts, run from instrumentation.ts) throws. This
 * check exists to catch that before the migration step runs, not after.
 *
 * Two different notions of "missing":
 *   - missingRequired: a variable `serverEnvSchema` (lib/env.ts) actually
 *     validates at startup. Missing one of these means the app will not
 *     boot — `npm run update` stops here, before touching the database.
 *   - missingOptional: a variable `.env.example` documents but the app
 *     tolerates being absent (has a code-level default, or is genuinely
 *     optional — OWNER_PASSWORD, LEGAL_*, the retention/polling tuning
 *     knobs). Worth telling the student about, not worth blocking on.
 *
 * `serverEnvSchema`'s keys are the single source of truth for "required" —
 * this file does not hand-maintain a second list that could drift from it.
 */
import { serverEnvSchema } from "@/lib/env";

export type EnvContractDiff = {
  missingRequired: string[];
  missingOptional: string[];
};

const REQUIRED_ENV_KEYS = Object.keys(serverEnvSchema.shape);

/**
 * Pulls every `KEY=value` name out of an .env-style file's text. Blank lines
 * and full-line comments are skipped; a commented-out example
 * (`# TRUSTED_PROXIES=...`) does not count as the key being present — that
 * matches how dotenv/Next.js itself reads the file.
 */
function parseEnvKeys(content: string): Set<string> {
  const keys = new Set<string>();
  for (const rawLine of content.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;
    const match = line.match(/^([A-Za-z_][A-Za-z0-9_]*)=/);
    if (match) keys.add(match[1]);
  }
  return keys;
}

export function diffEnvContract(
  exampleContent: string,
  envContent: string
): EnvContractDiff {
  const exampleKeys = parseEnvKeys(exampleContent);
  const envKeys = parseEnvKeys(envContent);

  const missingRequired = new Set<string>();
  const missingOptional = new Set<string>();

  for (const key of exampleKeys) {
    if (envKeys.has(key)) continue;
    if (REQUIRED_ENV_KEYS.includes(key)) {
      missingRequired.add(key);
    } else {
      missingOptional.add(key);
    }
  }

  // Defensive, other direction: a key `serverEnvSchema` requires could in
  // principle be missing from .env.example too (someone forgot to document
  // it there when they added it to the schema). Still block on it — the app
  // will still refuse to start.
  for (const key of REQUIRED_ENV_KEYS) {
    if (!envKeys.has(key)) {
      missingRequired.add(key);
    }
  }

  return {
    missingRequired: [...missingRequired].sort(),
    missingOptional: [...missingOptional].sort(),
  };
}
