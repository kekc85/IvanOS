/**
 * Campaign Safety Policy
 *
 * Small, dependency-free constants shared between the campaign API's
 * validation schema (server) and the campaign builder form (client), so both
 * sides agree on the same numbers without importing server-only code
 * (Prisma, Redis) into a client bundle.
 */

// A single canned public reply repeated under every matching comment is the
// clearest signal of automation to both other users and Instagram's abuse
// systems. Requiring a few different variants (picked at random per comment,
// see lib/queue/dm-worker.ts) is a small ask that meaningfully breaks up the
// pattern.
export const MIN_PUBLIC_REPLY_VARIANTS = 2;
