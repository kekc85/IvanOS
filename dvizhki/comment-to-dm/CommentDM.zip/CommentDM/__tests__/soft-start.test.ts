/**
 * Soft Start — Unit Tests
 *
 * Pure-function tests: a freshly connected account gets a quartered cap for
 * its first 72 hours, then the normal cap automatically once that window
 * passes. No Redis, no Prisma — see lib/utils/soft-start.ts.
 */

import { describe, it, expect } from "vitest";
import {
  isAccountInSoftStart,
  softStartCap,
  softStartHoursRemaining,
  SOFT_START_WINDOW_HOURS,
  SOFT_START_DIVISOR,
} from "../lib/utils/soft-start";

const NOW = new Date("2026-08-07T12:00:00.000Z");

describe("isAccountInSoftStart", () => {
  it("is true right after connecting", () => {
    expect(isAccountInSoftStart(NOW, NOW)).toBe(true);
  });

  it("is true a few hours into the 72-hour window", () => {
    const connectedAt = new Date(NOW.getTime() - 10 * 60 * 60 * 1000); // 10h ago
    expect(isAccountInSoftStart(connectedAt, NOW)).toBe(true);
  });

  it("is false exactly at the 72-hour boundary", () => {
    const connectedAt = new Date(
      NOW.getTime() - SOFT_START_WINDOW_HOURS * 60 * 60 * 1000
    );
    expect(isAccountInSoftStart(connectedAt, NOW)).toBe(false);
  });

  it("is false well past the 72-hour window", () => {
    const connectedAt = new Date(NOW.getTime() - 10 * 24 * 60 * 60 * 1000); // 10 days ago
    expect(isAccountInSoftStart(connectedAt, NOW)).toBe(false);
  });

  it("is false when there is no connection time (fails open, not closed)", () => {
    expect(isAccountInSoftStart(null, NOW)).toBe(false);
    expect(isAccountInSoftStart(undefined, NOW)).toBe(false);
  });

  it("accepts an ISO string the same way it accepts a Date", () => {
    const connectedAt = new Date(NOW.getTime() - 1 * 60 * 60 * 1000).toISOString();
    expect(isAccountInSoftStart(connectedAt, NOW)).toBe(true);
  });
});

describe("softStartCap", () => {
  it("quarters the cap during the soft-start window", () => {
    const connectedAt = new Date(NOW.getTime() - 1 * 60 * 60 * 1000); // 1h ago
    expect(softStartCap(750, connectedAt, NOW)).toBe(Math.floor(750 / SOFT_START_DIVISOR));
    expect(softStartCap(750, connectedAt, NOW)).toBe(187);
  });

  it("returns the full cap once the account has warmed up", () => {
    const connectedAt = new Date(NOW.getTime() - 10 * 24 * 60 * 60 * 1000);
    expect(softStartCap(750, connectedAt, NOW)).toBe(750);
  });

  it("returns the full cap when there is no connection time on record", () => {
    expect(softStartCap(150, null, NOW)).toBe(150);
  });

  it("never quarters down to zero for a small base cap", () => {
    const connectedAt = NOW;
    expect(softStartCap(2, connectedAt, NOW)).toBeGreaterThanOrEqual(1);
  });
});

describe("softStartHoursRemaining", () => {
  it("counts down from 72 right after connecting", () => {
    expect(softStartHoursRemaining(NOW, NOW)).toBe(SOFT_START_WINDOW_HOURS);
  });

  it("is 0 once the window has passed", () => {
    const connectedAt = new Date(NOW.getTime() - 100 * 60 * 60 * 1000);
    expect(softStartHoursRemaining(connectedAt, NOW)).toBe(0);
  });

  it("is 0 when there is no connection time on record", () => {
    expect(softStartHoursRemaining(null, NOW)).toBe(0);
  });
});
