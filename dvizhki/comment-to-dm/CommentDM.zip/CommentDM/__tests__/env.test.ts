import { describe, expect, it, vi, beforeEach } from "vitest";
import {
  getEncryptionKeyHex,
  getMetaGraphApiVersion,
  getMissingInstagramOAuthEnv,
  getSessionSecret,
  isPlaceholderSecret,
  requireEnv,
  validateCoreEnv,
} from "../lib/env";

const REAL_KEY = "5f3a9c1e7b2d4f608a1c3e5b7d9f1a3c5e7b9d1f3a5c7e9b1d3f5a7c9e1b3d5f";
const REAL_SECRET = "a-real-session-secret-with-plenty-of-length";

beforeEach(() => {
  vi.unstubAllEnvs();
});

describe("environment helpers", () => {
  it("requires missing variables", () => {
    expect(() => requireEnv("MISSING_TEST_ENV")).toThrow(
      "MISSING_TEST_ENV environment variable is required"
    );
  });

  it("validates the encryption key format", () => {
    vi.stubEnv("ENCRYPTION_KEY", "not-hex");
    expect(() => getEncryptionKeyHex()).toThrow(
      "ENCRYPTION_KEY must be a 32-byte hex string"
    );
  });

  it("defaults Meta Graph API version in one place", () => {
    expect(getMetaGraphApiVersion()).toBe("v25.0");
    vi.stubEnv("META_GRAPH_API_VERSION", "v26.0");
    expect(getMetaGraphApiVersion()).toBe("v26.0");
  });
});

describe("isPlaceholderSecret", () => {
  it("flags the exact .env.example encryption key", () => {
    expect(
      isPlaceholderSecret(
        "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      )
    ).toBe(true);
  });

  it("flags a single character repeated", () => {
    expect(isPlaceholderSecret("a".repeat(64))).toBe(true);
    expect(isPlaceholderSecret("0000000000000000")).toBe(true);
  });

  it("flags changeme / replace-me style values", () => {
    expect(isPlaceholderSecret("changeme")).toBe(true);
    expect(isPlaceholderSecret("change-me")).toBe(true);
    expect(isPlaceholderSecret("replace-me")).toBe(true);
    expect(isPlaceholderSecret("REPLACE_ME_PLEASE")).toBe(true);
  });

  it("does not flag a real-looking generated secret", () => {
    expect(isPlaceholderSecret(REAL_KEY)).toBe(false);
    expect(isPlaceholderSecret(REAL_SECRET)).toBe(false);
  });

  it("flags the exact Instagram credential stand-ins install.sh and .env.example ship (MEDIUM-5)", () => {
    expect(isPlaceholderSecret("your-instagram-app-id")).toBe(true);
    expect(isPlaceholderSecret("your-instagram-app-secret")).toBe(true);
    expect(isPlaceholderSecret("YOUR-INSTAGRAM-APP-ID")).toBe(true);
  });

  it("flags the generic your-x-here shape even for a value not individually listed", () => {
    expect(isPlaceholderSecret("your-api-key")).toBe(true);
    expect(isPlaceholderSecret("your-app-token")).toBe(true);
    expect(isPlaceholderSecret("your-value-here")).toBe(true);
  });

  it("does not flag a real-looking Instagram app id (just digits, no 'your-' prefix)", () => {
    expect(isPlaceholderSecret("1234567890123456")).toBe(false);
  });
});

describe("getEncryptionKeyHex rejects placeholders", () => {
  it("throws on the documented example value even though it is valid hex", () => {
    vi.stubEnv(
      "ENCRYPTION_KEY",
      "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
    );
    expect(() => getEncryptionKeyHex()).toThrow(/placeholder/);
  });

  it("accepts a real-looking key", () => {
    vi.stubEnv("ENCRYPTION_KEY", REAL_KEY);
    expect(getEncryptionKeyHex()).toBe(REAL_KEY);
  });
});

describe("getSessionSecret", () => {
  it("fails loudly instead of falling back to a constant when unset", () => {
    expect(() => getSessionSecret()).toThrow(
      "SESSION_SECRET environment variable is required"
    );
  });

  it("rejects the .env.example placeholder text", () => {
    vi.stubEnv("SESSION_SECRET", "replace-with-a-strong-random-secret");
    expect(() => getSessionSecret()).toThrow(/placeholder/);
  });

  it("accepts a real-looking secret", () => {
    vi.stubEnv("SESSION_SECRET", REAL_SECRET);
    expect(getSessionSecret()).toBe(REAL_SECRET);
  });
});

describe("getMissingInstagramOAuthEnv", () => {
  it("treats a placeholder ENCRYPTION_KEY as missing, not just a bad format", () => {
    vi.stubEnv("INSTAGRAM_APP_ID", "app-id");
    vi.stubEnv("INSTAGRAM_APP_SECRET", "app-secret");
    vi.stubEnv("SESSION_SECRET", REAL_SECRET);
    vi.stubEnv(
      "ENCRYPTION_KEY",
      "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
    );

    expect(getMissingInstagramOAuthEnv()).toContain("ENCRYPTION_KEY");
  });

  it("reports nothing missing once every value is real", () => {
    vi.stubEnv("INSTAGRAM_APP_ID", "app-id");
    vi.stubEnv("INSTAGRAM_APP_SECRET", "app-secret");
    vi.stubEnv("SESSION_SECRET", REAL_SECRET);
    vi.stubEnv("ENCRYPTION_KEY", REAL_KEY);

    expect(getMissingInstagramOAuthEnv()).toEqual([]);
  });

  it("treats the install.sh Instagram placeholders as missing too (MEDIUM-5)", () => {
    vi.stubEnv("INSTAGRAM_APP_ID", "your-instagram-app-id");
    vi.stubEnv("INSTAGRAM_APP_SECRET", "your-instagram-app-secret");
    vi.stubEnv("SESSION_SECRET", REAL_SECRET);
    vi.stubEnv("ENCRYPTION_KEY", REAL_KEY);

    const missing = getMissingInstagramOAuthEnv();
    expect(missing).toContain("INSTAGRAM_APP_ID");
    expect(missing).toContain("INSTAGRAM_APP_SECRET");
  });
});

describe("validateCoreEnv", () => {
  it("names the missing variable instead of throwing an opaque error", () => {
    vi.stubEnv("APP_URL", "http://localhost:3000");
    vi.stubEnv("SESSION_SECRET", REAL_SECRET);
    vi.stubEnv("DATABASE_URL", "postgresql://localhost/db");
    vi.stubEnv("REDIS_URL", "redis://localhost:6379");
    vi.stubEnv("ENCRYPTION_KEY", REAL_KEY);
    vi.stubEnv("INSTAGRAM_APP_ID", "");
    vi.stubEnv("INSTAGRAM_APP_SECRET", "app-secret");
    // vi.stubEnv with "" still sets the key on process.env; delete it so the
    // schema sees it as genuinely absent, matching a real half-filled .env.
    delete process.env.INSTAGRAM_APP_ID;

    expect(() => validateCoreEnv()).toThrow(/INSTAGRAM_APP_ID/);
  });

  it("passes with a fully valid, non-placeholder configuration", () => {
    vi.stubEnv("APP_URL", "http://localhost:3000");
    vi.stubEnv("SESSION_SECRET", REAL_SECRET);
    vi.stubEnv("DATABASE_URL", "postgresql://localhost/db");
    vi.stubEnv("REDIS_URL", "redis://localhost:6379");
    vi.stubEnv("ENCRYPTION_KEY", REAL_KEY);
    vi.stubEnv("INSTAGRAM_APP_ID", "app-id");
    vi.stubEnv("INSTAGRAM_APP_SECRET", "app-secret");

    expect(() => validateCoreEnv()).not.toThrow();
  });
});
