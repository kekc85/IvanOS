import { describe, it, expect, vi, beforeEach } from "vitest";

const {
  mockPrisma,
  mockGetRecentMediaComments,
  mockGetUserMedia,
  mockDecryptToken,
  mockMatchKeywords,
  mockQueueAdd,
  mockAcquireCommentClaim,
} = vi.hoisted(() => ({
  mockPrisma: {
    automation: {
      findMany: vi.fn(),
    },
    dmLog: {
      findMany: vi.fn(),
    },
    operationalEvent: {
      create: vi.fn(),
    },
  },
  mockGetRecentMediaComments: vi.fn(),
  mockGetUserMedia: vi.fn(),
  mockDecryptToken: vi.fn(),
  mockMatchKeywords: vi.fn(),
  mockQueueAdd: vi.fn(),
  mockAcquireCommentClaim: vi.fn(),
}));

vi.mock("@/lib/db/client", () => ({
  prisma: mockPrisma,
}));

vi.mock("@/lib/meta/client", () => ({
  getRecentMediaComments: mockGetRecentMediaComments,
  getUserMedia: mockGetUserMedia,
  MetaApiError: class MetaApiError extends Error {
    code: number;
    constructor(code: number, _subcode: unknown, _fbTraceId: unknown, message: string) {
      super(message);
      this.code = code;
      this.name = "MetaApiError";
    }
  },
}));

vi.mock("@/lib/meta/oauth", () => ({
  decryptToken: mockDecryptToken,
}));

vi.mock("@/lib/utils/keyword-matcher", () => ({
  matchKeywords: mockMatchKeywords,
}));

vi.mock("@/lib/queue/client", () => ({
  getDMQueue: () => ({ add: mockQueueAdd }),
}));

vi.mock("@/lib/queue/comment-claim", () => ({
  acquireCommentClaim: mockAcquireCommentClaim,
}));

import { reconcileComments } from "../lib/polling/comment-reconciler";

const account = {
  id: "ig_account_row_1",
  instagramId: "ig_owner_1",
  username: "the_owner",
  accessToken: "encrypted-token",
};

const baseAutomation = {
  id: "auto_1",
  name: "Test campaign",
  postId: "media_1",
  matchAnyPost: false,
  matchAnyWord: true,
  keywords: [],
  wholeWordMatch: true,
  publicReplyEnabled: false,
  workspaceId: "workspace_1",
  instagramAccount: account,
};

function makeComment(id: string, hoursAgo: number, fromId = "commenter_1") {
  const timestamp = new Date(Date.now() - hoursAgo * 60 * 60 * 1000).toISOString();
  return {
    id,
    text: "gimme",
    from: { id: fromId, username: `user_${id}` },
    timestamp,
    replies: { data: [] },
  };
}

beforeEach(() => {
  vi.clearAllMocks();
  mockDecryptToken.mockReturnValue("plaintext-token");
  mockMatchKeywords.mockReturnValue({ matched: true });
  mockPrisma.dmLog.findMany.mockResolvedValue([]);
  mockPrisma.operationalEvent.create.mockResolvedValue({});
  mockQueueAdd.mockResolvedValue({});
  mockAcquireCommentClaim.mockResolvedValue(true);
});

describe("comment reconciler: window default", () => {
  it("defaults the lookback window to 144 hours", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([baseAutomation]);
    mockGetRecentMediaComments.mockResolvedValue([]);

    await reconcileComments();

    expect(mockGetRecentMediaComments).toHaveBeenCalledTimes(1);
    const sinceMsArg = mockGetRecentMediaComments.mock.calls[0][2] as number;
    const expectedSinceMs = Date.now() - 144 * 60 * 60 * 1000;
    // A few seconds of slack for the time it took the test to run.
    expect(Math.abs(sinceMsArg - expectedSinceMs)).toBeLessThan(5000);
  });
});

describe("comment reconciler: stale comment skip", () => {
  it("skips a comment older than Meta's private-reply window and logs the reason, without enqueueing it", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([baseAutomation]);
    // 200 hours old: within the (raised) 144h fetch lookback in a real sweep,
    // but past Meta's 168h private-reply window — mocked here directly so the
    // test isn't coupled to the lookback constant.
    const staleComment = makeComment("stale_comment_1", 200);
    mockGetRecentMediaComments.mockResolvedValue([staleComment]);

    await reconcileComments();

    // Never reaches the send queue.
    expect(mockQueueAdd).not.toHaveBeenCalled();

    // But the skip is recorded in the operational event journal with an
    // explicit reason, not silently dropped.
    expect(mockPrisma.operationalEvent.create).toHaveBeenCalledTimes(1);
    const call = mockPrisma.operationalEvent.create.mock.calls[0][0];
    expect(call.data.payload.skippedTooOld).toBe(1);
    expect(call.data.payload.enqueued).toBe(0);
    expect(call.data.message).toMatch(/skipped/i);
    expect(call.data.message).toMatch(/reply window/i);
    expect(call.data.level).toBe("WARNING");
  });

  it("enqueues a comment that is still within Meta's private-reply window", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([baseAutomation]);
    const freshComment = makeComment("fresh_comment_1", 1);
    mockGetRecentMediaComments.mockResolvedValue([freshComment]);

    await reconcileComments();

    expect(mockQueueAdd).toHaveBeenCalledTimes(1);
    expect(mockQueueAdd).toHaveBeenCalledWith(
      "process-comment",
      expect.objectContaining({ commentId: "fresh_comment_1" })
    );
  });
});

/**
 * Дедуп-множество прохода — это DmLog. Терминальный отказ (SKIPPED_DEDUP) в нём
 * не считался обработанным, и один и тот же комментарий уезжал в очередь каждые
 * пять минут всё окно опроса: ~1700 джоб и столько же строк в журнале на
 * человека.
 */
describe("comment reconciler: SKIPPED_DEDUP is terminal", () => {
  /** Отдаёт строку, только если её спросили в том числе про SKIPPED_DEDUP. */
  function dmLogHandledOnDedup(commentId: string) {
    mockPrisma.dmLog.findMany.mockImplementation(
      async (args: { where?: { status?: { in?: string[] } } } = {}) => {
        const statuses = args.where?.status?.in ?? [];
        return statuses.includes("SKIPPED_DEDUP") ? [{ commentId }] : [];
      }
    );
  }

  it("не переочередывает комментарий, по которому уже лежит SKIPPED_DEDUP", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([baseAutomation]);
    mockGetRecentMediaComments.mockResolvedValue([
      makeComment("dedup_comment", 1),
    ]);
    dmLogHandledOnDedup("dedup_comment");

    await reconcileComments();

    expect(mockQueueAdd).not.toHaveBeenCalled();
    // До клейма дело даже не доходит — комментарий отсеян раньше.
    expect(mockAcquireCommentClaim).not.toHaveBeenCalled();
    // И журнал не растёт: тихий проход без находок ничего не пишет.
    expect(mockPrisma.operationalEvent.create).not.toHaveBeenCalled();
  });

  it("SENT по-прежнему считается обработанным", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([baseAutomation]);
    mockGetRecentMediaComments.mockResolvedValue([makeComment("sent_comment", 1)]);
    mockPrisma.dmLog.findMany.mockImplementation(
      async (args: { where?: { status?: { in?: string[] } } } = {}) => {
        const statuses = args.where?.status?.in ?? [];
        return statuses.includes("SENT") ? [{ commentId: "sent_comment" }] : [];
      }
    );

    await reconcileComments();

    expect(mockQueueAdd).not.toHaveBeenCalled();
  });

  it("не переочередывает комментарий с терминальным отказом FAILED_PERMANENT", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([baseAutomation]);
    mockGetRecentMediaComments.mockResolvedValue([
      makeComment("dead_comment", 1),
    ]);
    mockPrisma.dmLog.findMany.mockImplementation(
      async (args: { where?: { status?: { in?: string[] } } } = {}) => {
        const statuses = args.where?.status?.in ?? [];
        return statuses.includes("FAILED_PERMANENT")
          ? [{ commentId: "dead_comment" }]
          : [];
      }
    );

    await reconcileComments();

    // Директ закрыт навсегда: без этого один такой комментарий давал ~288
    // упавших джоб и столько же строк ERROR за 144 часа окна опроса.
    expect(mockQueueAdd).not.toHaveBeenCalled();
    expect(mockAcquireCommentClaim).not.toHaveBeenCalled();
    expect(mockPrisma.operationalEvent.create).not.toHaveBeenCalled();
  });

  it("обычный FAILED терминальным НЕ считается и возвращается на повтор", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([baseAutomation]);
    mockGetRecentMediaComments.mockResolvedValue([
      makeComment("retryable_comment", 1),
    ]);
    // Строка есть, но статус временный (сеть, пятисотка Meta) - запрос
    // handled её и не должен спрашивать.
    mockPrisma.dmLog.findMany.mockImplementation(
      async (args: { where?: { status?: { in?: string[] } } } = {}) => {
        const statuses = args.where?.status?.in ?? [];
        expect(statuses).not.toContain("FAILED");
        return [];
      }
    );

    await reconcileComments();

    expect(mockQueueAdd).toHaveBeenCalledWith(
      "process-comment",
      expect.objectContaining({ commentId: "retryable_comment" })
    );
  });

  it("гонка двух кампаний: отказ одной не закрывает комментарий для другой", async () => {
    const second = { ...baseAutomation, id: "auto_2", name: "Вторая кампания" };
    mockPrisma.automation.findMany.mockResolvedValue([baseAutomation, second]);
    mockGetRecentMediaComments.mockResolvedValue([makeComment("shared_comment", 1)]);
    // Дедуп-строка есть только у второй кампании: запрос идёт по automationId,
    // и первая обязана увидеть комментарий как необработанный.
    mockPrisma.dmLog.findMany.mockImplementation(
      async (args: { where?: { automationId?: string } } = {}) =>
        args.where?.automationId === "auto_2"
          ? [{ commentId: "shared_comment" }]
          : []
    );

    await reconcileComments();

    expect(mockQueueAdd).toHaveBeenCalledTimes(1);
    expect(mockQueueAdd).toHaveBeenCalledWith(
      "process-comment",
      expect.objectContaining({ commentId: "shared_comment" })
    );
  });

  it("у кампании с публичным ответом сигнал завершения остался прежним", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([
      { ...baseAutomation, publicReplyEnabled: true },
    ]);
    mockGetRecentMediaComments.mockResolvedValue([makeComment("pr_comment", 1)]);

    await reconcileComments();

    const where = mockPrisma.dmLog.findMany.mock.calls[0][0].where;
    // Публичный ответ, не отправленный с первого раза, обязан вернуться на
    // повтор, поэтому тут по-прежнему publicReplySentAt, а не статус DM.
    expect(where).toMatchObject({ publicReplySentAt: { not: null } });
    expect(where.status).toBeUndefined();
  });
});

describe("comment reconciler: overlapping-sweep claim guard", () => {
  it("skips enqueueing a comment whose earlier job is still claimed, and counts it separately from enqueued", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([baseAutomation]);
    const comment = makeComment("in_flight_comment", 1);
    mockGetRecentMediaComments.mockResolvedValue([comment]);
    // Simulates a previous sweep's job for this exact comment still being
    // queued/processed — its DmLog row doesn't exist yet, so the handledSet
    // check above can't see it; the claim is what closes that gap.
    mockAcquireCommentClaim.mockResolvedValue(false);

    await reconcileComments();

    expect(mockQueueAdd).not.toHaveBeenCalled();
    expect(mockAcquireCommentClaim).toHaveBeenCalledWith(
      account.instagramId,
      "in_flight_comment"
    );

    const call = mockPrisma.operationalEvent.create.mock.calls[0][0];
    expect(call.data.payload.alreadyQueued).toBe(1);
    expect(call.data.payload.enqueued).toBe(0);
    expect(call.data.message).toMatch(/already queued/i);
  });

  it("enqueues normally when the claim is free", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([baseAutomation]);
    const comment = makeComment("free_comment", 1);
    mockGetRecentMediaComments.mockResolvedValue([comment]);
    mockAcquireCommentClaim.mockResolvedValue(true);

    await reconcileComments();

    expect(mockQueueAdd).toHaveBeenCalledTimes(1);
    const call = mockPrisma.operationalEvent.create.mock.calls[0][0];
    expect(call.data.payload.alreadyQueued).toBe(0);
    expect(call.data.payload.enqueued).toBe(1);
  });
});

describe("comment reconciler: sweep truncation", () => {
  it("caps a sweep at MAX_NEW_PER_SWEEP (30) and records the truncation with how many are left", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([baseAutomation]);
    // 35 fresh, distinct, matching comments — five more than the default cap.
    const comments = Array.from({ length: 35 }, (_, i) =>
      makeComment(`comment_${i}`, 1, `commenter_${i}`)
    );
    mockGetRecentMediaComments.mockResolvedValue(comments);

    await reconcileComments();

    expect(mockQueueAdd).toHaveBeenCalledTimes(30);

    expect(mockPrisma.operationalEvent.create).toHaveBeenCalledTimes(1);
    const call = mockPrisma.operationalEvent.create.mock.calls[0][0];
    expect(call.data.payload.truncated).toBe(true);
    expect(call.data.payload.droppedForCapacity).toBe(5);
    expect(call.data.payload.enqueued).toBe(30);
    expect(call.data.message).toMatch(/left for next sweep/i);
    expect(call.data.level).toBe("WARNING");
  });

  it("does not flag truncation when everything fit in one sweep", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([baseAutomation]);
    const comments = Array.from({ length: 5 }, (_, i) =>
      makeComment(`comment_${i}`, 1, `commenter_${i}`)
    );
    mockGetRecentMediaComments.mockResolvedValue(comments);

    await reconcileComments();

    expect(mockQueueAdd).toHaveBeenCalledTimes(5);
    const call = mockPrisma.operationalEvent.create.mock.calls[0][0];
    expect(call.data.payload.truncated).toBe(false);
    expect(call.data.payload.droppedForCapacity).toBe(0);
    expect(call.data.level).toBe("INFO");
  });
});
