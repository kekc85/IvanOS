/**
 * The other half of the brief: tell "this is Meta's fault, not yours" apart
 * from "this is your account setup and needs fixing". classifyMetaError is
 * what every per-account token check in checks/tokens.ts funnels its caught
 * error through — this exercises it directly against each real error shape
 * Meta (or the network to it) can produce.
 */
import { describe, expect, it } from "vitest";
import {
  MetaApiError,
  PermissionError,
  RateLimitError,
  TokenExpiredError,
} from "../lib/meta/client";
import { DoctorTimeoutError } from "../lib/doctor/timeout";
import { classifyMetaError } from "../lib/doctor/checks/tokens";

describe("classifyMetaError", () => {
  it("treats an expired/revoked token as our fix — reconnect the account", () => {
    const finding = classifyMetaError("alice", new TokenExpiredError("Error validating access token"));

    expect(finding.level).toBe("error");
    expect(finding.code).toBe("E-11");
    expect(finding.message).toContain("alice");
    expect(finding.command).toMatch(/подключ/i);
    // Must not blame Meta being down for a token the account owner revoked.
    expect(finding.detail).not.toMatch(/это не у тебя сломалось/i);
  });

  it("treats a missing permission as our fix — reconnect the account", () => {
    const finding = classifyMetaError("bob", new PermissionError("Insufficient permission"));

    expect(finding.level).toBe("error");
    expect(finding.code).toBe("E-11");
    expect(finding.command).toMatch(/подключ/i);
  });

  it("treats a rate limit as Meta's fault, not ours", () => {
    const finding = classifyMetaError("carol", new RateLimitError("Too many calls"));

    expect(finding.level).toBe("warn");
    expect(finding.code).toBe("E-12");
    expect(finding.detail).toMatch(/это не у тебя сломалось/i);
  });

  it("treats an unrecognized Meta API error as Meta's fault, not ours", () => {
    const finding = classifyMetaError(
      "dave",
      new MetaApiError(2, undefined, "trace-123", "An unknown error occurred")
    );

    expect(finding.level).toBe("warn");
    expect(finding.code).toBe("E-12");
    expect(finding.detail).toContain("2");
  });

  it("treats a request that timed out as Meta/network being unreachable, not ours", () => {
    const finding = classifyMetaError("erin", new DoctorTimeoutError("Meta /me for @erin", 5000));

    expect(finding.level).toBe("warn");
    expect(finding.code).toBe("E-12");
    expect(finding.detail).toMatch(/это не у тебя сломалось/i);
  });

  it("treats a bare network failure as Meta/network being unreachable, not ours", () => {
    const finding = classifyMetaError("frank", new TypeError("fetch failed"));

    expect(finding.level).toBe("warn");
    expect(finding.code).toBe("E-12");
    expect(finding.detail).not.toMatch(/поломк.*аккаунт/i);
  });
});
