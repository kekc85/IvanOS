/**
 * Опрос диалогов — единственное место, где цепочка узнаёт, что человек
 * ответил. Тесты держат ровно те решения, на которых стоит вся фаза: матч по
 * обоим ID, стоп-слово, якорь расписания в момент ответа, продление окна без
 * перекройки расписания и живучесть прохода к падению одного аккаунта.
 */

import { describe, it, expect, vi, beforeEach } from "vitest";

const { mockPrisma, mockGetConversations, mockDecryptToken } = vi.hoisted(() => ({
  mockPrisma: {
    subscriberJourney: {
      findMany: vi.fn(),
      update: vi.fn(),
      updateMany: vi.fn(),
      count: vi.fn(),
    },
    instagramAccount: {
      findMany: vi.fn(),
    },
    workspace: {
      findFirst: vi.fn(),
    },
    operationalEvent: {
      create: vi.fn(),
    },
  },
  mockGetConversations: vi.fn(),
  mockDecryptToken: vi.fn(),
}));

vi.mock("@/lib/db/client", () => ({ prisma: mockPrisma }));

vi.mock("@/lib/meta/client", () => ({
  getConversations: mockGetConversations,
  MetaApiError: class MetaApiError extends Error {
    code: number;
    constructor(
      code: number,
      _subcode: number | undefined,
      _fbTraceId: string | undefined,
      message: string
    ) {
      super(message);
      this.code = code;
      this.name = "MetaApiError";
    }
  },
}));

vi.mock("@/lib/meta/oauth", () => ({ decryptToken: mockDecryptToken }));

import {
  CHAIN_STOP_WORDS,
  isStopWordMessage,
  pollConversations,
  resetConversationPollLogState,
} from "../lib/chain/conversation-poller";

const NOW = new Date("2026-08-09T12:00:00.000Z");
const GATE_SENT_AT = new Date("2026-08-09T10:00:00.000Z");
const ANSWERED_AT = "2026-08-09T11:30:00.000Z";

const ACCOUNT = {
  id: "acct_row_1",
  workspaceId: "ws_1",
  instagramId: "17841400000000001",
  username: "owner",
  accessToken: "encrypted",
};

function journeyRow(overrides: Record<string, unknown> = {}) {
  return {
    id: "journey_1",
    workspaceId: "ws_1",
    automationId: "auto_1",
    subscriberId: "recipient_555",
    commenterId: "commenter_999",
    conversationId: null,
    state: "GATE_SENT",
    gateSentAt: GATE_SENT_AT,
    lastUserMessageAt: null,
    ...overrides,
  };
}

function conversation(overrides: Record<string, unknown> = {}) {
  return {
    id: "thread_1",
    updated_time: ANSWERED_AT,
    participants: {
      data: [{ id: "recipient_555" }, { id: ACCOUNT.instagramId }],
    },
    messages: {
      data: [
        {
          id: "msg_1",
          created_time: ANSWERED_AT,
          message: "давай",
          from: { id: "recipient_555" },
        },
      ],
    },
    ...overrides,
  };
}

/**
 * Разводит два разных вызова subscriberJourney.findMany: первый (distinct)
 * отдаёт аккаунты, остальные — живые журнеи конкретного аккаунта.
 */
function wireJourneys(byAccount: Record<string, ReturnType<typeof journeyRow>[]>) {
  mockPrisma.subscriberJourney.findMany.mockImplementation(
    async (args: Record<string, unknown>) => {
      if (args?.distinct) {
        return Object.keys(byAccount).map((id) => ({ instagramAccountId: id }));
      }
      const where = args?.where as { instagramAccountId?: string };
      return byAccount[where?.instagramAccountId ?? ""] ?? [];
    }
  );
}

function updateData(journeyId = "journey_1") {
  const call = mockPrisma.subscriberJourney.update.mock.calls.find(
    (c) => (c[0] as { where: { id: string } }).where.id === journeyId
  );
  return (call?.[0] as { data: Record<string, unknown> } | undefined)?.data;
}

function events() {
  return mockPrisma.operationalEvent.create.mock.calls.map(
    (c) => (c[0] as { data: Record<string, unknown> }).data
  );
}

beforeEach(() => {
  vi.clearAllMocks();
  resetConversationPollLogState();
  mockDecryptToken.mockReturnValue("plain-token");
  mockPrisma.instagramAccount.findMany.mockResolvedValue([ACCOUNT]);
  mockPrisma.subscriberJourney.update.mockResolvedValue({});
  mockPrisma.subscriberJourney.count.mockResolvedValue(0);
  mockPrisma.workspace.findFirst.mockResolvedValue({ id: "ws_sole" });
  mockPrisma.operationalEvent.create.mockResolvedValue({});
  mockGetConversations.mockResolvedValue([]);
});

function passEvent() {
  return events().find((e) => String(e.message).includes("опрос диалогов -"));
}

describe("матч треда к журнею", () => {
  it("узнаёт человека по subscriberId (ID из пространства сообщений)", async () => {
    wireJourneys({ [ACCOUNT.id]: [journeyRow()] });
    mockGetConversations.mockResolvedValue([conversation()]);

    const result = await pollConversations(NOW);

    expect(result.activated).toBe(1);
    expect(updateData()).toMatchObject({ state: "ACTIVE" });
  });

  it("узнаёт человека и по commenterId, когда в треде другой ID", async () => {
    wireJourneys({ [ACCOUNT.id]: [journeyRow()] });
    mockGetConversations.mockResolvedValue([
      conversation({
        participants: {
          data: [{ id: "commenter_999" }, { id: ACCOUNT.instagramId }],
        },
        messages: {
          data: [
            {
              id: "msg_1",
              created_time: ANSWERED_AT,
              message: "давай",
              from: { id: "commenter_999" },
            },
          ],
        },
      }),
    ]);

    const result = await pollConversations(NOW);

    expect(result.activated).toBe(1);
    expect(updateData()).toMatchObject({ state: "ACTIVE" });
  });

  it("записывает conversationId при первом матче", async () => {
    wireJourneys({ [ACCOUNT.id]: [journeyRow()] });
    mockGetConversations.mockResolvedValue([conversation()]);

    await pollConversations(NOW);

    expect(updateData()).toMatchObject({ conversationId: "thread_1" });
  });

  it("не трогает журней, если тред ничей", async () => {
    wireJourneys({ [ACCOUNT.id]: [journeyRow()] });
    mockGetConversations.mockResolvedValue([
      conversation({
        participants: { data: [{ id: "stranger_1" }, { id: ACCOUNT.instagramId }] },
      }),
    ]);

    const result = await pollConversations(NOW);

    expect(result.activated).toBe(0);
    expect(mockPrisma.subscriberJourney.update).not.toHaveBeenCalled();
  });

  it("считает несопоставленные треды, а не роняет их молча", async () => {
    wireJourneys({ [ACCOUNT.id]: [journeyRow()] });
    mockGetConversations.mockResolvedValue([
      conversation(),
      conversation({
        id: "thread_2",
        participants: { data: [{ id: "stranger_1" }, { id: ACCOUNT.instagramId }] },
      }),
    ]);

    const result = await pollConversations(NOW);

    expect(result.threadsSeen).toBe(2);
    expect(result.unmatched).toBe(1);
  });

  it("делает ровно один запрос диалогов на аккаунт за проход", async () => {
    wireJourneys({
      [ACCOUNT.id]: [journeyRow(), journeyRow({ id: "journey_2", subscriberId: "r2" })],
    });
    mockGetConversations.mockResolvedValue([conversation()]);

    await pollConversations(NOW);

    expect(mockGetConversations).toHaveBeenCalledTimes(1);
    expect(mockGetConversations).toHaveBeenCalledWith(
      "plain-token",
      ACCOUNT.instagramId
    );
  });
});

/**
 * Главная непроверенная гипотеза контура: ID под комментарием и ID в
 * переписке - разные пространства, и если на аккаунте они разошлись, ответ
 * человека приезжает тредом, который не матчится ни с одним журнеем. Снаружи
 * это выглядит как «цепочка молча не стартовала», и до этой правки не
 * оставляло вообще никакого следа.
 */
describe("треды без журнея", () => {
  it("молчит, пока висящих GATE нет - чужие диалоги в директе это норма", async () => {
    wireJourneys({ [ACCOUNT.id]: [journeyRow()] });
    mockGetConversations.mockResolvedValue([
      conversation({
        participants: { data: [{ id: "stranger_1" }, { id: ACCOUNT.instagramId }] },
      }),
    ]);
    mockPrisma.subscriberJourney.count.mockResolvedValue(0);

    await pollConversations(NOW);

    expect(passEvent()!.level).toBe("INFO");
    expect(String(passEvent()!.message)).toContain("тредов без журнея 1 из 1");
  });

  it("предупреждает один раз за проход, когда рядом висят GATE старше 10 минут", async () => {
    wireJourneys({ [ACCOUNT.id]: [journeyRow()] });
    mockGetConversations.mockResolvedValue([
      conversation({
        participants: { data: [{ id: "stranger_1" }, { id: ACCOUNT.instagramId }] },
      }),
      conversation({
        id: "thread_3",
        participants: { data: [{ id: "stranger_2" }, { id: ACCOUNT.instagramId }] },
      }),
    ]);
    mockPrisma.subscriberJourney.count.mockResolvedValue(2);

    await pollConversations(NOW);

    const warnings = events().filter((e) => e.level === "WARNING");
    expect(warnings).toHaveLength(1);
    expect(String(warnings[0].message)).toContain("тредов без журнея 2 из 2");
    expect(String(warnings[0].message)).toContain("не узнали");
    expect(warnings[0].payload).toMatchObject({
      threadsSeen: 2,
      unmatched: 2,
      staleGates: 2,
    });

    // Возраст GATE меряется от момента прохода, а не от «сейчас» процесса.
    const where = mockPrisma.subscriberJourney.count.mock.calls[0][0].where;
    expect(where.state).toBe("GATE_SENT");
    expect((where.gateSentAt.lt as Date).getTime()).toBe(
      NOW.getTime() - 10 * 60_000
    );
  });

  it("тревога поднимает и тихий проход, которого иначе не было бы в журнале", async () => {
    wireJourneys({ [ACCOUNT.id]: [journeyRow()] });
    mockGetConversations.mockResolvedValue([
      conversation({
        participants: { data: [{ id: "stranger_1" }, { id: ACCOUNT.instagramId }] },
      }),
    ]);
    // На первом проходе висящих GATE нет - тревоге не с чего сработать, и
    // строка пишется только потому, что первый проход пишется всегда.
    mockPrisma.subscriberJourney.count.mockResolvedValue(0);
    await pollConversations(NOW);

    // Второй проход тихий: без тревоги его в журнале не было бы вовсе.
    mockPrisma.operationalEvent.create.mockClear();
    mockPrisma.subscriberJourney.count.mockResolvedValue(1);
    await pollConversations(new Date(NOW.getTime() + 90_000));

    expect(passEvent()).toBeDefined();
    expect(passEvent()!.level).toBe("WARNING");
  });

  /**
   * Оба условия тревоги - нормальное состояние живого аккаунта: чужие диалоги
   * в директе есть всегда, а «GATE ждёт дольше десяти минут» - это любой, кто
   * пока не ответил, при TTL гейта в 48 часов. Проход идёт каждые 90 секунд,
   * поэтому тревога «по состоянию» = 40 WARNING в час на ровном месте, и
   * владелец перестаёт читать журнал ровно перед настоящей поломкой. Тревога
   * должна быть про ПЕРЕХОД.
   */
  describe("тревога только на переходе", () => {
    function twoStrangerThreads() {
      wireJourneys({ [ACCOUNT.id]: [journeyRow()] });
      mockGetConversations.mockResolvedValue([
        conversation({
          participants: {
            data: [{ id: "stranger_1" }, { id: ACCOUNT.instagramId }],
          },
        }),
        conversation({
          id: "thread_3",
          participants: {
            data: [{ id: "stranger_2" }, { id: ACCOUNT.instagramId }],
          },
        }),
      ]);
    }

    function warnings() {
      return events().filter((e) => e.level === "WARNING");
    }

    it("две тревоги подряд за 90 секунд дают одну строку WARNING", async () => {
      twoStrangerThreads();
      mockPrisma.subscriberJourney.count.mockResolvedValue(2);

      await pollConversations(NOW);
      expect(warnings()).toHaveLength(1);

      mockPrisma.operationalEvent.create.mockClear();
      await pollConversations(new Date(NOW.getTime() + 90_000));

      // Состояние то же самое - сообщать нечего, строки нет вообще.
      expect(warnings()).toHaveLength(0);
      expect(passEvent()).toBeUndefined();
    });

    it("рост числа висящих GATE после остывания поднимает новую тревогу", async () => {
      twoStrangerThreads();
      mockPrisma.subscriberJourney.count.mockResolvedValue(2);
      await pollConversations(NOW);

      mockPrisma.operationalEvent.create.mockClear();
      mockPrisma.subscriberJourney.count.mockResolvedValue(5);
      await pollConversations(new Date(NOW.getTime() + 31 * 60_000));

      expect(warnings()).toHaveLength(1);
      expect(warnings()[0].payload).toMatchObject({ staleGates: 5 });
    });

    it("то же число после остывания тревогу не поднимает", async () => {
      twoStrangerThreads();
      mockPrisma.subscriberJourney.count.mockResolvedValue(2);
      await pollConversations(NOW);

      mockPrisma.operationalEvent.create.mockClear();
      await pollConversations(new Date(NOW.getTime() + 31 * 60_000));

      expect(warnings()).toHaveLength(0);
    });

    it("рост в пределах получаса ждёт остывания", async () => {
      twoStrangerThreads();
      mockPrisma.subscriberJourney.count.mockResolvedValue(2);
      await pollConversations(NOW);

      mockPrisma.operationalEvent.create.mockClear();
      mockPrisma.subscriberJourney.count.mockResolvedValue(9);
      await pollConversations(new Date(NOW.getTime() + 29 * 60_000));

      expect(warnings()).toHaveLength(0);
    });

    it("после спада планка опускается: новый рост снова слышно", async () => {
      twoStrangerThreads();
      mockPrisma.subscriberJourney.count.mockResolvedValue(7);
      await pollConversations(NOW);

      // Всплеск рассосался: GATE разобрали, висит один.
      mockPrisma.subscriberJourney.count.mockResolvedValue(1);
      await pollConversations(new Date(NOW.getTime() + 31 * 60_000));

      mockPrisma.operationalEvent.create.mockClear();
      mockPrisma.subscriberJourney.count.mockResolvedValue(3);
      await pollConversations(new Date(NOW.getTime() + 62 * 60_000));

      // 3 меньше прежних семи, но больше единицы - это новый рост.
      expect(warnings()).toHaveLength(1);
    });

    it("упавший счёт планку не опускает: следующий всплеск слышно как рост", async () => {
      twoStrangerThreads();
      mockPrisma.subscriberJourney.count.mockResolvedValue(7);
      await pollConversations(NOW);

      // База моргнула: счёт бросил, staleGates остался нулём. Ноль тут значит
      // «не посчитали», а не «стало меньше» - опустить планку до нуля значит
      // объявить тревогой любое следующее число.
      mockPrisma.subscriberJourney.count.mockRejectedValue(
        new Error("connection terminated")
      );
      await pollConversations(new Date(NOW.getTime() + 31 * 60_000));

      mockPrisma.operationalEvent.create.mockClear();
      mockPrisma.subscriberJourney.count.mockResolvedValue(3);
      await pollConversations(new Date(NOW.getTime() + 62 * 60_000));

      // 3 меньше прежних семи - роста нет, тревоги быть не должно.
      expect(warnings().filter((e) => String(e.message).includes("не узнали")))
        .toHaveLength(0);
    });

    it("счётчики видны и без тревоги, когда строка прохода всё равно пишется", async () => {
      twoStrangerThreads();
      mockPrisma.subscriberJourney.count.mockResolvedValue(2);
      await pollConversations(NOW);

      mockPrisma.operationalEvent.create.mockClear();
      // Кто-то ответил - проход и так не тихий, строка будет.
      wireJourneys({ [ACCOUNT.id]: [journeyRow()] });
      mockGetConversations.mockResolvedValue([
        conversation(),
        conversation({
          id: "thread_3",
          participants: {
            data: [{ id: "stranger_2" }, { id: ACCOUNT.instagramId }],
          },
        }),
      ]);
      await pollConversations(new Date(NOW.getTime() + 90_000));

      const pass = passEvent()!;
      expect(pass.level).toBe("INFO");
      expect(pass.payload).toMatchObject({ unmatched: 1, staleGates: 2 });
      expect(String(pass.message)).toContain("тредов без журнея 1 из 2");
      expect(String(pass.message)).not.toContain("не узнали");
    });
  });

  it("висящие GATE не считает, пока несопоставленных тредов нет", async () => {
    wireJourneys({ [ACCOUNT.id]: [journeyRow()] });
    mockGetConversations.mockResolvedValue([conversation()]);

    await pollConversations(NOW);

    expect(mockPrisma.subscriberJourney.count).not.toHaveBeenCalled();
  });
});

describe("активация цепочки", () => {
  it("ставит якорь на момент ответа и выдачу сразу", async () => {
    wireJourneys({ [ACCOUNT.id]: [journeyRow()] });
    mockGetConversations.mockResolvedValue([conversation()]);

    await pollConversations(NOW);

    const data = updateData()!;
    expect(data.state).toBe("ACTIVE");
    expect((data.lastUserMessageAt as Date).toISOString()).toBe(ANSWERED_AT);
    // Шаг 0 — ВЫДАЧА, ждать её человеку нечего: срок равен моменту ответа.
    expect((data.nextStepDueAt as Date).toISOString()).toBe(ANSWERED_AT);
  });

  it("пишет INFO о том, что цепочка пошла", async () => {
    wireJourneys({ [ACCOUNT.id]: [journeyRow()] });
    mockGetConversations.mockResolvedValue([conversation()]);

    await pollConversations(NOW);

    expect(
      events().some(
        (e) => e.level === "INFO" && String(e.message).includes("Цепочка пошла")
      )
    ).toBe(true);
  });

  it("игнорирует превью от самого аккаунта - это наш же GATE", async () => {
    wireJourneys({ [ACCOUNT.id]: [journeyRow()] });
    mockGetConversations.mockResolvedValue([
      conversation({
        messages: {
          data: [
            {
              id: "msg_gate",
              created_time: ANSWERED_AT,
              message: "твой гайд",
              from: { id: ACCOUNT.instagramId },
            },
          ],
        },
      }),
    ]);

    const result = await pollConversations(NOW);

    expect(result.activated).toBe(0);
    // Ссылку на тред всё равно запомнили, состояние не тронули.
    expect(updateData()).toEqual({ conversationId: "thread_1" });
  });

  it("игнорирует сообщение старше GATE - это переписка до кампании", async () => {
    wireJourneys({ [ACCOUNT.id]: [journeyRow()] });
    mockGetConversations.mockResolvedValue([
      conversation({
        messages: {
          data: [
            {
              id: "msg_old",
              created_time: "2026-08-09T09:00:00.000Z",
              message: "привет",
              from: { id: "recipient_555" },
            },
          ],
        },
      }),
    ]);

    const result = await pollConversations(NOW);

    expect(result.activated).toBe(0);
    expect(updateData()).toEqual({ conversationId: "thread_1" });
  });
});

describe("стоп-слово", () => {
  it.each(CHAIN_STOP_WORDS)("«%s» останавливает цепочку", async (word) => {
    wireJourneys({ [ACCOUNT.id]: [journeyRow()] });
    mockGetConversations.mockResolvedValue([
      conversation({
        messages: {
          data: [
            {
              id: "msg_stop",
              created_time: ANSWERED_AT,
              message: `${word.toUpperCase()}!`,
              from: { id: "recipient_555" },
            },
          ],
        },
      }),
    ]);

    const result = await pollConversations(NOW);

    expect(result.stopped).toBe(1);
    expect(result.activated).toBe(0);
    expect(updateData()).toMatchObject({ state: "STOPPED", nextStepDueAt: null });
    expect(
      events().some(
        (e) =>
          e.level === "WARNING" &&
          String(e.message).includes("попросил перестать")
      )
    ).toBe(true);
  });

  it("останавливает и уже идущую цепочку (ACTIVE)", async () => {
    wireJourneys({
      [ACCOUNT.id]: [
        journeyRow({
          state: "ACTIVE",
          lastUserMessageAt: new Date("2026-08-09T11:00:00.000Z"),
        }),
      ],
    });
    mockGetConversations.mockResolvedValue([
      conversation({
        messages: {
          data: [
            {
              id: "msg_stop",
              created_time: ANSWERED_AT,
              message: "хватит",
              from: { id: "recipient_555" },
            },
          ],
        },
      }),
    ]);

    const result = await pollConversations(NOW);

    expect(result.stopped).toBe(1);
    expect(updateData()).toMatchObject({ state: "STOPPED" });
  });

  it("не срабатывает внутри слова", () => {
    expect(isStopWordMessage("стопудово беру")).toBe(false);
    expect(isStopWordMessage("Стоп 🙏")).toBe(true);
  });
});

describe("окно уже идущей цепочки", () => {
  it("освежает якорь окна, не перекраивая расписание", async () => {
    wireJourneys({
      [ACCOUNT.id]: [
        journeyRow({
          state: "ACTIVE",
          conversationId: "thread_1",
          lastUserMessageAt: new Date("2026-08-09T11:00:00.000Z"),
        }),
      ],
    });
    mockGetConversations.mockResolvedValue([conversation()]);

    const result = await pollConversations(NOW);

    expect(result.refreshed).toBe(1);
    const data = updateData()!;
    expect((data.lastUserMessageAt as Date).toISOString()).toBe(ANSWERED_AT);
    // Расписание якорится на момент активации: срок следующего шага здесь не
    // трогается вообще, иначе разговорчивый человек отодвигал бы себе M1/M2/M3.
    expect(data).not.toHaveProperty("nextStepDueAt");
    expect(data).not.toHaveProperty("state");
  });

  it("не пишет в базу, если сообщение не новее известного якоря", async () => {
    wireJourneys({
      [ACCOUNT.id]: [
        journeyRow({
          state: "ACTIVE",
          conversationId: "thread_1",
          lastUserMessageAt: new Date(ANSWERED_AT),
        }),
      ],
    });
    mockGetConversations.mockResolvedValue([conversation()]);

    const result = await pollConversations(NOW);

    expect(result.refreshed).toBe(0);
    expect(mockPrisma.subscriberJourney.update).not.toHaveBeenCalled();
  });
});

describe("живучесть прохода", () => {
  it("ошибка одного аккаунта не валит остальные", async () => {
    const second = {
      ...ACCOUNT,
      id: "acct_row_2",
      instagramId: "17841400000000002",
      username: "second",
    };
    mockPrisma.instagramAccount.findMany.mockResolvedValue([ACCOUNT, second]);
    wireJourneys({
      [ACCOUNT.id]: [journeyRow()],
      [second.id]: [journeyRow({ id: "journey_2" })],
    });
    mockGetConversations.mockImplementation(async (_token, igId: string) => {
      if (igId === ACCOUNT.instagramId) throw new Error("Meta прилегла");
      return [conversation()];
    });

    const result = await pollConversations(NOW);

    expect(result.errors).toHaveLength(1);
    expect(result.activated).toBe(1);
    expect(updateData("journey_2")).toMatchObject({ state: "ACTIVE" });
    expect(
      events().some(
        (e) =>
          e.level === "WARNING" &&
          String(e.message).includes("опрос диалогов @owner не удался")
      )
    ).toBe(true);
  });

  it("нерасшифровываемый токен не роняет проход", async () => {
    wireJourneys({ [ACCOUNT.id]: [journeyRow()] });
    mockDecryptToken.mockImplementation(() => {
      throw new Error("bad key");
    });

    const result = await pollConversations(NOW);

    expect(result.errors).toHaveLength(1);
    expect(mockGetConversations).not.toHaveBeenCalled();
  });

  it("без живых журнеев к Meta не ходит вообще", async () => {
    wireJourneys({});

    const result = await pollConversations(NOW);

    expect(result.accounts).toBe(0);
    expect(mockPrisma.instagramAccount.findMany).not.toHaveBeenCalled();
    expect(mockGetConversations).not.toHaveBeenCalled();
  });

  it("первый проход после старта виден в журнале, второй тихий - нет", async () => {
    wireJourneys({});

    await pollConversations(NOW);
    expect(events()).toHaveLength(1);

    mockPrisma.operationalEvent.create.mockClear();
    await pollConversations(NOW);
    expect(events()).toHaveLength(0);
  });

  it("строку прохода пишет на воркспейс аккаунта", async () => {
    wireJourneys({ [ACCOUNT.id]: [journeyRow()] });
    mockGetConversations.mockResolvedValue([conversation()]);

    await pollConversations(NOW);

    expect(passEvent()!.workspaceId).toBe("ws_1");
    expect(mockPrisma.workspace.findFirst).not.toHaveBeenCalled();
  });

  it("на пустом проходе берёт единственный воркспейс из базы", async () => {
    wireJourneys({});

    await pollConversations(NOW);

    // Строка без воркспейса не попадает в отфильтрованную по нему ленту
    // «Журнал» - владелец её просто не видит.
    expect(passEvent()!.workspaceId).toBe("ws_sole");
  });
});
