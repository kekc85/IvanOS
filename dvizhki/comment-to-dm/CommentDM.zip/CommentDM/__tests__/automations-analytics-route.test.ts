/**
 * GET /api/automations — счётчики на карточке кампании.
 *
 * Здесь проверяется одна вещь, которую нельзя увидеть в юнит-тесте
 * lib/tracking/analytics.ts: что карточка кампании и дашборд считают ОДНО И
 * ТО ЖЕ. Раньше не считали — карточка сравнивала статус как `=== "FAILED"`, а
 * дашборд брал префиксом, и терминальный отказ FAILED_PERMANENT не попадал на
 * карточке ни в одну корзину вовсе: ни в «отправлено», ни в «ошибки», ни в
 * «пропущено». На одной установке владелец видел на дашборде одну цифру «не
 * дошло», а на карточке той же кампании — другую, и никакой подсказки, куда
 * делась разница.
 */

import { beforeEach, describe, expect, it, vi } from "vitest";
import type { NextRequest } from "next/server";
import { summarizeDmStatuses } from "../lib/tracking/analytics";

const { mockPrisma, mockGetCurrentWorkspaceId } = vi.hoisted(() => ({
  mockPrisma: {
    automation: { findMany: vi.fn(), update: vi.fn() },
    dmLog: { groupBy: vi.fn() },
    linkClick: { groupBy: vi.fn() },
    subscriberJourney: { groupBy: vi.fn() },
  },
  mockGetCurrentWorkspaceId: vi.fn(),
}));

vi.mock("@/lib/db/client", () => ({ prisma: mockPrisma }));

vi.mock("@/lib/auth/session", () => ({
  getCurrentWorkspaceId: mockGetCurrentWorkspaceId,
}));

vi.mock("@/lib/workspace-access", () => ({
  getCurrentWorkspaceContext: vi.fn(async () => ({
    workspaceId: "workspace_1",
  })),
}));

import { GET } from "../app/api/automations/route";

const AUTOMATION_ID = "automation_1";

/** Все статусы отправки разом — по одной строке на каждый, чтобы промах в
 * любой корзине был виден как расхождение в единицу, а не потерялся. */
const STATUS_ROWS = [
  { automationId: AUTOMATION_ID, status: "SENT", _count: { _all: 7 } },
  { automationId: AUTOMATION_ID, status: "FAILED", _count: { _all: 2 } },
  {
    automationId: AUTOMATION_ID,
    status: "FAILED_PERMANENT",
    _count: { _all: 3 },
  },
  { automationId: AUTOMATION_ID, status: "SKIPPED_DEDUP", _count: { _all: 1 } },
  {
    automationId: AUTOMATION_ID,
    status: "SKIPPED_RATE_LIMIT",
    _count: { _all: 4 },
  },
  { automationId: AUTOMATION_ID, status: "PENDING", _count: { _all: 5 } },
];

function getRequest() {
  return {
    nextUrl: { searchParams: new URLSearchParams() },
  } as unknown as NextRequest;
}

async function cardAnalytics() {
  const response = await GET(getRequest());
  const body = (await response.json()) as {
    data: { id: string; analytics: Record<string, number> }[];
  };
  return body.data[0].analytics;
}

beforeEach(() => {
  vi.clearAllMocks();
  mockGetCurrentWorkspaceId.mockResolvedValue("workspace_1");
  mockPrisma.automation.findMany.mockResolvedValue([
    {
      id: AUTOMATION_ID,
      workspaceId: "workspace_1",
      // Уже есть — маршрут не пойдёт его дописывать через automation.update.
      reportShareSlug: "share_slug",
      trackedLinks: [],
      chainSteps: [],
    },
  ]);
  mockPrisma.dmLog.groupBy.mockImplementation(
    async (args: { by?: string[] } = {}) =>
      args.by?.includes("status") ? STATUS_ROWS : []
  );
  mockPrisma.linkClick.groupBy.mockResolvedValue([]);
  mockPrisma.subscriberJourney.groupBy.mockResolvedValue([]);
});

describe("GET /api/automations — счётчики карточки кампании", () => {
  it("терминальный отказ FAILED_PERMANENT попадает в «не дошло», а не в никуда", async () => {
    const analytics = await cardAnalytics();

    // 2 обычных FAILED + 3 терминальных. До правки было 2, а три отказа
    // просто исчезали с карточки.
    expect(analytics.failed).toBe(5);
  });

  it("ни одна строка отправки не теряется между корзинами", async () => {
    const analytics = await cardAnalytics();

    expect(analytics.sent).toBe(7);
    expect(analytics.skipped).toBe(5);
    // PENDING сознательно не в корзинах: отправка по нему ещё не решена.
    expect(analytics.sent + analytics.failed + analytics.skipped).toBe(17);
  });

  it("карточка кампании и дашборд дают одинаковые цифры на одних данных", async () => {
    const analytics = await cardAnalytics();
    // Дашборд считает ровно этой функцией (app/api/dashboard/stats/route.ts).
    const dashboard = summarizeDmStatuses(STATUS_ROWS);

    expect({
      sent: analytics.sent,
      failed: analytics.failed,
      skipped: analytics.skipped,
    }).toEqual(dashboard);
  });
});
