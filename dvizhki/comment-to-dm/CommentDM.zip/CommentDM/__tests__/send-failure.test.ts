import { describe, it, expect } from "vitest";
import {
  classifyPermanentSendFailure,
  isPermanentFailureMessage,
  PERMANENT_SEND_FAILURES,
} from "../lib/queue/send-failure";
import { RateLimitError, TokenExpiredError } from "../lib/meta/client";

/**
 * Граница между «повторим» и «повторять нечего». Ошибка на этой границе стоит
 * дорого в обе стороны: лишний перманент = потерянная отправка, которая
 * прошла бы через час; недостающий = 288 упавших джоб на один комментарий.
 */
describe("перманентные отказы отправки", () => {
  it.each([
    ["Meta API Error 100: The requested user cannot be found", "закрыт директ"],
    [
      "Meta API Error 100: The comment is invalid for a private reply",
      "не принимает приватный ответ",
    ],
    [
      "Meta API Error 10: This message is sent outside of allowed window",
      "7-дневное окно",
    ],
  ])("%s - перманентный", (message, reasonFragment) => {
    const entry = classifyPermanentSendFailure(new Error(message));
    expect(entry).not.toBeNull();
    expect(entry?.reason).toContain(reasonFragment);
  });

  it.each([
    "fetch failed: ECONNRESET",
    "Meta API request timed out after 30000ms",
    "Meta API Error 2: Service temporarily unavailable",
    "Unsupported message template",
  ])("%s - временная, право на повтор сохраняется", (message) => {
    expect(classifyPermanentSendFailure(new Error(message))).toBeNull();
  });

  it("лимит и просроченный токен перманентными не считаются никогда", () => {
    // Оба лечатся: первый - временем, второй - переподключением аккаунта.
    // Даже если в тексте окажется знакомый признак, класс важнее текста.
    const rateLimit = new RateLimitError("The requested user cannot be found");
    const tokenExpired = new TokenExpiredError("invalid for a private reply");

    expect(classifyPermanentSendFailure(rateLimit)).toBeNull();
    expect(classifyPermanentSendFailure(tokenExpired)).toBeNull();
  });

  it("не-ошибки и пустые значения ничего не ломают", () => {
    expect(classifyPermanentSendFailure(null)).toBeNull();
    expect(classifyPermanentSendFailure(undefined)).toBeNull();
    expect(classifyPermanentSendFailure({})).toBeNull();
    expect(classifyPermanentSendFailure("")).toBeNull();
  });

  it("та же проверка по записанному errorMessage строки DmLog", () => {
    // Строка в базе несёт человеческую причину И дословный ответ Meta -
    // распознаваться должна по второму.
    expect(
      isPermanentFailureMessage(
        "Instagram больше не принимает приватный ответ на этот комментарий (Meta API Error 100: The comment is invalid for a private reply)"
      )
    ).toBe(true);
    expect(
      isPermanentFailureMessage("Meta API request timed out after 30000ms")
    ).toBe(false);
    expect(isPermanentFailureMessage(null)).toBe(false);
    expect(isPermanentFailureMessage("")).toBe(false);
  });

  it("у каждой причины есть человеческое объяснение владельцу", () => {
    // Текст причины уезжает в errorMessage строки DmLog и на страницу
    // диагностики: пустая или английская тут = владелец не поймёт, что делать.
    expect(PERMANENT_SEND_FAILURES.length).toBeGreaterThan(0);
    for (const entry of PERMANENT_SEND_FAILURES) {
      expect(entry.reason.length).toBeGreaterThan(30);
      expect(entry.reason).toMatch(/[а-яё]/i);
    }
  });
});
