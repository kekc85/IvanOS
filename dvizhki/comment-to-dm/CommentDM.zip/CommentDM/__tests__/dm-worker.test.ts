import { describe, it, expect, vi, beforeEach } from "vitest";

const {
  mockPrisma,
  mockSendPrivateReply,
  mockSendPrivateReplyWithLinkButton,
  mockSendCommentReply,
  mockDecryptToken,
  mockMatchKeywords,
  mockReserveDMSlot,
  mockReserveCommentReplySlot,
  mockQueueAdd,
  mockReserveWorkspaceDMSend,
  mockReleaseWorkspaceDMReservation,
} = vi.hoisted(() => ({
  mockPrisma: {
    automation: {
      findMany: vi.fn(),
      findFirst: vi.fn(),
    },
    dmLog: {
      findUnique: vi.fn(),
      findFirst: vi.fn(),
      upsert: vi.fn(),
      update: vi.fn(),
      create: vi.fn(),
    },
    instagramAccount: {
      findUnique: vi.fn(),
    },
    // Цепочка касаний: lib/chain/journey.ts ходит в ту же (замоканную)
    // призму, поэтому её модель тоже живёт здесь.
    subscriberJourney: {
      findFirst: vi.fn(),
      findUnique: vi.fn(),
      create: vi.fn(),
      upsert: vi.fn(),
      update: vi.fn(),
      updateMany: vi.fn(),
    },
    operationalEvent: {
      create: vi.fn(),
    },
  },
  mockSendPrivateReply: vi.fn(),
  mockSendPrivateReplyWithLinkButton: vi.fn(),
  mockSendCommentReply: vi.fn(),
  mockDecryptToken: vi.fn(),
  mockMatchKeywords: vi.fn(),
  mockReserveDMSlot: vi.fn(),
  mockReserveCommentReplySlot: vi.fn(),
  mockQueueAdd: vi.fn(),
  mockReserveWorkspaceDMSend: vi.fn(),
  mockReleaseWorkspaceDMReservation: vi.fn(),
}));

vi.mock("@/lib/db/client", () => ({
  prisma: mockPrisma,
}));

vi.mock("@/lib/meta/client", () => ({
  sendPrivateReply: mockSendPrivateReply,
  sendPrivateReplyWithLinkButton: mockSendPrivateReplyWithLinkButton,
  sendCommentReply: mockSendCommentReply,
  MetaApiError: class MetaApiError extends Error {
    code: number;
    constructor(
      code: number,
      _subcode: number | undefined,
      _fbTraceId: string | undefined,
      message: string
    ) {
      super(message);
      this.code = code;
      this.name = "MetaApiError";
    }
  },
  TokenExpiredError: class TokenExpiredError extends Error {
    name = "TokenExpiredError";
  },
  RateLimitError: class RateLimitError extends Error {
    name = "RateLimitError";
  },
  // vi.mock перечисляет экспорты поимённо: всё, что цепочка может позвать из
  // транспорта, должно быть здесь, иначе импорт упадёт на undefined.
  isOutsideWindowError: () => false,
}));

vi.mock("@/lib/meta/oauth", () => ({
  decryptToken: mockDecryptToken,
}));

vi.mock("@/lib/utils/keyword-matcher", () => ({
  matchKeywords: mockMatchKeywords,
}));

vi.mock("@/lib/utils/rate-limiter", () => ({
  reserveDMSlot: mockReserveDMSlot,
  reserveCommentReplySlot: mockReserveCommentReplySlot,
}));

vi.mock("@/lib/billing/usage", () => ({
  reserveWorkspaceDMSend: mockReserveWorkspaceDMSend,
  releaseWorkspaceDMReservation: mockReleaseWorkspaceDMReservation,
}));

vi.mock("@/lib/ops/worker-health", () => ({
  recordWorkerAlert: vi.fn(),
}));

vi.mock("@/lib/queue/client", () => ({
  getDMQueue: () => ({
    add: mockQueueAdd,
  }),
  getRedisConnection: vi.fn(),
}));

vi.mock("bullmq", () => {
  function MockWorker(_name: string, processor: unknown) {
    (global as Record<string, unknown>).__dmWorkerProcessor = processor;
    return {
      on: vi.fn(),
      close: vi.fn(),
    };
  }
  return {
    Worker: MockWorker,
  };
});

import { createDMWorker } from "../lib/queue/dm-worker";

const usagePeriodStart = new Date("2026-05-01T00:00:00.000Z");

const mockAutomation = {
  id: "auto_789",
  workspaceId: "workspace_123",
  instagramAccountId: "ig_account_row_1",
  postId: "media_101",
  keywords: ["LINK", "PRICE"],
  dmMessage: "Hey {username}! Here is the link: https://example.com",
  isActive: true,
  wholeWordMatch: true,
  matchAnyPost: false,
  matchAnyWord: false,
  linkButtonLabel: null,
  publicReplyEnabled: false,
  publicReplyMessage: null,
  publicReplyMessages: [],
  instagramAccount: {
    id: "ig_account_row_1",
    instagramId: "ig_456",
    accessToken: "encrypted_token_abc",
    // Well outside the 72h soft-start window, so tests exercise the normal
    // (non-quartered) rate-limit path unless a test overrides this.
    connectedAt: new Date("2020-01-01T00:00:00.000Z"),
  },
  workspace: {
    id: "workspace_123",
  },
  trackedLinks: [],
};

const mockJobData = {
  instagramAccountId: "ig_456",
  commentId: "comment_555",
  commentText: "I want the LINK!",
  commenterId: "commenter_999",
  commenterName: "commenter_user",
  mediaId: "media_101",
};

function getProcessor(): (job: {
  name?: string;
  data: typeof mockJobData | Record<string, unknown>;
  id: string;
  attemptsMade: number;
}) => Promise<void> {
  createDMWorker();
  return (global as Record<string, unknown>).__dmWorkerProcessor as (job: {
    name?: string;
    data: typeof mockJobData | Record<string, unknown>;
    id: string;
    attemptsMade: number;
  }) => Promise<void>;
}

function createMockJob(data = mockJobData) {
  return {
    data,
    id: "job_001",
    attemptsMade: 0,
  };
}

beforeEach(() => {
  vi.clearAllMocks();

  mockPrisma.automation.findMany.mockResolvedValue([mockAutomation]);
  mockPrisma.automation.findFirst.mockResolvedValue(null);
  mockPrisma.dmLog.findUnique.mockResolvedValue(null);
  mockPrisma.dmLog.create.mockResolvedValue({});
  // Two different lookups share findFirst: the cross-campaign private-reply
  // check (keyed on status SENT) and the prior-name lookup. Only the latter
  // should resolve by default, or every comment would look like a duplicate of
  // an already-answered one.
  mockPrisma.dmLog.findFirst.mockImplementation(
    async (args: { where?: { status?: string } } = {}) =>
      args.where?.status === "SENT" ? null : { commenterName: "commenter_user" }
  );
  mockPrisma.dmLog.upsert.mockResolvedValue({});
  mockPrisma.dmLog.update.mockResolvedValue({});
  mockPrisma.instagramAccount.findUnique.mockResolvedValue({
    workspaceId: "workspace_123",
  });
  mockPrisma.subscriberJourney.findFirst.mockResolvedValue(null);
  mockPrisma.subscriberJourney.findUnique.mockResolvedValue(null);
  mockPrisma.subscriberJourney.upsert.mockImplementation(
    async (args: { create?: Record<string, unknown> } = {}) => ({
      id: "journey_1",
      ...args.create,
    })
  );
  mockPrisma.operationalEvent.create.mockResolvedValue({});
  mockDecryptToken.mockReturnValue("decrypted_token");
  mockMatchKeywords.mockReturnValue({ matched: true, matchedKeyword: "LINK" });
  mockReserveWorkspaceDMSend.mockResolvedValue({
    allowed: true,
    reserved: true,
    remaining: 100,
    limit: 2000,
    periodStart: usagePeriodStart,
  });
  mockReserveDMSlot.mockResolvedValue({
    allowed: true,
    currentCount: 11,
    remainingDMs: 179,
    shouldRequeue: false,
    requeueDelayMs: 0,
    shouldSkip: false,
    reserved: true,
  });
  mockReserveCommentReplySlot.mockResolvedValue({
    allowed: true,
    currentCount: 5,
    remainingDMs: 145,
    shouldRequeue: false,
    requeueDelayMs: 0,
    shouldSkip: false,
    reserved: true,
  });
  mockReleaseWorkspaceDMReservation.mockResolvedValue({ count: 1 });
  mockSendPrivateReply.mockResolvedValue({
    recipient_id: "commenter_999",
    message_id: "msg_001",
  });
  mockSendPrivateReplyWithLinkButton.mockResolvedValue({
    recipient_id: "commenter_999",
    message_id: "msg_002",
  });
  mockSendCommentReply.mockResolvedValue({ id: "reply_001" });
});

describe("DM Worker — Full Pipeline", () => {
  it("should send a private reply for a matching comment", async () => {
    const processor = getProcessor();

    await processor(createMockJob());

    expect(mockPrisma.automation.findMany).toHaveBeenCalledWith({
      where: {
        OR: [{ postId: "media_101" }, { matchAnyPost: true }],
        isActive: true,
        instagramAccount: { instagramId: "ig_456" },
      },
      include: {
        instagramAccount: true,
        workspace: true,
        trackedLinks: {
          select: {
            slug: true,
            label: true,
            destinationUrl: true,
          },
          orderBy: { createdAt: "asc" },
        },
      },
      orderBy: { createdAt: "asc" },
    });
    expect(mockMatchKeywords).toHaveBeenCalledWith(
      "I want the LINK!",
      ["LINK", "PRICE"],
      true
    );
    expect(mockReserveWorkspaceDMSend).toHaveBeenCalledWith("workspace_123");
    expect(mockReserveDMSlot).toHaveBeenCalledWith(
      "ig_456",
      0,
      mockAutomation.instagramAccount.connectedAt
    );
    expect(mockDecryptToken).toHaveBeenCalledWith("encrypted_token_abc");
    expect(mockSendPrivateReply).toHaveBeenCalledWith(
      "decrypted_token",
      "ig_456",
      "comment_555",
      "Hey commenter_user! Here is the link: https://example.com"
    );
    expect(mockReleaseWorkspaceDMReservation).not.toHaveBeenCalled();
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith({
      where: {
        automationId_commentId: {
          automationId: "auto_789",
          commentId: "comment_555",
        },
      },
      data: expect.objectContaining({ status: "SENT" }),
    });
  });

  it("should skip when no automations match the media", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([]);
    const processor = getProcessor();

    await processor(createMockJob());

    expect(mockSendPrivateReply).not.toHaveBeenCalled();
    expect(mockPrisma.dmLog.upsert).not.toHaveBeenCalled();
  });

  it("should skip when keywords do not match", async () => {
    mockMatchKeywords.mockReturnValue({ matched: false, matchedKeyword: null });
    const processor = getProcessor();

    await processor(createMockJob());

    expect(mockSendPrivateReply).not.toHaveBeenCalled();
    expect(mockReserveWorkspaceDMSend).not.toHaveBeenCalled();
  });

  it("should skip duplicate comments already sent", async () => {
    mockPrisma.dmLog.findUnique.mockResolvedValue({
      id: "existing_log",
      status: "SENT",
    });
    const processor = getProcessor();

    await processor(createMockJob());

    expect(mockSendPrivateReply).not.toHaveBeenCalled();
    expect(mockReserveWorkspaceDMSend).not.toHaveBeenCalled();
  });

  it("should skip when monthly plan limit is reached", async () => {
    mockReserveWorkspaceDMSend.mockResolvedValue({
      allowed: false,
      reserved: false,
      remaining: 0,
      limit: 100,
      periodStart: usagePeriodStart,
    });

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockReserveDMSlot).not.toHaveBeenCalled();
    expect(mockSendPrivateReply).not.toHaveBeenCalled();
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "SKIPPED_PLAN_LIMIT" }),
      })
    );
  });

  it("should requeue and release monthly usage when rate limited", async () => {
    mockReserveDMSlot.mockResolvedValue({
      allowed: false,
      currentCount: 190,
      remainingDMs: 0,
      shouldRequeue: true,
      requeueDelayMs: 1800000,
      shouldSkip: false,
      reserved: false,
    });

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockReleaseWorkspaceDMReservation).toHaveBeenCalledWith(
      "workspace_123",
      usagePeriodStart
    );
    expect(mockSendPrivateReply).not.toHaveBeenCalled();
    expect(mockQueueAdd).toHaveBeenCalledWith(
      "process-comment",
      expect.objectContaining({
        commentId: "comment_555",
        requeueAttempt: 1,
      }),
      expect.objectContaining({
        delay: 1800000,
        jobId: "comment_ig_456_comment_555_retry_1",
      })
    );
  });

  it("should skip with SKIPPED_RATE_LIMIT after max requeue attempts", async () => {
    mockReserveDMSlot.mockResolvedValue({
      allowed: false,
      currentCount: 190,
      remainingDMs: 0,
      shouldRequeue: false,
      requeueDelayMs: 0,
      shouldSkip: true,
      reserved: false,
    });

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockReleaseWorkspaceDMReservation).toHaveBeenCalledWith(
      "workspace_123",
      usagePeriodStart
    );
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "SKIPPED_RATE_LIMIT" }),
      })
    );
    expect(mockSendPrivateReply).not.toHaveBeenCalled();
  });

  it("should log FAILED, release usage, and re-throw when private reply sending fails", async () => {
    const error = new Error("API Error");
    mockSendPrivateReply.mockRejectedValue(error);

    const processor = getProcessor();

    await expect(processor(createMockJob())).rejects.toThrow("API Error");
    expect(mockReleaseWorkspaceDMReservation).toHaveBeenCalledWith(
      "workspace_123",
      usagePeriodStart
    );
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith({
      where: {
        automationId_commentId: {
          automationId: "auto_789",
          commentId: "comment_555",
        },
      },
      data: expect.objectContaining({
        status: "FAILED",
        errorMessage: "API Error",
      }),
    });
  });

  it("should handle missing access token", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([
      {
        ...mockAutomation,
        instagramAccount: {
          ...mockAutomation.instagramAccount,
          accessToken: null,
        },
      },
    ]);

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockPrisma.dmLog.upsert).toHaveBeenCalledWith(
      expect.objectContaining({
        create: expect.objectContaining({
          status: "FAILED",
          errorMessage: "Нет токена доступа Instagram - переподключи аккаунт в настройках",
        }),
      })
    );
    expect(mockReserveWorkspaceDMSend).not.toHaveBeenCalled();
    expect(mockSendPrivateReply).not.toHaveBeenCalled();
  });

  it("should use 'there' when commenter name is not available", async () => {
    const processor = getProcessor();
    const jobDataWithoutName = {
      instagramAccountId: mockJobData.instagramAccountId,
      commentId: mockJobData.commentId,
      commentText: mockJobData.commentText,
      commenterId: mockJobData.commenterId,
      mediaId: mockJobData.mediaId,
    };

    await processor(createMockJob(jobDataWithoutName as typeof mockJobData));

    expect(mockSendPrivateReply).toHaveBeenCalledWith(
      "decrypted_token",
      "ig_456",
      "comment_555",
      "Hey there! Here is the link: https://example.com"
    );
  });

  it("should deliver tracked links as web_url buttons (one or two)", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([
      {
        ...mockAutomation,
        dmMessage: "Hey {username}! Here is the offer: {link}",
        linkButtonLabel: "Get offer",
        trackedLinks: [
          {
            slug: "abc123",
            label: "Primary campaign link",
            destinationUrl: "https://example.com",
          },
          {
            slug: "def456",
            label: "Book a call",
            destinationUrl: "https://example.com/book",
          },
        ],
      },
    ]);

    const processor = getProcessor();
    await processor(createMockJob());

    // Primary button title comes from linkButtonLabel; the second from its
    // own stored label. Both point at their tracked /r/<slug> URLs.
    expect(mockSendPrivateReplyWithLinkButton).toHaveBeenCalledWith(
      "decrypted_token",
      "ig_456",
      "comment_555",
      "Hey commenter_user! Here is the offer:",
      [
        { title: "Get offer", url: "http://localhost:3000/r/abc123" },
        { title: "Book a call", url: "http://localhost:3000/r/def456" },
      ]
    );
  });
});

describe("DM Worker — one private reply per comment", () => {
  it("should skip a campaign when another already used the comment's private reply", async () => {
    mockPrisma.dmLog.findFirst.mockImplementation(
      async (args: { where?: { status?: string } } = {}) =>
        args.where?.status === "SENT"
          ? { automation: { name: "campaign 1" } }
          : { commenterName: "commenter_user" }
    );

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockSendPrivateReply).not.toHaveBeenCalled();
    expect(mockReserveWorkspaceDMSend).not.toHaveBeenCalled();
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          status: "SKIPPED_DEDUP",
          errorMessage: expect.stringContaining("campaign 1"),
        }),
      })
    );
  });

  it("should not fall back to a plain-text private reply when the window is the problem", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([
      {
        ...mockAutomation,
        trackedLinks: [
          { slug: "abc123", label: null, destinationUrl: "https://example.com" },
        ],
      },
    ]);
    mockSendPrivateReplyWithLinkButton.mockRejectedValue(
      new Error("The comment is invalid for a private reply")
    );

    const processor = getProcessor();
    // Джоба больше НЕ падает: повторять тут нечего, и три попытки BullMQ
    // подряд стоили бы трёх строк ERROR ни за что.
    await processor(createMockJob());

    // A text retry on the same comment would fail identically and overwrite the
    // real reason, so it must not be attempted.
    expect(mockSendPrivateReply).not.toHaveBeenCalled();
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          // Терминальный статус, а не FAILED: единственный приватный ответ на
          // комментарий Meta не выдаёт второй раз никогда.
          status: "FAILED_PERMANENT",
          errorMessage: expect.stringContaining(
            "The comment is invalid for a private reply"
          ),
        }),
      })
    );
  });

  it("should still fall back to plain text when the button template itself is rejected", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([
      {
        ...mockAutomation,
        trackedLinks: [
          { slug: "abc123", label: null, destinationUrl: "https://example.com" },
        ],
      },
    ]);
    mockSendPrivateReplyWithLinkButton.mockRejectedValue(
      new Error("Unsupported message template")
    );

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockSendPrivateReply).toHaveBeenCalled();
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "SENT" }),
      })
    );
  });
});

describe("DM Worker — public reply gated by its own rate limiter", () => {
  const automationWithPublicReply = {
    ...mockAutomation,
    publicReplyEnabled: true,
    publicReplyMessages: ["Sent you a DM! 📩", "Check your inbox! 📬"],
  };

  it("does not post a public reply when the comment-reply rate limit is exhausted", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([automationWithPublicReply]);
    mockReserveCommentReplySlot.mockResolvedValue({
      allowed: false,
      currentCount: 150,
      remainingDMs: 0,
      shouldRequeue: true,
      requeueDelayMs: 1800000,
      shouldSkip: false,
      reserved: false,
    });

    const processor = getProcessor();
    await processor(createMockJob());

    // The limiter was consulted BEFORE any send was attempted — this is the
    // fix for the bug where sendCommentReply fired unconditionally, ahead of
    // (and unrelated to) any rate limit check.
    expect(mockReserveCommentReplySlot).toHaveBeenCalledWith(
      "ig_456",
      0,
      automationWithPublicReply.instagramAccount.connectedAt
    );
    expect(mockSendCommentReply).not.toHaveBeenCalled();
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          publicReplyError: expect.stringContaining("rate limit"),
        }),
      })
    );
    // The DM leg is independent of the public-reply leg and must still go out.
    expect(mockSendPrivateReply).toHaveBeenCalled();
  });

  it("posts the public reply when the comment-reply rate limit allows it", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([automationWithPublicReply]);
    mockReserveCommentReplySlot.mockResolvedValue({
      allowed: true,
      currentCount: 5,
      remainingDMs: 145,
      shouldRequeue: false,
      requeueDelayMs: 0,
      shouldSkip: false,
      reserved: true,
    });

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockSendCommentReply).toHaveBeenCalledWith(
      "decrypted_token",
      "comment_555",
      expect.any(String)
    );
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          publicReplySentAt: expect.any(Date),
          publicReplyError: null,
        }),
      })
    );
  });

  it("never calls the comment-reply limiter when public reply is disabled", async () => {
    // mockAutomation (the default fixture) has publicReplyEnabled: false.
    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockReserveCommentReplySlot).not.toHaveBeenCalled();
    expect(mockSendCommentReply).not.toHaveBeenCalled();
  });
});

describe("DM Worker — цепочка касаний: GATE и журней", () => {
  // Кампания с цепочкой, у которой в базе ЛЕЖАТ tracked-ссылки. API их
  // вместе не сохраняет, но данные могли приехать раньше кода или прямой
  // правкой базы — и именно это должен пережить код отправки.
  const chainAutomation = {
    ...mockAutomation,
    chainEnabled: true,
    linkButtonLabel: "Get offer",
    trackedLinks: [
      {
        slug: "abc123",
        label: "Primary campaign link",
        destinationUrl: "https://example.com",
      },
    ],
  };

  function journeyUpsertCreate() {
    const call = mockPrisma.subscriberJourney.upsert.mock.calls[0]?.[0] as
      | { create?: Record<string, unknown> }
      | undefined;
    return call?.create;
  }

  function eventMessages(): string[] {
    return mockPrisma.operationalEvent.create.mock.calls.map(
      (call: unknown[]) =>
        ((call[0] as { data?: { message?: string } })?.data?.message ?? "") as string
    );
  }

  function events(): { level?: string; message?: string }[] {
    return mockPrisma.operationalEvent.create.mock.calls.map(
      (call: unknown[]) =>
        ((call[0] as { data?: { level?: string; message?: string } })?.data ??
          {}) as { level?: string; message?: string }
    );
  }

  /**
   * Один мок на три разных запроса к журнеям, которые делит findFirst:
   * ретрай-дыра ищет по commentId, гейт повторного входа - по automationId и
   * OR из двух ID, кросс-кампанийный гейт - по commenterId с фильтром живых.
   *
   * Строку priorForCampaign мок отдаёт не безусловно, а по фильтру состояний
   * из САМОГО запроса: иначе тест «SKIPPED не блокирует» проходил бы и с
   * кодом, который этот фильтр не ставит.
   */
  function journeyLookups(rows: {
    priorForCampaign?: (Record<string, unknown> & { state?: string }) | null;
    liveByCommenter?: unknown;
    byComment?: unknown;
  }) {
    mockPrisma.subscriberJourney.findFirst.mockImplementation(
      async (
        args: {
          where?: {
            OR?: unknown;
            state?: { not?: string };
            commenterId?: string;
            commentId?: string;
          };
        } = {}
      ) => {
        if (args.where?.OR) {
          const row = rows.priorForCampaign ?? null;
          if (!row) return null;
          const excluded = args.where.state?.not;
          return excluded && row.state === excluded ? null : row;
        }
        if (args.where?.commenterId) return rows.liveByCommenter ?? null;
        if (args.where?.commentId) return rows.byComment ?? null;
        return null;
      }
    );
  }

  it("шлёт GATE простым текстом даже когда у кампании есть tracked-ссылки", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);

    const processor = getProcessor();
    await processor(createMockJob());

    // Кнопка дала бы человеку что нажать вместо ответа — а без ответа окно
    // Meta не открывается и ни один шаг после GATE не уходит.
    expect(mockSendPrivateReplyWithLinkButton).not.toHaveBeenCalled();
    expect(mockSendPrivateReply).toHaveBeenCalledWith(
      "decrypted_token",
      "ig_456",
      "comment_555",
      "Hey commenter_user! Here is the link: https://example.com"
    );
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "SENT" }),
      })
    );
  });

  it("кладёт в журней recipient_id из ответа Meta, а не ID комментатора", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);
    mockSendPrivateReply.mockResolvedValue({
      recipient_id: "messaging_777",
      message_id: "msg_001",
    });

    const processor = getProcessor();
    await processor(createMockJob());

    expect(journeyUpsertCreate()).toEqual(
      expect.objectContaining({
        state: "GATE_SENT",
        workspaceId: "workspace_123",
        automationId: "auto_789",
        instagramAccountId: "ig_account_row_1",
        subscriberId: "messaging_777",
        commenterId: "commenter_999",
        commentId: "comment_555",
      })
    );
  });

  it("без recipient_id журней всё равно заводится, но с предупреждением", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);
    mockSendPrivateReply.mockResolvedValue({ message_id: "msg_001" });

    const processor = getProcessor();
    await processor(createMockJob());

    expect(journeyUpsertCreate()).toEqual(
      expect.objectContaining({ subscriberId: "commenter_999" })
    );
    expect(eventMessages().join("\n")).toContain("не вернула recipient_id");
  });

  it("повторный комментарий при живой цепочке: SKIPPED без второй отправки", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);
    mockPrisma.subscriberJourney.findFirst.mockImplementation(
      async (args: { where?: { commenterId?: string } } = {}) =>
        args.where?.commenterId
          ? {
              id: "journey_live",
              automationId: "auto_other",
              state: "ACTIVE",
              automation: { name: "Кампания 1" },
            }
          : null
    );

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockSendPrivateReply).not.toHaveBeenCalled();
    expect(mockSendPrivateReplyWithLinkButton).not.toHaveBeenCalled();
    // Квоту рабочего пространства на пропущенную отправку не тратим.
    expect(mockReserveWorkspaceDMSend).not.toHaveBeenCalled();
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          status: "SKIPPED_DEDUP",
          errorMessage: expect.stringContaining("Кампания 1"),
        }),
      })
    );
    expect(journeyUpsertCreate()).toEqual(
      expect.objectContaining({ state: "SKIPPED" })
    );
  });

  it("ретрай после SENT дочиняет журней и не шлёт DM повторно", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);
    mockPrisma.dmLog.findUnique.mockResolvedValue({
      id: "existing_log",
      status: "SENT",
    });
    // Журнея по этому комментарию нет: между отправкой и записью оборвалось.
    mockPrisma.subscriberJourney.findFirst.mockResolvedValue(null);

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockSendPrivateReply).not.toHaveBeenCalled();
    expect(journeyUpsertCreate()).toEqual(
      expect.objectContaining({
        state: "GATE_SENT",
        subscriberId: "commenter_999",
        commenterId: "commenter_999",
        commentId: "comment_555",
      })
    );
    expect(eventMessages().join("\n")).toContain("восстановлен ретраем");
  });

  it("ретрай после SENT с уже существующим журнеем ничего не пишет", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);
    mockPrisma.dmLog.findUnique.mockResolvedValue({
      id: "existing_log",
      status: "SENT",
    });
    mockPrisma.subscriberJourney.findFirst.mockResolvedValue({
      id: "journey_1",
    });

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockPrisma.subscriberJourney.upsert).not.toHaveBeenCalled();
    expect(mockSendPrivateReply).not.toHaveBeenCalled();
  });

  it("повторный коммент после завершённой цепочки: SKIPPED, GATE не уходит", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);
    journeyLookups({
      priorForCampaign: {
        id: "journey_done",
        automationId: "auto_789",
        state: "DONE",
        automation: { name: "Цепочка про запуск" },
      },
    });

    const processor = getProcessor();
    await processor(createMockJob());

    // Второй GATE ушёл бы в пустоту: опрос диалогов сверяет треды только с
    // живыми журнеями и ответ на него никто бы не услышал.
    expect(mockSendPrivateReply).not.toHaveBeenCalled();
    expect(mockSendPrivateReplyWithLinkButton).not.toHaveBeenCalled();
    expect(mockReserveWorkspaceDMSend).not.toHaveBeenCalled();
    expect(mockReserveDMSlot).not.toHaveBeenCalled();

    // Гейт спрашивал именно ЛЮБОЙ журней этой кампании по обоим ID человека.
    expect(mockPrisma.subscriberJourney.findFirst).toHaveBeenCalledWith(
      expect.objectContaining({
        where: {
          automationId: "auto_789",
          state: { not: "SKIPPED" },
          OR: [
            { commenterId: "commenter_999" },
            { subscriberId: "commenter_999" },
          ],
        },
      })
    );
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          status: "SKIPPED_DEDUP",
          errorMessage: expect.stringContaining("состояние DONE"),
        }),
      })
    );
    // Штатный отказ по правилу, а не поломка.
    expect(events()).toContainEqual(
      expect.objectContaining({
        level: "INFO",
        message: expect.stringContaining("повторный вход закрыт"),
      })
    );
    // Прошлую цепочку не трогаем ни одним полем: DONE остаётся DONE.
    expect(mockPrisma.subscriberJourney.upsert).not.toHaveBeenCalled();
    expect(mockPrisma.subscriberJourney.update).not.toHaveBeenCalled();
  });

  it("повторная джоба по уже существующей строке DmLog журнал не заливает", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);
    // Строка по этому комментарию уже есть - значит про этот отказ владельцу
    // уже написали. Опрос комментариев теперь такие строки и не переочередует,
    // но джоба может зайти второй раз и без него (ретрай очереди, гонка
    // клейма), а INFO на каждый заход - это те самые сотни одинаковых строк.
    mockPrisma.dmLog.findUnique.mockResolvedValue({
      id: "existing_log",
      status: "SKIPPED_DEDUP",
      dmSentAt: null,
      publicReplySentAt: null,
    });
    journeyLookups({
      priorForCampaign: {
        id: "journey_done",
        automationId: "auto_789",
        state: "DONE",
        automation: { name: "Цепочка про запуск" },
      },
    });

    const processor = getProcessor();
    await processor(createMockJob());

    // Отказ прежний и виден в самой строке DmLog.
    expect(mockSendPrivateReply).not.toHaveBeenCalled();
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "SKIPPED_DEDUP" }),
      })
    );
    expect(eventMessages().join("\n")).not.toContain("повторный вход закрыт");
  });

  it.each(["EXPIRED", "FAILED", "STOPPED"])(
    "повторный коммент после журнея в состоянии %s тоже закрыт",
    async (state) => {
      mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);
      journeyLookups({
        priorForCampaign: {
          id: "journey_old",
          automationId: "auto_789",
          state,
          automation: { name: "Цепочка про запуск" },
        },
      });

      const processor = getProcessor();
      await processor(createMockJob());

      expect(mockSendPrivateReply).not.toHaveBeenCalled();
      expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            status: "SKIPPED_DEDUP",
            errorMessage: expect.stringContaining(`состояние ${state}`),
          }),
        })
      );
    }
  );

  it("журней SKIPPED этой же кампании вход НЕ закрывает: GATE уходит", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);
    // SKIPPED значит, что GATE человеку не уходил: в прошлый раз гейт отказал
    // из-за живой цепочки соседней кампании. Он попросил материал и не
    // получил ничего - запирать его на срок хранения журнея не за что.
    journeyLookups({
      priorForCampaign: {
        id: "journey_skipped",
        automationId: "auto_789",
        state: "SKIPPED",
        automation: { name: "Цепочка про запуск" },
      },
      // Соседняя цепочка к этому моменту закончилась, живых журнеев нет.
      liveByCommenter: null,
    });

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockSendPrivateReply).toHaveBeenCalledWith(
      "decrypted_token",
      "ig_456",
      "comment_555",
      "Hey commenter_user! Here is the link: https://example.com"
    );
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "SENT" }),
      })
    );
    expect(journeyUpsertCreate()).toEqual(
      expect.objectContaining({ state: "GATE_SENT" })
    );
  });

  it("SKIPPED не отменяет кросс-кампанийный гейт: живая цепочка соседней всё ещё держит", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);
    journeyLookups({
      priorForCampaign: {
        id: "journey_skipped",
        automationId: "auto_789",
        state: "SKIPPED",
        automation: { name: "Цепочка про запуск" },
      },
      liveByCommenter: {
        id: "journey_live",
        automationId: "auto_other",
        state: "ACTIVE",
        automation: { name: "Кампания 1" },
      },
    });

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockSendPrivateReply).not.toHaveBeenCalled();
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          status: "SKIPPED_DEDUP",
          errorMessage: expect.stringContaining("Кампания 1"),
        }),
      })
    );
  });

  it("живой GATE_SENT ДРУГОЙ кампании закрывает вход прежней причиной", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);
    // По этой кампании человек не ходил, а по соседней сейчас ждёт ответа.
    journeyLookups({
      priorForCampaign: null,
      liveByCommenter: {
        id: "journey_live",
        automationId: "auto_other",
        state: "GATE_SENT",
        automation: { name: "Кампания 1" },
      },
    });

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockSendPrivateReply).not.toHaveBeenCalled();
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          status: "SKIPPED_DEDUP",
          errorMessage: expect.stringContaining("Кампания 1"),
        }),
      })
    );
    expect(journeyUpsertCreate()).toEqual(
      expect.objectContaining({ state: "SKIPPED" })
    );
  });

  it("Meta «приватный ответ уже израсходован» + строка PENDING с отметкой вызова: GATE доставлен, журней чиним", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);
    // Улика прошлой отправки: dmAttemptedAt проставлен - значит воркер дошёл
    // до Meta и умер между ушедшим GATE и записью SENT, строка осталась
    // PENDING. Опрос принёс комментарий заново, а второго приватного ответа
    // Meta не даёт. Один PENDING без отметки уликой бы не был: его пишет
    // начало каждого захода (см. тест про переочередь ниже).
    mockPrisma.dmLog.findUnique.mockResolvedValue({
      id: "existing_log",
      status: "PENDING",
      dmAttemptedAt: new Date("2026-08-09T09:00:00.000Z"),
      dmSentAt: null,
      publicReplySentAt: null,
    });
    mockSendPrivateReply.mockRejectedValue(
      new Error("The comment is invalid for a private reply")
    );

    const processor = getProcessor();
    // Падение увело бы строку в FAILED, и журней не завёлся бы НИКОГДА.
    await processor(createMockJob());

    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "SENT" }),
      })
    );
    expect(mockPrisma.dmLog.update).not.toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "FAILED" }),
      })
    );
    // recipient_id взять неоткуда - ответа Meta нет, пишем ID комментатора.
    expect(journeyUpsertCreate()).toEqual(
      expect.objectContaining({
        state: "GATE_SENT",
        subscriberId: "commenter_999",
        commenterId: "commenter_999",
        commentId: "comment_555",
      })
    );
    expect(eventMessages().join("\n")).toContain(
      "восстановлен после сбоя записи"
    );
    // Сообщение человеку доставлено - месячную квоту не возвращаем.
    expect(mockReleaseWorkspaceDMReservation).not.toHaveBeenCalled();
  });

  it("FAILED после оборванного вызова С отметкой обращения - улика: GATE спасён, журней восстановлен", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);
    // Ровно тот сценарий, который нашёл скептик: у вызовов к Meta стоит
    // 30-секундный дедлайн. Meta успела ДОСТАВИТЬ GATE, а наш fetch умер по
    // таймауту - строка легла FAILED, dmSentAt пустой, но dmAttemptedAt
    // проставлен ПЕРЕД вызовом и пережил падение. Без этой ветки человек с
    // полученным GATE отвечал бы в пустоту вечно.
    mockPrisma.dmLog.findUnique.mockResolvedValue({
      id: "existing_log",
      status: "FAILED",
      dmAttemptedAt: new Date("2026-08-09T09:00:00.000Z"),
      dmSentAt: null,
      publicReplySentAt: null,
      errorMessage: "Meta API request timed out after 30000ms",
    });
    mockSendPrivateReply.mockRejectedValue(
      new Error("The comment is invalid for a private reply")
    );

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "SENT" }),
      })
    );
    expect(journeyUpsertCreate()).toEqual(
      expect.objectContaining({
        state: "GATE_SENT",
        subscriberId: "commenter_999",
        commenterId: "commenter_999",
        commentId: "comment_555",
      })
    );
    expect(eventMessages().join("\n")).toContain(
      "восстановлен после сбоя записи"
    );
  });

  it("FAILED с причиной «приватный ответ уже израсходован» уликой НЕ считается", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);
    // Эту строку оставил прошлый заход, который сам улики не нашёл и честно
    // отказал. Считать её уликой значит выдать SENT и журней человеку,
    // которому никогда ничего не уходило, - и заодно запереть ему повторный
    // вход на срок хранения журнея.
    mockPrisma.dmLog.findUnique.mockResolvedValue({
      id: "existing_log",
      status: "FAILED",
      // Отметка обращения к Meta есть - и всё равно не улика: причина отказа
      // из перманентного класса. Иначе первый же честный отказ становился бы
      // на втором заходе фальшивой доставкой.
      dmAttemptedAt: new Date("2026-08-09T09:00:00.000Z"),
      dmSentAt: null,
      publicReplySentAt: null,
      errorMessage:
        "Instagram больше не принимает приватный ответ на этот комментарий - он удалён либо единственный разрешённый ответ уже израсходован. Второго Instagram не даёт никогда (Meta API Error 100: The comment is invalid for a private reply)",
    });
    mockSendPrivateReply.mockRejectedValue(
      new Error("The comment is invalid for a private reply")
    );

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockPrisma.dmLog.update).not.toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "SENT" }),
      })
    );
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "FAILED_PERMANENT" }),
      })
    );
    expect(mockPrisma.subscriberJourney.upsert).not.toHaveBeenCalled();
    expect(eventMessages().join("\n")).not.toContain(
      "восстановлен после сбоя записи"
    );
  });

  /**
   * Три теста ниже закрывают дыру, из-за которой уликой служил СТАТУС строки.
   * FAILED и PENDING оба пишутся ДО всякой сети: первый - когда токена нет
   * или он не расшифровался, второй - в начале каждого захода и при
   * переочереди по часовому лимиту. На удалённом комментарии Meta отвечает
   * «invalid for a private reply» кому угодно, и по такой «улике» человек,
   * которому мы никогда не звонили, получал фальшивый SENT, журней-призрак и
   * запертый повторный вход на весь срок хранения журнея.
   */
  it("FAILED «Нет токена доступа» уликой не считается: до Meta заход не дошёл", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);
    // Строку оставил заход, у которого не было токена: он вышел на строке 392
    // dm-worker.ts, ни одного байта в сторону Meta не отправив. dmAttemptedAt
    // поэтому пуст - и это единственное, что здесь важно.
    mockPrisma.dmLog.findUnique.mockResolvedValue({
      id: "existing_log",
      status: "FAILED",
      dmAttemptedAt: null,
      dmSentAt: null,
      publicReplySentAt: null,
      errorMessage:
        "Нет токена доступа Instagram - переподключи аккаунт в настройках",
    });
    // Токен уже переподключили, заход идёт до конца - и упирается в удалённый
    // комментарий.
    mockSendPrivateReply.mockRejectedValue(
      new Error("The comment is invalid for a private reply")
    );

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockPrisma.dmLog.update).not.toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "SENT" }),
      })
    );
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "FAILED_PERMANENT" }),
      })
    );
    expect(mockPrisma.subscriberJourney.upsert).not.toHaveBeenCalled();
    expect(eventMessages().join("\n")).not.toContain(
      "восстановлен после сбоя записи"
    );
  });

  it("PENDING от переочереди по часовому лимиту уликой не считается", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);
    // Ровно та строка, которую пишет ветка requeue в dm-worker.ts: статус
    // PENDING, текст про запланированный повтор. Отправки не было - упёрлись
    // в лимит ДО вызова Meta, поэтому dmAttemptedAt пуст.
    mockPrisma.dmLog.findUnique.mockResolvedValue({
      id: "existing_log",
      status: "PENDING",
      dmAttemptedAt: null,
      dmSentAt: null,
      publicReplySentAt: null,
      errorMessage: "Упёрлись в часовой лимит, повтор запланирован",
    });
    mockSendPrivateReply.mockRejectedValue(
      new Error("The comment is invalid for a private reply")
    );

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockPrisma.dmLog.update).not.toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "SENT" }),
      })
    );
    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "FAILED_PERMANENT" }),
      })
    );
    expect(mockPrisma.subscriberJourney.upsert).not.toHaveBeenCalled();
  });

  it("отметка обращения к Meta ложится ДО вызова отправки, а не после", async () => {
    // Смысл поля целиком в порядке записи: заход, который умрёт ВНУТРИ
    // отправки, ничего после вызова записать уже не сможет. Если отметка
    // ляжет после - спасать будет нечем, и вся ветка выше станет мёртвой.
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);

    const processor = getProcessor();
    await processor(createMockJob());

    const attemptIndex = mockPrisma.dmLog.update.mock.calls.findIndex(
      (call: unknown[]) =>
        (call[0] as { data?: { dmAttemptedAt?: unknown } })?.data
          ?.dmAttemptedAt instanceof Date
    );
    expect(attemptIndex).toBeGreaterThanOrEqual(0);
    expect(
      mockPrisma.dmLog.update.mock.invocationCallOrder[attemptIndex]
    ).toBeLessThan(mockSendPrivateReply.mock.invocationCallOrder[0]);
  });

  it("тот же ответ Meta на ПЕРВОМ заходе - честный FAILED, без журнея", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);
    // Строки по этому комментарию не было: её завёл этот самый заход. Значит
    // улики, что единственный приватный ответ израсходовали МЫ, нет вовсе -
    // сама Meta эту ошибку выдаёт и на удалённый комментарий, и на чужую
    // ещё не записанную отправку. Спасать тут нечего: SENT и журней достались
    // бы человеку, который не получил ничего, да ещё и заперли бы ему
    // повторный вход на срок хранения журнея.
    mockPrisma.dmLog.findUnique.mockResolvedValue(null);
    mockSendPrivateReply.mockRejectedValue(
      new Error("The comment is invalid for a private reply")
    );

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          // Отказ честный И терминальный: второго приватного ответа на этот
          // комментарий Meta не даст, гонять его 144 часа не за чем.
          status: "FAILED_PERMANENT",
          errorMessage: expect.stringContaining(
            "The comment is invalid for a private reply"
          ),
        }),
      })
    );
    expect(mockPrisma.dmLog.update).not.toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "SENT" }),
      })
    );
    // Журнея нет: цепочку не заводим человеку, которому ничего не ушло.
    expect(mockPrisma.subscriberJourney.upsert).not.toHaveBeenCalled();
    expect(eventMessages().join("\n")).not.toContain(
      "восстановлен после сбоя записи"
    );
    // Отправки не было - месячную квоту возвращаем.
    expect(mockReleaseWorkspaceDMReservation).toHaveBeenCalledWith(
      "workspace_123",
      usagePeriodStart
    );
  });

  it("временная ошибка Meta на GATE по-прежнему роняет джобу в FAILED", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([chainAutomation]);
    // Пятисотка Meta - ровно тот класс, ради которого повтор и существует:
    // через пять минут та же отправка обычно проходит.
    mockSendPrivateReply.mockRejectedValue(
      new Error("Meta API Error 2: Service temporarily unavailable")
    );

    const processor = getProcessor();
    await expect(processor(createMockJob())).rejects.toThrow(
      "Service temporarily unavailable"
    );

    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "FAILED" }),
      })
    );
    expect(mockPrisma.dmLog.update).not.toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "FAILED_PERMANENT" }),
      })
    );
    expect(mockPrisma.subscriberJourney.upsert).not.toHaveBeenCalled();
  });

  it("кампания без цепочки журнеев не заводит и в их таблицу не ходит", async () => {
    // mockAutomation (дефолтная фикстура) идёт без chainEnabled.
    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockSendPrivateReply).toHaveBeenCalled();
    expect(mockPrisma.subscriberJourney.findFirst).not.toHaveBeenCalled();
    expect(mockPrisma.subscriberJourney.upsert).not.toHaveBeenCalled();
  });
});

/**
 * Терминальный отказ отправки. До него комментарий, который не уйдёт НИКОГДА
 * (у человека закрыт директ, комментарий удалён), оставался строкой FAILED -
 * а FAILED опрос комментариев обработанным не считает. Итог: ~288 упавших
 * джоб и столько же строк ERROR за 144 часа окна опроса на один комментарий,
 * и лента диагностики (20 строк) вычищена полностью.
 */
describe("DM Worker — терминальный отказ отправки (FAILED_PERMANENT)", () => {
  function events(): { level?: string; message?: string }[] {
    return mockPrisma.operationalEvent.create.mock.calls.map(
      (call: unknown[]) =>
        ((call[0] as { data?: { level?: string; message?: string } })?.data ??
          {}) as { level?: string; message?: string }
    );
  }

  it("«requested user cannot be found»: терминальный статус, джоба не падает", async () => {
    mockSendPrivateReply.mockRejectedValue(
      new Error("Meta API Error 100: The requested user cannot be found")
    );

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          status: "FAILED_PERMANENT",
          // Человеческая причина + дословный ответ Meta: первое объясняет,
          // второе даёт опознать тот же отказ потом.
          errorMessage: expect.stringContaining("закрыт директ"),
        }),
      })
    );
    // Квоту рабочего пространства возвращаем - сообщение не ушло.
    expect(mockReleaseWorkspaceDMReservation).toHaveBeenCalledWith(
      "workspace_123",
      usagePeriodStart
    );
  });

  it("владелец видит причину в журнале одной понятной строкой", async () => {
    mockSendPrivateReply.mockRejectedValue(
      new Error("Meta API Error 100: The requested user cannot be found")
    );

    const processor = getProcessor();
    await processor(createMockJob());

    expect(events()).toContainEqual(
      expect.objectContaining({
        level: "WARNING",
        message: expect.stringContaining(
          "Отправка по комментарию невозможна и повторяться не будет"
        ),
      })
    );
  });

  it("по терминальной строке следующий заход не шлёт ничего", async () => {
    mockPrisma.dmLog.findUnique.mockResolvedValue({
      id: "existing_log",
      status: "FAILED_PERMANENT",
      dmSentAt: null,
      publicReplySentAt: null,
      errorMessage: "Instagram не находит этого человека в переписке",
    });

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockSendPrivateReply).not.toHaveBeenCalled();
    expect(mockSendPrivateReplyWithLinkButton).not.toHaveBeenCalled();
    // Ни новой попытки, ни возврата строки в PENDING: она терминальная.
    expect(mockPrisma.dmLog.update).not.toHaveBeenCalled();
    expect(mockReserveWorkspaceDMSend).not.toHaveBeenCalled();
    expect(mockReserveDMSlot).not.toHaveBeenCalled();
  });

  it("публичный ответ по терминальной строке всё ещё имеет право на повтор", async () => {
    mockPrisma.automation.findMany.mockResolvedValue([
      {
        ...mockAutomation,
        publicReplyEnabled: true,
        publicReplyMessages: ["Ответил в директ 📩"],
      },
    ]);
    mockPrisma.dmLog.findUnique.mockResolvedValue({
      id: "existing_log",
      status: "FAILED_PERMANENT",
      dmSentAt: null,
      // Публичный ответ в прошлый раз не лёг - у него своя нога и свой повтор.
      publicReplySentAt: null,
      errorMessage: "Instagram не находит этого человека в переписке",
    });

    const processor = getProcessor();
    await processor(createMockJob());

    expect(mockSendCommentReply).toHaveBeenCalled();
    expect(mockSendPrivateReply).not.toHaveBeenCalled();
  });

  it("временная ошибка терминальной не становится: FAILED и падение джобы", async () => {
    mockSendPrivateReply.mockRejectedValue(
      new Error("fetch failed: ECONNRESET")
    );

    const processor = getProcessor();
    await expect(processor(createMockJob())).rejects.toThrow("ECONNRESET");

    expect(mockPrisma.dmLog.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "FAILED" }),
      })
    );
    expect(mockPrisma.dmLog.update).not.toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "FAILED_PERMANENT" }),
      })
    );
  });
});
