/**
 * Retention Config — Unit Tests
 *
 * Pure-function tests for the cutoff math in lib/gdpr/retention-config.ts.
 * The one property that matters most: DmLog's cutoff can never move inside
 * Meta's private-reply window, no matter how aggressively a self-hoster
 * configures DM_LOG_RETENTION_DAYS — DmLog doubles as the polling
 * reconciler's dedup set (see worker/dm-worker.ts and
 * lib/polling/comment-reconciler.ts), so a cleanup run inside that window
 * causes a duplicate DM.
 */

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  CHAIN_JOURNEY_MIN_RETENTION_DAYS,
  DEFAULT_CHAIN_JOURNEY_RETENTION_DAYS,
  DEFAULT_DM_LOG_RETENTION_DAYS,
  DEFAULT_LINK_CLICK_RETENTION_DAYS,
  DEFAULT_OPERATIONAL_EVENT_RETENTION_DAYS,
  DM_LOG_SAFETY_BUFFER_HOURS,
  getChainJourneyCutoff,
  getChainJourneyRetentionDays,
  getDmLogCutoff,
  getDmLogDedupSafeCutoff,
  getDmLogRetentionHours,
  getLinkClickCutoff,
  getOperationalEventCutoff,
} from "../lib/gdpr/retention-config";

const NOW = new Date("2026-08-07T12:00:00.000Z");

beforeEach(() => {
  vi.unstubAllEnvs();
});

afterEach(() => {
  vi.unstubAllEnvs();
});

describe("default cutoffs", () => {
  it("DmLog defaults to 180 days back", () => {
    const cutoff = getDmLogCutoff(NOW);
    const expected = new Date(NOW);
    expected.setUTCDate(expected.getUTCDate() - DEFAULT_DM_LOG_RETENTION_DAYS);
    expect(cutoff.getTime()).toBe(expected.getTime());
  });

  it("LinkClick is shorter than DmLog", () => {
    expect(DEFAULT_LINK_CLICK_RETENTION_DAYS).toBeLessThan(
      DEFAULT_DM_LOG_RETENTION_DAYS
    );
    const cutoff = getLinkClickCutoff(NOW);
    const expected = new Date(NOW);
    expected.setUTCDate(
      expected.getUTCDate() - DEFAULT_LINK_CLICK_RETENTION_DAYS
    );
    expect(cutoff.getTime()).toBe(expected.getTime());
  });

  it("OperationalEvent is the shortest of the three configurable windows", () => {
    expect(DEFAULT_OPERATIONAL_EVENT_RETENTION_DAYS).toBeLessThanOrEqual(
      DEFAULT_LINK_CLICK_RETENTION_DAYS
    );
    const cutoff = getOperationalEventCutoff(NOW);
    const expected = new Date(NOW);
    expected.setUTCDate(
      expected.getUTCDate() - DEFAULT_OPERATIONAL_EVENT_RETENTION_DAYS
    );
    expect(cutoff.getTime()).toBe(expected.getTime());
  });
});

describe("env overrides", () => {
  it("honors DM_LOG_RETENTION_DAYS when set (and it is above the floor)", () => {
    vi.stubEnv("DM_LOG_RETENTION_DAYS", "10");
    const cutoff = getDmLogCutoff(NOW);
    expect(cutoff.toISOString()).toBe("2026-07-28T12:00:00.000Z");
  });

  it("falls back to the default on an invalid override", () => {
    vi.stubEnv("LINK_CLICK_RETENTION_DAYS", "not-a-number");
    const cutoff = getLinkClickCutoff(NOW);
    const expected = new Date(NOW);
    expected.setUTCDate(
      expected.getUTCDate() - DEFAULT_LINK_CLICK_RETENTION_DAYS
    );
    expect(cutoff.getTime()).toBe(expected.getTime());
  });

  it("falls back to the default on a negative override", () => {
    vi.stubEnv("LINK_CLICK_RETENTION_DAYS", "-5");
    const cutoff = getLinkClickCutoff(NOW);
    const expected = new Date(NOW);
    expected.setUTCDate(
      expected.getUTCDate() - DEFAULT_LINK_CLICK_RETENTION_DAYS
    );
    expect(cutoff.getTime()).toBe(expected.getTime());
  });
});

describe("DmLog dedup floor — the Meta reply-window guard", () => {
  it("uses the default retention when it is already past the floor", () => {
    // Default is 180 days (4320h), well past 168h + 24h buffer = 192h.
    const hours = getDmLogRetentionHours();
    expect(hours).toBe(DEFAULT_DM_LOG_RETENTION_DAYS * 24);
  });

  it("clamps up to the window-plus-buffer floor when configured shorter", () => {
    // META_PRIVATE_REPLY_WINDOW_HOURS is read once at module load (its default
    // is 168h, unset in this test environment), so the floor here is the
    // real default window, not a value stubbed after the fact.
    vi.stubEnv("DM_LOG_RETENTION_DAYS", "1"); // 24h — far below the floor
    const hours = getDmLogRetentionHours();
    expect(hours).toBe(168 + DM_LOG_SAFETY_BUFFER_HOURS);
  });

  it("clamps to zero-configured retention as well — the floor always wins", () => {
    vi.stubEnv("DM_LOG_RETENTION_DAYS", "0");
    const hours = getDmLogRetentionHours();
    expect(hours).toBeGreaterThanOrEqual(168 + DM_LOG_SAFETY_BUFFER_HOURS);
  });

  it("never produces a cutoff newer than now minus Meta's window, however low DM_LOG_RETENTION_DAYS is set", () => {
    vi.stubEnv("DM_LOG_RETENTION_DAYS", "0");
    const cutoff = getDmLogCutoff(NOW);
    const metaWindowCutoff = new Date(NOW.getTime() - 168 * 60 * 60 * 1000);
    expect(cutoff.getTime()).toBeLessThanOrEqual(metaWindowCutoff.getTime());
  });

  it("respects a longer configured retention above the floor", () => {
    vi.stubEnv("DM_LOG_RETENTION_DAYS", "300");
    const hours = getDmLogRetentionHours();
    expect(hours).toBe(300 * 24);
  });
});

describe("getDmLogDedupSafeCutoff — floor only, ignores DM_LOG_RETENTION_DAYS", () => {
  it("sits exactly at the window-plus-buffer floor regardless of configured retention", () => {
    // Unlike getDmLogCutoff (routine cleanup), the GDPR erasure path wants
    // the earliest safe moment, not the (usually much longer) configured
    // audit retention.
    vi.stubEnv("DM_LOG_RETENTION_DAYS", "300");
    const cutoff = getDmLogDedupSafeCutoff(NOW);
    const expected = new Date(
      NOW.getTime() - (168 + DM_LOG_SAFETY_BUFFER_HOURS) * 60 * 60 * 1000
    );
    expect(cutoff.getTime()).toBe(expected.getTime());
  });

  it("is never earlier (further back) than the routine cleanup cutoff", () => {
    const dedupCutoff = getDmLogDedupSafeCutoff(NOW);
    const cleanupCutoff = getDmLogCutoff(NOW);
    // getDmLogCutoff uses max(configuredHours, floorHours), so its cutoff
    // reaches at least as far back as the floor-only dedup cutoff — the
    // dedup cutoff's timestamp is always the same or more recent.
    expect(dedupCutoff.getTime()).toBeGreaterThanOrEqual(cleanupCutoff.getTime());
  });
});

describe("chain journey retention — the re-entry ban window", () => {
  it("defaults to 30 days, which is also how long re-entry stays closed", () => {
    expect(getChainJourneyRetentionDays()).toBe(
      DEFAULT_CHAIN_JOURNEY_RETENTION_DAYS
    );
    const cutoff = getChainJourneyCutoff(NOW);
    const expected = new Date(NOW);
    expected.setUTCDate(
      expected.getUTCDate() - DEFAULT_CHAIN_JOURNEY_RETENTION_DAYS
    );
    expect(cutoff.getTime()).toBe(expected.getTime());
  });

  it("honors a shorter override that is still above the minimum", () => {
    vi.stubEnv("CHAIN_JOURNEY_RETENTION_DAYS", "7");
    expect(getChainJourneyRetentionDays()).toBe(7);
  });

  it("honors a longer override", () => {
    vi.stubEnv("CHAIN_JOURNEY_RETENTION_DAYS", "90");
    expect(getChainJourneyRetentionDays()).toBe(90);
  });

  it("refuses to go below the two-day minimum, so an operator cannot shred live chains", () => {
    vi.stubEnv("CHAIN_JOURNEY_RETENTION_DAYS", "0");
    expect(getChainJourneyRetentionDays()).toBe(CHAIN_JOURNEY_MIN_RETENTION_DAYS);

    // The concrete guarantee behind that number: an unanswered GATE lives 48h
    // before the chain itself closes it, so the cutoff must never reach into
    // the last two days.
    const cutoff = getChainJourneyCutoff(NOW);
    const twoDaysBack = new Date(NOW.getTime() - 48 * 60 * 60 * 1000);
    expect(cutoff.getTime()).toBeLessThanOrEqual(twoDaysBack.getTime());
  });

  it("falls back to the default on an invalid or negative override", () => {
    vi.stubEnv("CHAIN_JOURNEY_RETENTION_DAYS", "not-a-number");
    expect(getChainJourneyRetentionDays()).toBe(
      DEFAULT_CHAIN_JOURNEY_RETENTION_DAYS
    );
    vi.stubEnv("CHAIN_JOURNEY_RETENTION_DAYS", "-5");
    expect(getChainJourneyRetentionDays()).toBe(
      DEFAULT_CHAIN_JOURNEY_RETENTION_DAYS
    );
  });

  it("has no DmLog-style Meta-window floor: it is a product window, not a send-safety one", () => {
    vi.stubEnv("CHAIN_JOURNEY_RETENTION_DAYS", "3");
    const cutoff = getChainJourneyCutoff(NOW);
    const metaWindowCutoff = new Date(NOW.getTime() - 168 * 60 * 60 * 1000);
    // Three days back is *newer* than Meta's 168h window — allowed here,
    // unlike DmLog, because a journey is not the comment sweep's dedup marker.
    expect(cutoff.getTime()).toBeGreaterThan(metaWindowCutoff.getTime());
  });
});
