/**
 * Чтение и запись .env — контракт, общий для deploy/lib.sh и install.sh.
 *
 * Почему этот файл существует. И `node --env-file` (так запускается воркер,
 * см. deploy/commentdm-worker.service), и systemd EnvironmentFile принимают
 * строку настройки с ведущими пробелами, с префиксом `export ` и со
 * значением в кавычках. Прежний разбор в обоих скриптах видел ключ, только
 * если строка начиналась ровно с первой колонки — `grep -E "^KEY="`.
 *
 * Отсюда авария: ученик (или его Claude Code, что документация проекта прямо
 * поощряет) один раз переформатировал .env с отступом. Повторный install.sh
 * ключа не находил и дописывал ВТОРУЮ строку с новым случайным значением, а
 * при дублях выигрывает последняя. Для ENCRYPTION_KEY это молчаливая потеря
 * всех подключённых аккаунтов Instagram (расшифровать токены больше нечем),
 * для SESSION_SECRET / DATABASE_URL / OWNER_PASSWORD — потеря доступа.
 *
 * install.sh держит СВОЮ копию этих функций и не может подключить
 * deploy/lib.sh (он обязан работать одним скачанным файлом до того, как
 * репозиторий появится на диске — см. resolve_install_dir). Поэтому каждый
 * сценарий ниже гоняется против обеих реализаций: разъехаться они не должны.
 * install.sh подключается с COMMENTDM_INSTALL_SH_LIB_ONLY=1 — единственным
 * флагом, который даёт подключить файл и не запустить установку.
 */
import { execFileSync } from "node:child_process";
import { mkdtempSync, writeFileSync, readFileSync, rmSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";

const REPO_ROOT = path.resolve(__dirname, "..");

let workDir: string;
let envPath: string;

beforeEach(() => {
  workDir = mkdtempSync(path.join(tmpdir(), "commentdm-envfile-test-"));
  envPath = path.join(workDir, ".env");
});

afterEach(() => {
  rmSync(workDir, { recursive: true, force: true });
});

/**
 * Два адаптера к одному и тому же контракту: deploy/lib.sh принимает путь к
 * файлу отдельным аргументом, install.sh работает с глобальной ENV_FILE.
 * Тела сценариев ниже написаны один раз против общих get/set_if_absent/set.
 */
const IMPLEMENTATIONS = [
  {
    name: "deploy/lib.sh",
    preamble: [
      `source "${REPO_ROOT}/deploy/lib.sh"`,
      `get() { env_get "$ENV_FILE" "$1"; }`,
      `set_if_absent() { env_set_if_absent "$ENV_FILE" "$1" "$2"; }`,
      `set_always() { env_set "$ENV_FILE" "$1" "$2"; }`,
    ].join("\n"),
  },
  {
    name: "install.sh",
    preamble: [
      `export COMMENTDM_INSTALL_SH_LIB_ONLY=1`,
      `source "${REPO_ROOT}/install.sh"`,
      `get() { env_get "$1"; }`,
      `set_if_absent() { env_set_if_absent "$1" "$2"; }`,
      `set_always() { env_write_key "$1" "$2"; }`,
    ].join("\n"),
  },
] as const;

function runBash(impl: (typeof IMPLEMENTATIONS)[number], body: string): string {
  const script = [
    "set -uo pipefail",
    impl.preamble,
    // Строго ПОСЛЕ preamble: install.sh объявляет собственную ENV_FILE=""
    // в блоке глобальных переменных и затёр бы значение, выставленное до
    // его подключения.
    `ENV_FILE="${envPath}"`,
    body,
  ].join("\n");
  return execFileSync("bash", ["-c", script], {
    cwd: workDir,
    encoding: "utf8",
    stdio: ["pipe", "pipe", "pipe"],
  });
}

function countLinesFor(key: string): number {
  return readFileSync(envPath, "utf8")
    .split("\n")
    .filter((line) => new RegExp(`^\\s*(export\\s+)?${key}\\s*=`).test(line)).length;
}

describe.each(IMPLEMENTATIONS)("$name — чтение .env", (impl) => {
  it("видит ключ с ведущими пробелами", () => {
    writeFileSync(envPath, "  ENCRYPTION_KEY=abc123\n");
    expect(runBash(impl, `get ENCRYPTION_KEY`)).toBe("abc123");
  });

  it("видит ключ с ведущей табуляцией", () => {
    writeFileSync(envPath, "\tSESSION_SECRET=tabbed\n");
    expect(runBash(impl, `get SESSION_SECRET`)).toBe("tabbed");
  });

  it("видит ключ с префиксом export и снимает двойные кавычки", () => {
    writeFileSync(envPath, 'export SESSION_SECRET="quoted value"\n');
    expect(runBash(impl, `get SESSION_SECRET`)).toBe("quoted value");
  });

  it("снимает одинарные кавычки", () => {
    writeFileSync(envPath, "DATABASE_URL='postgresql://u:p@localhost:5432/db'\n");
    expect(runBash(impl, `get DATABASE_URL`)).toBe("postgresql://u:p@localhost:5432/db");
  });

  it("возвращает пустоту для отсутствующего ключа", () => {
    writeFileSync(envPath, "APP_URL=https://example.com\n");
    expect(runBash(impl, `get ENCRYPTION_KEY`)).toBe("");
  });

  it("не принимает закомментированную строку за заданный ключ", () => {
    writeFileSync(envPath, "# ENCRYPTION_KEY=старое-значение-из-примера\n");
    expect(runBash(impl, `get ENCRYPTION_KEY`)).toBe("");
  });

  it("не путает ключ с ключом, имя которого начинается так же", () => {
    writeFileSync(envPath, "ENCRYPTION_KEY_BACKUP=не-тот\nENCRYPTION_KEY=тот\n");
    expect(runBash(impl, `get ENCRYPTION_KEY`)).toBe("тот");
  });
});

describe.each(IMPLEMENTATIONS)("$name — повторный запуск не плодит секретов", (impl) => {
  it("не дописывает второй ENCRYPTION_KEY к ключу, записанному с отступом", () => {
    // Ровно та авария, ради которой этот файл: значение обязано остаться
    // прежним, а строк с этим ключом обязана остаться ровно одна.
    writeFileSync(envPath, "  ENCRYPTION_KEY=оригинальный-ключ\n");

    runBash(impl, `set_if_absent ENCRYPTION_KEY "новый-случайный-ключ"`);

    expect(countLinesFor("ENCRYPTION_KEY")).toBe(1);
    expect(readFileSync(envPath, "utf8")).toContain("оригинальный-ключ");
    expect(readFileSync(envPath, "utf8")).not.toContain("новый-случайный-ключ");
  });

  it("не дописывает второй SESSION_SECRET к строке вида export KEY=\"...\"", () => {
    writeFileSync(envPath, 'export SESSION_SECRET="оригинальный-секрет"\n');

    runBash(impl, `set_if_absent SESSION_SECRET "новый-секрет"`);

    expect(countLinesFor("SESSION_SECRET")).toBe(1);
    expect(runBash(impl, `get SESSION_SECRET`)).toBe("оригинальный-секрет");
  });

  it("держит все четыре критичных ключа при повторном проходе установщика", () => {
    // Файл в том виде, в каком его оставил бы переформатировавший его
    // Claude Code: отступы, export, кавычки — вперемешку.
    writeFileSync(
      envPath,
      [
        "  ENCRYPTION_KEY=ключ-шифрования",
        'export SESSION_SECRET="секрет-сессии"',
        "\tDATABASE_URL='postgresql://commentdm:пароль@localhost:5432/commentdm'",
        "  OWNER_PASSWORD=пароль-владельца",
        "",
      ].join("\n")
    );

    runBash(
      impl,
      [
        `set_if_absent ENCRYPTION_KEY "подмена-1"`,
        `set_if_absent SESSION_SECRET "подмена-2"`,
        `set_if_absent DATABASE_URL "подмена-3"`,
        `set_if_absent OWNER_PASSWORD "подмена-4"`,
      ].join("\n")
    );

    const content = readFileSync(envPath, "utf8");
    expect(content).not.toContain("подмена-");
    expect(runBash(impl, `get ENCRYPTION_KEY`)).toBe("ключ-шифрования");
    expect(runBash(impl, `get SESSION_SECRET`)).toBe("секрет-сессии");
    expect(runBash(impl, `get DATABASE_URL`)).toBe(
      "postgresql://commentdm:пароль@localhost:5432/commentdm"
    );
    expect(runBash(impl, `get OWNER_PASSWORD`)).toBe("пароль-владельца");
  });

  it("дописывает ключ, которого действительно нет", () => {
    writeFileSync(envPath, "APP_URL=https://example.com\n");
    runBash(impl, `set_if_absent REDIS_URL "redis://localhost:6379"`);
    expect(runBash(impl, `get REDIS_URL`)).toBe("redis://localhost:6379");
    expect(countLinesFor("REDIS_URL")).toBe(1);
  });

  it("считает пустое значение незаданным и заполняет его", () => {
    writeFileSync(envPath, "  ENCRYPTION_KEY=\n");
    runBash(impl, `set_if_absent ENCRYPTION_KEY "сгенерированный"`);
    expect(runBash(impl, `get ENCRYPTION_KEY`)).toBe("сгенерированный");
    expect(countLinesFor("ENCRYPTION_KEY")).toBe(1);
  });
});

describe.each(IMPLEMENTATIONS)("$name — перезапись значения", (impl) => {
  it("правит существующую строку, а не дописывает вторую", () => {
    writeFileSync(envPath, "  APP_URL=https://old.example.com\n");
    runBash(impl, `set_always APP_URL "https://new.example.com"`);
    expect(countLinesFor("APP_URL")).toBe(1);
    expect(runBash(impl, `get APP_URL`)).toBe("https://new.example.com");
  });

  it("схлопывает уже накопившиеся дубли в одну строку", () => {
    // Файл, который остался после старой версии установщика: три строки
    // одного ключа, побеждает последняя.
    writeFileSync(
      envPath,
      "ENCRYPTION_KEY=первый\n  ENCRYPTION_KEY=второй\nexport ENCRYPTION_KEY=третий\n"
    );
    runBash(impl, `set_always ENCRYPTION_KEY "единственный"`);
    expect(countLinesFor("ENCRYPTION_KEY")).toBe(1);
    expect(runBash(impl, `get ENCRYPTION_KEY`)).toBe("единственный");
  });

  it("не портит значения со спецсимволами sed (| & / \\)", () => {
    writeFileSync(envPath, "DATABASE_URL=заглушка\n");
    const tricky = "postgresql://u:a|b&c/d\\e@localhost:5432/db";
    runBash(impl, `set_always DATABASE_URL '${tricky}'`);
    expect(runBash(impl, `get DATABASE_URL`)).toBe(tricky);
  });

  it("не трогает остальные строки файла", () => {
    writeFileSync(
      envPath,
      "# заголовок\n  ENCRYPTION_KEY=не-трогать\nAPP_URL=https://old.example.com\n"
    );
    runBash(impl, `set_always APP_URL "https://new.example.com"`);
    const content = readFileSync(envPath, "utf8");
    expect(content).toContain("# заголовок");
    expect(content).toContain("  ENCRYPTION_KEY=не-трогать");
  });

  it("создаёт .env с режимом 600, если файла ещё нет", () => {
    runBash(impl, `set_always ENCRYPTION_KEY "первый-ключ"`);
    expect(statSync(envPath).mode & 0o777).toBe(0o600);
  });
});

describe.each(IMPLEMENTATIONS)("$name — владелец и режим .env", (impl) => {
  it("сохраняет режим доступа при перезаписи значения", () => {
    // set-domain.sh раньше писал .env через mktemp + mv и не возвращал
    // владельца — режим и владелец временного файла (root, 0600) переезжали
    // на .env. Веб при этом выживал (systemd читает от root), а воркер,
    // который tsx запускает от пользователя приложения, уходил в вечный
    // рестарт: сайт открыт, сообщения не уходят вообще. Восстановление
    // владельца и режима теперь живёт ВНУТРИ самой функции записи, поэтому
    // ни один вызывающий не может про это забыть.
    writeFileSync(envPath, "APP_URL=https://old.example.com\n", { mode: 0o640 });
    runBash(impl, `set_always APP_URL "https://new.example.com"`);
    expect(statSync(envPath).mode & 0o777).toBe(0o640);
  });

  it("сохраняет группу-владельца при перезаписи значения", () => {
    // Полноценную смену владельца на другого пользователя без root не
    // проверить; группа файла проверяема и ходит тем же вызовом chown.
    writeFileSync(envPath, "APP_URL=https://old.example.com\n");
    const before = statSync(envPath);
    const otherGid = process.getgroups?.().find((g) => g !== before.gid);
    if (otherGid === undefined) {
      return; // одна группа у пользователя — проверять нечего
    }
    execFileSync("chgrp", [String(otherGid), envPath]);
    expect(statSync(envPath).gid).toBe(otherGid);

    runBash(impl, `set_always APP_URL "https://new.example.com"`);

    expect(statSync(envPath).gid).toBe(otherGid);
  });
});

describe("deploy/lib.sh — load_env_file вместо `. .env`", () => {
  const lib = IMPLEMENTATIONS[0];

  it("не исполняет подстановку команд из значения", () => {
    // .env принадлежит пользователю приложения, а update.sh/rollback.sh
    // работают из-под root: точка превращала бы любую запись со стороны
    // приложения в команду от root.
    const marker = path.join(workDir, "PWNED");
    writeFileSync(envPath, `EVIL=$(touch ${marker})\n`);

    const out = runBash(lib, `load_env_file "$ENV_FILE"; printf '%s' "$EVIL"`);

    expect(out).toBe(`$(touch ${marker})`);
    expect(() => statSync(marker)).toThrow();
  });

  it("разбирает легальное значение с пробелом", () => {
    // `. .env` на такой строке пытается запустить команду «Ромашка».
    writeFileSync(envPath, "LEGAL_ENTITY_NAME=ООО Ромашка\n");
    const out = runBash(lib, `load_env_file "$ENV_FILE"; printf '%s' "$LEGAL_ENTITY_NAME"`);
    expect(out).toBe("ООО Ромашка");
  });

  it("понимает отступы, export, кавычки и комментарии", () => {
    writeFileSync(
      envPath,
      [
        "# комментарий",
        "  DATABASE_URL=postgresql://u:p@localhost:5432/db",
        'export SESSION_SECRET="секрет"',
        "\tOWNER_EMAIL='owner@localhost'",
        "",
      ].join("\n")
    );
    const out = runBash(
      lib,
      `load_env_file "$ENV_FILE"; printf '%s|%s|%s' "$DATABASE_URL" "$SESSION_SECRET" "$OWNER_EMAIL"`
    );
    expect(out).toBe("postgresql://u:p@localhost:5432/db|секрет|owner@localhost");
  });

  it("переживает файл с окончаниями строк CRLF", () => {
    writeFileSync(envPath, "DATABASE_URL=postgresql://u:p@localhost:5432/db\r\n");
    const out = runBash(lib, `load_env_file "$ENV_FILE"; printf '[%s]' "$DATABASE_URL"`);
    expect(out).toBe("[postgresql://u:p@localhost:5432/db]");
  });
});
