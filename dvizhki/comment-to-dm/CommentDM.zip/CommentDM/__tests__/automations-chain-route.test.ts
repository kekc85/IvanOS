/**
 * PATCH /api/automations — how a touch chain is written.
 *
 * Two things here are easy to get wrong and expensive to find later:
 *
 * 1. chainSteps is not a column on Automation. If it rode along in the spread
 *    into prisma.automation.update, every chain edit would throw.
 * 2. positions are unique per campaign, so an edit cannot patch rows one by
 *    one — renumbering in place collides with the rows still there. The whole
 *    list is replaced inside a single transaction instead.
 *
 * The schema-level rules live in automations-schema.test.ts; what this file
 * covers is the part only the handler can decide, because it needs the
 * database to answer: turning the chain on for a campaign whose stored steps
 * or stored link buttons make that impossible.
 */

import { beforeEach, describe, expect, it, vi } from "vitest";
import type { NextRequest } from "next/server";

const { mockPrisma, mockGetCurrentWorkspaceContext } = vi.hoisted(() => ({
  mockPrisma: {
    automation: { findFirst: vi.fn(), update: vi.fn() },
    sequenceStep: { count: vi.fn(), deleteMany: vi.fn(), createMany: vi.fn() },
    trackedLink: {
      findMany: vi.fn(),
      findFirst: vi.fn(),
      create: vi.fn(),
      update: vi.fn(),
      delete: vi.fn(),
    },
    $transaction: vi.fn(),
  },
  mockGetCurrentWorkspaceContext: vi.fn(),
}));

vi.mock("@/lib/db/client", () => ({ prisma: mockPrisma }));

vi.mock("@/lib/workspace-access", () => ({
  getCurrentWorkspaceContext: mockGetCurrentWorkspaceContext,
}));

vi.mock("@/lib/auth/session", () => ({
  getCurrentWorkspaceId: vi.fn(async () => "workspace_1"),
}));

import { PATCH } from "../app/api/automations/route";

const AUTOMATION_ID = "automation_1";

const STORED_CAMPAIGN = {
  id: AUTOMATION_ID,
  workspaceId: "workspace_1",
  chainEnabled: false,
};

const CHAIN = [
  { position: 0, delaySeconds: 0, message: "Вот обещанное" },
  { position: 1, delaySeconds: 600, message: "Как оно?" },
];

function patchRequest(body: unknown, id: string | null = AUTOMATION_ID) {
  return {
    nextUrl: { searchParams: new URLSearchParams(id ? { id } : {}) },
    json: async () => body,
  } as unknown as NextRequest;
}

/** The transaction callback runs against the same mock, as Prisma's does. */
function runTransaction(fn: (tx: typeof mockPrisma) => unknown) {
  return fn(mockPrisma);
}

beforeEach(() => {
  vi.clearAllMocks();
  mockGetCurrentWorkspaceContext.mockResolvedValue({ workspaceId: "workspace_1" });
  mockPrisma.automation.findFirst.mockResolvedValue(STORED_CAMPAIGN);
  mockPrisma.automation.update.mockResolvedValue({
    ...STORED_CAMPAIGN,
    chainEnabled: true,
    chainSteps: CHAIN,
  });
  mockPrisma.sequenceStep.count.mockResolvedValue(0);
  mockPrisma.sequenceStep.deleteMany.mockResolvedValue({ count: 0 });
  mockPrisma.sequenceStep.createMany.mockResolvedValue({ count: CHAIN.length });
  mockPrisma.trackedLink.findMany.mockResolvedValue([]);
  mockPrisma.$transaction.mockImplementation(runTransaction);
});

describe("PATCH /api/automations — replacing a chain", () => {
  it("replaces the whole chain inside one transaction", async () => {
    const response = await PATCH(
      patchRequest({ chainEnabled: true, chainSteps: CHAIN })
    );

    expect(response.status).toBe(200);
    expect(mockPrisma.$transaction).toHaveBeenCalledTimes(1);
    expect(mockPrisma.sequenceStep.deleteMany).toHaveBeenCalledWith({
      where: { automationId: AUTOMATION_ID },
    });
    expect(mockPrisma.sequenceStep.createMany).toHaveBeenCalledWith({
      data: [
        { automationId: AUTOMATION_ID, position: 0, delaySeconds: 0, message: "Вот обещанное" },
        { automationId: AUTOMATION_ID, position: 1, delaySeconds: 600, message: "Как оно?" },
      ],
    });
    // Delete before create: the unique (automationId, position) constraint
    // makes any other order collide with the rows already there.
    expect(
      mockPrisma.sequenceStep.deleteMany.mock.invocationCallOrder[0]
    ).toBeLessThan(mockPrisma.sequenceStep.createMany.mock.invocationCallOrder[0]);
  });

  it("never passes chainSteps into the automation update", async () => {
    await PATCH(patchRequest({ chainEnabled: true, chainSteps: CHAIN }));

    const updateArgs = mockPrisma.automation.update.mock.calls[0][0] as {
      data: Record<string, unknown>;
    };
    expect(updateArgs.data).not.toHaveProperty("chainSteps");
    expect(updateArgs.data.chainEnabled).toBe(true);
  });

  it("returns the stored chain so the builder can read it back", async () => {
    const response = await PATCH(
      patchRequest({ chainEnabled: true, chainSteps: CHAIN })
    );
    const payload = await response.json();

    expect(payload.success).toBe(true);
    expect(payload.data.chainSteps).toEqual(CHAIN);
  });

  it("clears the chain when an empty list is sent", async () => {
    mockPrisma.automation.findFirst.mockResolvedValue({
      ...STORED_CAMPAIGN,
      chainEnabled: true,
    });

    const response = await PATCH(
      patchRequest({ chainEnabled: false, chainSteps: [] })
    );

    expect(response.status).toBe(200);
    expect(mockPrisma.sequenceStep.deleteMany).toHaveBeenCalledTimes(1);
    expect(mockPrisma.sequenceStep.createMany).not.toHaveBeenCalled();
  });

  it("leaves the stored chain alone when the request doesn't mention it", async () => {
    const response = await PATCH(patchRequest({ isActive: false }));

    expect(response.status).toBe(200);
    expect(mockPrisma.$transaction).not.toHaveBeenCalled();
    expect(mockPrisma.sequenceStep.deleteMany).not.toHaveBeenCalled();
    expect(mockPrisma.sequenceStep.createMany).not.toHaveBeenCalled();
    expect(mockPrisma.automation.update).toHaveBeenCalledTimes(1);
  });
});

describe("PATCH /api/automations — chain rules that need the database", () => {
  it("refuses to switch the chain on when no steps are stored", async () => {
    mockPrisma.sequenceStep.count.mockResolvedValue(0);

    const response = await PATCH(patchRequest({ chainEnabled: true }));
    const payload = await response.json();

    expect(response.status).toBe(400);
    expect(payload.error).toContain("шагов нет");
    expect(mockPrisma.automation.update).not.toHaveBeenCalled();
  });

  it("allows switching the chain on when steps are already stored", async () => {
    mockPrisma.sequenceStep.count.mockResolvedValue(2);

    const response = await PATCH(patchRequest({ chainEnabled: true }));

    expect(response.status).toBe(200);
    expect(mockPrisma.automation.update).toHaveBeenCalledTimes(1);
  });

  // Б6: a button in the GATE gets tapped instead of answered, so Meta's 24h
  // window never opens and the chain has nowhere to go.
  it("refuses a chain while link buttons are still stored", async () => {
    mockPrisma.trackedLink.findMany.mockResolvedValue([{ id: "link_1" }]);

    const response = await PATCH(
      patchRequest({ chainEnabled: true, chainSteps: CHAIN })
    );
    const payload = await response.json();

    expect(response.status).toBe(400);
    expect(payload.error).toContain("кнопками-ссылками");
    expect(mockPrisma.automation.update).not.toHaveBeenCalled();
    expect(mockPrisma.sequenceStep.deleteMany).not.toHaveBeenCalled();
  });

  it("accepts the same request when it clears those buttons itself", async () => {
    // This is the path the campaign rebuild takes: drop the buttons, turn the
    // chain on, upload the steps — all in one call.
    mockPrisma.trackedLink.findMany.mockResolvedValue([{ id: "link_1" }]);
    mockPrisma.trackedLink.findFirst.mockResolvedValue({ id: "link_1" });

    const response = await PATCH(
      patchRequest({
        chainEnabled: true,
        chainSteps: CHAIN,
        trackedDestinationUrl: "",
      })
    );

    expect(response.status).toBe(200);
    expect(mockPrisma.trackedLink.delete).toHaveBeenCalledWith({
      where: { id: "link_1" },
    });
    expect(mockPrisma.sequenceStep.createMany).toHaveBeenCalledTimes(1);
  });

  it("still refuses when only one of two stored buttons is cleared", async () => {
    mockPrisma.trackedLink.findMany.mockResolvedValue([
      { id: "link_1" },
      { id: "link_2" },
    ]);

    const response = await PATCH(
      patchRequest({
        chainEnabled: true,
        chainSteps: CHAIN,
        trackedDestinationUrl: "",
      })
    );

    expect(response.status).toBe(400);
    expect(mockPrisma.automation.update).not.toHaveBeenCalled();
  });

  it("leaves campaigns without a chain untouched by any of this", async () => {
    mockPrisma.trackedLink.findMany.mockResolvedValue([{ id: "link_1" }]);

    const response = await PATCH(patchRequest({ isActive: false }));

    expect(response.status).toBe(200);
    expect(mockPrisma.sequenceStep.count).not.toHaveBeenCalled();
  });
});
