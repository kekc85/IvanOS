/**
 * Transport layer of the Meta client: the deadline on every call, and what
 * survives of Meta's own error reporting.
 *
 * Both exist because of real incidents. On 09.08 a single request to Meta was
 * accepted and never answered — `fetch` has no default timeout, so the comment
 * sweep's overlap guard was never released and polling stood still for two
 * hours. And the error classes used to overwrite Meta's code with one
 * representative number and drop error_subcode entirely, which erased the only
 * signal that says "the 24h message window is closed" (10/2534022) rather than
 * "you lack a permission" — a difference the touch chain has to act on.
 */

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  MetaApiError,
  META_TIMEOUT_CODE,
  OUTSIDE_WINDOW_SUBCODE,
  PermissionError,
  RateLimitError,
  TokenExpiredError,
  getConversations,
  getUserInfo,
  isOutsideWindowError,
  sendDirectMessage,
  sendPrivateReply,
} from "../lib/meta/client";

// Captured before the spy is installed, so the stub can hand back a real (but
// short) deadline instead of recursing into itself.
const realAbortTimeout = AbortSignal.timeout.bind(AbortSignal);

/** Meta answered, but with an error envelope. */
function metaErrorResponse(error: {
  message: string;
  code: number;
  error_subcode?: number;
  fbtrace_id?: string;
}) {
  return {
    ok: false,
    status: 400,
    json: async () => ({ error: { type: "OAuthException", ...error } }),
  } as unknown as Response;
}

function metaOkResponse(body: unknown) {
  return { ok: true, status: 200, json: async () => body } as unknown as Response;
}

beforeEach(() => {
  vi.clearAllMocks();
});

afterEach(() => {
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe("timeout on every call to Meta", () => {
  it("turns a request that never answers into a plain-Russian Meta error", async () => {
    // The deadline is real, only shortened: the fetch below never settles on
    // its own, exactly like the hung request on 09.08, and the only thing that
    // ends the wait is the AbortSignal the client attached.
    const requestedTimeouts: number[] = [];
    vi.spyOn(AbortSignal, "timeout").mockImplementation((ms: number) => {
      requestedTimeouts.push(ms);
      return realAbortTimeout(20);
    });

    const hangingFetch = vi.fn(
      (_url: string, init?: RequestInit) =>
        new Promise<Response>((_resolve, reject) => {
          init?.signal?.addEventListener("abort", () => {
            reject((init.signal as AbortSignal).reason);
          });
        })
    );
    vi.stubGlobal("fetch", hangingFetch);

    const error = await sendPrivateReply(
      "token",
      "ig_account",
      "comment_1",
      "hello"
    ).catch((err: unknown) => err);

    expect(error).toBeInstanceOf(MetaApiError);
    expect((error as MetaApiError).message).toBe("Meta не ответила за 30 секунд");
    expect((error as MetaApiError).code).toBe(META_TIMEOUT_CODE);
    // The production deadline is 30s — the test only substitutes a shorter one
    // so it doesn't have to sit out the real clock.
    expect(requestedTimeouts).toEqual([30_000]);
  });

  it("attaches the deadline to reads as well as sends", async () => {
    const signals: unknown[] = [];
    const okFetch = vi.fn((_url: string, init?: RequestInit) => {
      signals.push(init?.signal);
      return Promise.resolve(metaOkResponse({ data: [] }));
    });
    vi.stubGlobal("fetch", okFetch);

    await getConversations("token", "ig_user");
    await getUserInfo("token");

    expect(signals).toHaveLength(2);
    for (const signal of signals) {
      expect(signal).toBeInstanceOf(AbortSignal);
    }
  });

  it("lets an ordinary network failure through untouched", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(() => Promise.reject(new TypeError("fetch failed")))
    );

    await expect(getUserInfo("token")).rejects.toThrow("fetch failed");
  });
});

describe("Meta's real code and subcode survive classification", () => {
  it("keeps code 10 + subcode 2534022 on a closed-window refusal", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(() =>
        Promise.resolve(
          metaErrorResponse({
            message:
              "(#10) This message is sent outside of allowed window. Please refer to the documentation.",
            code: 10,
            error_subcode: OUTSIDE_WINDOW_SUBCODE,
            fbtrace_id: "trace-window",
          })
        )
      )
    );

    const error = await sendDirectMessage(
      "token",
      "ig_account",
      "subscriber_1",
      "step 1"
    ).catch((err: unknown) => err);

    expect(error).toBeInstanceOf(PermissionError);
    expect((error as PermissionError).code).toBe(10);
    expect((error as PermissionError).subcode).toBe(OUTSIDE_WINDOW_SUBCODE);
    expect((error as PermissionError).fbTraceId).toBe("trace-window");
    expect(isOutsideWindowError(error)).toBe(true);
  });

  it("keeps the rate-limit code Meta actually sent (4), not a stand-in", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(() =>
        Promise.resolve(
          metaErrorResponse({
            message: "Application request limit reached",
            code: 4,
            error_subcode: 2207051,
          })
        )
      )
    );

    const error = await getUserInfo("token").catch((err: unknown) => err);

    expect(error).toBeInstanceOf(RateLimitError);
    expect((error as RateLimitError).code).toBe(4);
    expect((error as RateLimitError).subcode).toBe(2207051);
  });

  it("keeps the subcode on an expired token", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(() =>
        Promise.resolve(
          metaErrorResponse({
            message: "Error validating access token: Session has expired",
            code: 190,
            error_subcode: 463,
          })
        )
      )
    );

    const error = await getUserInfo("token").catch((err: unknown) => err);

    expect(error).toBeInstanceOf(TokenExpiredError);
    expect((error as TokenExpiredError).code).toBe(190);
    expect((error as TokenExpiredError).subcode).toBe(463);
  });

  it("still defaults the code when constructed by hand without one", () => {
    // lib/doctor and the existing tests build these directly; those call sites
    // must keep working unchanged.
    expect(new PermissionError("Insufficient permission").code).toBe(100);
    expect(new RateLimitError("Too many calls").code).toBe(368);
    expect(new TokenExpiredError("Error validating access token").code).toBe(190);
  });
});

describe("isOutsideWindowError", () => {
  it("recognises the prose form, for responses that carry no subcode", () => {
    expect(
      isOutsideWindowError(
        new Error("(#10) This message is sent outside of allowed window.")
      )
    ).toBe(true);
  });

  it("does not fire on other permission refusals", () => {
    expect(
      isOutsideWindowError(new PermissionError("Insufficient permission"))
    ).toBe(false);
    expect(
      isOutsideWindowError(new MetaApiError(10, 2018001, undefined, "No matching user found"))
    ).toBe(false);
  });

  it("is safe on non-errors", () => {
    expect(isOutsideWindowError(undefined)).toBe(false);
    expect(isOutsideWindowError(null)).toBe(false);
    expect(isOutsideWindowError({ code: 10 })).toBe(false);
  });
});
