/**
 * withTimeout is the one guarantee every doctor check leans on: whatever it
 * wraps (a dead Redis, a dead Postgres, an unreachable Meta) resolves within
 * a bound instead of hanging the whole `npm run doctor` run forever. Proven
 * here directly against a promise that never settles, with fake timers so
 * the test itself doesn't have to wait out the real clock.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { DoctorTimeoutError, withTimeout } from "../lib/doctor/timeout";

beforeEach(() => {
  vi.useFakeTimers();
});

afterEach(() => {
  vi.useRealTimers();
});

describe("withTimeout", () => {
  it("rejects a promise that never settles once the timeout elapses", async () => {
    const neverResolves = new Promise<never>(() => {});

    const result = withTimeout(neverResolves, 1000, "hanging check");
    const assertion = expect(result).rejects.toBeInstanceOf(DoctorTimeoutError);

    await vi.advanceTimersByTimeAsync(1000);
    await assertion;
  });

  it("names the check in the timeout error so the finding is specific", async () => {
    const neverResolves = new Promise<never>(() => {});

    const result = withTimeout(neverResolves, 500, "Redis connect");
    const assertion = expect(result).rejects.toThrow(/Redis connect timed out after 500ms/);

    await vi.advanceTimersByTimeAsync(500);
    await assertion;
  });

  it("resolves normally when the wrapped promise settles first", async () => {
    await expect(withTimeout(Promise.resolve("fine"), 1000, "quick check")).resolves.toBe(
      "fine"
    );
  });

  it("propagates the original rejection when the wrapped promise fails first", async () => {
    await expect(
      withTimeout(Promise.reject(new Error("boom")), 1000, "quick check")
    ).rejects.toThrow("boom");
  });
});
