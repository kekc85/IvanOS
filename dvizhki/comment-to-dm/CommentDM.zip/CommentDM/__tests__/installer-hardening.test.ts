/**
 * Установщик и день-2 скрипты — проверки, каждая из которых закрывает
 * конкретную аварию, найденную приёмкой. Все гоняют настоящие скрипты, а не
 * пересказ их логики.
 *
 * Что здесь проверяется и почему:
 *   - разбор домена: `sudo bash install.sh https://bot.example.com` давал
 *     APP_URL=https://https://bot.example.com, а символ | в аргументе ломал
 *     sed-подстановку в Caddyfile и systemd-юнитах;
 *   - разбор пароля базы из DATABASE_URL: sed при несовпадении печатает
 *     строку целиком, и «паролем» становилась вся строка;
 *   - экранирование пароля в SQL: кавычка внутри пароля закрывала литерал
 *     ALTER ROLE, остаток исполнялся от суперпользователя Postgres;
 *   - запись конфигов: `sed ... > цель` обнуляет цель ДО записи, обрыв
 *     оставлял пустой systemd-юнит или пустой конфиг Caddy;
 *   - права на дампы: pg_dump | gzip создавал файлы 644, то есть переписку
 *     подписчиков и шифротексты токенов мог читать любой локальный аккаунт;
 *   - порядок операций отката: непроходимая проблема всплывала уже ПОСЛЕ
 *     остановки сервисов, и сервер оставался лежать.
 */
import { execFileSync } from "node:child_process";
import { gzipSync } from "node:zlib";
import {
  mkdtempSync,
  mkdirSync,
  writeFileSync,
  readFileSync,
  cpSync,
  chmodSync,
  rmSync,
  statSync,
} from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";

const REPO_ROOT = path.resolve(__dirname, "..");
const UNREACHABLE_DATABASE_URL =
  "postgresql://nouser:nopass@127.0.0.1:59999/nonexistent_test_db_commentdm";

let workDir: string;

beforeEach(() => {
  workDir = mkdtempSync(path.join(tmpdir(), "commentdm-hardening-test-"));
});

afterEach(() => {
  rmSync(workDir, { recursive: true, force: true });
});

/** Запускает snippet в bash с подключённым install.sh (без запуска установки). */
function inInstallSh(body: string): string {
  const script = [
    "set -uo pipefail",
    "export COMMENTDM_INSTALL_SH_LIB_ONLY=1",
    `source "${REPO_ROOT}/install.sh"`,
    body,
  ].join("\n");
  return execFileSync("bash", ["-c", script], {
    cwd: workDir,
    encoding: "utf8",
    stdio: ["pipe", "pipe", "pipe"],
  });
}

/** То же для deploy/lib.sh. */
function inLibSh(body: string): string {
  const script = ["set -uo pipefail", `source "${REPO_ROOT}/deploy/lib.sh"`, body].join("\n");
  return execFileSync("bash", ["-c", script], {
    cwd: workDir,
    encoding: "utf8",
    stdio: ["pipe", "pipe", "pipe"],
  });
}

const DOMAIN_IMPLS = [
  { name: "install.sh", run: inInstallSh },
  { name: "deploy/lib.sh", run: inLibSh },
] as const;

describe.each(DOMAIN_IMPLS)("$name — нормализация и проверка домена", (impl) => {
  const accepted: Array<[string, string]> = [
    ["bot.example.com", "bot.example.com"],
    ["https://bot.example.com", "bot.example.com"],
    ["http://bot.example.com/path/here", "bot.example.com"],
    ["BOT.Example.COM", "bot.example.com"],
    ["bot.example.com.", "bot.example.com"],
    ["https://bot.example.com/", "bot.example.com"],
    ["a-b.c-d.example.com", "a-b.c-d.example.com"],
  ];

  it.each(accepted)("принимает %s и приводит к %s", (input, expected) => {
    const out = impl.run(
      `d="$(normalize_domain '${input}')"; if validate_domain "$d"; then printf '%s' "$d"; else printf 'ОТКЛОНЁН'; fi`
    );
    expect(out).toBe(expected);
  });

  const rejected = [
    "bot|example.com", // ломал sed-подстановку в Caddyfile
    "bot example.com",
    "bot;rm -rf /.example.com",
    "localhost", // без точки — сертификат всё равно не выпустится
    "bot.example.com:8443", // порт установщик не поддерживает
    "user@bot.example.com",
    "-bad.example.com",
    "bad-.example.com",
    "пример.рф", // нужен punycode, а не кириллица
    "",
  ];

  it.each(rejected)("отклоняет %s", (input) => {
    const out = impl.run(
      `d="$(normalize_domain '${input}')"; if validate_domain "$d"; then printf 'ПРИНЯТ'; else printf 'ОТКЛОНЁН'; fi`
    );
    expect(out).toBe("ОТКЛОНЁН");
  });
});

describe("install.sh — пароль базы из DATABASE_URL", () => {
  it("достаёт пароль из обычной строки подключения", () => {
    expect(
      inInstallSh(
        `parse_db_password_from_url 'postgresql://commentdm:s3cret@localhost:5432/commentdm'`
      )
    ).toBe("s3cret");
  });

  it("не обрубает пароль, внутри которого есть @", () => {
    expect(
      inInstallSh(
        `parse_db_password_from_url 'postgresql://commentdm:pa@ss@localhost:5432/commentdm'`
      )
    ).toBe("pa@ss");
  });

  it("возвращает пустоту, а не всю строку, если это не строка подключения", () => {
    // Прежний sed при несовпадении печатал строку целиком, и «паролем»
    // становился весь текст.
    expect(inInstallSh(`parse_db_password_from_url 'что-то совсем другое'`)).toBe("");
    expect(inInstallSh(`parse_db_password_from_url 'postgresql://localhost/db'`)).toBe("");
  });

  it("работает со значением, записанным в .env в кавычках", () => {
    const envPath = path.join(workDir, ".env");
    writeFileSync(
      envPath,
      '  DATABASE_URL="postgresql://commentdm:in@quotes@localhost:5432/commentdm"\n'
    );
    const out = inInstallSh(
      `ENV_FILE="${envPath}"; parse_db_password_from_url "$(env_get DATABASE_URL)"`
    );
    expect(out).toBe("in@quotes");
  });
});

describe("install.sh — файрвол не отрезает ssh", () => {
  /**
   * Раньше configure_firewall открывал жёстко 22, не читая реальный порт.
   * У кого ssh перевешен на другой порт, установка отрезала доступ к
   * собственному серверу — чинить только через консоль хостера.
   */
  function withSshdConfig(content: string | null, extra = ""): string {
    const sshdConfig = path.join(workDir, "sshd_config");
    if (content !== null) {
      writeFileSync(sshdConfig, content);
    }
    // Третий источник detect_ssh_ports — живые сокеты через `ss`. На машине,
    // где sshd реально слушает (Linux CI), он подмешивал бы настоящий порт
    // и результат зависел бы от хоста. Подменяем `ss` пустым ответом, чтобы
    // каждый сценарий ниже проверял ровно тот источник, который называет.
    const stubBinDir = path.join(workDir, "ssh-stubbin");
    mkdirSync(stubBinDir, { recursive: true });
    const fakeSs = path.join(stubBinDir, "ss");
    writeFileSync(fakeSs, "#!/bin/sh\nexit 0\n");
    chmodSync(fakeSs, 0o755);

    return inInstallSh(
      [
        `export PATH="${stubBinDir}:$PATH"`,
        `export SSHD_CONFIG="${sshdConfig}"`,
        `export SSHD_CONFIG_DIR="${path.join(workDir, "sshd_config.d")}"`,
        `unset SSH_CONNECTION`,
        extra,
        `detect_ssh_ports | tr '\\n' ' '`,
      ].join("\n")
    ).trim();
  }

  it("находит нестандартный порт в sshd_config", () => {
    expect(withSshdConfig("#Port 22\nPort 2222\nPermitRootLogin yes\n")).toBe("2222");
  });

  it("находит порт, записанный с отступом", () => {
    expect(withSshdConfig("   Port 2202\n")).toBe("2202");
  });

  it("собирает все объявленные порты, а не только первый", () => {
    expect(withSshdConfig("Port 22\nPort 2222\n")).toBe("22 2222");
  });

  it("подхватывает порт из sshd_config.d/*.conf", () => {
    const dir = path.join(workDir, "sshd_config.d");
    mkdirSync(dir, { recursive: true });
    writeFileSync(path.join(dir, "99-custom.conf"), "Port 4242\n");
    expect(withSshdConfig("#Port 22\n")).toBe("4242");
  });

  it("верит порту текущей ssh-сессии, даже если конфиг молчит", () => {
    expect(
      withSshdConfig("#Port 22\n", `export SSH_CONNECTION="203.0.113.7 51234 198.51.100.9 2022"`)
    ).toBe("2022");
  });

  it("ничего не выдумывает, когда порт нигде не объявлен", () => {
    // Пустой результат — сигнал configure_firewall перейти к запасному 22.
    expect(withSshdConfig("#Port 22\nPermitRootLogin no\n")).toBe("");
  });
});

describe("install.sh — экранирование пароля в SQL", () => {
  it("удваивает одинарные кавычки, закрывая инъекцию в ALTER ROLE", () => {
    const out = inInstallSh(
      `sql_quote_literal "it's'; DROP DATABASE commentdm; --"`
    );
    // Литерал целиком остаётся ОДНИМ строковым литералом: внутри нет ни
    // одной непарной кавычки, которой можно было бы его закрыть.
    expect(out).toBe("'it''s''; DROP DATABASE commentdm; --'");
    const inner = out.slice(1, -1);
    expect(inner.replace(/''/g, "")).not.toContain("'");
  });

  it("обычный сгенерированный пароль не портит", () => {
    expect(inInstallSh(`sql_quote_literal "a1b2c3d4e5"`)).toBe("'a1b2c3d4e5'");
  });
});

describe.each(DOMAIN_IMPLS)("$name — запись конфигов через временный файл", (impl) => {
  it("не обнуляет действующий конфиг, если подготовка нового провалилась", () => {
    // Раньше здесь стоял `sed ... > /etc/systemd/system/unit`: перенаправление
    // обнуляет цель ДО того, как в неё что-то попало, и обрыв ровно на этом
    // месте оставлял сервер с пустым юнитом вместо приложения.
    const dest = path.join(workDir, "live.conf");
    writeFileSync(dest, "действующий конфиг\n");

    expect(() =>
      impl.run(`render_template "${workDir}/нет-такого-шаблона" "${dest}" "s|a|b|"`)
    ).toThrow();

    expect(readFileSync(dest, "utf8")).toBe("действующий конфиг\n");
  });

  it("подставляет плейсхолдер и переносит результат на место", () => {
    const src = path.join(workDir, "template");
    const dest = path.join(workDir, "result.conf");
    writeFileSync(src, "__DOMAIN__ {\n  reverse_proxy 127.0.0.1:3000\n}\n");

    impl.run(`render_template "${src}" "${dest}" "s|__DOMAIN__|bot.example.com|g"`);

    const content = readFileSync(dest, "utf8");
    expect(content).toContain("bot.example.com {");
    expect(content).not.toContain("__DOMAIN__");
  });

  it("сохраняет режим доступа уже существующей цели", () => {
    const src = path.join(workDir, "template");
    const dest = path.join(workDir, "result.conf");
    writeFileSync(src, "__DOMAIN__\n");
    writeFileSync(dest, "старое\n", { mode: 0o640 });

    impl.run(`render_template "${src}" "${dest}" "s|__DOMAIN__|bot.example.com|g"`);

    expect(statSync(dest).mode & 0o777).toBe(0o640);
  });
});

describe("deploy/backup.sh — права на дампы базы", () => {
  function setUpBackupDir(): { installDir: string; backupsDir: string; stubBinDir: string } {
    const installDir = path.join(workDir, "install");
    mkdirSync(path.join(installDir, "deploy"), { recursive: true });
    cpSync(path.join(REPO_ROOT, "deploy/backup.sh"), path.join(installDir, "deploy/backup.sh"));

    const backupsDir = path.join(installDir, "backups");
    mkdirSync(backupsDir, { recursive: true });

    // Настоящий pg_dump здесь не нужен и не должен быть нужен: проверяются
    // права на результат и уборка, а не содержимое дампа.
    const stubBinDir = path.join(workDir, "stubbin");
    mkdirSync(stubBinDir, { recursive: true });
    const fakePgDump = path.join(stubBinDir, "pg_dump");
    writeFileSync(fakePgDump, "#!/bin/sh\nprintf '%s\\n' '-- fake dump'\n");
    chmodSync(fakePgDump, 0o755);

    return { installDir, backupsDir, stubBinDir };
  }

  function runBackup(installDir: string, stubBinDir: string): string {
    return execFileSync("bash", [path.join(installDir, "deploy/backup.sh")], {
      cwd: installDir,
      encoding: "utf8",
      env: {
        ...process.env,
        PATH: `${stubBinDir}:${process.env.PATH}`,
        DATABASE_URL: UNREACHABLE_DATABASE_URL,
      },
      stdio: ["pipe", "pipe", "pipe"],
    });
  }

  it("создаёт дамп с режимом 600, а не 644", () => {
    const { installDir, backupsDir, stubBinDir } = setUpBackupDir();

    runBackup(installDir, stubBinDir);

    const dumps = execFileSync("ls", [backupsDir], { encoding: "utf8" })
      .split("\n")
      .filter((n) => n.endsWith(".sql.gz"));
    expect(dumps.length).toBe(1);
    expect(statSync(path.join(backupsDir, dumps[0])).mode & 0o777).toBe(0o600);
  });

  it("закрывает и сам каталог с дампами", () => {
    const { installDir, backupsDir, stubBinDir } = setUpBackupDir();
    chmodSync(backupsDir, 0o755);

    runBackup(installDir, stubBinDir);

    expect(statSync(backupsDir).mode & 0o777).toBe(0o700);
  });

  it("чинит задним числом дампы, оставшиеся открытыми от прежней версии", () => {
    const { installDir, backupsDir, stubBinDir } = setUpBackupDir();
    const old = path.join(backupsDir, "commentdm-19700101-000000.sql.gz");
    writeFileSync(old, gzipSync(Buffer.from("старый дамп")), { mode: 0o644 });

    runBackup(installDir, stubBinDir);

    expect(statSync(old).mode & 0o777).toBe(0o600);
  });

  it("убирает оборванные .tmp старше суток, которые ротация не видела", () => {
    const { installDir, backupsDir, stubBinDir } = setUpBackupDir();
    const stale = path.join(backupsDir, "commentdm-19700101-000001.sql.gz.tmp");
    writeFileSync(stale, "обрывок недописанного дампа");
    execFileSync("touch", ["-t", "200001010000", stale]);

    runBackup(installDir, stubBinDir);

    expect(() => statSync(stale)).toThrow();
  });
});

describe("scripts/rollback.sh — порядок операций", () => {
  /**
   * Установка-однодневка: свой deploy/lib.sh, свой restore-db.sh, свой
   * .commentdm-update-state и настоящий (крошечный) git-репозиторий.
   * `id` подменён, чтобы require_root проходил без root; `systemctl`
   * подменён и ЗАПИСЫВАЕТ каждый вызов в файл — по нему и видно, дошёл
   * скрипт до остановки сервисов или нет.
   */
  function setUpInstall(options: { dumpValid: boolean; stubPsql: boolean; dirtyFile?: string }): {
    installDir: string;
    stubBinDir: string;
    systemctlLog: string;
  } {
    const installDir = path.join(workDir, "install");
    mkdirSync(path.join(installDir, "deploy"), { recursive: true });
    mkdirSync(path.join(installDir, "scripts"), { recursive: true });
    cpSync(path.join(REPO_ROOT, "deploy/lib.sh"), path.join(installDir, "deploy/lib.sh"));
    cpSync(
      path.join(REPO_ROOT, "deploy/restore-db.sh"),
      path.join(installDir, "deploy/restore-db.sh")
    );
    cpSync(path.join(REPO_ROOT, "scripts/rollback.sh"), path.join(installDir, "scripts/rollback.sh"));

    writeFileSync(path.join(installDir, ".env"), `DATABASE_URL=${UNREACHABLE_DATABASE_URL}\n`);

    const dumpPath = path.join(installDir, "dump.sql.gz");
    if (options.dumpValid) {
      writeFileSync(dumpPath, gzipSync(Buffer.from("-- настоящий gzip\n")));
    } else {
      writeFileSync(dumpPath, "это вообще не gzip\n");
    }

    const gitEnv = {
      ...process.env,
      GIT_AUTHOR_NAME: "test",
      GIT_AUTHOR_EMAIL: "test@localhost",
      GIT_COMMITTER_NAME: "test",
      GIT_COMMITTER_EMAIL: "test@localhost",
    };
    execFileSync("git", ["init", "-q"], { cwd: installDir, env: gitEnv });
    writeFileSync(path.join(installDir, "README"), "fake install\n");
    execFileSync("git", ["add", "-A"], { cwd: installDir, env: gitEnv });
    execFileSync("git", ["commit", "-q", "-m", "initial"], { cwd: installDir, env: gitEnv });
    const head = execFileSync("git", ["rev-parse", "HEAD"], {
      cwd: installDir,
      env: gitEnv,
      encoding: "utf8",
    }).trim();

    if (options.dirtyFile) {
      writeFileSync(path.join(installDir, options.dirtyFile), "правка ученика\n");
    }

    writeFileSync(
      path.join(installDir, ".commentdm-update-state"),
      [`PREVIOUS_COMMIT=${head}`, `DUMP_PATH=${dumpPath}`, "UPDATED_AT=2026-01-01T00:00:00Z", ""].join(
        "\n"
      )
    );

    const stubBinDir = path.join(workDir, "stubbin");
    mkdirSync(stubBinDir, { recursive: true });
    const fakeId = path.join(stubBinDir, "id");
    writeFileSync(fakeId, "#!/bin/sh\necho 0\n");
    chmodSync(fakeId, 0o755);

    const systemctlLog = path.join(workDir, "systemctl.log");
    const fakeSystemctl = path.join(stubBinDir, "systemctl");
    writeFileSync(fakeSystemctl, `#!/bin/sh\necho "$@" >> "${systemctlLog}"\nexit 0\n`);
    chmodSync(fakeSystemctl, 0o755);

    if (options.stubPsql) {
      // Отвечает так же, как живая база на оба запроса --check: «я на
      // связи» и «чужих объектов в public нет».
      const fakePsql = path.join(stubBinDir, "psql");
      writeFileSync(fakePsql, "#!/bin/sh\necho 0\nexit 0\n");
      chmodSync(fakePsql, 0o755);
    }

    return { installDir, stubBinDir, systemctlLog };
  }

  function runRollback(
    installDir: string,
    stubBinDir: string,
    stdin: string
  ): { status: number; output: string } {
    try {
      // 2>&1 внутри команды, а не склейка stdout+stderr снаружи: часть
      // сообщений скрипта (err) идёт в stderr, а на успешном завершении
      // execFileSync возвращает только stdout и они бы потерялись.
      const output = execFileSync(
        "bash",
        ["-c", `bash "${path.join(installDir, "scripts/rollback.sh")}" 2>&1`],
        {
          cwd: installDir,
          input: stdin,
          env: { ...process.env, PATH: `${stubBinDir}:${process.env.PATH}` },
          encoding: "utf8",
          stdio: ["pipe", "pipe", "pipe"],
        }
      );
      return { status: 0, output };
    } catch (error) {
      const err = error as { status: number | null; stdout?: string; stderr?: string };
      return { status: err.status ?? 1, output: `${err.stdout ?? ""}${err.stderr ?? ""}` };
    }
  }

  it("на битом дампе останавливается ДО остановки сервисов", () => {
    const { installDir, stubBinDir, systemctlLog } = setUpInstall({
      dumpValid: false,
      stubPsql: true,
    });

    const { status, output } = runRollback(installDir, stubBinDir, "ОТКАТИТЬ\n");

    expect(status).not.toBe(0);
    expect(output).toContain("Откат остановлен до остановки сервисов");
    expect(output).not.toContain("Останавливаю сервисы");
    // Ни одной команды systemctl: сервисы не тронуты вообще.
    expect(() => statSync(systemctlLog)).toThrow();
  });

  it("на недоступной базе тоже останавливается ДО остановки сервисов", () => {
    const { installDir, stubBinDir, systemctlLog } = setUpInstall({
      dumpValid: true,
      stubPsql: false, // настоящий psql, база по порту 59999 не отвечает
    });

    const { status, output } = runRollback(installDir, stubBinDir, "ОТКАТИТЬ\n");

    expect(status).not.toBe(0);
    expect(output).toContain("Откат остановлен до остановки сервисов");
    expect(output).not.toContain("Останавливаю сервисы");
    expect(() => statSync(systemctlLog)).toThrow();
  });

  it("предупреждает про незакоммиченные правки, а не только про базу", () => {
    const { installDir, stubBinDir } = setUpInstall({
      dumpValid: true,
      stubPsql: true,
      // Имя латиницей намеренно: git в `status --porcelain` экранирует
      // не-ASCII пути в октальный вид, и проверка ловила бы кодировку, а не
      // предупреждение.
      dirtyFile: "my-experiment.ts",
    });

    const { output } = runRollback(installDir, stubBinDir, "нет\n");

    expect(output).toContain("Проверки пройдены");
    expect(output).toContain("В коде есть несохранённые правки");
    expect(output).toContain("my-experiment.ts");
    expect(output).toContain("Отменено. Ничего не тронуто.");
  });
});

describe("scripts/set-domain.sh — проверка домена до правки конфигов", () => {
  function setUpFakeInstall(): { installDir: string; stubBinDir: string; envPath: string } {
    const installDir = path.join(workDir, "install");
    mkdirSync(path.join(installDir, "deploy"), { recursive: true });
    mkdirSync(path.join(installDir, "scripts"), { recursive: true });
    cpSync(path.join(REPO_ROOT, "deploy/lib.sh"), path.join(installDir, "deploy/lib.sh"));
    cpSync(path.join(REPO_ROOT, "deploy/Caddyfile"), path.join(installDir, "deploy/Caddyfile"));
    cpSync(
      path.join(REPO_ROOT, "scripts/set-domain.sh"),
      path.join(installDir, "scripts/set-domain.sh")
    );

    const envPath = path.join(installDir, ".env");
    writeFileSync(envPath, "APP_URL=https://old.example.com\n");

    const stubBinDir = path.join(workDir, "stubbin");
    mkdirSync(stubBinDir, { recursive: true });
    for (const [name, body] of [
      ["id", "#!/bin/sh\necho 0\n"],
      ["caddy", "#!/bin/sh\nexit 0\n"],
      ["systemctl", "#!/bin/sh\nif [ \"$1\" = 'is-active' ]; then exit 1; fi\nexit 0\n"],
    ] as const) {
      const p = path.join(stubBinDir, name);
      writeFileSync(p, body);
      chmodSync(p, 0o755);
    }
    return { installDir, stubBinDir, envPath };
  }

  function run(
    installDir: string,
    stubBinDir: string,
    args: string[]
  ): { status: number; output: string } {
    try {
      const output = execFileSync(
        "bash",
        [
          "-c",
          `bash "${path.join(installDir, "scripts/set-domain.sh")}" ${args
            .map((a) => `'${a}'`)
            .join(" ")} 2>&1`,
        ],
        {
          cwd: installDir,
          input: "",
          env: {
            ...process.env,
            PATH: `${stubBinDir}:${process.env.PATH}`,
            CADDY_CONFIG_PATH: path.join(installDir, "fake-caddyfile"),
          },
          encoding: "utf8",
          stdio: ["pipe", "pipe", "pipe"],
        }
      );
      return { status: 0, output };
    } catch (error) {
      const err = error as { status: number | null; stdout?: string; stderr?: string };
      return { status: err.status ?? 1, output: `${err.stdout ?? ""}${err.stderr ?? ""}` };
    }
  }

  it("отказывается менять домен на строку с символом |", () => {
    const { installDir, stubBinDir, envPath } = setUpFakeInstall();

    const { status, output } = run(installDir, stubBinDir, ["bot|example.com", "--skip-dns-check"]);

    expect(status).not.toBe(0);
    expect(output).toContain("не похоже на доменное имя");
    expect(readFileSync(envPath, "utf8")).toContain("APP_URL=https://old.example.com");
  });

  it(
    "срезает схему из аргумента вместо https://https:// в APP_URL",
    () => {
      const { installDir, stubBinDir, envPath } = setUpFakeInstall();

      const { status } = run(installDir, stubBinDir, [
        "https://new.example.com",
        "--skip-dns-check",
      ]);

      expect(status).toBe(0);
      const content = readFileSync(envPath, "utf8");
      expect(content).toContain("APP_URL=https://new.example.com");
      expect(content).not.toContain("https://https://");
    },
    15000
  );
});
