/**
 * Session Token — Unit Tests
 *
 * The signed cookie is the whole authentication story now: there is no session
 * table to fall back on, so a forged or stale token has to fail on the
 * signature alone.
 */

import { afterEach, describe, expect, it, vi } from "vitest";
import { sessionCookieOptions } from "../lib/auth/session-cookie";
import {
  SESSION_COOKIE_NAME,
  SESSION_MAX_AGE_SECONDS,
  createSessionToken,
  verifySessionToken,
} from "../lib/auth/session-token";

afterEach(() => {
  vi.unstubAllEnvs();
});

const SECRET = "test-session-secret-with-enough-length";

describe("session token", () => {
  it("round-trips the user id through sign and verify", () => {
    const token = createSessionToken("user_123", SECRET);
    const payload = verifySessionToken(token, SECRET);

    expect(payload?.sub).toBe("user_123");
  });

  it("carries an expiry derived from the configured lifetime", () => {
    const now = 1_700_000_000_000;
    const token = createSessionToken("user_123", SECRET, undefined, now);
    const payload = verifySessionToken(token, SECRET, now);

    expect(payload?.iat).toBe(now);
    expect(payload?.exp).toBe(now + SESSION_MAX_AGE_SECONDS * 1000);
  });

  it("rejects a token signed with a different secret", () => {
    const token = createSessionToken("user_123", SECRET);

    expect(verifySessionToken(token, "another-secret-entirely")).toBeNull();
  });

  it("rejects a tampered payload", () => {
    const token = createSessionToken("user_123", SECRET);
    const [, signature] = token.split(".");
    const forgedPayload = Buffer.from(
      JSON.stringify({ sub: "attacker", iat: Date.now(), exp: Date.now() + 1000 })
    ).toString("base64url");

    expect(verifySessionToken(`${forgedPayload}.${signature}`, SECRET)).toBeNull();
  });

  it("rejects an expired token", () => {
    const now = 1_700_000_000_000;
    const token = createSessionToken("user_123", SECRET, 60, now);

    expect(verifySessionToken(token, SECRET, now + 61_000)).toBeNull();
  });

  it("rejects missing and malformed values", () => {
    expect(verifySessionToken(null, SECRET)).toBeNull();
    expect(verifySessionToken("", SECRET)).toBeNull();
    expect(verifySessionToken("no-separator", SECRET)).toBeNull();
    expect(verifySessionToken(".signature-only", SECRET)).toBeNull();
  });

  it("names the cookie the proxy looks for", () => {
    expect(SESSION_COOKIE_NAME).toBe("commentdm_session");
  });
});

describe("session cookie attributes", () => {
  it("is httpOnly and SameSite=Lax with a 30 day life", () => {
    vi.stubEnv("APP_URL", "https://commentdm.example.com");

    const options = sessionCookieOptions();

    expect(options.name).toBe(SESSION_COOKIE_NAME);
    expect(options.httpOnly).toBe(true);
    expect(options.sameSite).toBe("lax");
    expect(options.path).toBe("/");
    expect(options.maxAge).toBe(SESSION_MAX_AGE_SECONDS);
    expect(SESSION_MAX_AGE_SECONDS).toBe(30 * 24 * 60 * 60);
  });

  it("sets Secure when the app is served over https", () => {
    vi.stubEnv("APP_URL", "https://commentdm.example.com");

    expect(sessionCookieOptions().secure).toBe(true);
  });

  it("drops Secure on a plain-http install, so localhost can still log in", () => {
    vi.stubEnv("APP_URL", "http://localhost:3000");

    expect(sessionCookieOptions().secure).toBe(false);
  });

  it("clears the cookie with a zero max age", () => {
    vi.stubEnv("APP_URL", "https://commentdm.example.com");

    expect(sessionCookieOptions(0).maxAge).toBe(0);
  });
});
