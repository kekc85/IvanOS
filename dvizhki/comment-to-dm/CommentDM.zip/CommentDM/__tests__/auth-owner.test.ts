/**
 * Owner Bootstrap — Unit Tests
 *
 * With NextAuth's Prisma adapter gone, this module is the only writer of a
 * `User` row, and `Workspace.ownerId` is a foreign key onto it. So the case
 * that matters most is the empty database: the owner has to be created before
 * anything asks for a workspace.
 */

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const { mockFindFirst, mockCreate, mockUpdate } = vi.hoisted(() => ({
  mockFindFirst: vi.fn(),
  mockCreate: vi.fn(),
  mockUpdate: vi.fn(),
}));

vi.mock("@/lib/db/client", () => ({
  prisma: {
    user: {
      findFirst: mockFindFirst,
      create: mockCreate,
      update: mockUpdate,
    },
  },
}));

import {
  changeOwnerPassword,
  ensureOwner,
  resetOwnerBootstrapCache,
  verifyOwnerPassword,
} from "../lib/auth/owner";
import { hashPassword, verifyPassword } from "../lib/auth/password";

beforeEach(() => {
  vi.clearAllMocks();
  vi.unstubAllEnvs();
  resetOwnerBootstrapCache();
});

afterEach(() => {
  vi.restoreAllMocks();
});

describe("ensureOwner on an empty database", () => {
  it("creates the owner row with the configured password", async () => {
    vi.stubEnv("OWNER_PASSWORD", "tK9-quiet-lantern");
    vi.stubEnv("OWNER_EMAIL", "me@example.com");
    mockFindFirst.mockResolvedValue(null);
    mockCreate.mockImplementation(async ({ data }: { data: Record<string, string> }) => ({
      id: "user_1",
      email: data.email,
      passwordHash: data.passwordHash,
    }));

    const owner = await ensureOwner();

    expect(mockCreate).toHaveBeenCalledTimes(1);
    const created = mockCreate.mock.calls[0][0].data;
    expect(created.email).toBe("me@example.com");
    expect(created.passwordHash).not.toContain("tK9-quiet-lantern");
    await expect(
      verifyPassword("tK9-quiet-lantern", owner.passwordHash)
    ).resolves.toBe(true);
  });

  it("generates a password and prints it exactly once when none is configured", async () => {
    const log = vi.spyOn(console, "log").mockImplementation(() => {});
    mockFindFirst.mockResolvedValue(null);
    mockCreate.mockImplementation(async ({ data }: { data: Record<string, string> }) => ({
      id: "user_1",
      email: data.email,
      passwordHash: data.passwordHash,
    }));

    await ensureOwner();
    await ensureOwner();
    await ensureOwner();

    expect(mockCreate).toHaveBeenCalledTimes(1);
    expect(log).toHaveBeenCalledTimes(1);
    expect(String(log.mock.calls[0][0])).toContain("создан аккаунт владельца");
    // Honest, not the old false claim: the DB only ever holds the hash, but
    // this printed line does reach the system journal and stays there.
    expect(String(log.mock.calls[0][0])).not.toMatch(/not stored in plain text/i);
    expect(String(log.mock.calls[0][0])).toContain("журнал");
  });

  it("refuses to start on a blocklisted OWNER_PASSWORD", async () => {
    vi.stubEnv("OWNER_PASSWORD", "password");
    mockFindFirst.mockResolvedValue(null);

    await expect(ensureOwner()).rejects.toThrow(/самых угадываемых/);
    expect(mockCreate).not.toHaveBeenCalled();
  });

  it("refuses to start on a too-short OWNER_PASSWORD", async () => {
    vi.stubEnv("OWNER_PASSWORD", "short12");
    mockFindFirst.mockResolvedValue(null);

    await expect(ensureOwner()).rejects.toThrow(/не короче 8/);
    expect(mockCreate).not.toHaveBeenCalled();
  });

  it("does not cache a failed bootstrap", async () => {
    mockFindFirst.mockRejectedValueOnce(new Error("database is down"));

    await expect(ensureOwner()).rejects.toThrow("database is down");

    mockFindFirst.mockResolvedValue({
      id: "user_1",
      email: "me@example.com",
      passwordHash: null,
    });
    await expect(ensureOwner()).resolves.toMatchObject({ id: "user_1" });
  });
});

describe("ensureOwner with an existing owner", () => {
  it("leaves the row alone when no OWNER_PASSWORD is set", async () => {
    mockFindFirst.mockResolvedValue({
      id: "user_1",
      email: "me@example.com",
      passwordHash: "scrypt$16384$8$1$c2FsdA$aGFzaA",
    });

    const owner = await ensureOwner();

    expect(owner.id).toBe("user_1");
    expect(mockCreate).not.toHaveBeenCalled();
    expect(mockUpdate).not.toHaveBeenCalled();
  });

  it("ignores OWNER_PASSWORD for an existing owner — the stored hash is the sole source of truth", async () => {
    // Regression guard for the old behavior: OWNER_PASSWORD used to be
    // re-checked and silently re-applied on every boot, which meant the
    // real password had to live in .env in plain text for the life of the
    // instance. See the module doc in lib/auth/owner.ts.
    vi.stubEnv("OWNER_PASSWORD", "tK9-quiet-lantern");
    const existingHash = "scrypt$16384$8$1$c2FsdA$aGFzaA";
    mockFindFirst.mockResolvedValue({
      id: "user_1",
      email: "me@example.com",
      passwordHash: existingHash,
    });

    const owner = await ensureOwner();

    expect(mockUpdate).not.toHaveBeenCalled();
    expect(mockCreate).not.toHaveBeenCalled();
    expect(owner.passwordHash).toBe(existingHash);
  });
});

describe("changeOwnerPassword", () => {
  const existingHash = "scrypt$16384$8$1$c2FsdA$aGFzaA";

  it("rejects the wrong current password without touching the database", async () => {
    mockFindFirst.mockResolvedValue({
      id: "user_1",
      email: "me@example.com",
      passwordHash: existingHash,
    });

    const result = await changeOwnerPassword("wrong-current", "tK9-quiet-lantern");

    expect(result.ok).toBe(false);
    expect(mockUpdate).not.toHaveBeenCalled();
  });

  it("rejects a new password that fails policy, without touching the database", async () => {
    const realHash = await hashPassword("current-password-123");
    mockFindFirst.mockResolvedValue({
      id: "user_1",
      email: "me@example.com",
      passwordHash: realHash,
    });

    const result = await changeOwnerPassword("current-password-123", "short");

    expect(result.ok).toBe(false);
    expect(mockUpdate).not.toHaveBeenCalled();
  });

  it("updates the stored hash on a correct current password and valid new one", async () => {
    const realHash = await hashPassword("current-password-123");
    mockFindFirst.mockResolvedValue({
      id: "user_1",
      email: "me@example.com",
      passwordHash: realHash,
    });
    mockUpdate.mockImplementation(
      async ({ data }: { data: Record<string, string> }) => ({
        id: "user_1",
        email: "me@example.com",
        passwordHash: data.passwordHash,
      })
    );

    const result = await changeOwnerPassword(
      "current-password-123",
      "tK9-quiet-lantern"
    );

    expect(result.ok).toBe(true);
    expect(mockUpdate).toHaveBeenCalledTimes(1);
    const newHash = mockUpdate.mock.calls[0][0].data.passwordHash;
    await expect(verifyPassword("tK9-quiet-lantern", newHash)).resolves.toBe(
      true
    );
  });
});

describe("verifyOwnerPassword", () => {
  it("returns the owner id on the right password", async () => {
    vi.stubEnv("OWNER_PASSWORD", "tK9-quiet-lantern");
    mockFindFirst.mockResolvedValue(null);
    mockCreate.mockImplementation(async ({ data }: { data: Record<string, string> }) => ({
      id: "user_1",
      email: data.email,
      passwordHash: data.passwordHash,
    }));

    await expect(verifyOwnerPassword("tK9-quiet-lantern")).resolves.toBe(
      "user_1"
    );
  });

  it("returns null on a wrong password", async () => {
    vi.stubEnv("OWNER_PASSWORD", "tK9-quiet-lantern");
    mockFindFirst.mockResolvedValue(null);
    mockCreate.mockImplementation(async ({ data }: { data: Record<string, string> }) => ({
      id: "user_1",
      email: data.email,
      passwordHash: data.passwordHash,
    }));

    await expect(verifyOwnerPassword("wrong-password-here")).resolves.toBeNull();
    await expect(verifyOwnerPassword("")).resolves.toBeNull();
  });

  it("returns null when the owner row has no hash yet", async () => {
    mockFindFirst.mockResolvedValue({
      id: "user_1",
      email: "me@example.com",
      passwordHash: null,
    });

    await expect(verifyOwnerPassword("anything-at-all")).resolves.toBeNull();
  });
});
