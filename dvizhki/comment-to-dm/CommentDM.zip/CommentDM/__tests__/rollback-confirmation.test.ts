/**
 * scripts/rollback.sh — confirmation gate integration test.
 *
 * Rollback discards every row written to the database after the pre-update
 * dump, so it must never proceed on anything less than the exact typed
 * confirmation phrase. This runs the real script (not a re-implementation
 * of its logic) in a throwaway temp directory standing in for an install:
 * its own copy of deploy/lib.sh + deploy/restore-db.sh, a synthetic .env
 * pointing at a DATABASE_URL nothing is listening on, and a fake
 * `.commentdm-update-state`. `id` is stubbed on PATH so require_root passes
 * without actually running as root; systemctl being absent on this machine
 * is the test's own proof that the script reached (or didn't reach) the
 * destructive steps — not something asserted by inspecting the script's
 * source.
 *
 * Фикстура учитывает порядок операций, введённый после аварии с откатом на
 * PostgreSQL 12/14: rollback.sh теперь ПЕРЕД остановкой сервисов гоняет
 * deploy/restore-db.sh --check (дамп цел, база отвечает, коммит на месте) —
 * иначе непроходимая проблема всплывала уже после stop_services и сервер
 * оставался лежать. Чтобы этот файл проверял именно гейт подтверждения, а
 * не спотыкался о предпроверку, дамп здесь настоящий gzip, коммит отката —
 * настоящий HEAD, а `psql` подменён так, что отвечает на проверочные
 * запросы (-tAc) и отказывает на всём остальном. Отказ на «всём остальном»
 * и есть та же гарантия, что раньше давал недоступный Postgres: дойдя до
 * настоящего восстановления базы, скрипт обязан упасть.
 */
import { execFileSync } from "node:child_process";
import { gzipSync } from "node:zlib";
import { mkdtempSync, mkdirSync, writeFileSync, cpSync, chmodSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";

const REPO_ROOT = path.resolve(__dirname, "..");
// Nothing listens here — any DB call must fail fast with "connection
// refused" rather than hang, and can never be mistaken for a real database.
const UNREACHABLE_DATABASE_URL =
  "postgresql://nouser:nopass@127.0.0.1:59999/nonexistent_test_db_commentdm";

let installDir: string;
let stubBinDir: string;

function setUpFakeInstall(): void {
  installDir = mkdtempSync(path.join(tmpdir(), "commentdm-rollback-test-"));

  mkdirSync(path.join(installDir, "deploy"), { recursive: true });
  mkdirSync(path.join(installDir, "scripts"), { recursive: true });
  cpSync(path.join(REPO_ROOT, "deploy/lib.sh"), path.join(installDir, "deploy/lib.sh"));
  cpSync(
    path.join(REPO_ROOT, "deploy/restore-db.sh"),
    path.join(installDir, "deploy/restore-db.sh")
  );
  cpSync(
    path.join(REPO_ROOT, "scripts/rollback.sh"),
    path.join(installDir, "scripts/rollback.sh")
  );

  writeFileSync(path.join(installDir, ".env"), `DATABASE_URL=${UNREACHABLE_DATABASE_URL}\n`);

  // Настоящий gzip: предпроверка отката делает gzip -t и на мусорном файле
  // остановилась бы, не дойдя до гейта подтверждения, который здесь и
  // проверяется. Содержимое всё равно никогда не восстанавливается.
  const dumpPath = path.join(installDir, "fake-dump.sql.gz");
  writeFileSync(dumpPath, gzipSync(Buffer.from("-- never actually restored\n")));

  // confirm_rollback() prints the current HEAD before prompting — needs a
  // real (tiny) git repo under installDir.
  const gitEnv = {
    ...process.env,
    GIT_AUTHOR_NAME: "test",
    GIT_AUTHOR_EMAIL: "test@localhost",
    GIT_COMMITTER_NAME: "test",
    GIT_COMMITTER_EMAIL: "test@localhost",
  };
  execFileSync("git", ["init", "-q"], { cwd: installDir, env: gitEnv });
  writeFileSync(path.join(installDir, "README"), "fake install\n");
  execFileSync("git", ["add", "-A"], { cwd: installDir, env: gitEnv });
  execFileSync("git", ["commit", "-q", "-m", "initial"], { cwd: installDir, env: gitEnv });
  const head = execFileSync("git", ["rev-parse", "HEAD"], {
    cwd: installDir,
    env: gitEnv,
    encoding: "utf8",
  }).trim();

  writeFileSync(
    path.join(installDir, ".commentdm-update-state"),
    [
      `PREVIOUS_COMMIT=${head}`,
      `DUMP_PATH=${dumpPath}`,
      "UPDATED_AT=2026-01-01T00:00:00Z",
      "",
    ].join("\n")
  );

  // Fake `id`: require_root() only ever calls `id -u`. Stubbed so this test
  // doesn't need to run as root.
  stubBinDir = mkdtempSync(path.join(tmpdir(), "commentdm-rollback-stubbin-"));
  const fakeId = path.join(stubBinDir, "id");
  writeFileSync(fakeId, "#!/bin/sh\necho 0\n");
  chmodSync(fakeId, 0o755);

  // Fake `psql`: отвечает только на проверочные запросы предпроверки
  // (-tAc «SELECT 1» и счётчик чужих объектов в public) и отказывает на
  // всём остальном — в том числе на настоящей очистке базы. Именно этот
  // отказ доказывает, что скрипт дошёл до разрушительного шага.
  const fakePsql = path.join(stubBinDir, "psql");
  writeFileSync(
    fakePsql,
    [
      "#!/bin/sh",
      'for arg in "$@"; do',
      '  if [ "$arg" = "-tAc" ]; then echo 0; exit 0; fi',
      "done",
      'echo "fake psql: refusing to touch a database in tests" >&2',
      "exit 1",
      "",
    ].join("\n")
  );
  chmodSync(fakePsql, 0o755);
}

function runRollback(stdin: string): { status: number; output: string } {
  try {
    const output = execFileSync("bash", [path.join(installDir, "scripts/rollback.sh")], {
      cwd: installDir,
      input: stdin,
      env: { ...process.env, PATH: `${stubBinDir}:${process.env.PATH}` },
      encoding: "utf8",
      stdio: ["pipe", "pipe", "pipe"],
    });
    return { status: 0, output };
  } catch (error) {
    const err = error as { status: number | null; stdout?: string; stderr?: string };
    return {
      status: err.status ?? 1,
      output: `${err.stdout ?? ""}${err.stderr ?? ""}`,
    };
  }
}

beforeEach(() => {
  setUpFakeInstall();
});

afterEach(() => {
  rmSync(installDir, { recursive: true, force: true });
  rmSync(stubBinDir, { recursive: true, force: true });
});

describe("scripts/rollback.sh — confirmation gate", () => {
  it("declines and touches nothing when the answer isn't the exact phrase", () => {
    const { status, output } = runRollback("no\n");
    expect(status).toBe(0);
    expect(output).toContain("Отменено. Ничего не тронуто.");
    expect(output).not.toContain("Останавливаю сервисы");
    expect(output).not.toContain("Восстанавливаю базу данных");
  });

  it("declines on a near-miss (wrong case) — the match is exact, not case-insensitive", () => {
    const { status, output } = runRollback("откатить\n");
    expect(status).toBe(0);
    expect(output).toContain("Отменено. Ничего не тронуто.");
  });

  it("declines on empty input (just pressing enter)", () => {
    const { status, output } = runRollback("\n");
    expect(status).toBe(0);
    expect(output).toContain("Отменено. Ничего не тронуто.");
  });

  it("proceeds past the gate on the exact phrase and attempts the real restore", () => {
    const { status, output } = runRollback("ОТКАТИТЬ\n");
    // The fake DATABASE_URL guarantees this fails once it actually tries to
    // talk to a database — which is the point: it must have gotten that far.
    expect(status).not.toBe(0);
    expect(output).not.toContain("Отменено. Ничего не тронуто.");
    expect(output).toContain("Останавливаю сервисы");
    expect(output).toContain("Восстанавливаю базу данных");
  });
});

describe("scripts/rollback.sh — no update has ever run", () => {
  it("refuses to guess and explains why, without prompting for anything", () => {
    // Overwrite the fake install with one that has no state file at all —
    // the shape of a fresh install.sh install that has never run
    // `npm run update`.
    rmSync(path.join(installDir, ".commentdm-update-state"));

    const { status, output } = runRollback("");
    expect(status).not.toBe(0);
    expect(output).toContain("Нечего откатывать");
  });
});
