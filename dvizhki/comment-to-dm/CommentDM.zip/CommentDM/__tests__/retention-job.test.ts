/**
 * Retention Cleanup Job — Unit Tests
 *
 * Verifies the job deletes rows older than each table's cutoff and leaves
 * fresher rows alone, and — the one that matters most — that DmLog is
 * filtered against the Meta-window-aware safe cutoff, not a raw
 * retention-days cutoff that could reach inside the window. DmLog doubles
 * as the polling reconciler's dedup set, so this is the floor that actually
 * protects against a duplicate DM (see lib/gdpr/retention-config.ts).
 */

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const { mockPrisma } = vi.hoisted(() => ({
  mockPrisma: {
    dmLog: { deleteMany: vi.fn() },
    linkClick: { deleteMany: vi.fn() },
    subscriberJourney: { deleteMany: vi.fn() },
    operationalEvent: { deleteMany: vi.fn(), create: vi.fn() },
  },
}));

vi.mock("@/lib/db/client", () => ({
  prisma: mockPrisma,
}));

import { runRetentionCleanupJob } from "../lib/ops/retention-job";
import {
  getChainJourneyCutoff,
  getDmLogCutoff,
  getLinkClickCutoff,
  getOperationalEventCutoff,
} from "../lib/gdpr/retention-config";

beforeEach(() => {
  vi.clearAllMocks();
  vi.useFakeTimers();
  vi.setSystemTime(new Date("2026-08-07T12:00:00.000Z"));
  mockPrisma.dmLog.deleteMany.mockResolvedValue({ count: 3 });
  mockPrisma.linkClick.deleteMany.mockResolvedValue({ count: 7 });
  mockPrisma.subscriberJourney.deleteMany.mockResolvedValue({ count: 2 });
  mockPrisma.operationalEvent.deleteMany.mockResolvedValue({ count: 5 });
  mockPrisma.operationalEvent.create.mockResolvedValue({});
});

afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllEnvs();
});

describe("runRetentionCleanupJob", () => {
  it("deletes DmLog rows older than the DM log cutoff only", async () => {
    await runRetentionCleanupJob();
    const call = mockPrisma.dmLog.deleteMany.mock.calls[0][0];
    expect(call.where.createdAt.lt.getTime()).toBe(
      getDmLogCutoff(new Date()).getTime()
    );
  });

  it("deletes LinkClick rows older than the (shorter) link click cutoff", async () => {
    await runRetentionCleanupJob();
    const call = mockPrisma.linkClick.deleteMany.mock.calls[0][0];
    expect(call.where.createdAt.lt.getTime()).toBe(
      getLinkClickCutoff(new Date()).getTime()
    );
    // The link click cutoff must not be older (further back) than the DM log
    // cutoff — link clicks are retained for a shorter time, so their cutoff
    // date is more recent.
    expect(call.where.createdAt.lt.getTime()).toBeGreaterThan(
      getDmLogCutoff(new Date()).getTime()
    );
  });

  it("deletes OperationalEvent rows older than the operational event cutoff", async () => {
    await runRetentionCleanupJob();
    const call = mockPrisma.operationalEvent.deleteMany.mock.calls[0][0];
    expect(call.where.createdAt.lt.getTime()).toBe(
      getOperationalEventCutoff(new Date()).getTime()
    );
  });

  it("filters DmLog by the Meta-window-safe floor, not a raw retention cutoff", async () => {
    // Force the configured retention far below Meta's window so the only
    // way the test passes is if the job used the clamped floor cutoff.
    vi.stubEnv("DM_LOG_RETENTION_DAYS", "1");

    await runRetentionCleanupJob();

    const call = mockPrisma.dmLog.deleteMany.mock.calls[0][0];
    const usedCutoff: Date = call.where.createdAt.lt;
    const safeCutoff = getDmLogCutoff(new Date());
    const metaWindowCutoff = new Date(Date.now() - 168 * 60 * 60 * 1000);

    expect(usedCutoff.getTime()).toBe(safeCutoff.getTime());
    // The core guarantee: never reaches inside Meta's reply window, no
    // matter how the operator configured retention.
    expect(usedCutoff.getTime()).toBeLessThanOrEqual(metaWindowCutoff.getTime());
  });

  it("deletes finished chain journeys older than the journey cutoff", async () => {
    await runRetentionCleanupJob();
    const call = mockPrisma.subscriberJourney.deleteMany.mock.calls[0][0];
    expect(call.where.createdAt.lt.getTime()).toBe(
      getChainJourneyCutoff(new Date()).getTime()
    );
  });

  it("never touches a chain that is still running", async () => {
    await runRetentionCleanupJob();
    const call = mockPrisma.subscriberJourney.deleteMany.mock.calls[0][0];

    // The whole point of the state filter: GATE_SENT and ACTIVE are live
    // chains, closed by the chain's own TTL machinery, never by cleanup.
    expect(call.where.state.in).toEqual([
      "DONE",
      "EXPIRED",
      "STOPPED",
      "SKIPPED",
      "FAILED",
    ]);
    expect(call.where.state.in).not.toContain("GATE_SENT");
    expect(call.where.state.in).not.toContain("ACTIVE");
  });

  it("keeps the journey cutoff at least two days back even if configured to zero", async () => {
    vi.stubEnv("CHAIN_JOURNEY_RETENTION_DAYS", "0");

    await runRetentionCleanupJob();

    const call = mockPrisma.subscriberJourney.deleteMany.mock.calls[0][0];
    const twoDaysBack = new Date(Date.now() - 48 * 60 * 60 * 1000);
    expect(call.where.createdAt.lt.getTime()).toBeLessThanOrEqual(
      twoDaysBack.getTime()
    );
  });

  it("writes exactly one summary OperationalEvent with the deleted counts", async () => {
    const summary = await runRetentionCleanupJob();

    expect(summary).toEqual({
      dmLogsDeleted: 3,
      linkClicksDeleted: 7,
      chainJourneysDeleted: 2,
      operationalEventsDeleted: 5,
    });
    const message = mockPrisma.operationalEvent.create.mock.calls[0][0].data
      .message as string;
    expect(message).toContain("2 chain journey(s)");

    expect(mockPrisma.operationalEvent.create).toHaveBeenCalledTimes(1);
    const createCall = mockPrisma.operationalEvent.create.mock.calls[0][0];
    expect(createCall.data.source).toBe("SYSTEM");
    expect(createCall.data.payload).toEqual(summary);
  });

  it("does not throw when the summary write itself fails", async () => {
    mockPrisma.operationalEvent.create.mockRejectedValue(new Error("db down"));
    await expect(runRetentionCleanupJob()).resolves.toBeDefined();
  });
});
