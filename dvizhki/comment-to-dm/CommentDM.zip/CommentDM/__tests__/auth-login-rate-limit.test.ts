/**
 * Login Rate Limit — Unit Tests
 *
 * Redis is mocked the same way the DM rate limiter's tests mock it. What is
 * being checked is the decision, not ioredis.
 */

import { beforeEach, describe, expect, it, vi } from "vitest";

const { mockGet, mockIncr, mockExpire, mockTtl, mockDel } = vi.hoisted(() => ({
  mockGet: vi.fn(),
  mockIncr: vi.fn(),
  mockExpire: vi.fn(),
  mockTtl: vi.fn(),
  mockDel: vi.fn(),
}));

vi.mock("ioredis", () => {
  const MockRedis = vi.fn().mockImplementation(function (
    this: Record<string, unknown>
  ) {
    this.get = mockGet;
    this.incr = mockIncr;
    this.expire = mockExpire;
    this.ttl = mockTtl;
    this.del = mockDel;
    return this;
  });
  return { default: MockRedis };
});

vi.stubEnv("REDIS_URL", "redis://localhost:6379");
vi.stubEnv("SESSION_SECRET", "test-session-secret-with-enough-length");

import {
  LOGIN_MAX_ATTEMPTS,
  LOGIN_WINDOW_SECONDS,
  checkLoginRateLimit,
  clearLoginAttempts,
  registerFailedLogin,
} from "../lib/auth/login-rate-limit";

beforeEach(() => {
  vi.clearAllMocks();
});

describe("checkLoginRateLimit", () => {
  it("allows a client with no recorded failures", async () => {
    mockGet.mockResolvedValue(null);

    const result = await checkLoginRateLimit("203.0.113.10");

    expect(result.allowed).toBe(true);
    expect(result.attemptsUsed).toBe(0);
    expect(result.attemptsRemaining).toBe(LOGIN_MAX_ATTEMPTS);
  });

  it("allows a client that is one failure short of the cap", async () => {
    mockGet.mockResolvedValue(String(LOGIN_MAX_ATTEMPTS - 1));

    const result = await checkLoginRateLimit("203.0.113.10");

    expect(result.allowed).toBe(true);
    expect(result.attemptsRemaining).toBe(1);
  });

  it("locks out a client that reached the cap and reports the wait", async () => {
    mockGet.mockResolvedValue(String(LOGIN_MAX_ATTEMPTS));
    mockTtl.mockResolvedValue(420);

    const result = await checkLoginRateLimit("203.0.113.10");

    expect(result.allowed).toBe(false);
    expect(result.attemptsRemaining).toBe(0);
    expect(result.retryAfterSeconds).toBe(420);
  });

  it("falls back to the full window when Redis reports no TTL", async () => {
    mockGet.mockResolvedValue(String(LOGIN_MAX_ATTEMPTS + 3));
    mockTtl.mockResolvedValue(-1);

    const result = await checkLoginRateLimit("203.0.113.10");

    expect(result.allowed).toBe(false);
    expect(result.retryAfterSeconds).toBe(LOGIN_WINDOW_SECONDS);
  });

  it("never puts a raw IP address in the Redis key", async () => {
    mockGet.mockResolvedValue(null);

    await checkLoginRateLimit("203.0.113.10");

    const key = mockGet.mock.calls[0][0] as string;
    expect(key.startsWith("login:fail:")).toBe(true);
    expect(key).not.toContain("203.0.113.10");
  });

  it("buckets an unknown IP separately from a known one", async () => {
    mockGet.mockResolvedValue(null);

    await checkLoginRateLimit(null);
    await checkLoginRateLimit("203.0.113.10");

    expect(mockGet.mock.calls[0][0]).not.toBe(mockGet.mock.calls[1][0]);
  });
});

describe("registerFailedLogin", () => {
  it("starts the window on the first failure", async () => {
    mockIncr.mockResolvedValue(1);

    const result = await registerFailedLogin("203.0.113.10");

    expect(mockExpire).toHaveBeenCalledWith(
      expect.stringContaining("login:fail:"),
      LOGIN_WINDOW_SECONDS
    );
    expect(result.allowed).toBe(true);
    expect(result.attemptsRemaining).toBe(LOGIN_MAX_ATTEMPTS - 1);
  });

  it("does not extend the window on later failures", async () => {
    mockIncr.mockResolvedValue(3);

    await registerFailedLogin("203.0.113.10");

    expect(mockExpire).not.toHaveBeenCalled();
  });

  it("trips the lockout on the failure that reaches the cap", async () => {
    mockIncr.mockResolvedValue(LOGIN_MAX_ATTEMPTS);

    const result = await registerFailedLogin("203.0.113.10");

    expect(result.allowed).toBe(false);
    expect(result.attemptsRemaining).toBe(0);
    expect(result.retryAfterSeconds).toBe(LOGIN_WINDOW_SECONDS);
  });
});

describe("clearLoginAttempts", () => {
  it("drops the counter after a successful sign-in", async () => {
    mockDel.mockResolvedValue(1);

    await clearLoginAttempts("203.0.113.10");

    expect(mockDel).toHaveBeenCalledWith(
      expect.stringContaining("login:fail:")
    );
  });
});
