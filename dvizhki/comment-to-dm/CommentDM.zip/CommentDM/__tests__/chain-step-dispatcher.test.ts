/**
 * Диспетчер шагов — единственное место, откуда уходят сообщения цепочки.
 * Тесты держат порядок, в котором он обязан работать: клейм, гейт окна, своя
 * корзина лимитера, сдвиг позиции ДО сетевого вызова и честный откат на
 * каждом виде отказа.
 */

import { describe, it, expect, vi, beforeEach } from "vitest";

const {
  mockPrisma,
  mockSendDirectMessage,
  mockIsOutsideWindowError,
  mockDecryptToken,
  mockReserveChainSlot,
  mockRedisSet,
  mockRedisDel,
  MockRateLimitError,
} = vi.hoisted(() => {
  class MockRateLimitError extends Error {
    name = "RateLimitError";
  }
  return {
    mockPrisma: {
      subscriberJourney: {
        findMany: vi.fn(),
        findUnique: vi.fn(),
        update: vi.fn(),
        updateMany: vi.fn(),
      },
      sequenceStep: {
        findMany: vi.fn(),
      },
      workspace: {
        findFirst: vi.fn(),
      },
      operationalEvent: {
        create: vi.fn(),
      },
    },
    mockSendDirectMessage: vi.fn(),
    mockIsOutsideWindowError: vi.fn(),
    mockDecryptToken: vi.fn(),
    mockReserveChainSlot: vi.fn(),
    mockRedisSet: vi.fn(),
    mockRedisDel: vi.fn(),
    MockRateLimitError,
  };
});

vi.mock("@/lib/db/client", () => ({ prisma: mockPrisma }));

vi.mock("@/lib/meta/client", () => ({
  sendDirectMessage: mockSendDirectMessage,
  isOutsideWindowError: mockIsOutsideWindowError,
  RateLimitError: MockRateLimitError,
  MetaApiError: class MetaApiError extends Error {
    code: number;
    constructor(
      code: number,
      _subcode: number | undefined,
      _fbTraceId: string | undefined,
      message: string
    ) {
      super(message);
      this.code = code;
      this.name = "MetaApiError";
    }
  },
}));

vi.mock("@/lib/meta/oauth", () => ({ decryptToken: mockDecryptToken }));

vi.mock("@/lib/queue/client", () => ({
  getRedisConnection: () => ({ set: mockRedisSet, del: mockRedisDel }),
}));

vi.mock("@/lib/utils/rate-limiter", () => ({
  reserveChainSlot: mockReserveChainSlot,
}));

import {
  CHAIN_DISPATCH_BATCH,
  CHAIN_RATE_LIMIT_BACKOFF_MS,
  MAX_STEP_ATTEMPTS,
  dispatchChainSteps,
  resetChainDispatchLogState,
} from "../lib/chain/step-dispatcher";
import { MESSAGING_WINDOW_MS } from "../lib/chain/journey";

const NOW = new Date("2026-08-09T12:00:00.000Z");
const MINUTE = 60_000;
/** Срок шага уже наступил три минуты назад — обычная жизнь при тике в 30с. */
const DUE_AT = new Date(NOW.getTime() - 3 * MINUTE);

const STEPS = [
  { position: 0, delaySeconds: 0, message: "Держи гайд" },
  { position: 1, delaySeconds: 600, message: "M1" },
  { position: 2, delaySeconds: 7200, message: "M2" },
  { position: 3, delaySeconds: 72000, message: "M3" },
];

function journeyRow(overrides: Record<string, unknown> = {}) {
  return {
    id: "journey_1",
    workspaceId: "ws_1",
    automationId: "auto_1",
    instagramAccountId: "acct_row_1",
    subscriberId: "recipient_555",
    lastUserMessageAt: new Date(NOW.getTime() - 60 * MINUTE),
    nextStepPosition: 0,
    nextStepDueAt: DUE_AT,
    attempts: 0,
    automation: { name: "Воронка" },
    instagramAccount: {
      id: "acct_row_1",
      instagramId: "17841400000000001",
      accessToken: "encrypted",
      connectedAt: new Date("2026-01-01T00:00:00.000Z"),
    },
    ...overrides,
  };
}

/**
 * Кладёт пачку «кому пора» и одновременно учит перечитку под клеймом отвечать
 * ровно тем же: в обычной жизни журней между чтением пачки и клеймом не
 * меняется. Тесты гонки переопределяют findUnique после этого вызова.
 */
function setDue(rows: ReturnType<typeof journeyRow>[]) {
  mockPrisma.subscriberJourney.findMany.mockResolvedValue(rows);
  mockPrisma.subscriberJourney.findUnique.mockImplementation(
    async ({ where }: { where: { id: string } }) => {
      const row = rows.find((candidate) => candidate.id === where.id);
      if (!row) return null;
      return {
        state: "ACTIVE",
        nextStepPosition: row.nextStepPosition,
        nextStepDueAt: row.nextStepDueAt,
      };
    }
  );
}

function updateData(index = 0) {
  const call = mockPrisma.subscriberJourney.update.mock.calls[index];
  return (call?.[0] as { data: Record<string, unknown> } | undefined)?.data;
}

function lastUpdateData() {
  const calls = mockPrisma.subscriberJourney.update.mock.calls;
  return (calls[calls.length - 1]?.[0] as { data: Record<string, unknown> })?.data;
}

function events() {
  return mockPrisma.operationalEvent.create.mock.calls.map(
    (c) => (c[0] as { data: Record<string, unknown> }).data
  );
}

beforeEach(() => {
  vi.clearAllMocks();
  resetChainDispatchLogState();
  mockPrisma.subscriberJourney.updateMany.mockResolvedValue({ count: 0 });
  mockPrisma.subscriberJourney.update.mockResolvedValue({});
  setDue([]);
  mockPrisma.sequenceStep.findMany.mockResolvedValue(STEPS);
  mockPrisma.workspace.findFirst.mockResolvedValue({ id: "ws_sole" });
  mockPrisma.operationalEvent.create.mockResolvedValue({});
  mockDecryptToken.mockReturnValue("plain-token");
  mockRedisSet.mockResolvedValue("OK");
  mockRedisDel.mockResolvedValue(1);
  mockIsOutsideWindowError.mockReturnValue(false);
  mockSendDirectMessage.mockResolvedValue({
    recipient_id: "recipient_555",
    message_id: "mid_1",
  });
  mockReserveChainSlot.mockResolvedValue({
    allowed: true,
    currentCount: 1,
    remainingDMs: 199,
    shouldRequeue: false,
    requeueDelayMs: 0,
    shouldSkip: false,
    reserved: true,
  });
});

describe("выборка", () => {
  it("закрывает просроченные GATE в начале прохода", async () => {
    await dispatchChainSteps(NOW);

    expect(mockPrisma.subscriberJourney.updateMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({ state: "GATE_SENT" }),
        data: expect.objectContaining({ state: "EXPIRED" }),
      })
    );
  });

  it("берёт не больше кэпа за тик, старые сроки первыми", async () => {
    await dispatchChainSteps(NOW);

    expect(mockPrisma.subscriberJourney.findMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: { state: "ACTIVE", nextStepDueAt: { lte: NOW } },
        orderBy: { nextStepDueAt: "asc" },
        take: CHAIN_DISPATCH_BATCH,
      })
    );
    expect(CHAIN_DISPATCH_BATCH).toBe(10);
  });

  it("пропускает журней, который держит другой проход", async () => {
    setDue([journeyRow()]);
    mockRedisSet.mockResolvedValue(null);

    const result = await dispatchChainSteps(NOW);

    expect(result.claimed).toBe(1);
    expect(mockSendDirectMessage).not.toHaveBeenCalled();
    expect(mockPrisma.subscriberJourney.update).not.toHaveBeenCalled();
  });

  it("снимает клейм после обработки - M1 через 10 минут не должен ждать TTL", async () => {
    setDue([journeyRow()]);

    await dispatchChainSteps(NOW);

    expect(mockRedisDel).toHaveBeenCalledWith("chain:claim:journey_1");
  });
});

/**
 * Пачка читается ДО клейма, то есть в руках у прохода снимок. Второй воркер
 * успевает сдвинуть журней ровно в этот зазор - и отправка «по снимку» стала
 * бы вторым одинаковым сообщением человеку. Клейм без перечитки этого не
 * ловит: он лишь делит журнеи между процессами, а устаревший снимок остаётся
 * устаревшим.
 */
describe("перечитка под клеймом", () => {
  it("не шлёт шаг, если позицию успел сдвинуть другой проход", async () => {
    setDue([journeyRow()]);
    mockPrisma.subscriberJourney.findUnique.mockResolvedValue({
      state: "ACTIVE",
      nextStepPosition: 1,
      nextStepDueAt: DUE_AT,
    });

    const result = await dispatchChainSteps(NOW);

    expect(result.stale).toBe(1);
    expect(result.sent).toBe(0);
    expect(mockSendDirectMessage).not.toHaveBeenCalled();
    expect(mockPrisma.subscriberJourney.update).not.toHaveBeenCalled();
    // Клейм всё равно отпущен: следующий проход должен увидеть журней свободным.
    expect(mockRedisDel).toHaveBeenCalledWith("chain:claim:journey_1");
  });

  it("не шлёт шаг, если срок успели отодвинуть", async () => {
    setDue([journeyRow()]);
    mockPrisma.subscriberJourney.findUnique.mockResolvedValue({
      state: "ACTIVE",
      nextStepPosition: 0,
      nextStepDueAt: new Date(NOW.getTime() + 30 * MINUTE),
    });

    const result = await dispatchChainSteps(NOW);

    expect(result.stale).toBe(1);
    expect(mockSendDirectMessage).not.toHaveBeenCalled();
  });

  it("не шлёт шаг журнею, который уже не ACTIVE", async () => {
    setDue([journeyRow()]);
    mockPrisma.subscriberJourney.findUnique.mockResolvedValue({
      state: "STOPPED",
      nextStepPosition: 0,
      nextStepDueAt: DUE_AT,
    });

    const result = await dispatchChainSteps(NOW);

    expect(result.stale).toBe(1);
    expect(mockSendDirectMessage).not.toHaveBeenCalled();
  });

  it("не шлёт шаг журнею, который успели стереть", async () => {
    setDue([journeyRow()]);
    mockPrisma.subscriberJourney.findUnique.mockResolvedValue(null);

    const result = await dispatchChainSteps(NOW);

    expect(result.stale).toBe(1);
    expect(mockSendDirectMessage).not.toHaveBeenCalled();
  });

  it("шлёт шаг, когда журней не изменился", async () => {
    setDue([journeyRow()]);

    const result = await dispatchChainSteps(NOW);

    expect(result.stale).toBe(0);
    expect(result.sent).toBe(1);
    expect(mockPrisma.subscriberJourney.findUnique).toHaveBeenCalledWith(
      expect.objectContaining({ where: { id: "journey_1" } })
    );
    // Перечитка идёт ПОСЛЕ клейма: до него она ничего не доказывает.
    const claimOrder = mockRedisSet.mock.invocationCallOrder[0];
    const rereadOrder =
      mockPrisma.subscriberJourney.findUnique.mock.invocationCallOrder[0];
    expect(claimOrder).toBeLessThan(rereadOrder);
  });
});

describe("гейт окна", () => {
  it("закрытое окно кладёт журней в EXPIRED, ничего не отправляя", async () => {
    setDue([
      journeyRow({
        lastUserMessageAt: new Date(NOW.getTime() - MESSAGING_WINDOW_MS - MINUTE),
      }),
    ]);

    const result = await dispatchChainSteps(NOW);

    expect(result.expired).toBe(1);
    expect(mockSendDirectMessage).not.toHaveBeenCalled();
    expect(mockReserveChainSlot).not.toHaveBeenCalled();
    expect(updateData()).toMatchObject({
      state: "EXPIRED",
      nextStepDueAt: null,
      completedAt: NOW,
    });
    expect(
      events().some(
        (e) => e.level === "WARNING" && String(e.message).includes("Окно переписки")
      )
    ).toBe(true);
  });
});

describe("отправка шага", () => {
  it("сдвигает позицию в базе ДО сетевого вызова", async () => {
    setDue([journeyRow()]);

    await dispatchChainSteps(NOW);

    expect(updateData()).toMatchObject({ nextStepPosition: 1, attempts: 0 });
    const updateOrder =
      mockPrisma.subscriberJourney.update.mock.invocationCallOrder[0];
    const sendOrder = mockSendDirectMessage.mock.invocationCallOrder[0];
    expect(updateOrder).toBeLessThan(sendOrder);
  });

  it("считает срок следующего шага от ПРЕЖНЕГО срока, а не от «сейчас»", async () => {
    setDue([journeyRow()]);

    await dispatchChainSteps(NOW);

    // Шаг 1 идёт через 600с после шага 0. Якорь — прежний срок (NOW-3мин),
    // значит NOW+7мин. Если бы считали от «сейчас», вышло бы NOW+10мин, и
    // каждая задержка прохода накапливалась бы, съедая окно Meta.
    expect((updateData()!.nextStepDueAt as Date).toISOString()).toBe(
      new Date(DUE_AT.getTime() + 600_000).toISOString()
    );
  });

  it("шлёт текст шага простым сообщением по ID из пространства сообщений", async () => {
    setDue([journeyRow()]);

    const result = await dispatchChainSteps(NOW);

    expect(mockSendDirectMessage).toHaveBeenCalledWith(
      "plain-token",
      "17841400000000001",
      "recipient_555",
      "Держи гайд"
    );
    expect(result.sent).toBe(1);
  });

  it("резервирует слот в СВОЕЙ корзине цепочек", async () => {
    setDue([journeyRow()]);

    await dispatchChainSteps(NOW);

    expect(mockReserveChainSlot).toHaveBeenCalledWith(
      "17841400000000001",
      0,
      expect.any(Date)
    );
  });

  it("последний шаг закрывает журней в DONE", async () => {
    setDue([
      journeyRow({ nextStepPosition: 3 }),
    ]);

    const result = await dispatchChainSteps(NOW);

    expect(mockSendDirectMessage).toHaveBeenCalledWith(
      "plain-token",
      "17841400000000001",
      "recipient_555",
      "M3"
    );
    expect(result.completed).toBe(1);
    expect(lastUpdateData()).toMatchObject({
      state: "DONE",
      nextStepDueAt: null,
      completedAt: NOW,
    });
  });

  it("на последнем шаге срок не обнуляется ДО отправки", async () => {
    setDue([
      journeyRow({ nextStepPosition: 3 }),
    ]);

    await dispatchChainSteps(NOW);

    // Предотправочная запись оставляет ПРЕЖНИЙ срок. Пустой срок тут означал
    // бы вечного зомби: сбой между этой записью и отметкой DONE оставил бы
    // ACTIVE с NULL, а диспетчер выбирает по наступившему сроку и NULL не
    // видит никогда. С прошедшим сроком следующий тик доведёт журней до DONE.
    const data = updateData()!;
    expect(data).toMatchObject({ nextStepPosition: 4, attempts: 0 });
    expect((data.nextStepDueAt as Date).getTime()).toBe(DUE_AT.getTime());
    // Пустым он становится только вместе с DONE, уже после успешной отправки.
    const doneOrder =
      mockPrisma.subscriberJourney.update.mock.invocationCallOrder[1];
    const sendOrder = mockSendDirectMessage.mock.invocationCallOrder[0];
    expect(sendOrder).toBeLessThan(doneOrder);
    expect(lastUpdateData()).toMatchObject({ nextStepDueAt: null });
  });

  it("журней с позицией за концом цепочки закрывается DONE, не тратя слот", async () => {
    setDue([
      journeyRow({ nextStepPosition: 9 }),
    ]);

    const result = await dispatchChainSteps(NOW);

    expect(mockSendDirectMessage).not.toHaveBeenCalled();
    // Шаг читается ДО резерва: завершённая цепочка не должна выжигать место в
    // часовой корзине аккаунта, на которой держатся живые.
    expect(mockReserveChainSlot).not.toHaveBeenCalled();
    expect(result.completed).toBe(1);
    expect(lastUpdateData()).toMatchObject({
      state: "DONE",
      nextStepDueAt: null,
    });
  });

  it("подбирает зомби после сбоя: ACTIVE с прошедшим сроком за концом шагов", async () => {
    // Именно так выглядит журней, чей последний шаг ушёл, а отметку DONE унёс
    // сбой процесса: позиция за концом, срок прежний и уже прошедший.
    setDue([
      journeyRow({ nextStepPosition: 4, nextStepDueAt: DUE_AT }),
    ]);

    const result = await dispatchChainSteps(NOW);

    expect(result.completed).toBe(1);
    expect(mockSendDirectMessage).not.toHaveBeenCalled();
    expect(lastUpdateData()).toMatchObject({
      state: "DONE",
      nextStepDueAt: null,
    });
  });

  it("читает шаги кампании один раз на всю пачку", async () => {
    setDue([
      journeyRow(),
      journeyRow({ id: "journey_2", subscriberId: "recipient_666" }),
    ]);

    await dispatchChainSteps(NOW);

    expect(mockPrisma.sequenceStep.findMany).toHaveBeenCalledTimes(1);
    expect(mockSendDirectMessage).toHaveBeenCalledTimes(2);
  });
});

describe("свой лимитер", () => {
  it("исчерпанная корзина откладывает шаг на 30 минут, позицию не трогает", async () => {
    setDue([journeyRow()]);
    mockReserveChainSlot.mockResolvedValue({
      allowed: false,
      currentCount: 200,
      remainingDMs: 0,
      shouldRequeue: true,
      requeueDelayMs: 30 * MINUTE,
      shouldSkip: false,
      reserved: false,
    });

    const result = await dispatchChainSteps(NOW);

    expect(result.rateLimited).toBe(1);
    expect(mockSendDirectMessage).not.toHaveBeenCalled();
    const data = updateData()!;
    expect(data).not.toHaveProperty("nextStepPosition");
    expect((data.nextStepDueAt as Date).getTime()).toBe(
      NOW.getTime() + CHAIN_RATE_LIMIT_BACKOFF_MS
    );
  });
});

describe("отказы отправки", () => {
  it("закрытое окно от Meta = EXPIRED без ретраев, позиция возвращена", async () => {
    setDue([journeyRow()]);
    mockIsOutsideWindowError.mockReturnValue(true);
    mockSendDirectMessage.mockRejectedValue(
      new Error("outside of allowed window")
    );

    const result = await dispatchChainSteps(NOW);

    expect(result.expired).toBe(1);
    expect(mockSendDirectMessage).toHaveBeenCalledTimes(1);
    expect(lastUpdateData()).toMatchObject({
      state: "EXPIRED",
      nextStepPosition: 0,
      nextStepDueAt: null,
      completedAt: NOW,
    });
  });

  it("лимит Meta откатывает позицию и срок, попыток не жжёт", async () => {
    setDue([
      journeyRow({ attempts: 1 }),
    ]);
    mockSendDirectMessage.mockRejectedValue(new MockRateLimitError("too many"));

    const result = await dispatchChainSteps(NOW);

    expect(result.rateLimited).toBe(1);
    const data = lastUpdateData()!;
    expect(data.nextStepPosition).toBe(0);
    expect(data.attempts).toBe(1);
    expect((data.nextStepDueAt as Date).getTime()).toBe(
      NOW.getTime() + CHAIN_RATE_LIMIT_BACKOFF_MS
    );
    expect(data).not.toHaveProperty("state");
  });

  it("обычная ошибка откатывает позицию и наращивает попытки", async () => {
    setDue([journeyRow()]);
    mockSendDirectMessage.mockRejectedValue(new Error("сеть отвалилась"));

    const result = await dispatchChainSteps(NOW);

    expect(result.failed).toBe(0);
    const data = lastUpdateData()!;
    expect(data.nextStepPosition).toBe(0);
    expect(data.attempts).toBe(1);
    expect(data).not.toHaveProperty("state");
  });

  it("исчерпанные попытки кладут журней в FAILED с текстом ошибки", async () => {
    setDue([
      journeyRow({ attempts: MAX_STEP_ATTEMPTS - 1 }),
    ]);
    mockSendDirectMessage.mockRejectedValue(new Error("сеть отвалилась"));

    const result = await dispatchChainSteps(NOW);

    expect(result.failed).toBe(1);
    const data = lastUpdateData()!;
    expect(data.state).toBe("FAILED");
    expect(data.attempts).toBe(MAX_STEP_ATTEMPTS);
    expect(String(data.failReason)).toContain("сеть отвалилась");
    expect(
      events().some(
        (e) => e.level === "WARNING" && String(e.message).includes("сорвалась")
      )
    ).toBe(true);
  });

  it("нерасшифровываемый токен не двигает позицию", async () => {
    setDue([journeyRow()]);
    mockDecryptToken.mockImplementation(() => {
      throw new Error("bad key");
    });

    const result = await dispatchChainSteps(NOW);

    expect(result.errors).toHaveLength(1);
    expect(mockSendDirectMessage).not.toHaveBeenCalled();
    expect(mockPrisma.subscriberJourney.update).not.toHaveBeenCalled();
  });
});

describe("журнал", () => {
  it("первый проход после старта виден, второй тихий - нет", async () => {
    await dispatchChainSteps(NOW);
    expect(events()).toHaveLength(1);

    mockPrisma.operationalEvent.create.mockClear();
    await dispatchChainSteps(NOW);
    expect(events()).toHaveLength(0);
  });

  it("строка прохода называет причину нетерминального срыва", async () => {
    setDue([journeyRow()]);
    mockSendDirectMessage.mockRejectedValue(new Error("сеть отвалилась"));

    const result = await dispatchChainSteps(NOW);

    // Нетерминальный срыв не увеличивает «сорвалось» - без причин в строке
    // владелец видел «сорвалось 0» и шёл искать поломку, которой в строке нет.
    expect(result.failed).toBe(0);
    const pass = events().find((e) =>
      String(e.message).includes("проход диспетчера")
    )!;
    expect(pass.level).toBe("WARNING");
    expect(String(pass.message)).toContain("сорвалось 0");
    expect(String(pass.message)).toContain("причины:");
    expect(String(pass.message)).toContain("сеть отвалилась");
    // Payload остаётся прежним: там по-прежнему число, а не текст.
    expect((pass.payload as { errors: number }).errors).toBe(1);
  });

  it("показывает не больше двух причин и режет длинные", async () => {
    const long = "т".repeat(300);
    setDue([
      journeyRow(),
      journeyRow({ id: "journey_2", subscriberId: "recipient_666" }),
      journeyRow({ id: "journey_3", subscriberId: "recipient_777" }),
    ]);
    mockSendDirectMessage.mockRejectedValue(new Error(long));

    await dispatchChainSteps(NOW);

    const message = String(
      events().find((e) => String(e.message).includes("проход диспетчера"))!
        .message
    );
    expect(message).toContain("...");
    expect(message).toContain("и ещё 1");
    expect(message).not.toContain(long);
    expect(message.length).toBeLessThan(600);
  });

  it("строку прохода пишет на воркспейс журнея", async () => {
    setDue([journeyRow()]);

    await dispatchChainSteps(NOW);

    const pass = events().find((e) =>
      String(e.message).includes("проход диспетчера")
    )!;
    expect(pass.workspaceId).toBe("ws_1");
    expect(mockPrisma.workspace.findFirst).not.toHaveBeenCalled();
  });

  it("на пустом проходе берёт единственный воркспейс из базы", async () => {
    await dispatchChainSteps(NOW);

    const pass = events().find((e) =>
      String(e.message).includes("проход диспетчера")
    )!;
    // Строка без воркспейса не попадает в отфильтрованную ленту «Журнал» -
    // владелец её просто не видит.
    expect(pass.workspaceId).toBe("ws_sole");
  });

  it("устаревшие журнеи видны в строке прохода", async () => {
    setDue([journeyRow()]);
    mockPrisma.subscriberJourney.findUnique.mockResolvedValue(null);

    await dispatchChainSteps(NOW);

    const pass = events().find((e) =>
      String(e.message).includes("проход диспетчера")
    )!;
    expect(String(pass.message)).toContain("устарело 1");
  });
});
