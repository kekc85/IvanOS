import { describe, it, expect } from "vitest";
import {
  CHAIN_MAX_STEPS,
  CHAIN_MAX_TOTAL_DELAY_SECONDS,
  type ChainStepDraft,
  buildChainStepsPayload,
  chainStepLabel,
  draftDelaySeconds,
  emptyChainStepDraft,
  formatDelayRu,
  formatDurationShort,
  secondsToDraftDelay,
  stepsToDrafts,
  totalChainDelaySeconds,
  validateChainDrafts,
} from "@/components/chain-utils";

/**
 * The chain form's arithmetic and its Russian wording. The repo has no
 * component-test setup (vitest runs in node with no jsdom), so the rules that
 * decide what gets saved live in a plain module and are tested here directly.
 */

function draft(
  message: string,
  delayAmount = "0",
  delayUnit: ChainStepDraft["delayUnit"] = "minutes"
): ChainStepDraft {
  return { message, delayAmount, delayUnit };
}

describe("delay conversion", () => {
  it("keeps position 0 at zero no matter what the field says", () => {
    expect(draftDelaySeconds(draft("выдача", "45", "hours"), 0)).toBe(0);
  });

  it("converts minutes and hours to seconds", () => {
    expect(draftDelaySeconds(draft("m1", "10", "minutes"), 1)).toBe(600);
    expect(draftDelaySeconds(draft("m2", "2", "hours"), 2)).toBe(7200);
    expect(draftDelaySeconds(draft("m3", "20", "hours"), 3)).toBe(72000);
  });

  it("treats an emptied or broken field as no delay instead of NaN", () => {
    expect(draftDelaySeconds(draft("m", "", "minutes"), 1)).toBe(0);
    expect(draftDelaySeconds(draft("m", "abc", "hours"), 1)).toBe(0);
    expect(draftDelaySeconds(draft("m", "-5", "minutes"), 1)).toBe(0);
  });

  it("reads stored seconds back into the friendliest unit", () => {
    expect(secondsToDraftDelay(600)).toEqual({
      delayAmount: "10",
      delayUnit: "minutes",
    });
    expect(secondsToDraftDelay(7200)).toEqual({
      delayAmount: "2",
      delayUnit: "hours",
    });
    expect(secondsToDraftDelay(72000)).toEqual({
      delayAmount: "20",
      delayUnit: "hours",
    });
    // Not a whole number of hours, so it stays in minutes.
    expect(secondsToDraftDelay(5400)).toEqual({
      delayAmount: "90",
      delayUnit: "minutes",
    });
    expect(secondsToDraftDelay(0)).toEqual({
      delayAmount: "0",
      delayUnit: "minutes",
    });
  });

  it("round-trips the plan's chain (0 / 10 мин / 2 ч / 20 ч)", () => {
    const stored = [
      { position: 0, delaySeconds: 0, message: "Выдача" },
      { position: 1, delaySeconds: 600, message: "M1" },
      { position: 2, delaySeconds: 7200, message: "M2" },
      { position: 3, delaySeconds: 72000, message: "M3" },
    ];
    expect(buildChainStepsPayload(stepsToDrafts(stored), true)).toEqual(stored);
  });

  it("sorts steps by position when reading them back", () => {
    const drafts = stepsToDrafts([
      { position: 2, delaySeconds: 7200, message: "второе касание" },
      { position: 0, delaySeconds: 0, message: "выдача" },
      { position: 1, delaySeconds: 600, message: "первое касание" },
    ]);
    expect(drafts.map((d) => d.message)).toEqual([
      "выдача",
      "первое касание",
      "второе касание",
    ]);
  });
});

describe("payload assembly", () => {
  it("numbers positions densely from zero and zeroes the payload step", () => {
    const payload = buildChainStepsPayload(
      [
        draft("  выдача  ", "99", "hours"),
        draft("касание 2", "10", "minutes"),
        draft("касание 3", "2", "hours"),
      ],
      true
    );
    expect(payload).toEqual([
      { position: 0, delaySeconds: 0, message: "выдача" },
      { position: 1, delaySeconds: 600, message: "касание 2" },
      { position: 2, delaySeconds: 7200, message: "касание 3" },
    ]);
  });

  it("keeps blank steps while the chain is on, so the preview stays live", () => {
    const payload = buildChainStepsPayload([draft("выдача"), draft("")], true);
    expect(payload).toHaveLength(2);
    expect(payload[1].message).toBe("");
  });

  it("drops blank steps and renumbers when the chain is off", () => {
    const payload = buildChainStepsPayload(
      [draft("выдача"), draft("   "), draft("касание", "5", "minutes")],
      false
    );
    expect(payload).toEqual([
      { position: 0, delaySeconds: 0, message: "выдача" },
      { position: 1, delaySeconds: 300, message: "касание" },
    ]);
  });

  it("never sends more steps than the API accepts", () => {
    const many = Array.from({ length: 9 }, (_, i) => draft(`шаг ${i}`, "1", "minutes"));
    const payload = buildChainStepsPayload(many, true);
    expect(payload).toHaveLength(CHAIN_MAX_STEPS);
    expect(payload.at(-1)?.position).toBe(CHAIN_MAX_STEPS - 1);
  });

  it("sums the wait the same way the API does", () => {
    expect(
      totalChainDelaySeconds([
        draft("выдача", "10", "minutes"),
        draft("m1", "10", "minutes"),
        draft("m2", "2", "hours"),
        draft("m3", "20", "hours"),
      ])
    ).toBe(600 + 7200 + 72000);
  });

  it("seeds a new step with a usable default", () => {
    const seeded = emptyChainStepDraft();
    expect(seeded.message).toBe("");
    expect(draftDelaySeconds(seeded, 1)).toBe(600);
  });
});

describe("Russian formatting", () => {
  it("names the slots the way the interface calls them", () => {
    expect(chainStepLabel(0)).toBe("Выдача (сразу после ответа)");
    expect(chainStepLabel(1)).toBe("Касание 2");
    expect(chainStepLabel(3)).toBe("Касание 4");
  });

  it("declines minutes and hours correctly", () => {
    expect(formatDelayRu(60)).toBe("через 1 минуту");
    expect(formatDelayRu(120)).toBe("через 2 минуты");
    expect(formatDelayRu(600)).toBe("через 10 минут");
    expect(formatDelayRu(660)).toBe("через 11 минут");
    expect(formatDelayRu(1320)).toBe("через 22 минуты");
    expect(formatDelayRu(3600)).toBe("через 1 час");
    expect(formatDelayRu(7200)).toBe("через 2 часа");
    expect(formatDelayRu(18000)).toBe("через 5 часов");
    expect(formatDelayRu(72000)).toBe("через 20 часов");
    expect(formatDelayRu(5400)).toBe("через 1 час 30 минут");
    expect(formatDelayRu(0)).toBe("сразу");
  });

  it("writes the running total compactly", () => {
    expect(formatDurationShort(0)).toBe("0 мин");
    expect(formatDurationShort(600)).toBe("10 мин");
    expect(formatDurationShort(7200)).toBe("2 ч");
    expect(formatDurationShort(79800)).toBe("22 ч 10 мин");
  });
});

describe("client-side validation mirrors the API", () => {
  it("refuses a chain with no steps", () => {
    expect(validateChainDrafts([])).toContain("шагов нет");
  });

  it("refuses a blank step and names which one", () => {
    const problem = validateChainDrafts([draft("выдача"), draft("  ")]);
    expect(problem).toContain("Касание 2");
  });

  it("refuses a step longer than the API's 1000 characters", () => {
    const problem = validateChainDrafts([draft("x".repeat(1001))]);
    expect(problem).toContain("1000");
  });

  it("refuses a chain that outruns Meta's window", () => {
    const overflowing = [
      draft("выдача"),
      draft("m1", "23", "hours"),
      draft("m2", "1", "minutes"),
    ];
    expect(totalChainDelaySeconds(overflowing)).toBeGreaterThan(
      CHAIN_MAX_TOTAL_DELAY_SECONDS
    );
    expect(validateChainDrafts(overflowing)).toContain("23 часа");
  });

  it("accepts the chain the plan describes", () => {
    expect(
      validateChainDrafts([
        draft("Выдача"),
        draft("M1", "10", "minutes"),
        draft("M2", "2", "hours"),
        draft("M3", "20", "hours"),
      ])
    ).toBeNull();
  });
});
