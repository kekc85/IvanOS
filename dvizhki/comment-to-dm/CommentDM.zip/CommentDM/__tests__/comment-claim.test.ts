/**
 * Comment Claim — Unit Tests
 *
 * lib/queue/comment-claim.ts is the guard against two comment-poll sweeps
 * enqueuing the same comment while its earlier job is still queued or
 * running (see the module doc for the full race). Covers: NX-based
 * acquisition, the TTL passed to Redis, and release.
 */

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const { mockRedis } = vi.hoisted(() => ({
  mockRedis: {
    set: vi.fn(),
    del: vi.fn(),
  },
}));

vi.mock("@/lib/queue/client", () => ({
  getRedisConnection: () => mockRedis,
}));

import {
  acquireCommentClaim,
  releaseCommentClaim,
} from "../lib/queue/comment-claim";

beforeEach(() => {
  vi.clearAllMocks();
});

afterEach(() => {
  vi.unstubAllEnvs();
});

describe("acquireCommentClaim", () => {
  it("returns true and sets an NX key with a TTL when the claim is free", async () => {
    mockRedis.set.mockResolvedValue("OK");

    const acquired = await acquireCommentClaim("ig_123", "comment_1");

    expect(acquired).toBe(true);
    expect(mockRedis.set).toHaveBeenCalledWith(
      "claim:comment:ig_123:comment_1",
      "1",
      "EX",
      90 * 60,
      "NX"
    );
  });

  it("returns false when another sweep already holds the claim", async () => {
    // Redis returns null (not "OK") when NX finds the key already set.
    mockRedis.set.mockResolvedValue(null);

    const acquired = await acquireCommentClaim("ig_123", "comment_1");

    expect(acquired).toBe(false);
  });

  it("scopes the claim key by both instagramAccountId and commentId", async () => {
    mockRedis.set.mockResolvedValue("OK");

    await acquireCommentClaim("account_a", "comment_x");
    await acquireCommentClaim("account_b", "comment_x");

    const keys = mockRedis.set.mock.calls.map((call) => call[0]);
    expect(keys[0]).not.toBe(keys[1]);
  });

  it("honors COMMENT_CLAIM_TTL_SECONDS when overridden", async () => {
    vi.resetModules();
    vi.stubEnv("COMMENT_CLAIM_TTL_SECONDS", "120");
    const { acquireCommentClaim: acquireWithOverride } = await import(
      "../lib/queue/comment-claim"
    );
    mockRedis.set.mockResolvedValue("OK");

    await acquireWithOverride("ig_123", "comment_1");

    expect(mockRedis.set).toHaveBeenCalledWith(
      "claim:comment:ig_123:comment_1",
      "1",
      "EX",
      120,
      "NX"
    );
  });
});

describe("releaseCommentClaim", () => {
  it("deletes the claim key for the given account and comment", async () => {
    mockRedis.del.mockResolvedValue(1);

    await releaseCommentClaim("ig_123", "comment_1");

    expect(mockRedis.del).toHaveBeenCalledWith("claim:comment:ig_123:comment_1");
  });
});
