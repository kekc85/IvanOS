/**
 * The failure this whole phase exists to catch, per the phase brief: the
 * encryption key drifts, and every connected account silently stops
 * decrypting. Uses the real AES-256-GCM round trip from lib/meta/oauth.ts
 * (encrypt under one key, decrypt under another) rather than a mock of the
 * crypto itself, so this proves the actual cipher rejects the mismatched key
 * — not just that doctor's code path is reachable.
 */
import { beforeEach, describe, expect, it, vi } from "vitest";

const { mockPrisma, mockGetUserInfo } = vi.hoisted(() => ({
  mockPrisma: {
    instagramAccount: { findMany: vi.fn() },
  },
  mockGetUserInfo: vi.fn(),
}));

vi.mock("@/lib/db/client", () => ({
  prisma: mockPrisma,
}));

// checkAccountsTokens calls the real Meta API for a live token check once
// decryption succeeds — mocked here so this test stays a fast, offline unit
// test of the key-mismatch path, not a network test (that's covered
// separately in doctor-meta-error.test.ts).
vi.mock("@/lib/meta/client", async (importOriginal) => {
  const actual = await importOriginal<typeof import("../lib/meta/client")>();
  return { ...actual, getUserInfo: mockGetUserInfo };
});

import { encryptToken } from "../lib/meta/oauth";
import { checkAccountsTokens } from "../lib/doctor/checks/tokens";

const KEY_A = `${"1".repeat(63)}a`;
const KEY_B = `${"2".repeat(63)}b`;

beforeEach(() => {
  vi.clearAllMocks();
  vi.unstubAllEnvs();
});

describe("checkAccountsTokens — encryption key mismatch", () => {
  it("flags a token encrypted under a different key as E-10, not a crash", async () => {
    vi.stubEnv("ENCRYPTION_KEY", KEY_A);
    const ciphertext = encryptToken("real-instagram-access-token");

    mockPrisma.instagramAccount.findMany.mockResolvedValue([
      { id: "acct_1", username: "drifted_account", accessToken: ciphertext },
    ]);

    // Simulates the worker still holding KEY_A while .env (and this doctor
    // run) has moved on to KEY_B — the exact scenario in worker.ts's comment.
    vi.stubEnv("ENCRYPTION_KEY", KEY_B);

    const findings = await checkAccountsTokens(mockPrisma as never);

    expect(findings).toHaveLength(1);
    expect(findings[0]).toMatchObject({ level: "error", code: "E-10" });
    expect(findings[0].message).toContain("drifted_account");
    expect(findings[0].command).toContain("drifted_account");
  });

  it("decrypts and moves on to a live check when the key matches", async () => {
    vi.stubEnv("ENCRYPTION_KEY", KEY_A);
    const ciphertext = encryptToken("real-instagram-access-token");

    mockPrisma.instagramAccount.findMany.mockResolvedValue([
      { id: "acct_2", username: "healthy_account", accessToken: ciphertext },
    ]);
    mockGetUserInfo.mockResolvedValue({ id: "ig_1", username: "healthy_account" });

    const findings = await checkAccountsTokens(mockPrisma as never);

    expect(findings.some((f) => f.code === "E-10")).toBe(false);
    expect(findings[0]).toMatchObject({ level: "ok" });
    expect(mockGetUserInfo).toHaveBeenCalledWith("real-instagram-access-token");
  });
});
