/**
 * A fresh checkout that hasn't run `prisma generate` yet (app/generated/prisma
 * is gitignored — see prisma/schema.prisma's `output`) must not crash
 * `npm run doctor` with a raw "Cannot find module" stack trace. loadDoctorPrisma
 * takes an injectable importer specifically so this can be proven without
 * touching the real filesystem or generated output.
 */
import { describe, expect, it } from "vitest";
import { loadDoctorPrisma } from "../lib/doctor/prisma-loader";
import { checkPrismaClientMissing } from "../lib/doctor/checks/database";

describe("loadDoctorPrisma", () => {
  it("returns null instead of throwing when the generated client can't be imported", async () => {
    const failingImporter = () =>
      Promise.reject(
        new Error(
          "Cannot find module '@/app/generated/prisma/client' from 'lib/db/client.ts'"
        )
      );

    await expect(loadDoctorPrisma(failingImporter)).resolves.toBeNull();
  });

  it("returns the client when the import succeeds", async () => {
    const fakePrisma = { $queryRaw: async () => [{ ok: 1 }] };
    const workingImporter = () =>
      Promise.resolve({ prisma: fakePrisma as never });

    await expect(loadDoctorPrisma(workingImporter)).resolves.toBe(fakePrisma);
  });
});

describe("checkPrismaClientMissing", () => {
  it("gives a human, actionable message instead of an import error", () => {
    const finding = checkPrismaClientMissing();

    expect(finding.level).toBe("error");
    expect(finding.code).toBe("E-03");
    // No stack trace, no "Cannot find module" — a command a beginner can paste.
    expect(finding.message).not.toMatch(/cannot find module/i);
    expect(finding.command).toBe("npm run db:generate");
  });
});
