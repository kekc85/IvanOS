/**
 * Env Contract — Unit Tests
 *
 * diffEnvContract (lib/env-contract.ts) is what scripts/check-env-contract.ts
 * runs as step 4 of `npm run update`, before migrations. The property that
 * matters: a variable serverEnvSchema (lib/env.ts) actually requires at
 * startup must be flagged as "missing" (and treated as a hard stop by the
 * caller) the moment it's absent from .env — that's phases 2/3/6 changing
 * the variable set catching up with a student's stale .env.
 */
import { describe, expect, it } from "vitest";
import { diffEnvContract } from "../lib/env-contract";

const FULL_EXAMPLE = [
  "APP_URL=http://localhost:3000",
  "SESSION_SECRET=",
  "ENCRYPTION_KEY=",
  "OWNER_PASSWORD=",
  "OWNER_EMAIL=owner@localhost",
  "DATABASE_URL=postgresql://postgres:postgres@localhost:5432/commentdm",
  "REDIS_URL=redis://localhost:6379",
  "META_GRAPH_API_VERSION=v25.0",
  "INSTAGRAM_APP_ID=your-instagram-app-id",
  "INSTAGRAM_APP_SECRET=your-instagram-app-secret",
  "LEGAL_ENTITY_NAME=",
  "LEGAL_CONTACT_EMAIL=",
  "# TRUSTED_PROXIES=127.0.0.1/32,::1/128",
  "# DM_LOG_RETENTION_DAYS=180",
].join("\n");

const FULL_ENV = [
  "APP_URL=https://bot.example.com",
  "SESSION_SECRET=a-real-session-secret-with-plenty-of-length",
  "ENCRYPTION_KEY=5f3a9c1e7b2d4f608a1c3e5b7d9f1a3c5e7b9d1f3a5c7e9b1d3f5a7c9e1b3d5f",
  "OWNER_PASSWORD=hunter2hunter2",
  "OWNER_EMAIL=owner@localhost",
  "DATABASE_URL=postgresql://commentdm:secret@localhost:5432/commentdm",
  "REDIS_URL=redis://localhost:6379",
  "META_GRAPH_API_VERSION=v25.0",
  "INSTAGRAM_APP_ID=12345",
  "INSTAGRAM_APP_SECRET=abcde",
  "LEGAL_ENTITY_NAME=Example Owner LLC",
  "LEGAL_CONTACT_EMAIL=owner@example.com",
].join("\n");

describe("diffEnvContract", () => {
  it("reports nothing missing when .env has every key .env.example documents", () => {
    const result = diffEnvContract(FULL_EXAMPLE, FULL_ENV);
    expect(result.missingRequired).toEqual([]);
    expect(result.missingOptional).toEqual([]);
  });

  it("flags a required key entirely absent from .env as missingRequired — the phase 2/3/6 scenario", () => {
    // Simulates a student's .env from before phase 3 (no SESSION_SECRET /
    // ENCRYPTION_KEY yet — those replaced NextAuth's variables).
    const staleEnv = FULL_ENV.split("\n")
      .filter((line) => !line.startsWith("SESSION_SECRET=") && !line.startsWith("ENCRYPTION_KEY="))
      .join("\n");

    const result = diffEnvContract(FULL_EXAMPLE, staleEnv);
    expect(result.missingRequired).toEqual(["ENCRYPTION_KEY", "SESSION_SECRET"]);
  });

  it("does not block on an optional key being absent (OWNER_PASSWORD, LEGAL_*)", () => {
    const envWithoutOptionalKeys = FULL_ENV.split("\n")
      .filter(
        (line) =>
          !line.startsWith("OWNER_PASSWORD=") &&
          !line.startsWith("LEGAL_ENTITY_NAME=") &&
          !line.startsWith("LEGAL_CONTACT_EMAIL=")
      )
      .join("\n");

    const result = diffEnvContract(FULL_EXAMPLE, envWithoutOptionalKeys);
    expect(result.missingRequired).toEqual([]);
    expect(result.missingOptional).toEqual([
      "LEGAL_CONTACT_EMAIL",
      "LEGAL_ENTITY_NAME",
      "OWNER_PASSWORD",
    ]);
  });

  it("treats a commented-out example line as not present in .env.example's own key set", () => {
    // TRUSTED_PROXIES and DM_LOG_RETENTION_DAYS are commented out in
    // .env.example itself — they must not appear in either missing list,
    // since .env.example doesn't actually "document" them as present keys.
    const result = diffEnvContract(FULL_EXAMPLE, FULL_ENV);
    expect(result.missingOptional).not.toContain("TRUSTED_PROXIES");
    expect(result.missingOptional).not.toContain("DM_LOG_RETENTION_DAYS");
  });

  it("still blocks on a required key even if .env.example itself forgot to list it", () => {
    const exampleMissingRequiredKey = FULL_EXAMPLE.split("\n")
      .filter((line) => !line.startsWith("ENCRYPTION_KEY="))
      .join("\n");
    const envMissingIt = FULL_ENV.split("\n")
      .filter((line) => !line.startsWith("ENCRYPTION_KEY="))
      .join("\n");

    const result = diffEnvContract(exampleMissingRequiredKey, envMissingIt);
    expect(result.missingRequired).toContain("ENCRYPTION_KEY");
  });

  it("ignores blank lines and comments when parsing either file", () => {
    const result = diffEnvContract(
      "\n# a comment\n\nAPP_URL=http://localhost:3000\n",
      "\nAPP_URL=http://localhost:3000\n# APP_URL=ignored-because-commented\n"
    );
    expect(result.missingOptional).toEqual([]);
  });
});
