/**
 * scripts/set-domain.sh — integration test.
 *
 * The property that matters (phase 14): a domain change has to update BOTH
 * places APP_URL is baked into — .env (the app itself) and the Caddy
 * config (the reverse proxy that terminates TLS for it) — never just one.
 * Missing either one leaves the app answering on a domain Caddy doesn't
 * route, or Caddy fronting a domain the app doesn't think it's on.
 *
 * Runs the real script against a throwaway install dir. `id`, `caddy` and
 * `systemctl` are stubbed on PATH (none of the three exist/behave
 * predictably in a CI/dev sandbox, and this script is not the place to
 * verify Caddy's own validate logic or systemd's own reload semantics —
 * only that this script calls them with the files it's supposed to have
 * already written). CADDY_CONFIG_PATH is redirected to a temp file so this
 * never touches the real /etc/caddy/Caddyfile.
 */
import { execFileSync } from "node:child_process";
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, cpSync, chmodSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { afterEach, describe, expect, it } from "vitest";

const REPO_ROOT = path.resolve(__dirname, "..");

let installDir: string;
let stubBinDir: string;
let caddyConfigPath: string;
let envPath: string;

function setUpFakeInstall(oldDomain: string): void {
  installDir = mkdtempSync(path.join(tmpdir(), "commentdm-set-domain-test-"));
  mkdirSync(path.join(installDir, "deploy"), { recursive: true });
  mkdirSync(path.join(installDir, "scripts"), { recursive: true });

  cpSync(path.join(REPO_ROOT, "deploy/lib.sh"), path.join(installDir, "deploy/lib.sh"));
  cpSync(path.join(REPO_ROOT, "deploy/Caddyfile"), path.join(installDir, "deploy/Caddyfile"));
  cpSync(
    path.join(REPO_ROOT, "scripts/set-domain.sh"),
    path.join(installDir, "scripts/set-domain.sh")
  );

  envPath = path.join(installDir, ".env");
  writeFileSync(envPath, `APP_URL=https://${oldDomain}\nDATABASE_URL=unused-in-this-test\n`);

  caddyConfigPath = path.join(installDir, "fake-caddyfile");

  stubBinDir = mkdtempSync(path.join(tmpdir(), "commentdm-set-domain-stubbin-"));
  const fakeId = path.join(stubBinDir, "id");
  writeFileSync(fakeId, "#!/bin/sh\necho 0\n");
  chmodSync(fakeId, 0o755);

  // Only subcommand this script actually calls is `validate --config <path>`.
  const fakeCaddy = path.join(stubBinDir, "caddy");
  writeFileSync(fakeCaddy, "#!/bin/sh\nexit 0\n");
  chmodSync(fakeCaddy, 0o755);

  const fakeSystemctl = path.join(stubBinDir, "systemctl");
  writeFileSync(
    fakeSystemctl,
    // `systemctl is-active --quiet caddy` needs to resolve to a definite
    // answer for the reload-vs-restart branch — treat it as "not active" so
    // the script takes the `restart` path, and succeed on everything else.
    "#!/bin/sh\nif [ \"$1\" = 'is-active' ]; then exit 1; fi\nexit 0\n"
  );
  chmodSync(fakeSystemctl, 0o755);
}

function runSetDomain(args: string[]): { status: number; output: string } {
  try {
    const output = execFileSync(
      "bash",
      [path.join(installDir, "scripts/set-domain.sh"), ...args],
      {
        cwd: installDir,
        input: "",
        env: {
          ...process.env,
          PATH: `${stubBinDir}:${process.env.PATH}`,
          CADDY_CONFIG_PATH: caddyConfigPath,
        },
        encoding: "utf8",
        stdio: ["pipe", "pipe", "pipe"],
      }
    );
    return { status: 0, output };
  } catch (error) {
    const err = error as { status: number | null; stdout?: string; stderr?: string };
    return { status: err.status ?? 1, output: `${err.stdout ?? ""}${err.stderr ?? ""}` };
  }
}

afterEach(() => {
  rmSync(installDir, { recursive: true, force: true });
  rmSync(stubBinDir, { recursive: true, force: true });
});

describe("scripts/set-domain.sh", () => {
  // These three exercise the full script, including restart_app()'s
  // `sleep 5` after restarting both services (same pattern install.sh /
  // update.sh use to give a service a moment to come up before checking
  // it) — past vitest's 5000ms default per-test timeout, so given room here.
  it(
    "rewrites both APP_URL in .env and the domain in the Caddy config",
    () => {
      setUpFakeInstall("old.example.com");

      const { status, output } = runSetDomain(["new.example.com", "--skip-dns-check"]);

      expect(status).toBe(0);

      const envContent = readFileSync(envPath, "utf8");
      expect(envContent).toContain("APP_URL=https://new.example.com");
      expect(envContent).not.toContain("old.example.com");

      const caddyContent = readFileSync(caddyConfigPath, "utf8");
      expect(caddyContent).toContain("new.example.com");
      expect(caddyContent).not.toContain("__DOMAIN__");
      expect(caddyContent).not.toContain("old.example.com");

      // Both restart, not just reload — APP_URL is only read at process start.
      expect(output).toContain("Перезапускаю commentdm и commentdm-worker");
    },
    15000
  );

  it(
    "prints the Meta OAuth redirect memo naming the new callback URL",
    () => {
      setUpFakeInstall("old.example.com");
      const { output } = runSetDomain(["new.example.com", "--skip-dns-check"]);
      expect(output).toContain("https://new.example.com/api/instagram/callback");
    },
    15000
  );

  it(
    "warns that already-sent tracked links on the old domain will stop working",
    () => {
      setUpFakeInstall("old.example.com");
      const { output } = runSetDomain(["new.example.com", "--skip-dns-check"]);
      expect(output).toContain("old.example.com/r/");
    },
    15000
  );

  it("is a no-op when the domain hasn't actually changed", () => {
    setUpFakeInstall("same.example.com");
    const { status, output } = runSetDomain(["same.example.com", "--skip-dns-check"]);
    expect(status).toBe(0);
    expect(output).toContain("менять нечего");

    const envContent = readFileSync(envPath, "utf8");
    expect(envContent).toContain("APP_URL=https://same.example.com");
  });

  it("refuses to run without a domain argument", () => {
    setUpFakeInstall("old.example.com");
    const { status, output } = runSetDomain([]);
    expect(status).not.toBe(0);
    expect(output).toContain("Домен не указан");
  });
});
