/**
 * S1 — the API surface refuses anonymous callers.
 *
 * The route list is read off the filesystem, not typed out here. That is the
 * whole point: a new file under app/api that forgets its guard joins this
 * sweep automatically and fails it, instead of shipping unnoticed.
 *
 * Every route falls into exactly one bucket:
 *
 *   PUBLIC   — served to anyone on purpose. One entry, /api/health.
 *   REDIRECT — browser navigation targets (OAuth hops, sign out). A 401 body
 *              would be a dead end in the address bar, so they answer with a
 *              same-origin 3xx and no data.
 *   default  — everything else must answer 401.
 *
 * The buckets are hardcoded by path, so a new route cannot quietly opt into a
 * softer rule; it lands in the default bucket and has to produce a 401.
 *
 * Second case in this file: a validly *signed* cookie carrying a user id that
 * is not the owner. Before this phase that request minted itself a brand new
 * workspace and got a working, empty dashboard. Now it resolves to nothing.
 */

import { readdirSync } from "node:fs";
import path from "node:path";
import { beforeEach, describe, expect, it, vi } from "vitest";

const API_DIR = path.resolve(__dirname, "../app/api");

const PUBLIC_ROUTES = new Set(["/api/health"]);

const REDIRECT_ROUTES = new Set([
  "/api/auth/sign-out",
  "/api/instagram/connect",
  "/api/instagram/callback",
]);

const HTTP_METHODS = ["GET", "POST", "PATCH", "PUT", "DELETE"] as const;

type RouteFile = { urlPath: string; filePath: string };

function collectRouteFiles(dir: string, prefix = "/api"): RouteFile[] {
  const found: RouteFile[] = [];
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      found.push(...collectRouteFiles(full, `${prefix}/${entry.name}`));
    } else if (entry.name === "route.ts" || entry.name === "route.tsx") {
      found.push({ urlPath: prefix, filePath: full });
    }
  }
  return found.sort((a, b) => a.urlPath.localeCompare(b.urlPath));
}

const ROUTE_FILES = collectRouteFiles(API_DIR);

// ─── Test doubles ───────────────────────────────────────────────────────────

const { cookieJar, mockPrisma, prismaCalls } = vi.hoisted(() => {
  const cookieJar = new Map<string, string>();
  const prismaCalls: string[] = [];

  // Every model method is created on demand and rejects by default. An
  // unguarded route therefore fails loudly instead of returning mock data,
  // and the call is recorded so the failure message names what it touched.
  const modelCache = new Map<string, Record<string, ReturnType<typeof vi.fn>>>();
  const mockPrisma = new Proxy(
    {} as Record<string, Record<string, ReturnType<typeof vi.fn>>>,
    {
      get(_target, model: string) {
        let methods = modelCache.get(model);
        if (!methods) {
          methods = new Proxy({} as Record<string, ReturnType<typeof vi.fn>>, {
            get(bag, method: string) {
              if (!(method in bag)) {
                bag[method] = vi.fn(async () => {
                  prismaCalls.push(`${model}.${method}`);
                  throw new Error(
                    `prisma.${model}.${method} reached without a session`
                  );
                });
              }
              return bag[method];
            },
          });
          modelCache.set(model, methods);
        }
        return methods;
      },
    }
  );

  return { cookieJar, mockPrisma, prismaCalls };
});

vi.mock("@/lib/db/client", () => ({
  prisma: mockPrisma,
  getPrisma: () => mockPrisma,
}));

vi.mock("next/headers", () => ({
  cookies: async () => ({
    get: (name: string) =>
      cookieJar.has(name) ? { name, value: cookieJar.get(name) } : undefined,
    set: () => undefined,
    delete: () => undefined,
  }),
}));

vi.mock("@/lib/queue/client", () => ({
  getDMQueue: () => ({
    getJobCounts: async () => ({ waiting: 0, active: 0, delayed: 0, failed: 0 }),
    add: async () => undefined,
  }),
  getRedisConnection: () => ({
    ping: async () => "PONG",
    get: async () => null,
    lrange: async () => [],
  }),
}));

// requireEnv("SESSION_SECRET") runs on every guarded request; without it the
// guard would throw instead of answering 401 and the sweep would prove nothing.
process.env.SESSION_SECRET = "s1-test-secret-value-long-enough";
process.env.APP_URL = "http://localhost:3000";
// Not a repeated-character placeholder — lib/env.ts now refuses those.
process.env.ENCRYPTION_KEY =
  "5f3a9c1e7b2d4f608a1c3e5b7d9f1a3c5e7b9d1f3a5c7e9b1d3f5a7c9e1b3d5f";
process.env.INSTAGRAM_APP_ID = "test-app-id";
process.env.INSTAGRAM_APP_SECRET = "test-app-secret";

async function callRoute(
  filePath: string,
  urlPath: string,
  method: string
): Promise<{ status: number; location: string | null } | null> {
  const mod = (await import(filePath)) as Record<string, unknown>;
  const handler = mod[method];
  if (typeof handler !== "function") return null;

  const { NextRequest } = await import("next/server");
  const request = new NextRequest(
    new URL(`http://localhost:3000${urlPath.replace(/\[[^\]]+\]/g, "x")}`),
    {
      method,
      ...(method === "GET" || method === "DELETE"
        ? {}
        : {
            body: JSON.stringify({}),
            headers: { "content-type": "application/json" },
          }),
    }
  );

  const response = (await (
    handler as (req: unknown, ctx: unknown) => Promise<Response>
  )(request, { params: Promise.resolve({ id: "x", slug: "x" }) })) as Response;

  return {
    status: response.status,
    location: response.headers.get("location"),
  };
}

beforeEach(() => {
  cookieJar.clear();
  prismaCalls.length = 0;
});

describe("S1: every API route refuses an anonymous caller", () => {
  it("finds the routes on disk rather than from a hand-written list", () => {
    expect(ROUTE_FILES.length).toBeGreaterThan(5);
    expect(ROUTE_FILES.map((r) => r.urlPath)).toContain("/api/health");
  });

  for (const route of ROUTE_FILES) {
    const bucket = PUBLIC_ROUTES.has(route.urlPath)
      ? "public"
      : REDIRECT_ROUTES.has(route.urlPath)
        ? "redirect"
        : "unauthorized";

    if (bucket === "public") continue;

    it(`${route.urlPath} (${bucket})`, async () => {
      const results: Array<{ method: string; status: number; location: string | null }> =
        [];

      for (const method of HTTP_METHODS) {
        let outcome;
        try {
          outcome = await callRoute(route.filePath, route.urlPath, method);
        } catch (error) {
          throw new Error(
            `${method} ${route.urlPath} threw instead of denying: ` +
              `${error instanceof Error ? error.message : String(error)}` +
              (prismaCalls.length ? ` (prisma: ${prismaCalls.join(", ")})` : "")
          );
        }
        if (outcome) results.push({ method, ...outcome });
      }

      expect(results.length).toBeGreaterThan(0);

      for (const result of results) {
        if (bucket === "unauthorized") {
          expect(
            `${result.method} ${route.urlPath} -> ${result.status}`
          ).toBe(`${result.method} ${route.urlPath} -> 401`);
        } else {
          // A denial, not a payload: 3xx, and never off this origin.
          expect(result.status).toBeGreaterThanOrEqual(300);
          expect(result.status).toBeLessThan(400);
          expect(result.location).toMatch(/^http:\/\/localhost:3000\//);
        }
      }
    });
  }

  it("keeps /api/health public on purpose", async () => {
    const health = ROUTE_FILES.find((r) => r.urlPath === "/api/health");
    expect(health).toBeDefined();
    const result = await callRoute(health!.filePath, health!.urlPath, "GET");
    expect(result?.status).not.toBe(401);
  });
});

describe("S1: a second authenticated identity sees nothing", () => {
  it("a validly signed cookie for a non-owner id resolves to no user and no workspace", async () => {
    const { createSessionToken, SESSION_COOKIE_NAME } = await import(
      "@/lib/auth/session-token"
    );
    cookieJar.set(
      SESSION_COOKIE_NAME,
      createSessionToken("user_intruder", process.env.SESSION_SECRET!)
    );

    // The owner row is the only User row there can be, so an id that is not
    // it simply is not found.
    mockPrisma.user.findUnique.mockResolvedValue(null);

    const { getCurrentUser, getCurrentWorkspaceId } = await import(
      "@/lib/auth/session"
    );
    await expect(getCurrentUser()).resolves.toBeNull();
    await expect(getCurrentWorkspaceId()).resolves.toBeNull();

    // The old ensureWorkspaceForUser would have created a tenant right here.
    expect(mockPrisma.workspace.create).not.toHaveBeenCalled();
    expect(mockPrisma.workspace.findFirst).not.toHaveBeenCalled();
  });

  it("data routes answer 401 to that same cookie", async () => {
    const { createSessionToken, SESSION_COOKIE_NAME } = await import(
      "@/lib/auth/session-token"
    );
    cookieJar.set(
      SESSION_COOKIE_NAME,
      createSessionToken("user_intruder", process.env.SESSION_SECRET!)
    );
    mockPrisma.user.findUnique.mockResolvedValue(null);

    for (const urlPath of ["/api/logs", "/api/automations", "/api/dashboard/stats"]) {
      const route = ROUTE_FILES.find((r) => r.urlPath === urlPath);
      expect(route, `${urlPath} should exist`).toBeDefined();
      const result = await callRoute(route!.filePath, urlPath, "GET");
      expect(`${urlPath} -> ${result?.status}`).toBe(`${urlPath} -> 401`);
    }
  });

  it("the owner's cookie resolves to the one workspace, and does not create a second", async () => {
    const { createSessionToken, SESSION_COOKIE_NAME } = await import(
      "@/lib/auth/session-token"
    );
    cookieJar.set(
      SESSION_COOKIE_NAME,
      createSessionToken("user_owner", process.env.SESSION_SECRET!)
    );
    mockPrisma.user.findUnique.mockResolvedValue({
      id: "user_owner",
      email: "owner@localhost",
      name: "Owner",
    });
    mockPrisma.workspace.findFirst.mockResolvedValue({
      id: "workspace_single",
      name: "My workspace",
      ownerId: "user_owner",
    });

    const { getCurrentWorkspaceId } = await import("@/lib/auth/session");
    await expect(getCurrentWorkspaceId()).resolves.toBe("workspace_single");

    // The lookup carries no user filter — that is what makes it one workspace
    // for whoever asks, rather than one per identity.
    expect(mockPrisma.workspace.findFirst).toHaveBeenCalledWith({
      orderBy: { createdAt: "asc" },
    });
    expect(mockPrisma.workspace.create).not.toHaveBeenCalled();
  });
});
