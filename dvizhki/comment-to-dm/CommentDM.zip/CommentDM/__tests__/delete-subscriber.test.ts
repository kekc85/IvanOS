/**
 * Subscriber Data Erasure — Unit Tests
 *
 * Covers the "right to be forgotten" command: matching a subscriber by
 * Instagram id or username, and the case that matters most — a DmLog row
 * still inside Meta's private-reply window is withheld rather than deleted,
 * because that row also doubles as the polling reconciler's dedup marker
 * (deleting it early would make the reconciler re-send a DM to someone who
 * just asked to be forgotten).
 *
 * The other half is chain journeys, where the stakes are the opposite way
 * round: a journey row is what the step dispatcher sends from, so erasing it
 * is the only thing that actually stops a chain that is mid-sequence. The
 * last describe block below pins that invariant down by running the real
 * delete against a fake table and then asking the dispatcher's own question
 * of what's left.
 */

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const { mockPrisma } = vi.hoisted(() => ({
  mockPrisma: {
    dmLog: { findMany: vi.fn(), deleteMany: vi.fn() },
    subscriberJourney: { findMany: vi.fn(), deleteMany: vi.fn() },
    operationalEvent: { create: vi.fn() },
  },
}));

vi.mock("@/lib/db/client", () => ({
  prisma: mockPrisma,
}));

import {
  eraseSubscriberData,
  previewSubscriberErasure,
} from "../lib/gdpr/delete-subscriber";

// As of NOW (2026-08-07T12:00), the dedup floor is 168h + 24h = 192h back,
// i.e. 2026-07-30T12:00. comment-old is well before that (deletable now);
// comment-recent is after it (still inside Meta's window, withheld).
const SAMPLE_ROWS = [
  {
    id: "log-1",
    commenterId: "ig-123",
    commenterName: "alice_ig",
    commentId: "comment-old",
    createdAt: new Date("2026-01-01T00:00:00.000Z"),
  },
  {
    id: "log-2",
    commenterId: "ig-123",
    commenterName: "alice_ig",
    commentId: "comment-recent",
    createdAt: new Date("2026-08-06T00:00:00.000Z"),
  },
];

const SAMPLE_JOURNEYS = [
  {
    id: "journey-1",
    subscriberId: "msg-777",
    commenterId: "ig-123",
    subscriberName: "alice_ig",
    state: "ACTIVE",
    gateSentAt: new Date("2026-08-07T09:00:00.000Z"),
    createdAt: new Date("2026-08-07T09:00:00.000Z"),
  },
  {
    id: "journey-2",
    subscriberId: "msg-777",
    commenterId: "ig-123",
    subscriberName: "alice_ig",
    state: "DONE",
    gateSentAt: new Date("2026-07-01T09:00:00.000Z"),
    createdAt: new Date("2026-07-01T09:00:00.000Z"),
  },
];

beforeEach(() => {
  vi.clearAllMocks();
  vi.useFakeTimers();
  vi.setSystemTime(new Date("2026-08-07T12:00:00.000Z"));
  mockPrisma.dmLog.findMany.mockResolvedValue(SAMPLE_ROWS);
  mockPrisma.dmLog.deleteMany.mockResolvedValue({ count: 1 });
  mockPrisma.subscriberJourney.findMany.mockResolvedValue(SAMPLE_JOURNEYS);
  mockPrisma.subscriberJourney.deleteMany.mockResolvedValue({ count: 2 });
  mockPrisma.operationalEvent.create.mockResolvedValue({});
});

afterEach(() => {
  vi.useRealTimers();
});

describe("previewSubscriberErasure", () => {
  it("matches by Instagram commenter id or username (case-insensitive)", async () => {
    await previewSubscriberErasure("ALICE_ig");
    const where = mockPrisma.dmLog.findMany.mock.calls[0][0].where;
    expect(where.OR).toEqual([
      { commenterId: "ALICE_ig" },
      { commenterName: { equals: "ALICE_ig", mode: "insensitive" } },
    ]);
  });

  it("reports DmLog rows as deletable-now vs withheld by Meta's window", async () => {
    const preview = await previewSubscriberErasure("ig-123");
    expect(preview.dmLogs).toHaveLength(2);
    expect(preview.dmLogsDeletableNow).toBe(1);
    expect(preview.dmLogsWithheld).toBe(1);
  });

  it("returns an explicit note that LinkClick cannot be matched to this identity", async () => {
    const preview = await previewSubscriberErasure("ig-123");
    expect(preview.linkClickNote.toLowerCase()).toContain("linkclick");
  });

  it("returns zero counts when nothing matches", async () => {
    mockPrisma.dmLog.findMany.mockResolvedValue([]);
    mockPrisma.subscriberJourney.findMany.mockResolvedValue([]);
    const preview = await previewSubscriberErasure("nobody");
    expect(preview.dmLogs).toHaveLength(0);
    expect(preview.dmLogsDeletableNow).toBe(0);
    expect(preview.dmLogsWithheld).toBe(0);
    expect(preview.journeys).toHaveLength(0);
    expect(preview.journeysLive).toBe(0);
  });

  it("matches journeys by messaging id, commenter id, or name (case-insensitive)", async () => {
    await previewSubscriberErasure("ALICE_ig");
    const where = mockPrisma.subscriberJourney.findMany.mock.calls[0][0].where;
    expect(where.OR).toEqual([
      { subscriberId: "ALICE_ig" },
      { commenterId: "ALICE_ig" },
      { subscriberName: { equals: "ALICE_ig", mode: "insensitive" } },
    ]);
  });

  it("shows the journeys it found and how many of them are live chains", async () => {
    const preview = await previewSubscriberErasure("ig-123");
    // Shown before any confirmation: the operator sees the rows themselves,
    // not just a number.
    expect(preview.journeys).toHaveLength(2);
    expect(preview.journeys.map((row) => row.state)).toEqual(["ACTIVE", "DONE"]);
    // Only the ACTIVE one is a chain still messaging this person.
    expect(preview.journeysLive).toBe(1);
  });
});

describe("eraseSubscriberData", () => {
  it("deletes only DmLog rows outside Meta's reply window", async () => {
    await eraseSubscriberData("ig-123");
    const call = mockPrisma.dmLog.deleteMany.mock.calls[0][0];
    expect(call.where.OR).toEqual([
      { commenterId: "ig-123" },
      { commenterName: { equals: "ig-123", mode: "insensitive" } },
    ]);
    // The critical guard: the delete is scoped to createdAt < the dedup safe
    // cutoff, never an unqualified delete of every row this person has.
    expect(call.where.createdAt.lt).toBeInstanceOf(Date);
  });

  it("reports withheld rows separately from deleted ones", async () => {
    const result = await eraseSubscriberData("ig-123");
    expect(result.dmLogsDeleted).toBe(1);
    expect(result.dmLogsWithheld).toBe(1);
  });

  it("never writes the identifier, commenter name, or comment text into the audit log", async () => {
    await eraseSubscriberData("ig-123");
    const call = mockPrisma.operationalEvent.create.mock.calls[0][0];
    const serialized = JSON.stringify(call.data);
    expect(serialized).not.toContain("ig-123");
    expect(serialized).not.toContain("alice_ig");
    expect(serialized).not.toContain("comment-old");
    expect(serialized).not.toContain("comment-recent");
    // Journey identity too: the messaging-space id and the journey row ids are
    // just as personal as the commenter id.
    expect(serialized).not.toContain("msg-777");
    expect(serialized).not.toContain("journey-1");
    expect(call.data.source).toBe("SYSTEM");
  });

  it("reports zero deleted and zero withheld when the subscriber has no DmLog rows", async () => {
    mockPrisma.dmLog.findMany.mockResolvedValue([]);
    mockPrisma.dmLog.deleteMany.mockResolvedValue({ count: 0 });
    mockPrisma.subscriberJourney.findMany.mockResolvedValue([]);
    mockPrisma.subscriberJourney.deleteMany.mockResolvedValue({ count: 0 });

    const result = await eraseSubscriberData("nobody");

    expect(result.dmLogsDeleted).toBe(0);
    expect(result.dmLogsWithheld).toBe(0);
    expect(result.journeysDeleted).toBe(0);
    expect(result.journeysStopped).toBe(0);
  });

  it("deletes chain journeys outright — no window guard, that is what stops the chain", async () => {
    await eraseSubscriberData("ig-123");

    const call = mockPrisma.subscriberJourney.deleteMany.mock.calls[0][0];
    expect(call.where.OR).toEqual([
      { subscriberId: "ig-123" },
      { commenterId: "ig-123" },
      { subscriberName: { equals: "ig-123", mode: "insensitive" } },
    ]);
    // Unlike DmLog, no createdAt bound: a journey is nobody's dedup marker,
    // and leaving a live one behind would keep messaging the erased person.
    expect(call.where.createdAt).toBeUndefined();
    expect(call.where.state).toBeUndefined();
  });

  it("reports how many journeys were deleted and how many live chains that stopped", async () => {
    const result = await eraseSubscriberData("ig-123");
    expect(result.journeysDeleted).toBe(2);
    expect(result.journeysStopped).toBe(1);
  });

  it("removes journeys before DM logs, so a crash between the two can never leave a live chain", async () => {
    const order: string[] = [];
    mockPrisma.subscriberJourney.deleteMany.mockImplementation(async () => {
      order.push("journeys");
      return { count: 2 };
    });
    mockPrisma.dmLog.deleteMany.mockImplementation(async () => {
      order.push("dmLogs");
      return { count: 1 };
    });

    await eraseSubscriberData("ig-123");

    expect(order).toEqual(["journeys", "dmLogs"]);
  });
});

/**
 * The invariant this whole feature exists for: after erasure, the chain has
 * nothing left to send to that person.
 *
 * Instead of asserting on the query shape, this runs the real `where` clause
 * the erasure builds against a fake journey table, then asks the two chain
 * contours' own questions of whatever survived:
 *   - lib/chain/step-dispatcher.ts: `state: "ACTIVE", nextStepDueAt <= now`
 *   - lib/chain/conversation-poller.ts: `state in (GATE_SENT, ACTIVE)`
 * If either still returns the erased person, the chain would keep messaging
 * them — that is the failure this guards.
 */
type JourneyRow = {
  id: string;
  subscriberId: string;
  commenterId: string | null;
  subscriberName: string | null;
  state: string;
  gateSentAt: Date;
  createdAt: Date;
  nextStepDueAt: Date | null;
};

type WhereCondition = Record<string, unknown>;

function matchesCondition(row: JourneyRow, condition: WhereCondition): boolean {
  const [field, expected] = Object.entries(condition)[0];
  const actual = (row as unknown as Record<string, unknown>)[field];

  if (expected !== null && typeof expected === "object" && "equals" in expected) {
    const { equals, mode } = expected as { equals: string; mode?: string };
    if (typeof actual !== "string") return false;
    return mode === "insensitive"
      ? actual.toLowerCase() === equals.toLowerCase()
      : actual === equals;
  }

  return actual === expected;
}

function matchesWhere(row: JourneyRow, where: { OR: WhereCondition[] }): boolean {
  return where.OR.some((condition) => matchesCondition(row, condition));
}

describe("after erasure the chain dispatcher has nothing left to send", () => {
  const NOW = new Date("2026-08-07T12:00:00.000Z");
  let table: JourneyRow[];

  beforeEach(() => {
    table = [
      // The erased person, mid-chain: a step was due five minutes ago.
      {
        id: "journey-live",
        subscriberId: "msg-777",
        commenterId: "ig-123",
        subscriberName: "alice_ig",
        state: "ACTIVE",
        gateSentAt: new Date("2026-08-07T09:00:00.000Z"),
        createdAt: new Date("2026-08-07T09:00:00.000Z"),
        nextStepDueAt: new Date("2026-08-07T11:55:00.000Z"),
      },
      // Same person, second campaign, GATE sent and not answered yet.
      {
        id: "journey-gate",
        subscriberId: "msg-777",
        commenterId: "ig-123",
        subscriberName: "alice_ig",
        state: "GATE_SENT",
        gateSentAt: new Date("2026-08-07T11:00:00.000Z"),
        createdAt: new Date("2026-08-07T11:00:00.000Z"),
        nextStepDueAt: null,
      },
      // Somebody else, also due right now — must survive untouched.
      {
        id: "journey-other",
        subscriberId: "msg-999",
        commenterId: "ig-999",
        subscriberName: "bob_ig",
        state: "ACTIVE",
        gateSentAt: new Date("2026-08-07T09:00:00.000Z"),
        createdAt: new Date("2026-08-07T09:00:00.000Z"),
        nextStepDueAt: new Date("2026-08-07T11:55:00.000Z"),
      },
    ];

    mockPrisma.subscriberJourney.findMany.mockImplementation(
      async ({ where }: { where: { OR: WhereCondition[] } }) =>
        table.filter((row) => matchesWhere(row, where))
    );
    mockPrisma.subscriberJourney.deleteMany.mockImplementation(
      async ({ where }: { where: { OR: WhereCondition[] } }) => {
        const before = table.length;
        table = table.filter((row) => !matchesWhere(row, where));
        return { count: before - table.length };
      }
    );
  });

  it("leaves no journey the dispatcher would pick up for the erased person", async () => {
    const dueBefore = table.filter(
      (row) =>
        row.state === "ACTIVE" &&
        row.nextStepDueAt !== null &&
        row.nextStepDueAt <= NOW
    );
    expect(dueBefore.map((row) => row.id)).toContain("journey-live");

    await eraseSubscriberData("ig-123");

    const dueAfter = table.filter(
      (row) =>
        row.state === "ACTIVE" &&
        row.nextStepDueAt !== null &&
        row.nextStepDueAt <= NOW
    );
    expect(dueAfter.map((row) => row.subscriberId)).not.toContain("msg-777");
    expect(dueAfter.map((row) => row.id)).toEqual(["journey-other"]);
  });

  it("leaves no live journey for the erased person for the conversation poller either", async () => {
    await eraseSubscriberData("ig-123");

    const live = table.filter(
      (row) => row.state === "GATE_SENT" || row.state === "ACTIVE"
    );
    expect(
      live.filter(
        (row) => row.subscriberId === "msg-777" || row.commenterId === "ig-123"
      )
    ).toHaveLength(0);
  });

  it("finds the same person by their messaging-space id too", async () => {
    await eraseSubscriberData("msg-777");

    expect(table.map((row) => row.id)).toEqual(["journey-other"]);
  });

  it("does not touch anybody else's running chain", async () => {
    await eraseSubscriberData("ig-123");

    expect(table).toHaveLength(1);
    expect(table[0].id).toBe("journey-other");
    expect(table[0].state).toBe("ACTIVE");
  });
});
