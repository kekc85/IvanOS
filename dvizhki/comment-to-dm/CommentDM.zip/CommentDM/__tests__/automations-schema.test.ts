/**
 * Campaign Validation Schema — Safe Defaults
 *
 * Tests the create/update Zod schemas directly (exported from
 * app/api/automations/route.ts) rather than the full route handler, since
 * the handler needs a live auth/workspace/Prisma pipeline this file doesn't
 * stand up. This is exactly the surface a student's new campaign passes
 * through, so it's the right place to pin down the safe defaults from phase 7:
 * a new campaign defaults to a specific post (not "any post") and to public
 * reply OFF, and turning public reply on requires enough reply variants that
 * it doesn't just repeat the same text under every comment.
 */

import { describe, it, expect } from "vitest";
import {
  createAutomationSchema,
  updateAutomationSchema,
} from "../app/api/automations/route";
import { MIN_PUBLIC_REPLY_VARIANTS } from "../lib/automations/policy";

const minimalCreatePayload = {
  name: "Test campaign",
  postId: "media_123",
  keywords: ["price"],
  dmMessage: "Here's the link!",
};

describe("createAutomationSchema — safe defaults", () => {
  it("defaults matchAnyPost to false (targets a specific post, not every post)", () => {
    const parsed = createAutomationSchema.parse(minimalCreatePayload);
    expect(parsed.matchAnyPost).toBe(false);
  });

  it("defaults publicReplyEnabled to false", () => {
    const parsed = createAutomationSchema.parse(minimalCreatePayload);
    expect(parsed.publicReplyEnabled).toBe(false);
  });

  it("rejects a campaign that names no post, any-post, or next-reel trigger", () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      postId: null,
    });
    expect(result.success).toBe(false);
  });

  it("accepts matchAnyPost: true only when the student opts in explicitly", () => {
    const parsed = createAutomationSchema.parse({
      ...minimalCreatePayload,
      postId: null,
      matchAnyPost: true,
    });
    expect(parsed.matchAnyPost).toBe(true);
  });

  it(`rejects publicReplyEnabled: true with fewer than ${MIN_PUBLIC_REPLY_VARIANTS} reply variants`, () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      publicReplyEnabled: true,
      publicReplyMessages: ["Only one reply"],
    });
    expect(result.success).toBe(false);
  });

  it("rejects publicReplyEnabled: true with zero reply variants supplied", () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      publicReplyEnabled: true,
    });
    expect(result.success).toBe(false);
  });

  it(`accepts publicReplyEnabled: true with ${MIN_PUBLIC_REPLY_VARIANTS} or more distinct reply variants`, () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      publicReplyEnabled: true,
      publicReplyMessages: ["Sent you a DM!", "Check your inbox!"],
    });
    expect(result.success).toBe(true);
  });

  it("ignores blank/whitespace-only variants when counting toward the minimum", () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      publicReplyEnabled: true,
      publicReplyMessages: ["Sent you a DM!", "   ", ""],
    });
    expect(result.success).toBe(false);
  });
});

// A touch chain: the GATE opens Meta's 24h window, position 0 is the payload
// the person came for, later positions are follow-ups. Delays are measured
// from the previous step, and the whole chain has to fit inside the window.
const chainSteps = [
  { position: 0, delaySeconds: 0, message: "Вот обещанное" },
  { position: 1, delaySeconds: 600, message: "Как оно?" },
  { position: 2, delaySeconds: 7200, message: "Ещё пара мыслей" },
];

describe("createAutomationSchema — цепочка касаний", () => {
  it("defaults chainEnabled to false and the chain to empty", () => {
    const parsed = createAutomationSchema.parse(minimalCreatePayload);
    expect(parsed.chainEnabled).toBe(false);
    expect(parsed.chainSteps).toEqual([]);
  });

  it("accepts a chain of steps with the switch on", () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      chainEnabled: true,
      chainSteps,
    });
    expect(result.success).toBe(true);
  });

  it("lets steps be saved while the chain is still off (a draft)", () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      chainSteps,
    });
    expect(result.success).toBe(true);
  });

  it("rejects the switch turned on with no steps to send", () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      chainEnabled: true,
      chainSteps: [],
    });
    expect(result.success).toBe(false);
  });

  it("rejects a gap in positions", () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      chainSteps: [
        { position: 0, delaySeconds: 0, message: "Вот обещанное" },
        { position: 2, delaySeconds: 600, message: "Как оно?" },
      ],
    });
    expect(result.success).toBe(false);
  });

  it("rejects duplicate positions", () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      chainSteps: [
        { position: 0, delaySeconds: 0, message: "Вот обещанное" },
        { position: 0, delaySeconds: 600, message: "Как оно?" },
      ],
    });
    expect(result.success).toBe(false);
  });

  it("rejects a chain that does not start at position 0", () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      chainSteps: [{ position: 1, delaySeconds: 0, message: "Вот обещанное" }],
    });
    expect(result.success).toBe(false);
  });

  it("rejects a negative delay", () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      chainSteps: [{ position: 0, delaySeconds: -1, message: "Вот обещанное" }],
    });
    expect(result.success).toBe(false);
  });

  it("accepts a chain whose delays add up to exactly 23 hours", () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      chainSteps: [
        { position: 0, delaySeconds: 0, message: "Вот обещанное" },
        { position: 1, delaySeconds: 82_800, message: "Последнее касание" },
      ],
    });
    expect(result.success).toBe(true);
  });

  it("rejects a chain that runs past Meta's 24h window", () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      chainSteps: [
        { position: 0, delaySeconds: 0, message: "Вот обещанное" },
        { position: 1, delaySeconds: 82_801, message: "Уже не уйдёт" },
      ],
    });
    expect(result.success).toBe(false);
  });

  it("rejects more than six steps", () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      chainSteps: Array.from({ length: 7 }, (_, index) => ({
        position: index,
        delaySeconds: 60,
        message: `Шаг ${index}`,
      })),
    });
    expect(result.success).toBe(false);
  });

  it("rejects an empty step message", () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      chainSteps: [{ position: 0, delaySeconds: 0, message: "" }],
    });
    expect(result.success).toBe(false);
  });

  it("rejects a step message over 1000 characters", () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      chainSteps: [{ position: 0, delaySeconds: 0, message: "я".repeat(1001) }],
    });
    expect(result.success).toBe(false);
  });

  // Б6: with a button in the GATE the person taps instead of writing back, the
  // 24h window never opens, and the chain has nowhere to go.
  it("rejects a chain alongside a tracked link button", () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      chainEnabled: true,
      chainSteps,
      trackedDestinationUrl: "https://example.com/guide",
    });
    expect(result.success).toBe(false);
  });

  it("rejects a chain alongside a second link button", () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      chainEnabled: true,
      chainSteps,
      secondaryDestinationUrl: "https://example.com/bonus",
    });
    expect(result.success).toBe(false);
  });

  it("allows tracked links on a campaign without a chain", () => {
    const result = createAutomationSchema.safeParse({
      ...minimalCreatePayload,
      trackedDestinationUrl: "https://example.com/guide",
    });
    expect(result.success).toBe(true);
  });
});

describe("updateAutomationSchema — цепочка касаний", () => {
  it("accepts a replacement chain", () => {
    const result = updateAutomationSchema.safeParse({ chainSteps });
    expect(result.success).toBe(true);
  });

  it("accepts clearing the chain with an empty list", () => {
    const result = updateAutomationSchema.safeParse({
      chainEnabled: false,
      chainSteps: [],
    });
    expect(result.success).toBe(true);
  });

  it("rejects enabling the chain with an empty list in the same request", () => {
    const result = updateAutomationSchema.safeParse({
      chainEnabled: true,
      chainSteps: [],
    });
    expect(result.success).toBe(false);
  });

  it("leaves a partial update that only flips the switch to the route handler", () => {
    // Nothing here says how many steps are stored, so the schema can't judge
    // it — app/api/automations/route.ts checks the database instead.
    const result = updateAutomationSchema.safeParse({ chainEnabled: true });
    expect(result.success).toBe(true);
  });

  it("applies the same position and window rules as create", () => {
    expect(
      updateAutomationSchema.safeParse({
        chainSteps: [{ position: 3, delaySeconds: 0, message: "Шаг" }],
      }).success
    ).toBe(false);
    expect(
      updateAutomationSchema.safeParse({
        chainSteps: [{ position: 0, delaySeconds: 90_000, message: "Шаг" }],
      }).success
    ).toBe(false);
    expect(
      updateAutomationSchema.safeParse({
        chainSteps: [{ position: 0, delaySeconds: -5, message: "Шаг" }],
      }).success
    ).toBe(false);
  });

  it("rejects turning the chain on together with a link button", () => {
    const result = updateAutomationSchema.safeParse({
      chainEnabled: true,
      chainSteps,
      trackedDestinationUrl: "https://example.com/guide",
    });
    expect(result.success).toBe(false);
  });
});

describe("updateAutomationSchema — same floor on public reply variants", () => {
  it(`rejects enabling public reply with fewer than ${MIN_PUBLIC_REPLY_VARIANTS} variants in the same update`, () => {
    const result = updateAutomationSchema.safeParse({
      publicReplyEnabled: true,
      publicReplyMessages: ["Only one reply"],
    });
    expect(result.success).toBe(false);
  });

  it("accepts enabling public reply alongside enough variants", () => {
    const result = updateAutomationSchema.safeParse({
      publicReplyEnabled: true,
      publicReplyMessages: ["Sent you a DM!", "Check your inbox!"],
    });
    expect(result.success).toBe(true);
  });

  it("does not block a partial update that leaves the reply list untouched", () => {
    const result = updateAutomationSchema.safeParse({
      isActive: false,
    });
    expect(result.success).toBe(true);
  });
});
