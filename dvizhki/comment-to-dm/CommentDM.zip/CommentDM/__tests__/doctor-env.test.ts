/**
 * Doctor's Environment Check — Unit Tests
 *
 * MEDIUM-5: on a fresh install, install.sh writes INSTAGRAM_APP_ID and
 * INSTAGRAM_APP_SECRET as non-empty stand-ins (your-instagram-app-id /
 * your-instagram-app-secret). Before this fix, serverEnvSchema only checked
 * those two for non-emptiness, so doctor reported "Всё в порядке" while
 * Instagram could never actually connect. Also covers the raw-English-leak
 * fix: every finding's message/detail here must read as Russian, not zod's
 * default issue.message text.
 */

import { beforeEach, describe, expect, it, vi } from "vitest";
import { checkEnv } from "../lib/doctor/checks/env";

const REAL_ENV = {
  APP_URL: "https://commentdm.example.com",
  SESSION_SECRET: "a-real-session-secret-with-plenty-of-length",
  DATABASE_URL: "postgresql://user:pass@localhost:5432/commentdm",
  REDIS_URL: "redis://localhost:6379",
  ENCRYPTION_KEY:
    "5f3a9c1e7b2d4f608a1c3e5b7d9f1a3c5e7b9d1f3a5c7e9b1d3f5a7c9e1b3d5f",
  INSTAGRAM_APP_ID: "1234567890123456",
  INSTAGRAM_APP_SECRET: "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4",
};

// checkEnv's default parameter type is NodeJS.ProcessEnv, which (in this
// repo's TS config) requires NODE_ENV — irrelevant to what's under test
// here, so a small helper casts test fixtures past it instead of repeating
// `as NodeJS.ProcessEnv` at every call site.
function env(overrides: Record<string, string | undefined>): NodeJS.ProcessEnv {
  return overrides as NodeJS.ProcessEnv;
}

beforeEach(() => {
  vi.unstubAllEnvs();
});

function noEnglishLeak(text: string | undefined): void {
  if (!text) return;
  // A crude but effective signal for the specific leak this test guards
  // against: zod's default English phrasing for these checks.
  expect(text).not.toMatch(/must be|is required|invalid|placeholder value copied/i);
}

describe("checkEnv", () => {
  it("reports ok with every variable genuinely real, Instagram included", () => {
    const findings = checkEnv(env(REAL_ENV));

    expect(findings).toHaveLength(1);
    expect(findings[0].level).toBe("ok");
    expect(findings[0].detail).toContain("INSTAGRAM_APP_ID");
  });

  it("flags install.sh's literal Instagram stand-ins as a warning, not an error (MEDIUM-5)", () => {
    const findings = checkEnv(
      env({
        ...REAL_ENV,
        INSTAGRAM_APP_ID: "your-instagram-app-id",
        INSTAGRAM_APP_SECRET: "your-instagram-app-secret",
      })
    );

    expect(findings).toHaveLength(1);
    expect(findings[0].level).toBe("warn");
    expect(findings[0].message).toContain("INSTAGRAM_APP_ID");
    expect(findings[0].message).toContain("INSTAGRAM_APP_SECRET");
    expect(findings[0].code).toBe("E-02");
  });

  it("never reports ok while an Instagram credential is still a placeholder", () => {
    const findings = checkEnv(
      env({ ...REAL_ENV, INSTAGRAM_APP_ID: "your-instagram-app-id" })
    );

    expect(findings.some((f) => f.level === "ok")).toBe(false);
  });

  it("still flags a placeholder ENCRYPTION_KEY as a boot-blocking error", () => {
    const findings = checkEnv(
      env({
        ...REAL_ENV,
        ENCRYPTION_KEY:
          "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
      })
    );

    const encryptionFinding = findings.find((f) =>
      f.message.includes("ENCRYPTION_KEY")
    );
    expect(encryptionFinding?.level).toBe("error");
    expect(encryptionFinding?.code).toBe("E-02");
  });

  it("reports a genuinely missing required variable as an error, in Russian", () => {
    const withoutAppUrl: Record<string, string> = { ...REAL_ENV };
    delete withoutAppUrl.APP_URL;
    const findings = checkEnv(env(withoutAppUrl));

    const appUrlFinding = findings.find((f) => f.message.includes("APP_URL"));
    expect(appUrlFinding?.level).toBe("error");
    expect(appUrlFinding?.code).toBe("E-01");
    for (const f of findings) {
      noEnglishLeak(f.message);
      noEnglishLeak(f.detail);
    }
  });

  it("collapses multiple zod issues on the same field into one finding", () => {
    // A malformed ENCRYPTION_KEY fails both the hex-format regex and (were
    // it hex) would also be checked for placeholder-ness — either way, one
    // human-facing finding per variable, not one per validator.
    const findings = checkEnv(env({ ...REAL_ENV, ENCRYPTION_KEY: "not-hex-at-all" }));

    const encryptionFindings = findings.filter((f) =>
      f.message.includes("ENCRYPTION_KEY")
    );
    expect(encryptionFindings).toHaveLength(1);
  });

  it("never leaks zod's raw English message text into a finding", () => {
    const findings = checkEnv(env({}));
    expect(findings.length).toBeGreaterThan(0);
    for (const f of findings) {
      noEnglishLeak(f.message);
      noEnglishLeak(f.detail);
    }
  });
});
