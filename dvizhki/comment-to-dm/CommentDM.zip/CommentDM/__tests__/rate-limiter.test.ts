/**
 * Rate Limiter — Unit Tests
 *
 * Tests the hourly private-reply cap enforcement using mocked Redis.
 * Assertions derive from RATE_LIMIT_MAX so they survive a change to the cap.
 */

import { describe, it, expect, vi, beforeEach } from "vitest";

const { mockGet, mockEval, mockDel } = vi.hoisted(() => ({
  mockGet: vi.fn(),
  mockEval: vi.fn(),
  mockDel: vi.fn(),
}));

vi.mock("ioredis", () => {
  const MockRedis = vi.fn().mockImplementation(function (
    this: Record<string, unknown>
  ) {
    this.get = mockGet;
    this.eval = mockEval;
    this.del = mockDel;
    return this;
  });
  return { default: MockRedis };
});

vi.stubEnv("REDIS_URL", "redis://localhost:6379");

import {
  checkRateLimit,
  incrementDMCounter,
  reserveDMSlot,
  reserveCommentReplySlot,
  reserveChainSlot,
  RATE_LIMIT_MAX,
  COMMENT_REPLY_RATE_LIMIT_MAX,
  CHAIN_RATE_LIMIT_MAX,
} from "../lib/utils/rate-limiter";

beforeEach(() => {
  vi.clearAllMocks();
});

describe("checkRateLimit", () => {
  it("should allow when count is below limit", async () => {
    mockGet.mockResolvedValue("50");

    const result = await checkRateLimit("account_123");

    expect(result.allowed).toBe(true);
    expect(result.currentCount).toBe(50);
    expect(result.remainingDMs).toBe(RATE_LIMIT_MAX - 50);
    expect(result.shouldRequeue).toBe(false);
    expect(result.shouldSkip).toBe(false);
    expect(result.reserved).toBe(false);
  });

  it("should allow when no previous count exists", async () => {
    mockGet.mockResolvedValue(null);

    const result = await checkRateLimit("account_123");

    expect(result.allowed).toBe(true);
    expect(result.currentCount).toBe(0);
    expect(result.remainingDMs).toBe(RATE_LIMIT_MAX);
  });

  it("should deny when count reaches the limit", async () => {
    mockGet.mockResolvedValue(String(RATE_LIMIT_MAX));

    const result = await checkRateLimit("account_123");

    expect(result.allowed).toBe(false);
    expect(result.shouldRequeue).toBe(true);
    expect(result.shouldSkip).toBe(false);
  });

  it("should skip after max requeue attempts", async () => {
    mockGet.mockResolvedValue(String(RATE_LIMIT_MAX));

    const result = await checkRateLimit("account_123", 3);

    expect(result.allowed).toBe(false);
    expect(result.shouldRequeue).toBe(false);
    expect(result.shouldSkip).toBe(true);
  });
});

describe("reserveDMSlot", () => {
  it("should atomically reserve a slot when below the hourly cap", async () => {
    mockEval.mockResolvedValue([1, 51, 139]);

    const result = await reserveDMSlot("account_123");

    expect(mockEval).toHaveBeenCalledWith(
      expect.any(String),
      1,
      "rate:dm:account_123",
      RATE_LIMIT_MAX,
      3600
    );
    expect(result.allowed).toBe(true);
    expect(result.reserved).toBe(true);
    expect(result.currentCount).toBe(51);
    expect(result.remainingDMs).toBe(139);
  });

  it("should recommend requeue when the atomic reserve is denied", async () => {
    mockEval.mockResolvedValue([0, RATE_LIMIT_MAX, 0]);

    const result = await reserveDMSlot("account_123", 0);

    expect(result.allowed).toBe(false);
    expect(result.reserved).toBe(false);
    expect(result.shouldRequeue).toBe(true);
    expect(result.shouldSkip).toBe(false);
  });

  it("should skip after max requeue attempts", async () => {
    mockEval.mockResolvedValue(["0", String(RATE_LIMIT_MAX), "0"]);

    const result = await reserveDMSlot("account_123", 3);

    expect(result.allowed).toBe(false);
    expect(result.shouldRequeue).toBe(false);
    expect(result.shouldSkip).toBe(true);
  });
});

describe("incrementDMCounter", () => {
  it("should use the atomic reservation path", async () => {
    mockEval.mockResolvedValue([1, 51, 139]);

    const count = await incrementDMCounter("account_123");

    expect(mockEval).toHaveBeenCalled();
    expect(count).toBe(51);
  });
});

describe("reserveCommentReplySlot", () => {
  it("is a second, separate limiter: its own key and its own (lower) cap", async () => {
    mockEval.mockResolvedValue([1, 10, COMMENT_REPLY_RATE_LIMIT_MAX - 10]);

    const result = await reserveCommentReplySlot("account_123");

    expect(mockEval).toHaveBeenCalledWith(
      expect.any(String),
      1,
      "rate:comment:account_123",
      COMMENT_REPLY_RATE_LIMIT_MAX,
      3600
    );
    expect(COMMENT_REPLY_RATE_LIMIT_MAX).toBeLessThan(RATE_LIMIT_MAX);
    expect(result.allowed).toBe(true);
    expect(result.reserved).toBe(true);
  });

  it("denies once the comment-reply cap is hit, independent of the DM cap", async () => {
    mockEval.mockResolvedValue([0, COMMENT_REPLY_RATE_LIMIT_MAX, 0]);

    const result = await reserveCommentReplySlot("account_123", 0);

    expect(result.allowed).toBe(false);
    expect(result.shouldRequeue).toBe(true);
    expect(result.shouldSkip).toBe(false);
  });

  it("skips (rather than requeues) after the max requeue attempts, same as the DM limiter", async () => {
    mockEval.mockResolvedValue([0, COMMENT_REPLY_RATE_LIMIT_MAX, 0]);

    const result = await reserveCommentReplySlot("account_123", 3);

    expect(result.allowed).toBe(false);
    expect(result.shouldRequeue).toBe(false);
    expect(result.shouldSkip).toBe(true);
  });
});

describe("reserveChainSlot", () => {
  it("is a third, separate limiter: its own key and its own cap", async () => {
    mockEval.mockResolvedValue([1, 10, CHAIN_RATE_LIMIT_MAX - 10]);

    const result = await reserveChainSlot("account_123");

    expect(mockEval).toHaveBeenCalledWith(
      expect.any(String),
      1,
      "rate:chain:account_123",
      CHAIN_RATE_LIMIT_MAX,
      3600
    );
    // Chains must never be able to exhaust the bucket GATEs depend on: a
    // missed GATE loses the person for good, a postponed chain step does not.
    expect(CHAIN_RATE_LIMIT_MAX).toBeLessThan(RATE_LIMIT_MAX);
    expect(result.allowed).toBe(true);
    expect(result.reserved).toBe(true);
  });

  it("denies once the chain cap is hit, independent of the DM cap", async () => {
    mockEval.mockResolvedValue([0, CHAIN_RATE_LIMIT_MAX, 0]);

    const result = await reserveChainSlot("account_123", 0);

    expect(result.allowed).toBe(false);
    expect(result.reserved).toBe(false);
    expect(result.shouldRequeue).toBe(true);
  });

  it("quarters the cap for an account still in soft start", async () => {
    mockEval.mockResolvedValue([1, 1, 0]);
    const connectedAt = new Date(Date.now() - 60 * 60 * 1000); // 1h ago

    await reserveChainSlot("account_123", 0, connectedAt);

    expect(mockEval).toHaveBeenCalledWith(
      expect.any(String),
      1,
      "rate:chain:account_123",
      Math.floor(CHAIN_RATE_LIMIT_MAX / 4),
      3600
    );
  });

  it("uses the full cap once the soft-start window has passed", async () => {
    mockEval.mockResolvedValue([1, 1, 0]);
    const connectedAt = new Date(Date.now() - 100 * 60 * 60 * 1000); // 100h ago

    await reserveChainSlot("account_123", 0, connectedAt);

    expect(mockEval).toHaveBeenCalledWith(
      expect.any(String),
      1,
      "rate:chain:account_123",
      CHAIN_RATE_LIMIT_MAX,
      3600
    );
  });
});

describe("soft start: reserveDMSlot / reserveCommentReplySlot with connectedAt", () => {
  it("reserveDMSlot uses the full cap when connectedAt is omitted (unchanged, backward-compatible behavior)", async () => {
    mockEval.mockResolvedValue([1, 1, RATE_LIMIT_MAX - 1]);

    await reserveDMSlot("account_123");

    expect(mockEval).toHaveBeenCalledWith(
      expect.any(String),
      1,
      "rate:dm:account_123",
      RATE_LIMIT_MAX,
      3600
    );
  });

  it("reserveDMSlot quarters the cap for an account connected within the last 72 hours", async () => {
    mockEval.mockResolvedValue([1, 1, 0]);
    const connectedAt = new Date(Date.now() - 60 * 60 * 1000); // 1h ago

    await reserveDMSlot("account_123", 0, connectedAt);

    expect(mockEval).toHaveBeenCalledWith(
      expect.any(String),
      1,
      "rate:dm:account_123",
      Math.floor(RATE_LIMIT_MAX / 4),
      3600
    );
  });

  it("reserveDMSlot uses the full cap once 72 hours have passed since connecting", async () => {
    mockEval.mockResolvedValue([1, 1, 0]);
    const connectedAt = new Date(Date.now() - 100 * 60 * 60 * 1000); // 100h ago

    await reserveDMSlot("account_123", 0, connectedAt);

    expect(mockEval).toHaveBeenCalledWith(
      expect.any(String),
      1,
      "rate:dm:account_123",
      RATE_LIMIT_MAX,
      3600
    );
  });

  it("reserveCommentReplySlot quarters its own (lower) cap during soft start too", async () => {
    mockEval.mockResolvedValue([1, 1, 0]);
    const connectedAt = new Date(Date.now() - 60 * 60 * 1000); // 1h ago

    await reserveCommentReplySlot("account_123", 0, connectedAt);

    expect(mockEval).toHaveBeenCalledWith(
      expect.any(String),
      1,
      "rate:comment:account_123",
      Math.floor(COMMENT_REPLY_RATE_LIMIT_MAX / 4),
      3600
    );
  });
});
