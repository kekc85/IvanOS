import { beforeEach, describe, expect, it, vi } from "vitest";

const { mockPrisma, mockRedisSet } = vi.hoisted(() => ({
  mockPrisma: {
    trackedLink: {
      findUnique: vi.fn(),
    },
    linkClick: {
      create: vi.fn(),
    },
  },
  mockRedisSet: vi.fn(),
}));

vi.mock("@/lib/db/client", () => ({
  prisma: mockPrisma,
}));

vi.mock("@/lib/queue/client", () => ({
  getRedisConnection: () => ({ set: mockRedisSet }),
}));

vi.stubEnv("SESSION_SECRET", "test-session-secret-with-enough-length");

import { GET } from "../app/r/[slug]/route";

beforeEach(() => {
  vi.clearAllMocks();
  // Default: every click write is allowed (first caller in the window).
  mockRedisSet.mockResolvedValue("OK");
});

function makeRequest(url: string, headers: Record<string, string> = {}) {
  return new Request(url, { headers }) as Parameters<typeof GET>[0];
}

describe("tracked link redirect route", () => {
  it("logs a workspace-isolated click and redirects to the destination", async () => {
    mockPrisma.trackedLink.findUnique.mockResolvedValue({
      id: "link_123",
      workspaceId: "workspace_123",
      automationId: "automation_123",
      destinationUrl: "https://example.com/offer",
      automation: {
        instagramAccountId: "instagram_account_123",
      },
    });
    mockPrisma.linkClick.create.mockResolvedValue({});

    const response = await GET(
      makeRequest("https://app.example.com/r/abc123", {
        "user-agent": "vitest",
        referer: "https://instagram.com/",
        "x-forwarded-for": "203.0.113.10",
      }),
      { params: Promise.resolve({ slug: "abc123" }) }
    );

    expect(response.status).toBe(302);
    expect(response.headers.get("location")).toBe("https://example.com/offer");
    expect(mockPrisma.trackedLink.findUnique).toHaveBeenCalledWith({
      where: { slug: "abc123" },
      select: expect.any(Object),
    });
    expect(mockPrisma.linkClick.create).toHaveBeenCalledWith({
      data: expect.objectContaining({
        workspaceId: "workspace_123",
        automationId: "automation_123",
        instagramAccountId: "instagram_account_123",
        trackedLinkId: "link_123",
        userAgent: "vitest",
        referrer: "https://instagram.com/",
      }),
    });
  });

  it("redirects unknown slugs to the homepage without logging a click", async () => {
    mockPrisma.trackedLink.findUnique.mockResolvedValue(null);

    const response = await GET(
      makeRequest("https://app.example.com/r/missing"),
      { params: Promise.resolve({ slug: "missing" }) }
    );

    expect(response.status).toBe(302);
    expect(response.headers.get("location")).toBe("https://app.example.com/");
    expect(mockPrisma.linkClick.create).not.toHaveBeenCalled();
  });

  it("truncates an oversized user-agent and referrer instead of writing them whole", async () => {
    mockPrisma.trackedLink.findUnique.mockResolvedValue({
      id: "link_123",
      workspaceId: "workspace_123",
      automationId: "automation_123",
      destinationUrl: "https://example.com/offer",
      automation: { instagramAccountId: "instagram_account_123" },
    });
    mockPrisma.linkClick.create.mockResolvedValue({});

    const hugeUserAgent = "A".repeat(2000);
    const hugeReferrer = "https://example.com/" + "b".repeat(2000);

    await GET(
      makeRequest("https://app.example.com/r/abc123", {
        "user-agent": hugeUserAgent,
        referer: hugeReferrer,
        "x-forwarded-for": "203.0.113.20",
      }),
      { params: Promise.resolve({ slug: "abc123" }) }
    );

    const call = mockPrisma.linkClick.create.mock.calls[0][0];
    expect(call.data.userAgent.length).toBe(512);
    expect(call.data.referrer.length).toBe(1024);
    expect(hugeUserAgent.length).toBeGreaterThan(512);
    expect(hugeReferrer.length).toBeGreaterThan(1024);
  });

  it("refuses to redirect to a non-http(s) destination", async () => {
    mockPrisma.trackedLink.findUnique.mockResolvedValue({
      id: "link_evil",
      workspaceId: "workspace_123",
      automationId: "automation_123",
      destinationUrl: "javascript:alert(1)",
      automation: { instagramAccountId: "instagram_account_123" },
    });

    const response = await GET(
      makeRequest("https://app.example.com/r/evil"),
      { params: Promise.resolve({ slug: "evil" }) }
    );

    expect(response.status).toBe(400);
    expect(mockPrisma.linkClick.create).not.toHaveBeenCalled();
  });

  it("rejects a data: destination the same way", async () => {
    mockPrisma.trackedLink.findUnique.mockResolvedValue({
      id: "link_evil2",
      workspaceId: "workspace_123",
      automationId: "automation_123",
      destinationUrl: "data:text/html,<script>alert(1)</script>",
      automation: { instagramAccountId: "instagram_account_123" },
    });

    const response = await GET(
      makeRequest("https://app.example.com/r/evil2"),
      { params: Promise.resolve({ slug: "evil2" }) }
    );

    expect(response.status).toBe(400);
  });

  it("skips the click write when the per-slug-per-IP window already fired, but still redirects", async () => {
    mockPrisma.trackedLink.findUnique.mockResolvedValue({
      id: "link_123",
      workspaceId: "workspace_123",
      automationId: "automation_123",
      destinationUrl: "https://example.com/offer",
      automation: { instagramAccountId: "instagram_account_123" },
    });
    mockRedisSet.mockResolvedValue(null); // NX lost: someone already wrote in this window

    const response = await GET(
      makeRequest("https://app.example.com/r/abc123", {
        "x-forwarded-for": "203.0.113.30",
      }),
      { params: Promise.resolve({ slug: "abc123" }) }
    );

    expect(response.status).toBe(302);
    expect(response.headers.get("location")).toBe("https://example.com/offer");
    expect(mockPrisma.linkClick.create).not.toHaveBeenCalled();
    expect(mockRedisSet).toHaveBeenCalledWith(
      expect.stringMatching(/^redirect:click:abc123:/),
      "1",
      "EX",
      60,
      "NX"
    );
  });

  it("still redirects even if the click write itself throws", async () => {
    mockPrisma.trackedLink.findUnique.mockResolvedValue({
      id: "link_123",
      workspaceId: "workspace_123",
      automationId: "automation_123",
      destinationUrl: "https://example.com/offer",
      automation: { instagramAccountId: "instagram_account_123" },
    });
    mockRedisSet.mockRejectedValue(new Error("redis down"));

    const response = await GET(
      makeRequest("https://app.example.com/r/abc123"),
      { params: Promise.resolve({ slug: "abc123" }) }
    );

    expect(response.status).toBe(302);
    expect(response.headers.get("location")).toBe("https://example.com/offer");
  });
});
