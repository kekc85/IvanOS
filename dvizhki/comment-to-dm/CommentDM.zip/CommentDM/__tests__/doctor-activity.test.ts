/**
 * Doctor's Activity Check — Unit Tests
 *
 * MEDIUM-6: checkPollingActivity and checkRecentSends used to return null
 * when zero Instagram accounts are connected — which, combined with
 * checkTokenRefreshFreshness also returning null before the worker's first
 * daily run, could empty out checkActivity()'s whole result array. format.ts
 * skips a section with no findings, so the entire "Опрос комментариев и
 * отправки" section vanished from the report instead of showing "nothing to
 * check yet". Fixed by returning an explicit ok() finding in the
 * zero-accounts case.
 */

import { describe, expect, it, vi } from "vitest";
import { checkActivity } from "../lib/doctor/checks/activity";

function makePrisma(overrides: {
  lastSweepEvent?: unknown;
  lastTokenRefreshEvent?: unknown;
  dmLogGroups?: unknown[];
}) {
  return {
    operationalEvent: {
      findFirst: vi.fn(async ({ where }: { where: { source: string } }) => {
        if (where.source === "SYSTEM") return overrides.lastSweepEvent ?? null;
        if (where.source === "TOKEN_REFRESH")
          return overrides.lastTokenRefreshEvent ?? null;
        return null;
      }),
    },
    dmLog: {
      groupBy: vi.fn(async () => overrides.dmLogGroups ?? []),
    },
  } as never;
}

describe("checkActivity with zero connected accounts", () => {
  it("never returns an empty array, even with no sweep and no token-refresh history yet", async () => {
    const prisma = makePrisma({});

    const findings = await checkActivity(prisma, 0);

    expect(findings.length).toBeGreaterThan(0);
  });

  it("explicitly says there is nothing to check, rather than staying silent", async () => {
    const prisma = makePrisma({});

    const findings = await checkActivity(prisma, 0);

    expect(findings.some((f) => f.message.includes("нечего проверять"))).toBe(
      true
    );
    expect(findings.every((f) => f.level !== "error")).toBe(true);
  });
});

describe("checkActivity with a connected account", () => {
  it("reports the last sweep event when one exists", async () => {
    const prisma = makePrisma({
      lastSweepEvent: {
        createdAt: new Date(Date.now() - 5 * 60_000),
        message: 'Comment sweep "Test" [word]: 1 enqueued, 1 matched, 0 already replied',
      },
    });

    const findings = await checkActivity(prisma, 1);

    expect(
      findings.some((f) => f.message.includes("Опрос комментариев последний раз"))
    ).toBe(true);
  });

  it("reports no sends in the last day distinctly from zero accounts", async () => {
    const prisma = makePrisma({ dmLogGroups: [] });

    const findings = await checkActivity(prisma, 1);

    expect(
      findings.some((f) => f.message.includes("Отправок за последние сутки не было"))
    ).toBe(true);
  });
});

/**
 * Число и глагол в строке про терминальные отказы. Мелочь ровно до того
 * момента, пока владелец не прочитает в отчёте «из них 1 не уйдут никогда» и
 * не решит, что отчёт машинный и доверять ему нечему.
 */
describe("checkActivity — согласование числа в строке про терминальные отказы", () => {
  async function permanentNote(sent: number, permanent: number) {
    const prisma = makePrisma({
      dmLogGroups: [
        { status: "SENT", _count: { _all: sent } },
        { status: "FAILED_PERMANENT", _count: { _all: permanent } },
      ],
    });

    const findings = await checkActivity(prisma, 1);
    return findings.map((f) => f.detail ?? "").join("\n");
  }

  it("одна строка - «1 не уйдёт никогда»", async () => {
    expect(await permanentNote(10, 1)).toContain("из них 1 не уйдёт никогда");
  });

  it("две - «2 не уйдут никогда»", async () => {
    expect(await permanentNote(10, 2)).toContain("из них 2 не уйдут никогда");
  });

  it("пять - «5 не уйдут никогда»", async () => {
    expect(await permanentNote(10, 5)).toContain("из них 5 не уйдут никогда");
  });

  it("двадцать одна - «21 не уйдёт никогда», а не «21 не уйдут»", async () => {
    expect(await permanentNote(50, 21)).toContain("из них 21 не уйдёт никогда");
  });

  it("одиннадцать - «11 не уйдут никогда», исключение второго десятка", async () => {
    expect(await permanentNote(50, 11)).toContain("из них 11 не уйдут никогда");
  });
});
