/**
 * Doctor's Chain Check — Unit Tests
 *
 * Three branches this has to get right, in falling order of how much damage a
 * wrong verdict does:
 *   1. Chain contour dead → error E-16 with a restart command. The chain is
 *      the only part of the system that keeps messaging a person after the
 *      first DM, and Meta's window is 24 hours: a stalled dispatcher quietly
 *      costs every chain currently running.
 *   2. Chains running but a fifth of them failing → warning, pointing at the
 *      journal where each failure wrote its reason.
 *   3. No campaign uses chains → one calm "not in use" line, no noise.
 *
 * The trap in between: both chain contours only write to the journal when
 * something happened (plus once on their first pass after start), so "no
 * event for 15 minutes" is NOT by itself a fault. These tests pin down that a
 * quiet-but-alive contour is reported as fine, and that the error fires on the
 * two signals that really do mean breakage — nothing logged since the worker
 * started, and steps sitting past due.
 */

import { describe, expect, it, vi } from "vitest";
import { checkChain } from "../lib/doctor/checks/chain";
import { CODES } from "../lib/doctor/types";

const MINUTE = 60_000;

interface ChainEvent {
  createdAt: Date;
  message: string;
}

function makePrisma(overrides: {
  chainCampaigns?: number;
  dispatcherEvent?: ChainEvent | null;
  pollerEvent?: ChainEvent | null;
  overdueSteps?: number;
  /** ACTIVE с пустым сроком следующего шага — журней, которого не подберёт никто. */
  strandedJourneys?: number;
  journeyStates?: Array<{ state: string; _count: { _all: number } }>;
}) {
  const automationCount = vi.fn(async () => overrides.chainCampaigns ?? 1);
  const journeyCount = vi.fn(
    async (args: {
      where: {
        state: string;
        nextStepDueAt: { lt: Date } | null;
        updatedAt?: { lt: Date };
      };
    }) =>
      args.where.nextStepDueAt === null
        ? overrides.strandedJourneys ?? 0
        : overrides.overdueSteps ?? 0
  );
  const journeyGroupBy = vi.fn(async () => overrides.journeyStates ?? []);

  return {
    prisma: {
      automation: { count: automationCount },
      operationalEvent: {
        findFirst: vi.fn(
          async ({
            where,
          }: {
            where: { message: { startsWith: string } };
          }) => {
            if (where.message.startsWith.includes("проход диспетчера")) {
              return overrides.dispatcherEvent ?? null;
            }
            if (where.message.startsWith.includes("опрос диалогов")) {
              return overrides.pollerEvent ?? null;
            }
            return null;
          }
        ),
      },
      subscriberJourney: {
        count: journeyCount,
        groupBy: journeyGroupBy,
      },
    } as never,
    automationCount,
    journeyCount,
    journeyGroupBy,
  };
}

function freshEvent(minutesAgo: number, message: string): ChainEvent {
  return { createdAt: new Date(Date.now() - minutesAgo * MINUTE), message };
}

const ALIVE_WORKER = () => ({
  alive: true,
  startedAt: new Date(Date.now() - 60 * MINUTE),
});

describe("no campaign uses chains", () => {
  it("says so in one line and checks nothing else", async () => {
    const { prisma, journeyCount, journeyGroupBy } = makePrisma({
      chainCampaigns: 0,
    });

    const findings = await checkChain(prisma, ALIVE_WORKER());

    expect(findings).toHaveLength(1);
    expect(findings[0].level).toBe("ok");
    expect(findings[0].message).toContain("не используются");
    // No noise, and no pointless queries against an unused feature.
    expect(journeyCount).not.toHaveBeenCalled();
    expect(journeyGroupBy).not.toHaveBeenCalled();
  });
});

describe("chain contour freshness", () => {
  it("reports both contours as fine when each logged within the last 15 minutes", async () => {
    const { prisma } = makePrisma({
      dispatcherEvent: freshEvent(2, "Цепочка: проход диспетчера - пора 0"),
      pollerEvent: freshEvent(1, "Цепочка: опрос диалогов - аккаунтов 1"),
    });

    const findings = await checkChain(prisma, ALIVE_WORKER());

    expect(findings.every((f) => f.level === "ok")).toBe(true);
  });

  it("fails with a restart command when a contour never logged since the worker started", async () => {
    const { prisma } = makePrisma({
      // Дежурная запись есть, но она старше запуска процесса: значит в этом
      // процессе контур не поднялся.
      dispatcherEvent: freshEvent(300, "Цепочка: проход диспетчера - пора 0"),
      pollerEvent: freshEvent(1, "Цепочка: опрос диалогов - аккаунтов 1"),
    });

    const findings = await checkChain(prisma, ALIVE_WORKER());

    const failure = findings.find((f) => f.level === "error");
    expect(failure).toBeDefined();
    expect(failure!.code).toBe(CODES.CHAIN_STALLED);
    expect(failure!.message).toContain("Диспетчер шагов");
    expect(failure!.command).toContain("systemctl restart commentdm-worker");
  });

  it("fails the same way when a contour has no journal entry at all", async () => {
    const { prisma } = makePrisma({
      dispatcherEvent: freshEvent(1, "Цепочка: проход диспетчера - пора 0"),
      pollerEvent: null,
    });

    const findings = await checkChain(prisma, ALIVE_WORKER());

    const failure = findings.find((f) => f.level === "error");
    expect(failure).toBeDefined();
    expect(failure!.message).toContain("Опрос диалогов");
  });

  it("does not fail a quiet contour that logged after the worker started", async () => {
    const { prisma } = makePrisma({
      // Worker up 60 min, both contours logged 30 min ago and then went quiet
      // because nobody is in a chain right now — normal, not a fault.
      dispatcherEvent: freshEvent(30, "Цепочка: проход диспетчера - пора 0"),
      pollerEvent: freshEvent(30, "Цепочка: опрос диалогов - аккаунтов 1"),
    });

    const findings = await checkChain(prisma, ALIVE_WORKER());

    expect(findings.every((f) => f.level === "ok")).toBe(true);
    expect(findings.some((f) => f.message.includes("тихо"))).toBe(true);
  });

  it("gives a freshly started worker a grace period instead of failing it", async () => {
    const { prisma } = makePrisma({ dispatcherEvent: null, pollerEvent: null });

    const findings = await checkChain(prisma, {
      alive: true,
      startedAt: new Date(Date.now() - 1 * MINUTE),
    });

    expect(findings.every((f) => f.level !== "error")).toBe(true);
    expect(findings.some((f) => f.message.includes("только запустился"))).toBe(
      true
    );
  });

  it("stays quiet about the chain when the worker itself is down", async () => {
    const { prisma } = makePrisma({ dispatcherEvent: null, pollerEvent: null });

    const findings = await checkChain(prisma, { alive: false, startedAt: null });

    // The worker section already says this loudly; a second alarm here would
    // send a beginner to fix the wrong thing.
    expect(findings.every((f) => f.level !== "error")).toBe(true);
    expect(
      findings.some((f) => f.message.includes("фоновый процесс не отвечает"))
    ).toBe(true);
  });

  it("warns rather than fails when the worker does not report its start time", async () => {
    const { prisma } = makePrisma({ dispatcherEvent: null, pollerEvent: null });

    const findings = await checkChain(prisma, { alive: true, startedAt: null });

    expect(findings.every((f) => f.level !== "error")).toBe(true);
    const warning = findings.find((f) => f.level === "warn");
    expect(warning!.code).toBe(CODES.CHAIN_STALLED);
    expect(warning!.command).toContain("systemctl restart commentdm-worker");
  });
});

describe("steps that are past due", () => {
  it("fails when somebody has been waiting for their next step over 15 minutes", async () => {
    const { prisma, journeyCount } = makePrisma({
      dispatcherEvent: freshEvent(1, "Цепочка: проход диспетчера - пора 3"),
      pollerEvent: freshEvent(1, "Цепочка: опрос диалогов - аккаунтов 1"),
      overdueSteps: 4,
    });

    const findings = await checkChain(prisma, ALIVE_WORKER());

    const failure = findings.find((f) => f.level === "error");
    expect(failure).toBeDefined();
    expect(failure!.code).toBe(CODES.CHAIN_STALLED);
    expect(failure!.detail).toContain("4");
    expect(failure!.command).toContain("systemctl restart commentdm-worker");

    // Only live chains count as overdue — a finished journey keeps its old due
    // date forever and must never be read as a stuck step.
    const where = journeyCount.mock.calls
      .map((call) => call[0].where)
      .find((candidate) => candidate.nextStepDueAt !== null)!;
    expect(where.state).toBe("ACTIVE");
    expect(where.nextStepDueAt!.lt).toBeInstanceOf(Date);
  });

  /**
   * Журней-зомби: ACTIVE, но срок следующего шага пуст. Диспетчер выбирает по
   * наступившему сроку, а NULL не наступает никогда — такую цепочку не
   * сдвинет даже перезапуск. Проверка, смотревшая только на просроченные
   * сроки, при этом честно рапортовала «застрявших шагов нет».
   */
  it("fails on a live journey stranded with no due date at all", async () => {
    const { prisma, journeyCount } = makePrisma({
      dispatcherEvent: freshEvent(1, "Цепочка: проход диспетчера - пора 0"),
      pollerEvent: freshEvent(1, "Цепочка: опрос диалогов - аккаунтов 1"),
      overdueSteps: 0,
      strandedJourneys: 2,
    });

    const findings = await checkChain(prisma, ALIVE_WORKER());

    const failure = findings.find((f) => f.message.includes("Застрявшая"));
    expect(failure).toBeDefined();
    expect(failure!.level).toBe("error");
    expect(failure!.code).toBe(CODES.CHAIN_STALLED);
    expect(failure!.detail).toContain("2");
    // Restarting the worker does not help here, so the command has to show the
    // rows instead of pretending a restart is the fix.
    expect(failure!.command).toContain("SubscriberJourney");

    // Age is measured on updatedAt: a journey touched a minute ago is still
    // being worked on, not stranded.
    const where = journeyCount.mock.calls
      .map((call) => call[0].where)
      .find((candidate) => candidate.nextStepDueAt === null)!;
    expect(where.state).toBe("ACTIVE");
    expect(where.updatedAt!.lt).toBeInstanceOf(Date);
  });

  it("stays quiet when neither overdue nor stranded journeys exist", async () => {
    const { prisma } = makePrisma({
      dispatcherEvent: freshEvent(1, "Цепочка: проход диспетчера - пора 0"),
      pollerEvent: freshEvent(1, "Цепочка: опрос диалогов - аккаунтов 1"),
    });

    const findings = await checkChain(prisma, ALIVE_WORKER());

    expect(findings.every((f) => f.level === "ok")).toBe(true);
    expect(findings.some((f) => f.message.includes("Застрявших шагов нет"))).toBe(
      true
    );
  });
});

describe("chain outcomes over the last 7 days", () => {
  it("warns when more than a fifth of chains failed and there are enough of them", async () => {
    const { prisma } = makePrisma({
      dispatcherEvent: freshEvent(1, "Цепочка: проход диспетчера - пора 0"),
      pollerEvent: freshEvent(1, "Цепочка: опрос диалогов - аккаунтов 1"),
      journeyStates: [
        { state: "DONE", _count: { _all: 6 } },
        { state: "FAILED", _count: { _all: 4 } },
      ],
    });

    const findings = await checkChain(prisma, ALIVE_WORKER());

    const warning = findings.find((f) => f.level === "warn");
    expect(warning).toBeDefined();
    expect(warning!.code).toBe(CODES.CHAIN_STALLED);
    expect(warning!.message).toContain("срывается");
    expect(warning!.detail).toContain("40%");
    expect(warning!.command).toContain("OperationalEvent");
  });

  /**
   * A small sample says nothing about a *rate* — but silence here was the
   * worse error: on a fresh install the first few people ARE the whole
   * dataset, so "all three failed" used to render as a green section at
   * exactly the moment the contour was dead. Warning, not error: one failed
   * chain early on can simply be a person who let the window close.
   */
  it("warns, not stays silent, when the sample is small but chains do fail", async () => {
    const { prisma } = makePrisma({
      dispatcherEvent: freshEvent(1, "Цепочка: проход диспетчера - пора 0"),
      pollerEvent: freshEvent(1, "Цепочка: опрос диалогов - аккаунтов 1"),
      journeyStates: [
        { state: "DONE", _count: { _all: 2 } },
        { state: "FAILED", _count: { _all: 1 } },
      ],
    });

    const findings = await checkChain(prisma, ALIVE_WORKER());

    expect(findings.every((f) => f.level !== "error")).toBe(true);
    const warning = findings.find((f) => f.level === "warn");
    expect(warning).toBeDefined();
    expect(warning!.code).toBe(CODES.CHAIN_STALLED);
    expect(warning!.message).toContain("Цепочек мало");
    expect(warning!.detail).toContain("3");
    expect(warning!.command).toContain("OperationalEvent");
  });

  it("catches the 100% failure that the share threshold used to hide", async () => {
    const { prisma } = makePrisma({
      dispatcherEvent: freshEvent(1, "Цепочка: проход диспетчера - пора 0"),
      pollerEvent: freshEvent(1, "Цепочка: опрос диалогов - аккаунтов 1"),
      journeyStates: [{ state: "FAILED", _count: { _all: 3 } }],
    });

    const findings = await checkChain(prisma, ALIVE_WORKER());

    expect(findings.some((f) => f.level === "warn")).toBe(true);
  });

  it("stays calm on a small sample with no failures at all", async () => {
    const { prisma } = makePrisma({
      dispatcherEvent: freshEvent(1, "Цепочка: проход диспетчера - пора 0"),
      pollerEvent: freshEvent(1, "Цепочка: опрос диалогов - аккаунтов 1"),
      journeyStates: [
        { state: "DONE", _count: { _all: 2 } },
        { state: "ACTIVE", _count: { _all: 1 } },
      ],
    });

    const findings = await checkChain(prisma, ALIVE_WORKER());

    expect(findings.every((f) => f.level === "ok")).toBe(true);
  });

  it("shows the state breakdown when the failure rate is healthy", async () => {
    const { prisma } = makePrisma({
      dispatcherEvent: freshEvent(1, "Цепочка: проход диспетчера - пора 0"),
      pollerEvent: freshEvent(1, "Цепочка: опрос диалогов - аккаунтов 1"),
      journeyStates: [
        { state: "DONE", _count: { _all: 9 } },
        { state: "ACTIVE", _count: { _all: 3 } },
        { state: "FAILED", _count: { _all: 1 } },
      ],
    });

    const findings = await checkChain(prisma, ALIVE_WORKER());

    const summary = findings.find((f) => f.message.includes("Цепочек за"));
    expect(summary).toBeDefined();
    expect(summary!.message).toContain("13");
    expect(summary!.detail).toContain("дошли до конца: 9");
    expect(summary!.detail).toContain("сорвались: 1");
  });

  it("says plainly when nobody entered a chain in the last week", async () => {
    const { prisma } = makePrisma({
      dispatcherEvent: freshEvent(1, "Цепочка: проход диспетчера - пора 0"),
      pollerEvent: freshEvent(1, "Цепочка: опрос диалогов - аккаунтов 1"),
      journeyStates: [],
    });

    const findings = await checkChain(prisma, ALIVE_WORKER());

    expect(
      findings.some((f) => f.message.includes("никто не заходил"))
    ).toBe(true);
  });
});

describe("when the database itself misbehaves", () => {
  it("degrades to one warning instead of taking the whole report down", async () => {
    const prisma = {
      automation: {
        count: vi.fn(async () => {
          throw new Error("connection reset");
        }),
      },
    } as never;

    const findings = await checkChain(prisma, ALIVE_WORKER());

    expect(findings).toHaveLength(1);
    expect(findings[0].level).toBe("warn");
    expect(findings[0].detail).toContain("connection reset");
  });
});
