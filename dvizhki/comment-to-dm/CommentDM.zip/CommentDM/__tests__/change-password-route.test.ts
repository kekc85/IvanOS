/**
 * POST /api/auth/change-password — behavior beyond the anonymous-401 sweep
 * in api-auth-surface.test.ts (which already proves this route refuses a
 * caller with no session). This covers what happens once there IS a
 * session: missing fields, a wrong current password, a new password that
 * fails policy, and the success path.
 */

import { beforeEach, describe, expect, it, vi } from "vitest";

const { mockGetCurrentUser, mockChangeOwnerPassword } = vi.hoisted(() => ({
  mockGetCurrentUser: vi.fn(),
  mockChangeOwnerPassword: vi.fn(),
}));

vi.mock("@/lib/auth/session", () => ({
  getCurrentUser: mockGetCurrentUser,
}));

vi.mock("@/lib/auth/owner", () => ({
  changeOwnerPassword: mockChangeOwnerPassword,
}));

import { POST } from "../app/api/auth/change-password/route";

function postRequest(body: unknown) {
  return new Request("http://localhost:3000/api/auth/change-password", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  }) as never; // route only reads request.json(), matches NextRequest's shape closely enough
}

beforeEach(() => {
  vi.clearAllMocks();
  mockGetCurrentUser.mockResolvedValue({ id: "user_owner", email: "owner@localhost", name: "Владелец" });
});

describe("POST /api/auth/change-password", () => {
  it("401s when there is no session, without calling changeOwnerPassword", async () => {
    mockGetCurrentUser.mockResolvedValue(null);

    const response = await POST(postRequest({ currentPassword: "a", newPassword: "b" }));

    expect(response.status).toBe(401);
    expect(mockChangeOwnerPassword).not.toHaveBeenCalled();
  });

  it("400s when either field is missing", async () => {
    const response = await POST(postRequest({ currentPassword: "" }));

    expect(response.status).toBe(400);
    expect(mockChangeOwnerPassword).not.toHaveBeenCalled();
  });

  it("400s with the reason when the current password is wrong", async () => {
    mockChangeOwnerPassword.mockResolvedValue({
      ok: false,
      reason: "Текущий пароль неверен",
    });

    const response = await POST(
      postRequest({ currentPassword: "wrong", newPassword: "tK9-quiet-lantern" })
    );
    const payload = await response.json();

    expect(response.status).toBe(400);
    expect(payload).toEqual({ success: false, error: "Текущий пароль неверен" });
  });

  it("200s on success", async () => {
    mockChangeOwnerPassword.mockResolvedValue({ ok: true });

    const response = await POST(
      postRequest({ currentPassword: "current-123", newPassword: "tK9-quiet-lantern" })
    );
    const payload = await response.json();

    expect(response.status).toBe(200);
    expect(payload).toEqual({ success: true });
    expect(mockChangeOwnerPassword).toHaveBeenCalledWith(
      "current-123",
      "tK9-quiet-lantern"
    );
  });
});
