/**
 * Owner Password — Unit Tests
 *
 * Covers the two things the login form leans on: a wrong password never
 * verifies, and a password from the guessed-first list never gets stored in
 * the first place.
 */

import { describe, expect, it } from "vitest";
import {
  MIN_PASSWORD_LENGTH,
  checkPasswordPolicy,
  generatePassword,
  hashPassword,
  isPasswordBlocked,
  verifyPassword,
} from "../lib/auth/password";

describe("password hashing", () => {
  it("verifies the correct password", async () => {
    const hash = await hashPassword("correct-horse-battery");

    await expect(verifyPassword("correct-horse-battery", hash)).resolves.toBe(
      true
    );
  });

  it("rejects a wrong password", async () => {
    const hash = await hashPassword("correct-horse-battery");

    await expect(verifyPassword("correct-horse-batterz", hash)).resolves.toBe(
      false
    );
    await expect(verifyPassword("", hash)).resolves.toBe(false);
  });

  it("never stores the password in plain text", async () => {
    const hash = await hashPassword("correct-horse-battery");

    expect(hash).not.toContain("correct-horse-battery");
    expect(hash.startsWith("scrypt$")).toBe(true);
  });

  it("salts each hash, so the same password hashes differently", async () => {
    const first = await hashPassword("correct-horse-battery");
    const second = await hashPassword("correct-horse-battery");

    expect(first).not.toBe(second);
    await expect(verifyPassword("correct-horse-battery", second)).resolves.toBe(
      true
    );
  });

  it("treats a missing or malformed hash as a failed login", async () => {
    await expect(verifyPassword("anything", null)).resolves.toBe(false);
    await expect(verifyPassword("anything", "")).resolves.toBe(false);
    await expect(verifyPassword("anything", "not-a-hash")).resolves.toBe(false);
    await expect(
      verifyPassword("anything", "scrypt$16384$8$1$only-four-parts")
    ).resolves.toBe(false);
  });

  it("generates a password that passes its own policy", async () => {
    const generated = generatePassword();

    expect(generated.length).toBeGreaterThanOrEqual(MIN_PASSWORD_LENGTH);
    expect(checkPasswordPolicy(generated).ok).toBe(true);
  });
});

describe("password policy", () => {
  it("refuses passwords from the blocklist", () => {
    for (const blocked of ["123456", "password", "admin", "PASSWORD", "QWERTY"]) {
      expect(isPasswordBlocked(blocked)).toBe(true);
      expect(checkPasswordPolicy(blocked).ok).toBe(false);
    }
  });

  it("refuses passwords shorter than the minimum", () => {
    const result = checkPasswordPolicy("short12");

    expect(result.ok).toBe(false);
    expect(result.ok === false && result.reason).toContain(
      String(MIN_PASSWORD_LENGTH)
    );
  });

  it("refuses to hash a blocklisted password at all", async () => {
    await expect(hashPassword("password123")).rejects.toThrow(
      /самых угадываемых/
    );
    await expect(hashPassword("admin")).rejects.toThrow();
  });

  it("accepts an ordinary strong password", () => {
    expect(checkPasswordPolicy("tK9-quiet-lantern").ok).toBe(true);
  });
});
