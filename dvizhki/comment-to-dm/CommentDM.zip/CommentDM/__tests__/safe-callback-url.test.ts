/**
 * safeCallbackUrl — Unit Tests
 *
 * MEDIUM-8: an open redirect through ?callbackUrl=. The login form's
 * callbackUrl feeds straight into redirect() after a successful login, so
 * anything that survives this function unrejected is where the browser
 * ends up post-login.
 */

import { describe, expect, it } from "vitest";
import { safeCallbackUrl } from "../lib/net/safe-callback-url";

function formValue(value: string): FormDataEntryValue {
  const fd = new FormData();
  fd.set("callbackUrl", value);
  return fd.get("callbackUrl")!;
}

describe("safeCallbackUrl", () => {
  it("passes through an ordinary in-app path", () => {
    expect(safeCallbackUrl(formValue("/dashboard"))).toBe("/dashboard");
    expect(safeCallbackUrl(formValue("/campaigns/abc123"))).toBe(
      "/campaigns/abc123"
    );
  });

  it("falls back to /dashboard for null or non-string input", () => {
    expect(safeCallbackUrl(null)).toBe("/dashboard");
  });

  it("falls back to /dashboard for a path that doesn't start with /", () => {
    expect(safeCallbackUrl(formValue("evil.com"))).toBe("/dashboard");
    expect(safeCallbackUrl(formValue("https://evil.com"))).toBe("/dashboard");
  });

  it("rejects a literal protocol-relative URL", () => {
    expect(safeCallbackUrl(formValue("//evil.com"))).toBe("/dashboard");
    expect(safeCallbackUrl(formValue("///evil.com"))).toBe("/dashboard");
  });

  it("rejects the backslash-normalization bypass (MEDIUM-8)", () => {
    // Browsers that normalize a backslash right after the leading slash
    // into another forward slash turn this into //evil.com at navigation
    // time — the exact gap the old raw.startsWith("//") check missed.
    expect(safeCallbackUrl(formValue("/\\evil.com"))).toBe("/dashboard");
    expect(safeCallbackUrl(formValue("/\\/evil.com"))).toBe("/dashboard");
    expect(safeCallbackUrl(formValue("/\\\\evil.com"))).toBe("/dashboard");
  });

  it("still allows a real in-app path containing a backslash later in it, if such a path existed", () => {
    // Only a LEADING backslash-into-double-slash is the attack; a backslash
    // elsewhere doesn't turn the path off-origin.
    expect(safeCallbackUrl(formValue("/campaigns/foo\\bar"))).toBe(
      "/campaigns/foo\\bar"
    );
  });
});
