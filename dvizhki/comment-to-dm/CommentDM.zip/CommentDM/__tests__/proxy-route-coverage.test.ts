/**
 * proxy.ts — Route Coverage
 *
 * MEDIUM-7: PROTECTED_PREFIXES in proxy.ts is a hand-maintained list, and it
 * had drifted — /overview, /inbox, /campaigns, and /diagnostics were all
 * real pages under app/(dashboard)/ with no entry here, so an anonymous
 * visitor hitting one of those by a bookmarked URL skipped proxy's early
 * redirect entirely (DashboardLayout's own getCurrentUser() check still
 * caught it — no data leaked — but the fast, no-render redirect didn't
 * fire). Nothing caught the drift before this test.
 *
 * This reads the actual route list off disk (same technique as
 * api-auth-surface.test.ts for app/api) so a new page under
 * app/(dashboard)/ fails this test the moment it's added without also
 * being added to proxy.ts, instead of silently falling through.
 */

import { readdirSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { NextRequest } from "next/server";
import { proxy } from "../proxy";

const DASHBOARD_GROUP_DIR = path.resolve(__dirname, "../app/(dashboard)");

// Every subdirectory of app/(dashboard)/ is a route segment; layout.tsx (and
// any other loose file directly in the group) is not a page of its own.
const DASHBOARD_ROUTES = readdirSync(DASHBOARD_GROUP_DIR, { withFileTypes: true })
  .filter((entry) => entry.isDirectory())
  .map((entry) => `/${entry.name}`)
  .sort();

function anonymousRequest(pathname: string): NextRequest {
  return new NextRequest(new URL(`http://localhost:3000${pathname}`));
}

describe("proxy: every page under app/(dashboard)/ is protected", () => {
  it("finds more than a couple of routes on disk, so this test isn't vacuous", () => {
    expect(DASHBOARD_ROUTES.length).toBeGreaterThan(3);
  });

  for (const route of DASHBOARD_ROUTES) {
    it(`redirects an anonymous visitor away from ${route}`, () => {
      const response = proxy(anonymousRequest(route));

      expect(response.status).toBeGreaterThanOrEqual(300);
      expect(response.status).toBeLessThan(400);
      const location = response.headers.get("location");
      expect(location).toBeTruthy();
      expect(new URL(location!).pathname).toBe("/login");
    });

    it(`redirects an anonymous visitor away from a nested path under ${route}`, () => {
      const response = proxy(anonymousRequest(`${route}/some-id`));

      expect(response.status).toBeGreaterThanOrEqual(300);
      expect(response.status).toBeLessThan(400);
      expect(new URL(response.headers.get("location")!).pathname).toBe("/login");
    });
  }

  it("lets an anonymous visitor through to /login itself", () => {
    const response = proxy(anonymousRequest("/login"));
    expect(response.status).toBe(200);
  });

  it("lets an anonymous visitor through to the public health check", () => {
    const response = proxy(anonymousRequest("/api/health"));
    expect(response.status).toBe(200);
  });
});
