/**
 * Overlap Guard — Unit Tests
 *
 * lib/polling/overlap-guard.ts stops a slow interval-driven job (the
 * comment-poll timer in worker/dm-worker.ts) from having two invocations in
 * flight at once.
 */

import { describe, expect, it, vi } from "vitest";
import { createOverlapGuard } from "../lib/polling/overlap-guard";

function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((r) => {
    resolve = r;
  });
  return { promise, resolve };
}

describe("createOverlapGuard", () => {
  it("runs the function and reports 'ran' when nothing else is in flight", async () => {
    const guard = createOverlapGuard();
    const fn = vi.fn().mockResolvedValue(undefined);

    const outcome = await guard(fn);

    expect(outcome).toBe("ran");
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it("skips a second invocation while the first is still running", async () => {
    const guard = createOverlapGuard();
    const first = deferred<void>();
    const slowFn = vi.fn().mockReturnValue(first.promise);
    const fastFn = vi.fn().mockResolvedValue(undefined);

    const firstRun = guard(slowFn); // still in flight — slowFn hasn't resolved
    const secondRun = await guard(fastFn); // fires while firstRun is pending

    expect(secondRun).toBe("skipped");
    expect(fastFn).not.toHaveBeenCalled();

    first.resolve();
    expect(await firstRun).toBe("ran");
  });

  it("allows a new run once the previous one has finished", async () => {
    const guard = createOverlapGuard();
    const fn = vi.fn().mockResolvedValue(undefined);

    await guard(fn);
    const secondOutcome = await guard(fn);

    expect(secondOutcome).toBe("ran");
    expect(fn).toHaveBeenCalledTimes(2);
  });

  it("clears the in-flight flag even when the function throws", async () => {
    const guard = createOverlapGuard();
    const failing = vi.fn().mockRejectedValue(new Error("boom"));
    const fn = vi.fn().mockResolvedValue(undefined);

    await expect(guard(failing)).rejects.toThrow("boom");

    // The guard must not stay "stuck" thinking a run is still in flight
    // just because that run threw.
    const outcome = await guard(fn);
    expect(outcome).toBe("ran");
  });
});
