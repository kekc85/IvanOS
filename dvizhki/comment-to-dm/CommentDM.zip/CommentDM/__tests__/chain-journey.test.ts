import { describe, it, expect, vi, beforeEach } from "vitest";

const { mockPrisma } = vi.hoisted(() => ({
  mockPrisma: {
    subscriberJourney: {
      findFirst: vi.fn(),
      findUnique: vi.fn(),
      create: vi.fn(),
      upsert: vi.fn(),
      update: vi.fn(),
      updateMany: vi.fn(),
    },
    workspace: {
      findFirst: vi.fn(),
    },
    operationalEvent: {
      create: vi.fn(),
    },
  },
}));

vi.mock("@/lib/db/client", () => ({
  prisma: mockPrisma,
}));

import {
  GATE_TTL_MS,
  MESSAGING_WINDOW_MS,
  createGateJourney,
  expireStaleGates,
  findAnyJourneyForCampaign,
  findLiveJourneyByCommenter,
  hasLiveJourney,
  hasLiveJourneyByCommenter,
  isWindowOpen,
  markJourneySkipped,
  restartBlockedReason,
} from "../lib/chain/journey";
import { DEFAULT_CHAIN_JOURNEY_RETENTION_DAYS } from "../lib/gdpr/retention-defaults";

const NOW = new Date("2026-08-09T12:00:00.000Z");

const gateInput = {
  workspaceId: "workspace_123",
  automationId: "auto_789",
  instagramAccountId: "ig_account_row_1",
  subscriberId: "recipient_555",
  commenterId: "commenter_999",
  subscriberName: "commenter_user",
  commentId: "comment_555",
  now: NOW,
};

/** Строка журнея так, как её вернула бы база. */
function journeyRow(overrides: Record<string, unknown> = {}) {
  return {
    id: "journey_1",
    workspaceId: "workspace_123",
    automationId: "auto_789",
    instagramAccountId: "ig_account_row_1",
    subscriberId: "recipient_555",
    commenterId: "commenter_999",
    subscriberName: "commenter_user",
    commentId: "comment_555",
    conversationId: null,
    state: "GATE_SENT",
    gateSentAt: NOW,
    lastUserMessageAt: null,
    nextStepPosition: 0,
    nextStepDueAt: null,
    attempts: 0,
    failReason: null,
    completedAt: null,
    createdAt: NOW,
    updatedAt: NOW,
    ...overrides,
  };
}

function lastEvent() {
  const calls = mockPrisma.operationalEvent.create.mock.calls;
  return calls[calls.length - 1]?.[0]?.data;
}

beforeEach(() => {
  vi.clearAllMocks();
  mockPrisma.subscriberJourney.findFirst.mockResolvedValue(null);
  mockPrisma.subscriberJourney.findUnique.mockResolvedValue(null);
  mockPrisma.subscriberJourney.upsert.mockResolvedValue(journeyRow());
  mockPrisma.subscriberJourney.updateMany.mockResolvedValue({ count: 0 });
  mockPrisma.workspace.findFirst.mockResolvedValue({ id: "ws_sole" });
  mockPrisma.operationalEvent.create.mockResolvedValue({});
});

describe("chain journey — гейт «одна живая цепочка на человека»", () => {
  it("ищет живой журней по subscriberId только в живых состояниях", async () => {
    mockPrisma.subscriberJourney.findFirst.mockResolvedValue({
      id: "journey_1",
      automationId: "auto_1",
      state: "ACTIVE",
      automation: { name: "Кампания 1" },
    });

    await expect(hasLiveJourney("ig_account_row_1", "recipient_555")).resolves.toBe(
      true
    );
    expect(mockPrisma.subscriberJourney.findFirst).toHaveBeenCalledWith(
      expect.objectContaining({
        where: {
          instagramAccountId: "ig_account_row_1",
          subscriberId: "recipient_555",
          state: { in: ["GATE_SENT", "ACTIVE"] },
        },
      })
    );
  });

  it("без живого журнея отвечает false", async () => {
    await expect(hasLiveJourney("ig_account_row_1", "recipient_555")).resolves.toBe(
      false
    );
  });

  it("тот же гейт по commenterId - им пользуются ДО отправки GATE", async () => {
    mockPrisma.subscriberJourney.findFirst.mockResolvedValue({
      id: "journey_1",
      automationId: "auto_1",
      state: "GATE_SENT",
      automation: { name: "Кампания 1" },
    });

    const live = await findLiveJourneyByCommenter(
      "ig_account_row_1",
      "commenter_999"
    );

    expect(mockPrisma.subscriberJourney.findFirst).toHaveBeenCalledWith(
      expect.objectContaining({
        where: {
          instagramAccountId: "ig_account_row_1",
          commenterId: "commenter_999",
          state: { in: ["GATE_SENT", "ACTIVE"] },
        },
      })
    );
    // Имя кампании нужно, чтобы владелец прочитал в логе, ЧЬЯ цепочка заняла
    // человека, а не просто «пропущено».
    expect(live?.automationName).toBe("Кампания 1");
  });

  it("журней в терминальном состоянии живым не считается", async () => {
    // findFirst с фильтром по живым состояниям вернёт null — DONE в выборку
    // не попадает; проверяем, что функция не додумывает за базу.
    mockPrisma.subscriberJourney.findFirst.mockResolvedValue(null);

    await expect(
      hasLiveJourneyByCommenter("ig_account_row_1", "commenter_999")
    ).resolves.toBe(false);
  });
});

describe("chain journey — гейт повторного входа (Prohibit restart)", () => {
  it("ищет журней кампании по ОБОИМ ID человека, из состояний исключает только SKIPPED", async () => {
    mockPrisma.subscriberJourney.findFirst.mockResolvedValue({
      id: "journey_done",
      automationId: "auto_789",
      state: "DONE",
      automation: { name: "Цепочка про запуск" },
    });

    const prior = await findAnyJourneyForCampaign("auto_789", "commenter_999");

    expect(mockPrisma.subscriberJourney.findFirst).toHaveBeenCalledWith(
      expect.objectContaining({
        where: {
          automationId: "auto_789",
          // Фильтра по LIVE_JOURNEY_STATES тут быть не должно: терминальная
          // строка - это и есть то, ради чего гейт стоит. Вычеркнут ровно
          // один SKIPPED: при нём GATE человеку не уходил.
          state: { not: "SKIPPED" },
          // До отправки GATE на руках только ID из пространства
          // комментариев, а в старой строке мог лежать любой из двух.
          OR: [
            { commenterId: "commenter_999" },
            { subscriberId: "commenter_999" },
          ],
        },
        orderBy: { createdAt: "desc" },
      })
    );
    expect(prior?.state).toBe("DONE");
    expect(prior?.automationName).toBe("Цепочка про запуск");
  });

  it("без прошлого журнея этой кампании отвечает null", async () => {
    await expect(
      findAnyJourneyForCampaign("auto_789", "commenter_999")
    ).resolves.toBeNull();
  });

  it("причина отказа называет состояние прошлой цепочки и срок запрета", () => {
    const reason = restartBlockedReason("EXPIRED");

    expect(reason).toContain("EXPIRED");
    // Срок запрета = ретеншн журнеев, отдельной константы под него нет.
    expect(reason).toContain(`${DEFAULT_CHAIN_JOURNEY_RETENTION_DAYS} дней`);
  });
});

describe("chain journey — createGateJourney", () => {
  it("заводит журней в GATE_SENT с обоими идентификаторами", async () => {
    const result = await createGateJourney(gateInput);

    expect(mockPrisma.subscriberJourney.upsert).toHaveBeenCalledWith(
      expect.objectContaining({
        where: {
          automationId_subscriberId: {
            automationId: "auto_789",
            subscriberId: "recipient_555",
          },
        },
        create: expect.objectContaining({
          state: "GATE_SENT",
          subscriberId: "recipient_555",
          commenterId: "commenter_999",
          commentId: "comment_555",
          gateSentAt: NOW,
          nextStepPosition: 0,
        }),
        update: {},
      })
    );
    expect(result.created).toBe(true);
    expect(lastEvent()).toEqual(
      expect.objectContaining({
        source: "WORKER",
        level: "INFO",
        message: expect.stringContaining("GATE отправлен"),
      })
    );
  });

  it("на дубле не бросает P2002: пишет upsert-ом, а не create", async () => {
    await createGateJourney(gateInput);

    expect(mockPrisma.subscriberJourney.create).not.toHaveBeenCalled();
    expect(mockPrisma.subscriberJourney.upsert).toHaveBeenCalledTimes(1);
  });

  it("существующий журней возвращает как есть - не пересоздаёт и не сбрасывает", async () => {
    const existing = journeyRow({
      state: "ACTIVE",
      nextStepPosition: 2,
      gateSentAt: new Date("2026-08-08T10:00:00.000Z"),
    });
    mockPrisma.subscriberJourney.findUnique.mockResolvedValue(existing);

    const result = await createGateJourney(gateInput);

    expect(result.created).toBe(false);
    expect(result.journey.nextStepPosition).toBe(2);
    expect(mockPrisma.subscriberJourney.upsert).not.toHaveBeenCalled();
    expect(mockPrisma.subscriberJourney.update).not.toHaveBeenCalled();
  });

  it("проигранная гонка (строку вставили между чтением и записью) не падает и не считается созданием", async () => {
    // findUnique ничего не нашёл, а к моменту upsert строка уже есть: он
    // возвращает чужую, с более старым gateSentAt.
    mockPrisma.subscriberJourney.upsert.mockResolvedValue(
      journeyRow({
        state: "ACTIVE",
        gateSentAt: new Date("2026-08-09T11:00:00.000Z"),
      })
    );

    const result = await createGateJourney(gateInput);

    expect(result.created).toBe(false);
    expect(result.journey.state).toBe("ACTIVE");
  });
});

describe("chain journey — markJourneySkipped", () => {
  it("пишет SKIPPED с причиной и WARNING в журнал", async () => {
    mockPrisma.subscriberJourney.upsert.mockResolvedValue(
      journeyRow({ state: "SKIPPED", failReason: "цепочка уже идёт" })
    );

    const journey = await markJourneySkipped({
      ...gateInput,
      subscriberId: "commenter_999",
      failReason: "цепочка уже идёт",
    });

    expect(mockPrisma.subscriberJourney.upsert).toHaveBeenCalledWith(
      expect.objectContaining({
        create: expect.objectContaining({
          state: "SKIPPED",
          failReason: "цепочка уже идёт",
          completedAt: NOW,
        }),
        update: expect.objectContaining({
          state: "SKIPPED",
          failReason: "цепочка уже идёт",
        }),
      })
    );
    expect(journey.state).toBe("SKIPPED");
    expect(lastEvent()).toEqual(
      expect.objectContaining({
        level: "WARNING",
        message: expect.stringContaining("цепочка уже идёт"),
      })
    );
  });

  it("живой журней под тем же ключом не затирает", async () => {
    mockPrisma.subscriberJourney.findUnique.mockResolvedValue(
      journeyRow({ state: "ACTIVE", nextStepPosition: 1 })
    );

    const journey = await markJourneySkipped({
      ...gateInput,
      failReason: "цепочка уже идёт",
    });

    expect(mockPrisma.subscriberJourney.upsert).not.toHaveBeenCalled();
    expect(journey.state).toBe("ACTIVE");
    expect(lastEvent()).toEqual(
      expect.objectContaining({ level: "WARNING" })
    );
  });
});

describe("chain journey — TTL неотвеченного GATE", () => {
  it("закрывает GATE_SENT старше 48 часов и возвращает счётчик", async () => {
    mockPrisma.subscriberJourney.updateMany.mockResolvedValue({ count: 3 });

    const count = await expireStaleGates(NOW);

    expect(count).toBe(3);
    expect(mockPrisma.subscriberJourney.updateMany).toHaveBeenCalledWith({
      where: {
        state: "GATE_SENT",
        gateSentAt: { lt: new Date(NOW.getTime() - 48 * 60 * 60 * 1000) },
      },
      data: expect.objectContaining({
        state: "EXPIRED",
        completedAt: NOW,
      }),
    });
    expect(lastEvent()).toEqual(
      expect.objectContaining({
        level: "WARNING",
        message: expect.stringContaining("3"),
      })
    );
  });

  it("48 часов - это ровно два срока окна с запасом, не 24", () => {
    expect(GATE_TTL_MS).toBe(48 * 60 * 60 * 1000);
  });

  it("строку про закрытые GATE пишет на воркспейс установки, а не ничьей", async () => {
    mockPrisma.subscriberJourney.updateMany.mockResolvedValue({ count: 2 });

    await expireStaleGates(NOW);

    // Ничья строка выпадает из любой выборки по установке - остальные строки
    // цепочки идут с воркспейсом, эта обязана идти так же.
    expect(lastEvent()?.workspaceId).toBe("ws_sole");
  });

  it("тихий проход ничего не пишет в журнал и за воркспейсом не ходит", async () => {
    mockPrisma.subscriberJourney.updateMany.mockResolvedValue({ count: 0 });

    await expect(expireStaleGates(NOW)).resolves.toBe(0);
    expect(mockPrisma.operationalEvent.create).not.toHaveBeenCalled();
    expect(mockPrisma.workspace.findFirst).not.toHaveBeenCalled();
  });
});

describe("chain journey — окно переписки", () => {
  it("окно 23.5 часа: 30 минут запаса от 24-часового потолка Meta", () => {
    expect(MESSAGING_WINDOW_MS).toBe(23.5 * 60 * 60 * 1000);
    expect(24 * 60 * 60 * 1000 - MESSAGING_WINDOW_MS).toBe(30 * 60 * 1000);
  });

  it("открыто за минуту до границы и закрыто за минуту после", () => {
    const anchor = new Date(NOW.getTime() - MESSAGING_WINDOW_MS + 60 * 1000);
    expect(isWindowOpen(anchor, NOW)).toBe(true);

    const past = new Date(NOW.getTime() - MESSAGING_WINDOW_MS - 60 * 1000);
    expect(isWindowOpen(past, NOW)).toBe(false);
  });

  it("без ответа человека окно считается закрытым", () => {
    expect(isWindowOpen(null, NOW)).toBe(false);
    expect(isWindowOpen(undefined, NOW)).toBe(false);
  });
});
