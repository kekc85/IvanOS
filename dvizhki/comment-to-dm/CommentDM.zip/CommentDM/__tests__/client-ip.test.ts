import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  getClientIp,
  isTrustedProxyIp,
  resetTrustedProxiesCache,
} from "../lib/net/client-ip";

function headersOf(values: Record<string, string>) {
  const map = new Map(Object.entries(values));
  return { get: (name: string) => map.get(name.toLowerCase()) ?? null };
}

beforeEach(() => {
  resetTrustedProxiesCache();
});

afterEach(() => {
  vi.unstubAllEnvs();
  resetTrustedProxiesCache();
});

describe("isTrustedProxyIp — default allowlist", () => {
  it("trusts loopback and private ranges", () => {
    expect(isTrustedProxyIp("127.0.0.1")).toBe(true);
    expect(isTrustedProxyIp("::1")).toBe(true);
    expect(isTrustedProxyIp("10.0.0.5")).toBe(true);
    expect(isTrustedProxyIp("172.16.4.9")).toBe(true);
    expect(isTrustedProxyIp("192.168.1.50")).toBe(true);
  });

  it("does not trust a public address", () => {
    expect(isTrustedProxyIp("203.0.113.10")).toBe(false);
    expect(isTrustedProxyIp("8.8.8.8")).toBe(false);
    // Just outside the 172.16.0.0/12 range (172.32.0.0/12 and up are public).
    expect(isTrustedProxyIp("172.32.0.1")).toBe(false);
  });
});

describe("getClientIp", () => {
  it("takes the header value directly when it is not a trusted-proxy address", () => {
    const ip = getClientIp(headersOf({ "x-forwarded-for": "203.0.113.10" }));
    expect(ip).toBe("203.0.113.10");
  });

  it("walks past a trusted-proxy hop to find the real client behind it", () => {
    // Caddy (127.0.0.1, in the default allowlist) appended its own observed
    // peer to the right of whatever the client already claimed.
    const ip = getClientIp(
      headersOf({ "x-forwarded-for": "198.51.100.9, 127.0.0.1" })
    );
    expect(ip).toBe("198.51.100.9");
  });

  it("ignores a client-forged leading hop once the real proxy hop is trusted", () => {
    // The attacker sends X-Forwarded-For: 8.8.8.8 to impersonate Google; the
    // proxy on our TRUSTED_PROXIES list appends the address it actually saw
    // in front of the attacker's real one. The old code took index [0] and
    // would have reported "8.8.8.8" — the forged value.
    vi.stubEnv("TRUSTED_PROXIES", "203.0.113.0/24");
    resetTrustedProxiesCache();
    const ip = getClientIp(
      headersOf({ "x-forwarded-for": "8.8.8.8, 198.51.100.9, 203.0.113.55" })
    );
    expect(ip).toBe("198.51.100.9");
  });

  it("falls back to x-real-ip when there is no x-forwarded-for", () => {
    const ip = getClientIp(headersOf({ "x-real-ip": "203.0.113.77" }));
    expect(ip).toBe("203.0.113.77");
  });

  it("returns null when no address header is present at all", () => {
    expect(getClientIp(headersOf({}))).toBeNull();
  });

  it("respects a custom TRUSTED_PROXIES override", () => {
    vi.stubEnv("TRUSTED_PROXIES", "203.0.113.0/24");
    resetTrustedProxiesCache();

    // Now 203.0.113.x is a trusted hop and gets walked past.
    const ip = getClientIp(
      headersOf({ "x-forwarded-for": "198.51.100.20, 203.0.113.5" })
    );
    expect(ip).toBe("198.51.100.20");
  });
});
