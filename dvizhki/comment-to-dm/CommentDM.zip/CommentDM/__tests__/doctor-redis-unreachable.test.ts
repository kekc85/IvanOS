/**
 * The trap named explicitly in this phase's brief: the app's own Redis
 * helper (lib/queue/client.ts) is built with `maxRetriesPerRequest: null` and
 * ioredis's default infinite-backoff reconnect strategy, because BullMQ
 * needs that for blocking commands. Reused as-is inside doctor, a downed
 * Redis would make the command hang forever instead of reporting the
 * problem. doctor uses its own bounded connection instead (redis-client.ts) —
 * proven here against a real closed port, so this is an actual connection
 * attempt failing fast, not a mocked-away assumption.
 */
import { describe, expect, it } from "vitest";
import { withDoctorRedis, REDIS_CONNECT_TIMEOUT_MS } from "../lib/doctor/redis-client";
import { checkRedisAndQueue } from "../lib/doctor/checks/redis";

// Nothing listens on this port — a fast, deterministic "connection refused"
// stand-in for a stopped Redis service.
const UNREACHABLE_REDIS_URL = "redis://127.0.0.1:1";

describe("withDoctorRedis against an unreachable Redis", () => {
  it("resolves to null well inside the bound instead of hanging", async () => {
    const startedAt = Date.now();

    const result = await withDoctorRedis(UNREACHABLE_REDIS_URL, async (client) => {
      return client.ping();
    });

    const elapsedMs = Date.now() - startedAt;

    expect(result).toBeNull();
    // Generous margin over the connect timeout itself — this only fails if
    // something is actually retrying/hanging, not on ordinary scheduling jitter.
    expect(elapsedMs).toBeLessThan(REDIS_CONNECT_TIMEOUT_MS + 3000);
  }, 10_000);
});

describe("checkRedisAndQueue against an unreachable Redis", () => {
  it("reports E-06 instead of hanging the doctor run", async () => {
    const findings = await checkRedisAndQueue(UNREACHABLE_REDIS_URL);

    expect(findings).toHaveLength(1);
    expect(findings[0]).toMatchObject({ level: "error", code: "E-06" });
    expect(findings[0].command).toBeTruthy();
  }, 10_000);
});
