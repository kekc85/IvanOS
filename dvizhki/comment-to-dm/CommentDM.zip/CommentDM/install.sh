#!/usr/bin/env bash
#
# commentdm — установка на чистый Ubuntu VPS одной командой.
#
# Использование:
#   sudo bash install.sh <домен> [--owner-password=...] [--owner-email=...] [--skip-dns-check]
#
# Переезд на новый сервер (фаза 14, см. npm run export-secrets на старом):
#   sudo bash install.sh <домен> --restore --encryption-key=... [--session-secret=...]
#
# Что делает (по шагам, каждый описан в шапке своей функции ниже):
#   1. Пять предпроверок — ничего не меняет в системе, пока все не пройдены
#      (кроме файла подкачки при нехватке памяти — это часть самой проверки).
#   2. Ставит Node.js 20+, PostgreSQL, Redis, Caddy.
#   3. Идемпотентно создаёт базу и пользователя Postgres.
#   4. Пишет .env: существующие секреты сохраняет, генерирует только
#      отсутствующие. Повторный запуск НЕ меняет ENCRYPTION_KEY — иначе все
#      подключённые аккаунты Instagram отвалятся молча.
#   5. npm ci, сборка с ограничением памяти под маленький VPS, миграция БД.
#   6. Ставит systemd-юниты из deploy/ (приложение + воркер + суточный дамп).
#   7. Настраивает Caddy на домен (HTTPS выпускается и продлевается сам).
#   8. Закрывает файрволом всё, кроме 22/80/443 — порт приложения (3000)
#      обязательно недоступен снаружи.
#   9. Запускает всё, в конце гонит npm run doctor и печатает пароль владельца.
#
# Каждый шаг пишется в лог: /var/log/commentdm-install.log
# Повторный запуск безопасен: каждый шаг идемпотентен.

set -euo pipefail

# ==============================================================================
# РЕПОЗИТОРИЙ, ОТКУДА СКАЧИВАЕТСЯ КОД.
# ПЛЕЙСХОЛДЕР — заменяется на реальный публичный адрес в фазе 18 (публикация
# репозитория). Это единственная строка, которую нужно поправить при публикации.
# ==============================================================================
# 🔴 ПЕРЕД РАЗДАЧЕЙ: подставь сюда адрес своего репозитория вместо OWNER.
# Без этого установщик остановится на предпроверке и скажет, что делать.
REPO_URL="https://github.com/theivansergeev/commentdm.git"

APP_USER="commentdm"
DEFAULT_INSTALL_DIR="/opt/commentdm"
DB_NAME="commentdm"
DB_USER="commentdm"
LOG_FILE="/var/log/commentdm-install.log"
NODE_MAJOR=20
MIN_MEM_MB=2048
SWAP_FILE="/swapfile-commentdm"
SWAP_SIZE_MB=2048

DOMAIN=""
OWNER_PASSWORD_ARG=""
OWNER_EMAIL_ARG=""
SKIP_DNS_CHECK=0
OWNER_PASSWORD_NEW=0
INSTALL_DIR=""
ENV_FILE=""
DATABASE_URL=""
NODE_MAX_OLD_SPACE_MB=1536
# Итог npm run doctor на последнем шаге — влияет только на текст баннера.
DOCTOR_OK=1

# --restore: install onto a NEW server as the second half of a machine
# migration (phase 14). See scripts/export-secrets.ts on the OLD server for
# the exact recipe this pairs with — it prints ENCRYPTION_KEY_ARG and
# SESSION_SECRET_ARG below ready to paste.
RESTORE_MODE=0
ENCRYPTION_KEY_ARG=""
SESSION_SECRET_ARG=""

# ---------------------------------------------------------------------------
# Вывод
# ---------------------------------------------------------------------------
c_bold=$'\033[1m'
c_reset=$'\033[0m'

info()  { printf '%s\n' "$*"; }
ok()    { printf '✅ %s\n' "$*"; }
warn()  { printf '⚠️  %s\n' "$*"; }
err()   { printf '❌ %s\n' "$*" >&2; }
step()  { printf '\n%s==> %s%s\n' "$c_bold" "$*" "$c_reset"; }

# Every deliberate exit goes through this, not a bare `exit`. Without it the
# ERR trap below fires a second, confusing "unexpected error" message right
# after a clear one — `exit N` still counts as the command that made the
# (sub)shell's last status non-zero, so ERR sees it too.
clean_exit() {
  trap - ERR
  exit "${1:-1}"
}

# fail: понятное сообщение + выход, а не падение посреди установки.
fail() {
  err "$1"
  if [ -n "${2:-}" ]; then
    printf '   %s\n' "$2"
  fi
  clean_exit 1
}

on_unexpected_error() {
  local line="$1"
  err "Установка прервалась на строке $line (неожиданная ошибка команды)."
  info "   Полный лог: $LOG_FILE"
  info "   Все шаги идемпотентны — почините проблему и запустите install.sh ещё раз."
  clean_exit 1
}
trap 'on_unexpected_error $LINENO' ERR

# ---------------------------------------------------------------------------
# Файлы: владелец, режим, атомарная запись. Копия того же в deploy/lib.sh —
# install.sh не может подключить lib.sh, он обязан работать одним файлом до
# того, как репозиторий вообще появится на диске (см. resolve_install_dir).
# ---------------------------------------------------------------------------
file_mode() {
  stat -c '%a' "$1" 2>/dev/null || stat -f '%OLp' "$1" 2>/dev/null || true
}

file_owner() {
  stat -c '%u:%g' "$1" 2>/dev/null || stat -f '%u:%g' "$1" 2>/dev/null || true
}

# copy_file_identity <источник> <цель> — переносит владельца и режим. Нужен
# везде, где файл переписывается приёмом «временный файл рядом + mv»:
# mktemp создаёт файл от root с режимом 0600, и без этой строки владелец и
# режим временного файла переезжают на цель.
copy_file_identity() {
  local src="$1" dst="$2" mode owner
  mode="$(file_mode "$src")"
  owner="$(file_owner "$src")"
  if [ -n "$mode" ]; then
    chmod "$mode" "$dst" 2>/dev/null || true
  fi
  if [ -n "$owner" ]; then
    chown "$owner" "$dst" 2>/dev/null || true
  fi
}

# render_template <шаблон> <цель> <аргументы sed...> — подстановка
# плейсхолдеров с записью через временный файл рядом с целью и переносом на
# место одним mv. Прямое `sed ... > цель` обнуляет цель ДО записи: обрыв
# ровно на этом месте оставляет пустой systemd-юнит или пустой конфиг Caddy.
render_template() {
  local src="$1" dest="$2" tmp
  shift 2
  tmp="$(mktemp "${dest}.XXXXXX")"
  if ! sed "$@" "$src" > "$tmp"; then
    rm -f "$tmp"
    err "Не удалось подготовить $dest из шаблона $src"
    return 1
  fi
  if [ -e "$dest" ]; then
    copy_file_identity "$dest" "$tmp"
  else
    chmod 644 "$tmp"
  fi
  mv "$tmp" "$dest"
}

# ---------------------------------------------------------------------------
# Домен. Строка с командной строки уезжает и в APP_URL, и в sed-подстановку
# Caddyfile: символ | ломает саму подстановку, а схема https:// в аргументе
# давала APP_URL=https://https://bot.example.com. Копия того же в
# deploy/lib.sh — по той же причине, что и всё остальное дублирование здесь.
# ---------------------------------------------------------------------------
normalize_domain() {
  local d="$1"
  d="${d#http://}"
  d="${d#https://}"
  d="${d%%/*}"
  d="${d%.}"
  printf '%s' "$d" | tr '[:upper:]' '[:lower:]'
}

validate_domain() {
  local d="$1"
  [ -n "$d" ] || return 1
  [ "${#d}" -le 253 ] || return 1
  printf '%s' "$d" \
    | grep -qE '^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$'
}

usage() {
  cat <<'USAGE'
Использование: sudo bash install.sh <домен> [опции]

  <домен>                    Домен или поддомен, A-запись которого уже
                              указывает на IP этого сервера. Обязателен.

Опции:
  --owner-password=ПАРОЛЬ    Задать пароль владельца вручную вместо
                              случайной генерации (минимум 8 символов).
  --owner-email=EMAIL        Email для входа (по умолчанию owner@localhost,
                              никуда не отправляется, это просто логин).
  --skip-dns-check            Пропустить проверку A-записи. HTTPS всё равно
                              не выпустится, пока Caddy не сможет
                              достучаться до этого домена по 80/443.
  --restore                   Переезд на новый сервер (фаза 14), а не
                              установка с нуля: требует --encryption-key,
                              и НЕ генерирует случайный пароль владельца —
                              оставляет OWNER_PASSWORD пустым, чтобы после
                              восстановления дампа базы сработал прежний
                              пароль (его хеш приезжает вместе с дампом).
                              См. npm run export-secrets на старом сервере.
  --encryption-key=КЛЮЧ        Использовать этот ENCRYPTION_KEY вместо
                              случайной генерации. Обязателен вместе с
                              --restore — без него расшифровка токенов
                              Instagram из перенесённого дампа молча не
                              сработает.
  --session-secret=СЕКРЕТ      Использовать этот SESSION_SECRET вместо
                              случайной генерации (необязателен даже с
                              --restore — без него просто придётся один раз
                              заново войти после переезда).
  -h, --help                  Показать эту справку.

Пример:
  sudo bash install.sh bot.example.com

Пример переезда на новый сервер (см. npm run export-secrets на старом):
  sudo bash install.sh bot.example.com --restore \
    --encryption-key=<64 hex-символа со старого сервера> \
    --session-secret=<секрет со старого сервера>
USAGE
}

# ---------------------------------------------------------------------------
# Аргументы
# ---------------------------------------------------------------------------
parse_args() {
  while [ $# -gt 0 ]; do
    case "$1" in
      --owner-password=*) OWNER_PASSWORD_ARG="${1#*=}" ;;
      --owner-email=*) OWNER_EMAIL_ARG="${1#*=}" ;;
      --skip-dns-check) SKIP_DNS_CHECK=1 ;;
      --restore) RESTORE_MODE=1 ;;
      --encryption-key=*) ENCRYPTION_KEY_ARG="${1#*=}" ;;
      --session-secret=*) SESSION_SECRET_ARG="${1#*=}" ;;
      -h|--help) usage; clean_exit 0 ;;
      -*)
        err "Неизвестный флаг: $1"
        usage
        clean_exit 1
        ;;
      *)
        if [ -z "$DOMAIN" ]; then
          DOMAIN="$1"
        else
          err "Лишний аргумент: $1"
          usage
          clean_exit 1
        fi
        ;;
    esac
    shift
  done

  if [ -n "$OWNER_PASSWORD_ARG" ] && [ "${#OWNER_PASSWORD_ARG}" -lt 8 ]; then
    fail "Пароль из --owner-password короче 8 символов." "Приложение всё равно откажется его принять при первом входе — выберите длиннее."
  fi

  if [ "$RESTORE_MODE" -eq 1 ] && [ -z "$ENCRYPTION_KEY_ARG" ]; then
    fail "--restore требует --encryption-key=..." "Без ключа со старого сервера расшифровка токенов подключённых Instagram-аккаунтов из перенесённого дампа молча не сработает. Возьми его командой npm run export-secrets на старом сервере."
  fi

  if [ -n "$ENCRYPTION_KEY_ARG" ] && ! printf '%s' "$ENCRYPTION_KEY_ARG" | grep -qE '^[a-f0-9]{64}$'; then
    fail "--encryption-key должен быть 32-байтным hex-значением (64 символа 0-9a-f)." "Скопируй его как есть из вывода npm run export-secrets, ничего не меняя."
  fi

  # Домен приводим к голому имени хоста и проверяем ЗДЕСЬ, до того как он
  # уедет в APP_URL и в sed-подстановку Caddyfile: `install.sh
  # https://bot.example.com` иначе давал APP_URL=https://https://bot.example.com,
  # а символ | в аргументе ломал саму подстановку.
  if [ -n "$DOMAIN" ]; then
    local normalized
    normalized="$(normalize_domain "$DOMAIN")"
    if [ "$normalized" != "$DOMAIN" ]; then
      info "   Домен приведён к виду: $normalized (было: $DOMAIN)"
      DOMAIN="$normalized"
    fi
    if ! validate_domain "$DOMAIN"; then
      fail "«${DOMAIN}» не похоже на доменное имя." "Нужен домен или поддомен вида bot.example.com — латиница, цифры и дефисы, минимум одна точка, без порта, пробелов и спецсимволов. Пример: sudo bash install.sh bot.example.com"
    fi
  fi
}

# ---------------------------------------------------------------------------
# Права root и лог. Root проверяется до всего остального, потому что без
# него нет смысла что-либо ещё проверять или выводить.
# ---------------------------------------------------------------------------
require_root() {
  if [ "$(id -u)" -ne 0 ]; then
    err "Нужны права root."
    printf '   Запустите команду через sudo:\n\n'
    printf '     sudo bash install.sh %s\n\n' "${DOMAIN:-<домен>}"
    clean_exit 1
  fi
}

setup_logging() {
  mkdir -p "$(dirname "$LOG_FILE")"
  touch "$LOG_FILE"
  chmod 640 "$LOG_FILE"
  # С этой строки весь вывод (и preflight-проверки, и сама установка) идёт
  # одновременно на экран и в файл — «лог каждого шага» без ручных log()
  # вызовов на каждой строке.
  exec > >(tee -a "$LOG_FILE") 2>&1
  info "Лог установки: $LOG_FILE"
  ok "Запущено от root"
}

# ---------------------------------------------------------------------------
# Предпроверка 2: Ubuntu поддерживаемой версии, архитектура x86_64/arm64.
# ---------------------------------------------------------------------------
check_repo_url() {
  case "$REPO_URL" in
    *"/OWNER/"*)
      fail "Адрес репозитория не подставлен.\n" \
           "  В install.sh строка REPO_URL всё ещё содержит заглушку OWNER.\n" \
           "  Замени её на адрес своего репозитория и запусти установку снова."
      ;;
  esac
}

check_os() {
  if [ ! -f /etc/os-release ]; then
    fail "Не удалось определить дистрибутив (нет /etc/os-release)." "Этот установщик поддерживает только Ubuntu."
  fi
  # shellcheck disable=SC1091
  . /etc/os-release

  if [ "${ID:-}" != "ubuntu" ]; then
    fail "Обнаружен дистрибутив «${PRETTY_NAME:-неизвестный}», а не Ubuntu." "Этот установщик поддерживает только Ubuntu 20.04 и новее."
  fi

  local major minor
  major="${VERSION_ID%%.*}"
  minor="${VERSION_ID##*.}"
  if [ "$major" -lt 20 ] || { [ "$major" -eq 20 ] && [ "$minor" -lt 4 ]; }; then
    fail "Обнаружен Ubuntu ${VERSION_ID}." "Нужна версия 20.04 или новее (рекомендуется 22.04 / 24.04)."
  fi
  ok "Ubuntu ${VERSION_ID} — поддерживается"

  local arch
  arch="$(uname -m)"
  case "$arch" in
    x86_64|aarch64) ok "Архитектура ${arch} — поддерживается" ;;
    *) fail "Архитектура «${arch}» не поддерживается." "Нужен x86_64 или arm64 (aarch64)." ;;
  esac
}

# ---------------------------------------------------------------------------
# Предпроверка 3: минимум 2 ГБ памяти, иначе файл подкачки.
# Это единственная предпроверка, которая при необходимости меняет систему —
# создание swap и есть её «провал → чинит сам», а не «провал → выход».
# Блокер из pre-mortem: next build на Next 16 + React-компиляторе падает по
# памяти примерно у половины дешёвых VPS без подкачки.
# ---------------------------------------------------------------------------
check_memory_and_swap() {
  local mem_kb mem_mb
  mem_kb="$(awk '/^MemTotal:/ {print $2}' /proc/meminfo)"
  mem_mb=$(( mem_kb / 1024 ))

  if [ "$mem_mb" -ge "$MIN_MEM_MB" ]; then
    ok "Память: ${mem_mb} МБ — достаточно"
    return
  fi

  warn "Память: ${mem_mb} МБ, меньше рекомендованных ${MIN_MEM_MB} МБ"

  if swapon --show=NAME --noheadings 2>/dev/null | grep -q .; then
    ok "Подкачка уже включена — файл подкачки не создаю"
    return
  fi

  info "   Создаю файл подкачки ${SWAP_SIZE_MB} МБ ($SWAP_FILE), иначе сборка next build скорее всего упадёт по памяти"
  # Файл собирается под временным именем и переносится на место готовым:
  # оборванный прошлый запуск иначе оставлял бы файл нужного имени, но
  # недописанный, и следующий запуск считал бы его готовым.
  if [ ! -f "$SWAP_FILE" ]; then
    rm -f "${SWAP_FILE}.partial"
    fallocate -l "${SWAP_SIZE_MB}M" "${SWAP_FILE}.partial" 2>/dev/null \
      || dd if=/dev/zero of="${SWAP_FILE}.partial" bs=1M count="$SWAP_SIZE_MB" status=none
    chmod 600 "${SWAP_FILE}.partial"
    mv "${SWAP_FILE}.partial" "$SWAP_FILE"
  fi
  chmod 600 "$SWAP_FILE"
  # mkswap каждый раз, а не только вместе с созданием файла: раньше mkswap
  # стоял ВНУТРИ условия, а swapon — снаружи, и обрыв между ними делал
  # установщик неперезапускаемым (файл есть, разметки нет, swapon падает).
  # Сюда мы попадаем только когда никакой подкачки в системе не включено,
  # так что переразметка ничего не ломает.
  mkswap "$SWAP_FILE" >/dev/null
  swapon "$SWAP_FILE"
  if ! grep -q "^${SWAP_FILE} " /etc/fstab 2>/dev/null; then
    echo "${SWAP_FILE} none swap sw 0 0" >> /etc/fstab
  fi
  ok "Подкачка включена: ${SWAP_SIZE_MB} МБ, переживёт перезагрузку (записано в /etc/fstab)"
}

# ---------------------------------------------------------------------------
# Предпроверка 4: порты 80 и 443 свободны (провайдеры иногда ставят панель
# заранее). Пропускается на повторном запуске, где 80/443 уже держит НАШ
# Caddy — иначе установщик никогда не проходил бы переустановку.
# ---------------------------------------------------------------------------
check_ports_free() {
  local holder=""
  if systemctl list-unit-files 2>/dev/null | grep -q '^commentdm\.service'; then
    ok "commentdm уже установлен на этой машине — проверка портов 80/443 пропущена (их держит наш же Caddy)"
    return
  fi

  local port
  for port in 80 443; do
    # Кто именно держит порт. Свой Caddy - это не конфликт, а наша же
    # предыдущая установка: ругаться на неё значит запретить переустановку.
    if command -v ss >/dev/null 2>&1; then
      holder="$(ss -Htlnp "( sport = :${port} )" 2>/dev/null | grep -oE 'users:\(\("[^"]+' | sed 's/.*"//' | head -1 || true)"
      case "$holder" in
        caddy) ok "Порт ${port} держит наш Caddy от прошлой установки - это не конфликт"; continue ;;
      esac
    fi
    if command -v ss >/dev/null 2>&1 && ss -Htln "( sport = :${port} )" 2>/dev/null | grep -q .; then
      fail "Порт ${port} уже занят." "У провайдера бывает предустановлена панель (Apache/Nginx/что-то ещё). Посмотрите, что слушает порт: ss -tlnp | grep :${port} — остановите или удалите это, и запустите установщик заново."
    fi
  done
  ok "Порты 80 и 443 свободны"
}

# ---------------------------------------------------------------------------
# Предпроверка 5: домен указан и его A-запись ведёт на IP этой машины.
# curl — единственное исключение из «ничего не меняем до предпроверок»:
# он почти всегда уже стоит на облачном образе Ubuntu, но если нет, без него
# саму эту проверку выполнить нечем.
# ---------------------------------------------------------------------------
ensure_curl_for_dns_check() {
  if command -v curl >/dev/null 2>&1; then
    return
  fi
  warn "curl не найден — ставлю только его, он нужен, чтобы вообще проверить DNS"
  apt-get update -qq
  apt-get install -y -qq curl
}

get_public_ip() {
  curl -fsS4 --max-time 5 https://api.ipify.org 2>/dev/null \
    || curl -fsS4 --max-time 5 https://ifconfig.me 2>/dev/null \
    || true
}

resolve_domain_ips() {
  local domain="$1" json
  json="$(curl -fsS --max-time 5 "https://dns.google/resolve?name=${domain}&type=A" 2>/dev/null || true)"
  if [ -n "$json" ]; then
    # `|| true`: a domain with no A record makes both greps find nothing,
    # which under pipefail fails this whole pipeline — that is this
    # function's last command, called from a `var="$(resolve_domain_ips …)"`
    # assignment, so a non-zero exit here would trip the caller's set -e
    # instead of just yielding an empty (and valid) result.
    printf '%s' "$json" \
      | grep -oE '"data":"[0-9]{1,3}(\.[0-9]{1,3}){3}"' \
      | grep -oE '[0-9]{1,3}(\.[0-9]{1,3}){3}' \
      || true
    return
  fi
  # DNS-over-HTTPS could not be reached (e.g. outbound to Google blocked) —
  # fall back to whatever this box's own resolver says. Same `|| true`
  # reasoning as above.
  getent ahosts "$domain" 2>/dev/null \
    | awk '{print $1}' \
    | grep -E '^[0-9]{1,3}(\.[0-9]{1,3}){3}$' \
    | sort -u \
    || true
}

check_domain_and_dns() {
  if [ -z "$DOMAIN" ]; then
    err "Домен не указан."
    usage
    clean_exit 1
  fi

  if [ "$SKIP_DNS_CHECK" -eq 1 ]; then
    warn "Проверка DNS пропущена (--skip-dns-check). Если A-запись не указывает сюда, HTTPS-сертификат не выпустится."
    return
  fi

  ensure_curl_for_dns_check

  local server_ip resolved
  server_ip="$(get_public_ip)"
  if [ -z "$server_ip" ]; then
    fail "Не удалось определить публичный IP этого сервера." "Проверьте исходящий доступ в интернет, или запустите с --skip-dns-check, если уверены в DNS."
  fi

  resolved="$(resolve_domain_ips "$DOMAIN")"
  if [ -z "$resolved" ]; then
    fail "Домен ${DOMAIN} не резолвится ни в один IP-адрес." "Сертификат HTTPS не выпустится, пока A-запись не появится и не распространится (обычно от нескольких минут до пары часов). Добавьте A-запись ${DOMAIN} → ${server_ip} у регистратора/хостинга и запустите установщик заново."
  fi

  if printf '%s\n' "$resolved" | grep -qx "$server_ip"; then
    ok "DNS: ${DOMAIN} → ${server_ip} — совпадает с этим сервером"
  else
    err "DNS: ${DOMAIN} указывает на $(printf '%s' "$resolved" | tr '\n' ' ' | sed 's/ *$//'), а не на этот сервер (${server_ip})."
    info "   Сертификат HTTPS не выпустится, пока A-запись не будет указывать сюда."
    info "   Поправьте A-запись у регистратора/хостинга на ${server_ip} и запустите установщик заново."
    info "   (Если точно знаете, что делаете — например, Caddy стоит за другим прокси — повторите запуск с --skip-dns-check.)"
    clean_exit 1
  fi
}

run_preflight_checks() {
  step "Предпроверки"
  check_repo_url
  check_os
  check_memory_and_swap
  check_ports_free
  check_domain_and_dns
  ok "Все предпроверки пройдены — начинаю установку"
}

# ---------------------------------------------------------------------------
# Код: если install.sh уже лежит внутри клонированного репозитория —
# используем эту директорию как есть. Если это одиночный файл (например,
# скачанный отдельно и запущенный первым) — клонируем REPO_URL в
# /opt/commentdm. Оба сценария в итоге приводят к одному и тому же
# состоянию: полный репозиторий на диске, install.sh продолжает уже оттуда.
# ---------------------------------------------------------------------------
resolve_install_dir() {
  local self script_dir
  self="${BASH_SOURCE[0]:-}"
  script_dir=""
  if [ -n "$self" ] && [ -f "$self" ]; then
    script_dir="$(cd "$(dirname "$self")" >/dev/null 2>&1 && pwd)"
  fi

  if [ -n "$script_dir" ] && [ -f "$script_dir/package.json" ] \
    && grep -q '"name": *"commentdm"' "$script_dir/package.json" 2>/dev/null; then
    case "$script_dir" in
      /tmp/*|/var/tmp/*|/private/tmp/*)
        fail "Нельзя ставить из временной папки: $script_dir\n" \
             "  Службы запускаются с изоляцией временного каталога (PrivateTmp)\n" \
             "  и файлы из /tmp не увидят. Приложение будет бесконечно\n" \
             "  перезапускаться с ошибкой NAMESPACE.\n" \
             "  Перенесите папку и запустите оттуда:\n" \
             "    sudo mv \"$script_dir\" /opt/commentdm && cd /opt/commentdm && sudo bash install.sh <домен>"
        ;;
    esac
    INSTALL_DIR="$script_dir"
    ok "Запущено внутри уже склонированного репозитория: $INSTALL_DIR"
    return
  fi

  INSTALL_DIR="$DEFAULT_INSTALL_DIR"
  step "Скачиваю код в $INSTALL_DIR"
  if [ -d "$INSTALL_DIR/.git" ]; then
    info "   $INSTALL_DIR уже существует, обновляю (git pull)"
    git -C "$INSTALL_DIR" pull --ff-only
  else
    mkdir -p "$(dirname "$INSTALL_DIR")"
    git clone --depth 1 "$REPO_URL" "$INSTALL_DIR"
  fi
  ok "Код в $INSTALL_DIR"
}

# ---------------------------------------------------------------------------
# Пакеты
# ---------------------------------------------------------------------------
install_base_packages() {
  step "Обновляю списки пакетов и ставлю базовые утилиты"
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq
  apt-get install -y -qq \
    ca-certificates curl gnupg git ufw lsof build-essential
  ok "Базовые пакеты установлены"
}

install_node() {
  step "Ставлю Node.js ${NODE_MAJOR}.x (NodeSource, не из apt Ubuntu — тот слишком старый для Next 16)"
  if command -v node >/dev/null 2>&1 \
    && [ "$(node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)" -ge "$NODE_MAJOR" ]; then
    ok "Node уже установлен: $(node -v)"
    return
  fi
  curl -fsSL "https://deb.nodesource.com/setup_${NODE_MAJOR}.x" | bash - >/dev/null
  apt-get install -y -qq nodejs
  ok "Node установлен: $(node -v), npm $(npm -v)"
}

install_postgres() {
  step "Ставлю PostgreSQL"
  apt-get install -y -qq postgresql postgresql-contrib
  systemctl enable --now postgresql >/dev/null
  ok "PostgreSQL запущен"
}

install_redis() {
  step "Ставлю Redis"
  apt-get install -y -qq redis-server
  systemctl enable --now redis-server >/dev/null
  ok "Redis запущен"
}

install_caddy() {
  step "Ставлю Caddy (автоматический HTTPS)"
  if ! command -v caddy >/dev/null 2>&1; then
    apt-get install -y -qq debian-keyring debian-archive-keyring apt-transport-https
    # --yes: без него gpg на повторном запуске (ключ уже лежит на месте)
    # спрашивает «перезаписать?» и установщик молча висит на этом вопросе.
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' \
      | gpg --dearmor --yes -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
    # Скачиваем во временный файл и переносим на место: оборванная закачка
    # прямо в sources.list.d оставляет обрезанный список репозиториев, на
    # котором падает уже apt-get update.
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' \
      -o /etc/apt/sources.list.d/caddy-stable.list.partial
    chmod 644 /etc/apt/sources.list.d/caddy-stable.list.partial
    mv /etc/apt/sources.list.d/caddy-stable.list.partial \
      /etc/apt/sources.list.d/caddy-stable.list
    apt-get update -qq
    apt-get install -y -qq caddy
  fi
  ok "Caddy установлен: $(caddy version | head -1)"
}

# ---------------------------------------------------------------------------
# Системный пользователь для запуска приложения (не root).
# ---------------------------------------------------------------------------
create_app_user() {
  step "Создаю системного пользователя $APP_USER"
  if id -u "$APP_USER" >/dev/null 2>&1; then
    ok "Пользователь $APP_USER уже существует"
  else
    useradd --system --home-dir "$INSTALL_DIR" --shell /usr/sbin/nologin "$APP_USER"
    ok "Пользователь $APP_USER создан"
  fi
}

# ---------------------------------------------------------------------------
# База данных — идемпотентно. Повторный запуск не падает на «уже
# существует» и не меняет пароль роли на новый, если он уже был записан.
# ---------------------------------------------------------------------------
# parse_db_password_from_url <url> — пароль из postgresql://user:pass@host/db
# или пустая строка, если строка не такого вида.
#
# Прежний разбор был `sed -E 's|^DATABASE_URL=postgresql://[^:]+:([^@]+)@.*|\1|'`,
# а sed при НЕсовпадении печатает строку целиком: кавычки вокруг значения
# или @ внутри пароля — и «паролем» становилась вся строка. Здесь совпадение
# либо есть, либо результат пустой. `%` вместо `%%` при отрезании хвоста —
# чтобы @ внутри самого пароля не обрубал его на первом же символе.
parse_db_password_from_url() {
  local url="$1" rest creds
  case "$url" in
    postgresql://*|postgres://*) ;;
    *) return 0 ;;
  esac
  rest="${url#*://}"
  case "$rest" in
    *@*) ;;
    *) return 0 ;;
  esac
  creds="${rest%@*}"
  case "$creds" in
    *:*) ;;
    *) return 0 ;;
  esac
  printf '%s' "${creds#*:}"
}

# sql_quote_literal <строка> — строковый литерал SQL с удвоенными
# одинарными кавычками. Без него кавычка внутри пароля закрывала литерал в
# ALTER ROLE, и остаток строки исполнялся от суперпользователя Postgres.
sql_quote_literal() {
  local s="$1"
  s="${s//\'/\'\'}"
  printf "'%s'" "$s"
}

# psql_as_postgres_stdin — SQL приходит на stdin, а не аргументом -c.
# Аргументы командной строки видны в `ps aux` любому пользователю системы,
# а здесь в SQL едет пароль роли базы.
psql_as_postgres_stdin() {
  sudo -u postgres psql -v ON_ERROR_STOP=1 -q >/dev/null
}

setup_database() {
  step "Настраиваю базу данных Postgres"

  local db_password="" existing_url=""
  if [ -f "$ENV_FILE" ]; then
    existing_url="$(env_get DATABASE_URL)"
  fi
  if [ -n "$existing_url" ]; then
    db_password="$(parse_db_password_from_url "$existing_url")"
    if [ -z "$db_password" ]; then
      # Сгенерировать новый пароль здесь нельзя: env_set_if_absent не станет
      # переписывать уже существующий DATABASE_URL, роль получит новый
      # пароль, а .env останется со старым — приложение просто перестанет
      # подключаться к базе. Лучше честно остановиться.
      fail "В $ENV_FILE есть DATABASE_URL, но пароль из него не читается." \
        "Ожидается вид postgresql://пользователь:пароль@localhost:5432/база. Поправьте строку (спецсимволы в пароле должны быть в percent-кодировке) и запустите установщик заново."
    fi
  else
    db_password="$(openssl rand -hex 24)"
  fi

  local role_exists db_exists
  role_exists="$(sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='${DB_USER}'")"
  if [ "$role_exists" = "1" ]; then
    info "   Роль $DB_USER уже существует, пароль в базе синхронизирован с .env"
    printf 'ALTER ROLE %s WITH PASSWORD %s;\n' \
      "\"${DB_USER}\"" "$(sql_quote_literal "$db_password")" | psql_as_postgres_stdin
  else
    printf 'CREATE ROLE %s WITH LOGIN PASSWORD %s;\n' \
      "\"${DB_USER}\"" "$(sql_quote_literal "$db_password")" | psql_as_postgres_stdin
    ok "Роль $DB_USER создана"
  fi

  db_exists="$(sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'")"
  if [ "$db_exists" = "1" ]; then
    ok "База $DB_NAME уже существует"
  else
    sudo -u postgres psql -c "CREATE DATABASE ${DB_NAME} OWNER ${DB_USER};" >/dev/null
    ok "База $DB_NAME создана"
  fi

  DATABASE_URL="postgresql://${DB_USER}:${db_password}@localhost:5432/${DB_NAME}"
}

# ---------------------------------------------------------------------------
# .env — секреты генерируются локально через openssl rand. Значения, уже
# записанные в файле, никогда не перезаписываются: это единственное, что
# защищает ENCRYPTION_KEY (и вместе с ним все подключённые Instagram-аккаунты)
# от молчаливой поломки при повторном запуске.
# ---------------------------------------------------------------------------
# И `node --env-file`, и systemd EnvironmentFile принимают строку с ведущими
# пробелами, с префиксом `export ` и со значением в кавычках. Разбор «строка
# начинается ровно с KEY=» этого не видел: ученик (или его Claude Code) один
# раз переформатировал .env с отступом, повторный install.sh ключа не
# находил и дописывал ВТОРУЮ строку с новым случайным значением, а
# выигрывает последняя. Для ENCRYPTION_KEY это молчаливая потеря всех
# подключённых аккаунтов Instagram, для DATABASE_URL / SESSION_SECRET /
# OWNER_PASSWORD — потеря доступа. Поэтому чтение и запись понимают все три
# формы, а запись НИКОГДА не дописывает вторую строку к уже имеющемуся ключу.
env_get() {
  local key="$1" raw first last
  raw="$(COMMENTDM_ENV_KEY="$key" awk '
    BEGIN { key = ENVIRON["COMMENTDM_ENV_KEY"] }
    {
      line = $0
      sub(/^[ \t]+/, "", line)
      sub(/^export[ \t]+/, "", line)
      eq = index(line, "=")
      if (eq == 0) next
      name = substr(line, 1, eq - 1)
      sub(/[ \t]+$/, "", name)
      if (name != key) next
      value = substr(line, eq + 1)
      sub(/^[ \t]+/, "", value)
      sub(/[ \t\r]+$/, "", value)
      print value
      exit
    }
  ' "$ENV_FILE" 2>/dev/null || true)"

  if [ "${#raw}" -ge 2 ]; then
    first="${raw:0:1}"
    last="${raw: -1}"
    if { [ "$first" = '"' ] && [ "$last" = '"' ]; } \
      || { [ "$first" = "'" ] && [ "$last" = "'" ]; }; then
      raw="${raw:1:${#raw}-2}"
    fi
  fi
  printf '%s' "$raw"
}

# Единственная точка записи в .env: правит существующую строку ключа (в
# любой из принимаемых форм), схлопывает дубли и восстанавливает владельца и
# режим файла прямо здесь, внутри записи.
env_write_key() {
  local key="$1" value="$2" tmp
  if [ ! -e "$ENV_FILE" ]; then
    : > "$ENV_FILE"
    chmod 600 "$ENV_FILE" 2>/dev/null || true
  fi
  tmp="$(mktemp "${ENV_FILE}.XXXXXX")"
  if ! COMMENTDM_ENV_KEY="$key" COMMENTDM_ENV_VALUE="$value" awk '
    BEGIN {
      key = ENVIRON["COMMENTDM_ENV_KEY"]
      value = ENVIRON["COMMENTDM_ENV_VALUE"]
      done = 0
    }
    {
      line = $0
      sub(/^[ \t]+/, "", line)
      sub(/^export[ \t]+/, "", line)
      eq = index(line, "=")
      name = ""
      if (eq > 0) {
        name = substr(line, 1, eq - 1)
        sub(/[ \t]+$/, "", name)
      }
      if (eq > 0 && name == key) {
        if (done == 0) { print key "=" value; done = 1 }
        next
      }
      print $0
    }
    END { if (done == 0) print key "=" value }
  ' "$ENV_FILE" > "$tmp"; then
    rm -f "$tmp"
    fail "Не удалось переписать $ENV_FILE (ключ $key)." "Файл не тронут — проверьте место на диске и права."
  fi
  copy_file_identity "$ENV_FILE" "$tmp"
  mv "$tmp" "$ENV_FILE"
}

# Заполняет ключ, только если его ещё нет или он пуст. Уже заданное
# значение не трогает — вот и вся идемпотентность секретов.
env_set_if_absent() {
  local key="$1" value="$2"
  if [ -n "$(env_get "$key")" ]; then
    return 0
  fi
  env_write_key "$key" "$value"
}

write_env() {
  step "Пишу .env"
  touch "$ENV_FILE"
  chmod 600 "$ENV_FILE"

  env_set_if_absent APP_URL "https://${DOMAIN}"
  # --restore passes these in from the old server (see scripts/export-secrets.ts
  # there) instead of generating fresh ones — a fresh ENCRYPTION_KEY would
  # leave every token in the restored dump silently undecryptable.
  env_set_if_absent SESSION_SECRET "${SESSION_SECRET_ARG:-$(openssl rand -hex 32)}"
  env_set_if_absent ENCRYPTION_KEY "${ENCRYPTION_KEY_ARG:-$(openssl rand -hex 32)}"
  env_set_if_absent DATABASE_URL "$DATABASE_URL"
  env_set_if_absent REDIS_URL "redis://localhost:6379"
  env_set_if_absent OWNER_EMAIL "${OWNER_EMAIL_ARG:-owner@localhost}"
  env_set_if_absent META_GRAPH_API_VERSION "v25.0"
  # Настоящие значения ставятся вручную после регистрации приложения в Meta
  # (см. docs/setup.md) — заранее их сгенерировать не из чего.
  env_set_if_absent INSTAGRAM_APP_ID "your-instagram-app-id"
  env_set_if_absent INSTAGRAM_APP_SECRET "your-instagram-app-secret"

  if [ -n "$(env_get OWNER_PASSWORD)" ]; then
    OWNER_PASSWORD_NEW=0
    info "   OWNER_PASSWORD уже задан в .env — не меняю"
  elif [ "$RESTORE_MODE" -eq 1 ] && [ -z "$OWNER_PASSWORD_ARG" ]; then
    # Оставляем пустым: после восстановления дампа сработает пароль,
    # мигрировавший вместе со строкой User (см. lib/auth/owner.ts —
    # существующий User + пустой OWNER_PASSWORD = хеш из базы не трогается).
    OWNER_PASSWORD_NEW=0
    info "   --restore: OWNER_PASSWORD оставлен пустым — сработает пароль из восстановленного дампа"
  else
    OWNER_PASSWORD_NEW=1
    local generated="${OWNER_PASSWORD_ARG:-$(openssl rand -base64 24 | tr -d '=+/\n')}"
    env_set_if_absent OWNER_PASSWORD "$generated"
  fi

  ok ".env готов: $ENV_FILE"
}

# ---------------------------------------------------------------------------
# Сборка. NODE_OPTIONS ограничивает кучу V8, чтобы next build не убивал
# процесс OOM-киллером на маленьком VPS — размер подобран по общей памяти
# (ОЗУ + подкачка после check_memory_and_swap).
# ---------------------------------------------------------------------------
compute_node_max_old_space() {
  local mem_kb mem_mb swap_kb swap_mb total
  mem_kb="$(awk '/^MemTotal:/ {print $2}' /proc/meminfo)"
  mem_mb=$(( mem_kb / 1024 ))
  swap_kb="$(awk '/^SwapTotal:/ {print $2}' /proc/meminfo)"
  swap_mb=$(( swap_kb / 1024 ))
  total=$(( mem_mb + swap_mb ))

  if [ "$total" -ge 6144 ]; then
    NODE_MAX_OLD_SPACE_MB=4096
  elif [ "$total" -ge 4096 ]; then
    NODE_MAX_OLD_SPACE_MB=3072
  else
    NODE_MAX_OLD_SPACE_MB=1536
  fi
}

build_app() {
  cd "$INSTALL_DIR"

  step "Ставлю зависимости (npm ci)"
  compute_node_max_old_space
  export NODE_OPTIONS="--max-old-space-size=${NODE_MAX_OLD_SPACE_MB}"
  npm ci --no-audit --no-fund
  ok "Зависимости установлены"

  step "Собираю приложение (next build, ограничение памяти ${NODE_MAX_OLD_SPACE_MB} МБ)"
  # Next.js и Prisma сами читают .env из корня проекта (loadEnvConfig /
  # dotenv в prisma.config.ts) — здесь ничего вручную экспортировать не нужно.
  npm run build
  unset NODE_OPTIONS
  ok "Сборка завершена"
}

run_migrations() {
  step "Накатываю миграцию базы данных"
  cd "$INSTALL_DIR"
  npx prisma migrate deploy
  ok "Миграция применена"
}

# ---------------------------------------------------------------------------
# systemd — юниты лежат файлами в репозитории (deploy/), это просто их
# копирование с подстановкой пути установки и имени пользователя. Тот же
# механизм переиспользует фаза 13 (обновление) после каждого git pull.
# ---------------------------------------------------------------------------
install_systemd_units() {
  step "Ставлю systemd-юниты (приложение, воркер, суточный дамп)"
  local unit
  for unit in commentdm.service commentdm-worker.service commentdm-backup.service commentdm-backup.timer; do
    # render_template, а не `sed ... > юнит`: прямая запись обнуляет
    # действующий юнит ДО того, как в него что-то попало, и обрыв ровно
    # здесь оставляет сервер с пустым юнитом вместо приложения.
    render_template "$INSTALL_DIR/deploy/$unit" "/etc/systemd/system/$unit" \
      -e "s|__INSTALL_DIR__|${INSTALL_DIR}|g" -e "s|__APP_USER__|${APP_USER}|g"
  done
  chmod +x "$INSTALL_DIR/deploy/backup.sh"
  systemctl daemon-reload
  ok "systemd-юниты установлены"
}

configure_caddy() {
  step "Настраиваю Caddy на домен $DOMAIN"
  render_template "$INSTALL_DIR/deploy/Caddyfile" /etc/caddy/Caddyfile \
    "s|__DOMAIN__|${DOMAIN}|g"
  # Каталог логов Caddy не создаём: файловый вывод убран из Caddyfile.
  # Пакетный юнит Caddy запрещает запись в /var/log (ProtectSystem),
  # служба падала при старте. Логи доступа идут в journalctl -u caddy.
  caddy validate --config /etc/caddy/Caddyfile >/dev/null
  systemctl enable caddy >/dev/null
  if systemctl is-active --quiet caddy; then
    systemctl reload caddy
  else
    systemctl restart caddy
  fi
  ok "Caddy настроен — сертификат для $DOMAIN выпускается автоматически при первом запросе"
}

# ---------------------------------------------------------------------------
# Файрвол. Порт приложения (3000) обязательно закрыт: на этом держится
# доверие к X-Forwarded-For из фазы 5 (lib/net/client-ip.ts) — прокси
# считается доверенным именно потому, что порт приложения недостижим
# напрямую из интернета.
# ---------------------------------------------------------------------------
# detect_ssh_ports — реальные порты sshd, а не «наверное, 22».
# Раньше файрвол открывал жёстко 22: у кого ssh перевешен на другой порт,
# установка отрезала доступ к собственному серверу. Смотрим три источника и
# берём объединение: директивы Port в конфигах sshd, порт текущей ssh-сессии
# (SSH_CONNECTION, если sudo его донёс) и то, что sshd реально слушает.
detect_ssh_ports() {
  local ports=""
  # Пути переопределяемы — тем же приёмом, что CADDY_CONFIG_PATH в
  # scripts/set-domain.sh: тесту нужно подсунуть свой sshd_config, а на
  # реальной установке значения по умолчанию совпадают с системными.
  local sshd_config="${SSHD_CONFIG:-/etc/ssh/sshd_config}"
  local sshd_config_dir="${SSHD_CONFIG_DIR:-/etc/ssh/sshd_config.d}"
  if [ -f "$sshd_config" ]; then
    ports="$(grep -hiE '^[[:space:]]*Port[[:space:]]+[0-9]+' "$sshd_config" 2>/dev/null \
      | awk '{print $2}' || true)"
  fi
  if compgen -G "${sshd_config_dir}/*.conf" >/dev/null 2>&1; then
    ports="${ports}
$(grep -hiE '^[[:space:]]*Port[[:space:]]+[0-9]+' "${sshd_config_dir}"/*.conf 2>/dev/null \
      | awk '{print $2}' || true)"
  fi
  if [ -n "${SSH_CONNECTION:-}" ]; then
    ports="${ports}
$(printf '%s' "$SSH_CONNECTION" | awk '{print $4}')"
  fi
  if command -v ss >/dev/null 2>&1; then
    ports="${ports}
$(ss -Htlnp 2>/dev/null | awk '/sshd/ {print $4}' | sed 's/.*://' || true)"
  fi
  printf '%s\n' "$ports" | grep -E '^[0-9]+$' | sort -un || true
}

configure_firewall() {
  local ssh_ports port
  ssh_ports="$(detect_ssh_ports)"
  if [ -z "$ssh_ports" ]; then
    ssh_ports="22"
    warn "Порт ssh определить не удалось — открываю стандартный 22"
  fi

  step "Настраиваю файрвол (ufw): открываю 80, 443 и порты ssh ($(printf '%s' "$ssh_ports" | tr '\n' ' ' | sed 's/ *$//'))"
  ufw --force default deny incoming >/dev/null
  ufw --force default allow outgoing >/dev/null
  while IFS= read -r port; do
    [ -n "$port" ] || continue
    ufw allow "${port}/tcp" >/dev/null
  done <<< "$ssh_ports"
  ufw allow 80/tcp >/dev/null
  ufw allow 443/tcp >/dev/null
  ufw deny 3000/tcp >/dev/null
  ufw --force enable >/dev/null
  ok "Файрвол включён: открыты 80, 443 и ssh ($(printf '%s' "$ssh_ports" | tr '\n' ' ' | sed 's/ *$//')); порт приложения 3000 закрыт снаружи"
}

finalize_permissions() {
  step "Передаю права на $INSTALL_DIR пользователю $APP_USER"
  mkdir -p "$INSTALL_DIR/backups"
  chown -R "${APP_USER}:${APP_USER}" "$INSTALL_DIR"
  ok "Права переданы"
}

start_services() {
  step "Запускаю сервисы"
  systemctl enable --now commentdm.service
  systemctl enable --now commentdm-worker.service
  systemctl enable --now commentdm-backup.timer

  sleep 8
  if systemctl is-active --quiet commentdm.service; then
    ok "commentdm.service запущен"
  else
    warn "commentdm.service не поднялся с первой попытки — journalctl -u commentdm -n 50"
  fi
  if systemctl is-active --quiet commentdm-worker.service; then
    ok "commentdm-worker.service запущен"
  else
    warn "commentdm-worker.service не поднялся с первой попытки — journalctl -u commentdm-worker -n 50"
  fi
}

run_doctor_check() {
  step "Запускаю npm run doctor"
  cd "$INSTALL_DIR"
  # Вердикт doctor раньше глушился через `|| true`, и баннер «установлено»
  # печатался поверх найденных ошибок. Установка при этом действительно
  # завершена, поэтому не падаем — но результат запоминаем и говорим о нём
  # в итоговом баннере.
  if sudo -u "$APP_USER" --preserve-env=PATH npm run doctor; then
    DOCTOR_OK=1
  else
    DOCTOR_OK=0
    warn "npm run doctor нашёл проблемы (вывод выше) — установка завершена, но проверьте их."
  fi
}

print_summary() {
  local owner_password owner_email
  owner_password="$(env_get OWNER_PASSWORD)"
  owner_email="$(env_get OWNER_EMAIL)"

  echo
  echo "################################################################################"
  echo "#"
  if [ "$DOCTOR_OK" -eq 1 ]; then
    echo "#   commentdm установлен"
  else
    echo "#   commentdm установлен, НО npm run doctor нашёл проблемы"
    echo "#   (его вывод выше по логу — начните разбор с него:"
    echo "#    cd ${INSTALL_DIR} && npm run doctor)"
  fi
  echo "#"
  echo "#   Адрес:  https://${DOMAIN}"
  echo "#   Логин:  ${owner_email}"
  if [ -z "$owner_password" ] && [ "$RESTORE_MODE" -eq 1 ]; then
    echo "#   Пароль: не сгенерирован (--restore, OWNER_PASSWORD оставлен пустым)."
    echo "#"
    echo "#   Как только восстановишь дамп базы (bash deploy/restore-db.sh <дамп>),"
    echo "#   сработает прежний пароль владельца — тот, что был на старом сервере."
    echo "#   До восстановления дампа входа в это приложение НЕТ."
  elif [ "$OWNER_PASSWORD_NEW" -eq 1 ]; then
    echo "#   Пароль (сгенерирован сейчас, больше нигде не показывается):"
    echo "#"
    echo "#       ${owner_password}"
    echo "#"
    echo "#   СОХРАНИТЕ ЕГО СЕЙЧАС — он хранится только в виде хеша и больше"
    echo "#   нигде не покажется этим установщиком."
  else
    echo "#   Пароль (был задан раньше, .env не менялся):"
    echo "#"
    echo "#       ${owner_password}"
    echo "#"
    echo "#   СОХРАНИТЕ ЕГО СЕЙЧАС — он хранится только в виде хеша и больше"
    echo "#   нигде не покажется этим установщиком."
  fi
  echo "#"
  echo "################################################################################"
  echo
  echo "Дальше нужно сделать руками (установщик этого не делает):"
  if [ "$RESTORE_MODE" -eq 1 ]; then
    echo "  0. Это --restore: без восстановленного дампа базы аккаунты Instagram,"
    echo "     кампании и пароль владельца сюда ещё не переехали. Перенеси файл"
    echo "     дампа со старого сервера и выполни:"
    echo "       cd ${INSTALL_DIR} && set -a && . .env && set +a"
    echo "       bash deploy/restore-db.sh <файл-дампа.sql.gz>"
    echo "     затем npm run doctor — проверит в том числе, что ENCRYPTION_KEY"
    echo "     совпадает с тем, которым были зашифрованы перенесённые токены."
  fi
  echo "  1. Завести приложение в Meta и вписать настоящие INSTAGRAM_APP_ID и"
  echo "     INSTAGRAM_APP_SECRET в ${ENV_FILE} (сейчас там заглушки),"
  echo "     затем перезапустить: systemctl restart commentdm commentdm-worker"
  echo "  2. Подробности — docs/setup.md внутри репозитория"
  echo
  echo "Полезные команды:"
  echo "  journalctl -u commentdm -f            # логи приложения"
  echo "  journalctl -u commentdm-worker -f     # логи воркера"
  echo "  cd ${INSTALL_DIR} && npm run doctor   # самодиагностика в любой момент"
  echo "  systemctl status commentdm commentdm-worker caddy postgresql redis-server"
  echo
  echo "Лог этой установки: $LOG_FILE"
}

main() {
  parse_args "$@"
  require_root
  setup_logging
  run_preflight_checks

  resolve_install_dir
  ENV_FILE="$INSTALL_DIR/.env"

  install_base_packages
  install_node
  install_postgres
  install_redis
  install_caddy

  create_app_user
  setup_database
  write_env
  build_app
  run_migrations
  install_systemd_units
  configure_caddy
  configure_firewall
  finalize_permissions
  start_services
  run_doctor_check
  print_summary
}

# COMMENTDM_INSTALL_SH_LIB_ONLY=1 — единственный способ подключить этот файл
# (source install.sh) и НЕ запустить установку. Нужен тестам: install.sh
# держит собственные копии разбора .env, проверки домена и разбора
# DATABASE_URL — те же по смыслу, что в deploy/lib.sh, но физически другие
# (install.sh обязан работать одним файлом до появления репозитория на
# диске), и расходиться они не должны. При обычном запуске переменной нет и
# поведение прежнее.
if [ "${COMMENTDM_INSTALL_SH_LIB_ONLY:-0}" != "1" ]; then
  main "$@"
fi
