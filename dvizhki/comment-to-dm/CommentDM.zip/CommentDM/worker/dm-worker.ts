import { getEncryptionKeyFingerprint, validateCoreEnv } from "@/lib/env";
import { createDMWorker } from "@/lib/queue/dm-worker";
import { recordWorkerAlert, recordWorkerHeartbeat } from "@/lib/ops/worker-health";
import { reconcileComments } from "@/lib/polling/comment-reconciler";
import { createOverlapGuard } from "@/lib/polling/overlap-guard";
import { pollConversations } from "@/lib/chain/conversation-poller";
import { dispatchChainSteps } from "@/lib/chain/step-dispatcher";
import { runTokenRefreshJob } from "@/lib/ops/token-refresh-job";
import { runAttachNextReelJob } from "@/lib/ops/attach-next-reel-job";
import { runFollowerSnapshotJob } from "@/lib/ops/follower-snapshot-job";
import { runRetentionCleanupJob } from "@/lib/ops/retention-job";
import os from "node:os";

// Fails loudly, naming every missing or invalid variable, before the worker
// ever opens a queue connection — a half-filled .env should not boot a
// worker that then throws mid-job on whichever variable it happened to need
// first.
validateCoreEnv();

const worker = createDMWorker();
const startedAt = new Date().toISOString();
const HEARTBEAT_INTERVAL_MS = 30_000;
// Comment polling — the only path that discovers comments. Runs in the worker
// because it must fire every few minutes and there is no scheduler on a plain
// VPS to fire it for us.
const POLL_INTERVAL_MS = Number(
  process.env.COMMENT_POLL_INTERVAL_MS ?? 5 * 60_000
);
// Touch chains — the two contours that carry a chain forward after the GATE.
// Both live here for the same reason comment polling does: a plain VPS has no
// scheduler, and a chain that stops being driven silently strands people
// mid-sequence.
//
// The poller asks Meta for each account's DM threads (one call per account, see
// lib/chain/conversation-poller.ts) — 90s keeps that at ~40 calls/hour per
// account while still noticing an answer fast enough that "instant" delivery
// still reads as instant. The dispatcher only reads the database and sends what
// is already due, so it runs far more often: chain delays are exact times
// (+10 min, +2h, +20h) and a coarse tick would smear all of them.
const CONVERSATION_POLL_INTERVAL_MS = Number(
  process.env.CONVERSATION_POLL_INTERVAL_MS ?? 90_000
);
const CHAIN_DISPATCH_INTERVAL_MS = Number(
  process.env.CHAIN_DISPATCH_INTERVAL_MS ?? 30_000
);
// Both contours start after the comment sweep's own first run (10s), so a boot
// doesn't fire three Graph API contours into the same second.
const CHAIN_INITIAL_DELAY_MS = 15_000;

const DAY_MS = 24 * 60 * 60 * 1000;

console.log("[DM Worker] Started");

async function heartbeat() {
  try {
    await recordWorkerHeartbeat({
      pid: process.pid,
      hostname: os.hostname(),
      startedAt,
      encryptionKeyFingerprint: getEncryptionKeyFingerprint(),
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    console.error("[DM Worker] Heartbeat failed:", message);
  }
}

void heartbeat();
const heartbeatTimer = setInterval(() => void heartbeat(), HEARTBEAT_INTERVAL_MS);

// Stops a slow sweep (many campaigns, many Graph API calls) from having a
// second one start on top of it at the next tick — see
// lib/polling/overlap-guard.ts. The deeper per-comment race (two sweeps
// re-enqueuing the same comment while its job is still queued) is closed
// separately in lib/queue/comment-claim.ts; this is the outer, cheap guard.
const runPollGuarded = createOverlapGuard();

async function poll() {
  const outcome = await runPollGuarded(async () => {
    try {
      await reconcileComments();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unknown error";
      console.error("[DM Worker] Comment reconciliation failed:", message);
    }
  });

  if (outcome === "skipped") {
    console.warn(
      "[DM Worker] Comment sweep skipped: the previous sweep is still running"
    );
    await recordWorkerAlert({
      level: "warning",
      message:
        "Проход опроса комментариев пропущен - предыдущий проход ещё не завершился",
    }).catch(() => {});
  }
}

// Kick off one sweep shortly after boot, then on a fixed interval.
setTimeout(() => void poll(), 10_000);
const pollTimer = setInterval(() => void poll(), POLL_INTERVAL_MS);

// Each chain contour gets its OWN overlap guard, for the same reason the
// comment sweep has one (and because of the 09.08 incident, where a single
// hung Meta call froze polling for two hours): a slow pass must finish before
// the next tick starts a second one on top of it. Separate guards, not one
// shared: a stuck conversation poll must not also stop steps that are already
// due from going out — those need no network call to Meta beyond the send.
const runConversationPollGuarded = createOverlapGuard();
const runChainDispatchGuarded = createOverlapGuard();

async function runGuardedContour(
  label: string,
  alert: string,
  guard: (fn: () => Promise<void>) => Promise<"ran" | "skipped">,
  run: () => Promise<unknown>
) {
  const outcome = await guard(async () => {
    try {
      await run();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unknown error";
      console.error(`[DM Worker] ${label} failed:`, message);
    }
  });

  if (outcome === "skipped") {
    console.warn(`[DM Worker] ${label} skipped: the previous pass is still running`);
    await recordWorkerAlert({ level: "warning", message: alert }).catch(() => {});
  }
}

function pollChainConversations() {
  return runGuardedContour(
    "Chain conversation poll",
    "Проход опроса диалогов пропущен - предыдущий проход ещё не завершился",
    runConversationPollGuarded,
    pollConversations
  );
}

function dispatchChain() {
  return runGuardedContour(
    "Chain step dispatch",
    "Проход диспетчера цепочек пропущен - предыдущий проход ещё не завершился",
    runChainDispatchGuarded,
    dispatchChainSteps
  );
}

setTimeout(() => void pollChainConversations(), CHAIN_INITIAL_DELAY_MS);
const conversationPollTimer = setInterval(
  () => void pollChainConversations(),
  CONVERSATION_POLL_INTERVAL_MS
);

setTimeout(() => void dispatchChain(), CHAIN_INITIAL_DELAY_MS);
const chainDispatchTimer = setInterval(
  () => void dispatchChain(),
  CHAIN_DISPATCH_INTERVAL_MS
);

/**
 * Periodic housekeeping jobs, formerly Vercel Cron routes hit by an external
 * scheduler once a day. There is no such scheduler on a plain VPS, so they
 * run as intervals in this same process instead — same daily cadence,
 * staggered against each other and against the comment poll above so they
 * never all fire in the same tick. Each job writes its own success/failure
 * to the operational event journal on every run (see lib/ops/*-job.ts), which
 * is what lets `npm run doctor` (phase 11) tell "this job hasn't run
 * recently" apart from "this job is running and failing".
 *
 * Token refresh is the one that matters most: an Instagram access token dies
 * 60 days after it's issued, and once it does every send starts failing with
 * no visible symptom short of reading the journal. It runs first and
 * soonest after boot for that reason.
 */
interface ScheduledJob {
  name: string;
  run: () => Promise<unknown>;
  initialDelayMs: number;
  intervalMs: number;
}

const SCHEDULED_JOBS: ScheduledJob[] = [
  {
    name: "token-refresh",
    run: runTokenRefreshJob,
    initialDelayMs: 30_000, // 30s after boot — critical, don't wait a day for it
    intervalMs: Number(process.env.TOKEN_REFRESH_INTERVAL_MS ?? DAY_MS),
  },
  {
    name: "attach-next-reel",
    run: runAttachNextReelJob,
    initialDelayMs: 5 * 60_000, // 5 min after boot
    intervalMs: Number(process.env.ATTACH_NEXT_REEL_INTERVAL_MS ?? DAY_MS),
  },
  {
    name: "follower-snapshot",
    run: runFollowerSnapshotJob,
    initialDelayMs: 10 * 60_000, // 10 min after boot
    intervalMs: Number(process.env.FOLLOWER_SNAPSHOT_INTERVAL_MS ?? DAY_MS),
  },
  {
    name: "retention-cleanup",
    run: runRetentionCleanupJob,
    initialDelayMs: 15 * 60_000, // 15 min after boot — no rush, nothing else depends on it
    intervalMs: Number(process.env.RETENTION_CLEANUP_INTERVAL_MS ?? DAY_MS),
  },
];

async function runScheduledJob(job: ScheduledJob) {
  try {
    await job.run();
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    console.error(`[DM Worker] Scheduled job "${job.name}" failed:`, message);
  }
}

const scheduledTimers = SCHEDULED_JOBS.map((job) => {
  const initialTimer = setTimeout(() => {
    void runScheduledJob(job);
  }, job.initialDelayMs);
  const intervalTimer = setInterval(() => {
    void runScheduledJob(job);
  }, job.intervalMs);
  return { initialTimer, intervalTimer };
});

async function shutdown(signal: string) {
  console.log(`[DM Worker] ${signal} received, closing worker`);
  clearInterval(heartbeatTimer);
  clearInterval(pollTimer);
  clearInterval(conversationPollTimer);
  clearInterval(chainDispatchTimer);
  for (const { initialTimer, intervalTimer } of scheduledTimers) {
    clearTimeout(initialTimer);
    clearInterval(intervalTimer);
  }
  await worker.close();
  process.exit(0);
}

process.on("SIGINT", () => void shutdown("SIGINT"));
process.on("SIGTERM", () => void shutdown("SIGTERM"));
