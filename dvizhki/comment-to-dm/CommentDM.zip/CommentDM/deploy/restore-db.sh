#!/usr/bin/env bash
#
# Restores a gzip'd pg_dump produced by deploy/backup.sh onto DATABASE_URL,
# replacing whatever is there now. Shared by scripts/rollback.sh (restoring
# this same server's own pre-update dump) and by the machine-migration runbook
# printed by scripts/export-secrets.ts (restoring an old server's dump onto a
# freshly installed new one).
#
# Usage:
#   deploy/restore-db.sh <path-to-dump.sql.gz>
#   deploy/restore-db.sh --check <path-to-dump.sql.gz>
#
# --check делает ТОЛЬКО проверки и ничего не меняет: файл на месте, gzip
# целый, база отвечает, права на очистку схемы есть. Этим пользуется
# scripts/rollback.sh, чтобы упереться в проблему ДО остановки сервисов, а
# не после.
#
# DATABASE_URL must already be in the environment (source .env first) — same
# convention as deploy/backup.sh.
#
# backup.sh's dump is a plain `pg_dump` with no --clean flag, so replaying it
# straight onto a database that already has tables (this server's current
# schema, or the schema install.sh just created on a new one) would fail on
# "already exists". Поэтому цель сначала очищается.
#
# ПОЧЕМУ НЕ `DROP SCHEMA public CASCADE`. Так было раньше, и это работает
# только там, где схемой public владеет наша же роль — то есть на PostgreSQL
# 15 и новее. На Ubuntu 20.04 (PG 12) и 22.04 (PG 14) владелец public —
# postgres, а роль commentdm создаётся install.sh без суперправ, и откат
# падал с «must be owner of schema public». Причём падал уже после того, как
# rollback.sh остановил сервисы.
#
# `DROP OWNED BY CURRENT_USER` сносит всё, что эта роль в этой базе создала
# (таблицы, последовательности, индексы, типы, права), не требует прав на
# саму схему и ведёт себя одинаково на PG 12 и новее. Схема public при этом
# остаётся на месте (её владелец нас не касается), а если на PG 15+ она всё
# же была нашей и уехала вместе с остальным — следующая строка создаёт её
# заново.
set -euo pipefail

CHECK_ONLY=0
if [ "${1:-}" = "--check" ]; then
  CHECK_ONLY=1
  shift
fi

DUMP_FILE="${1:-}"

if [ -z "$DUMP_FILE" ]; then
  echo "Использование: deploy/restore-db.sh [--check] <путь-к-дампу.sql.gz>" >&2
  exit 1
fi

if [ ! -f "$DUMP_FILE" ]; then
  echo "❌ Файл дампа не найден: $DUMP_FILE" >&2
  exit 1
fi

: "${DATABASE_URL:?DATABASE_URL is not set — source .env first: set -a; . .env; set +a}"

# --- Проверки. Все до единой не меняют ничего. ------------------------------

echo "[restore-db] проверяю дамп: $DUMP_FILE"
if ! gzip -t "$DUMP_FILE" 2>/dev/null; then
  echo "❌ Файл дампа повреждён или это не gzip: $DUMP_FILE" >&2
  echo "   Проверить руками: gzip -t $DUMP_FILE" >&2
  exit 1
fi

echo "[restore-db] проверяю подключение к базе"
if ! psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -tAc 'SELECT 1' >/dev/null 2>&1; then
  echo "❌ База по DATABASE_URL не отвечает." >&2
  echo "   Проверьте, что PostgreSQL запущен и строка подключения верна:" >&2
  echo "     systemctl status postgresql" >&2
  exit 1
fi

# Есть ли в public объекты, которые эта роль снести НЕ сможет (создан
# кем-то другим). На чистой установке commentdm таких нет, но лучше сказать
# об этом здесь, чем вывалить стену ошибок psql на середине восстановления.
FOREIGN_OBJECTS="$(psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -tAc "
  SELECT count(*)
  FROM pg_class c
  JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname = 'public'
    AND c.relkind IN ('r','p','v','m','S')
    AND pg_get_userbyid(c.relowner) <> current_user
" 2>/dev/null || echo 0)"

if [ "${FOREIGN_OBJECTS:-0}" != "0" ]; then
  echo "❌ В схеме public есть $FOREIGN_OBJECTS объект(ов), принадлежащих другой роли." >&2
  echo "   Роль из DATABASE_URL не сможет их удалить, и восстановление дампа" >&2
  echo "   упадёт на «already exists». Разберитесь с ними вручную (psql, \\dt+)" >&2
  echo "   или восстанавливайте в пустую базу." >&2
  exit 1
fi

if [ "$CHECK_ONLY" -eq 1 ]; then
  echo "[restore-db] проверки пройдены (--check): дамп цел, база отвечает, схема наша"
  exit 0
fi

# --- Дальше начинается разрушительная часть. --------------------------------

echo "[restore-db] очищаю текущее содержимое базы (DROP OWNED BY CURRENT_USER)"
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -q >/dev/null <<'SQL'
BEGIN;
DROP OWNED BY CURRENT_USER;
COMMIT;
SQL

# Отдельным запросом, вне транзакции выше: на PG 15+ схема могла принадлежать
# нам и уехать вместе с остальным, на PG 12/14 она принадлежит postgres и
# осталась на месте — IF NOT EXISTS покрывает оба случая одинаково.
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -q >/dev/null <<'SQL'
CREATE SCHEMA IF NOT EXISTS public;
SQL

echo "[restore-db] восстанавливаю дамп: $DUMP_FILE"
gunzip -c "$DUMP_FILE" | psql "$DATABASE_URL" -v ON_ERROR_STOP=1 >/dev/null

echo "[restore-db] готово"
