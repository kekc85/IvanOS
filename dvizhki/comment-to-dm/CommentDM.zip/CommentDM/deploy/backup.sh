#!/usr/bin/env bash
# Daily Postgres dump with rotation. Run by commentdm-backup.service (see
# commentdm-backup.timer for the schedule), which loads .env as
# EnvironmentFile before calling this, so DATABASE_URL is already in the
# environment — this script does not parse .env itself.
#
# Can also be run by hand for an on-demand backup:
#   sudo -u commentdm bash -c 'set -a; source /opt/commentdm/.env; set +a; bash /opt/commentdm/deploy/backup.sh'
set -euo pipefail

# Дамп — это вся переписка с подписчиками и шифротексты токенов Instagram.
# Без этой строки gzip создавал файл по общей umask (обычно 022), то есть
# 644: читать дампы мог любой локальный аккаунт на машине. umask здесь
# закрывает и сам файл, и каталог, а явные chmod ниже — страховка на случай
# unmask, унаследованной от systemd или от чужой оболочки.
umask 077

: "${DATABASE_URL:?DATABASE_URL is not set — run this via systemd (commentdm-backup.service) or export it first}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
BACKUP_DIR="$INSTALL_DIR/backups"
RETENTION_DAYS="${BACKUP_RETENTION_DAYS:-14}"
TIMESTAMP="$(date -u +%Y%m%d-%H%M%S)"
DEST="$BACKUP_DIR/commentdm-$TIMESTAMP.sql.gz"

mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR" 2>/dev/null || true

# Ремонт задним числом: установки, успевшие наделать дампов с режимом 644,
# чинятся первым же запуском новой версии, а не остаются открытыми навсегда.
find "$BACKUP_DIR" -maxdepth 1 -type f -name 'commentdm-*.sql.gz' -exec chmod 600 {} + 2>/dev/null || true

echo "[backup] dumping database to $DEST"
pg_dump "$DATABASE_URL" | gzip > "$DEST.tmp"
chmod 600 "$DEST.tmp"
mv "$DEST.tmp" "$DEST"
echo "[backup] wrote $(du -h "$DEST" | cut -f1)"

echo "[backup] deleting dumps older than $RETENTION_DAYS days"
find "$BACKUP_DIR" -maxdepth 1 -name 'commentdm-*.sql.gz' -mtime "+$RETENTION_DAYS" -print -delete

# Оборванный прошлый запуск (упал pg_dump, кончилось место, перезагрузка)
# оставлял .tmp навсегда: под шаблон ротации выше он не подходит и копился
# полными дампами до конца диска.
echo "[backup] deleting interrupted dumps (*.tmp) older than 1 day"
find "$BACKUP_DIR" -maxdepth 1 -name 'commentdm-*.sql.gz.tmp' -mtime +1 -print -delete

echo "[backup] done, $(find "$BACKUP_DIR" -maxdepth 1 -name 'commentdm-*.sql.gz' | wc -l | tr -d ' ') dump(s) kept"
