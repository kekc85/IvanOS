#!/usr/bin/env bash
# shellcheck shell=bash
#
# Shared bash helpers for the day-2 operator scripts: scripts/update.sh,
# scripts/rollback.sh, scripts/set-domain.sh, scripts/restore-db.sh.
#
# install.sh does NOT source this file on purpose: install.sh has to work as
# a single file downloaded and run before the repository even exists on disk
# (see its own resolve_install_dir — the "curl the one file, run it, it
# clones the rest" bootstrap path). This file would not exist yet at that
# point. The scripts that source this one always run from inside an already
# installed repository (an operator runs `npm run update` from
# /opt/commentdm), so `deploy/lib.sh` is guaranteed to be there. The output
# helpers and the two small pieces of logic below are intentionally
# duplicated from install.sh rather than factored out of it, for that reason.
#
# Usage: source "$(dirname "${BASH_SOURCE[0]}")/deploy/lib.sh" (or an
# equivalent path to this file) near the top of the caller, after `set -euo
# pipefail`.

# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------
c_bold=$'\033[1m'
c_reset=$'\033[0m'

info()  { printf '%s\n' "$*"; }
ok()    { printf '✅ %s\n' "$*"; }
warn()  { printf '⚠️  %s\n' "$*"; }
err()   { printf '❌ %s\n' "$*" >&2; }
step()  { printf '\n%s==> %s%s\n' "$c_bold" "$*" "$c_reset"; }

# Every deliberate exit goes through this, not a bare `exit` — same reasoning
# as install.sh's clean_exit: it disarms the ERR trap first so a controlled
# `exit N` doesn't also print a second, confusing "unexpected error" message.
clean_exit() {
  trap - ERR
  exit "${1:-1}"
}

fail() {
  err "$1"
  if [ -n "${2:-}" ]; then
    printf '   %s\n' "$2"
  fi
  clean_exit 1
}

# Call once per script, right after sourcing this file:
#   trap 'on_unexpected_error $LINENO "$0"' ERR
on_unexpected_error() {
  local line="$1" script="${2:-$0}"
  err "$(basename "$script") прервался на строке $line (неожиданная ошибка команды)."
  if [ -n "${LOG_FILE:-}" ]; then
    info "   Полный лог: $LOG_FILE"
  fi
  clean_exit 1
}

# setup_logging <log_file> — tee stdout+stderr into <log_file> as well as
# the terminal, same as install.sh does for its own log. Guarded: if the log
# file can't be created or written (unwritable /var/log, running as a
# non-root user in a test harness, a read-only filesystem mid-incident),
# this silently continues without the file rather than failing the whole
# script over logging — the script's real job is not "write a log file".
setup_logging() {
  local log_file="$1"
  mkdir -p "$(dirname "$log_file")" 2>/dev/null || true
  if touch "$log_file" 2>/dev/null; then
    chmod 640 "$log_file" 2>/dev/null || true
    exec > >(tee -a "$log_file") 2>&1
    info "Лог: $log_file"
  fi
}

require_root() {
  local cmd="${1:-это}"
  if [ "$(id -u)" -ne 0 ]; then
    err "Нужны права root."
    printf '   Запусти команду через sudo:\n\n'
    printf '     sudo %s\n\n' "$cmd"
    clean_exit 1
  fi
}

# ---------------------------------------------------------------------------
# Файлы: владелец, режим, атомарная запись.
# ---------------------------------------------------------------------------

# file_mode / file_owner <file> — GNU (Ubuntu, боевой сервер) и BSD (macOS,
# где гоняются тесты этого проекта) stat принимают разные флаги, поэтому
# пробуем оба и молча отдаём пустую строку, если не вышло ни так, ни так.
file_mode() {
  stat -c '%a' "$1" 2>/dev/null || stat -f '%OLp' "$1" 2>/dev/null || true
}

file_owner() {
  stat -c '%u:%g' "$1" 2>/dev/null || stat -f '%u:%g' "$1" 2>/dev/null || true
}

# copy_file_identity <источник> <цель> — переносит владельца и режим доступа
# с одного файла на другой. Нужен везде, где файл переписывается приёмом
# «временный файл рядом + mv»: mktemp создаёт файл от root с режимом 0600,
# и без этой строки владелец и режим временного файла переезжают на цель.
# Для .env это не косметика: приложение и воркер читают .env от имени
# пользователя приложения, и .env, ставший root:root 0600, роняет воркер в
# вечный рестарт при живом веб-приложении (веб systemd читает от root).
copy_file_identity() {
  local src="$1" dst="$2" mode owner
  mode="$(file_mode "$src")"
  owner="$(file_owner "$src")"
  if [ -n "$mode" ]; then
    chmod "$mode" "$dst" 2>/dev/null || true
  fi
  if [ -n "$owner" ]; then
    chown "$owner" "$dst" 2>/dev/null || true
  fi
}

# render_template <шаблон> <цель> <аргументы sed...> — подстановка
# плейсхолдеров с записью через временный файл рядом с целью и переносом на
# место одним mv.
#
# Прямое `sed ... > /etc/systemd/system/unit` обнуляет цель ДО того, как в
# неё что-то записано: обрыв связи или падение ровно на этом месте оставляет
# пустой systemd-юнит или пустой конфиг Caddy, то есть сервер без
# приложения. Здесь цель до последнего момента остаётся прежней, а если sed
# не отработал — не меняется вовсе.
render_template() {
  local src="$1" dest="$2" tmp
  shift 2
  tmp="$(mktemp "${dest}.XXXXXX")"
  if ! sed "$@" "$src" > "$tmp"; then
    rm -f "$tmp"
    err "Не удалось подготовить $dest из шаблона $src"
    return 1
  fi
  if [ -e "$dest" ]; then
    copy_file_identity "$dest" "$tmp"
  else
    chmod 644 "$tmp"
  fi
  mv "$tmp" "$dest"
}

# ---------------------------------------------------------------------------
# .env — чтение и запись. Тот же контракт, что и у собственных копий этих
# функций в install.sh (install.sh не может подключить этот файл: он обязан
# работать одним файлом до того, как репозиторий появится на диске).
#
# Ключевое: и `node --env-file`, и systemd EnvironmentFile принимают строку
# с ведущими пробелами, с префиксом `export ` и со значением в кавычках.
# Разбор «строка начинается ровно с KEY=» этого не видел — и повторный
# install.sh дописывал ВТОРУЮ строку с новым случайным значением, а
# выигрывала последняя. Для ENCRYPTION_KEY это молчаливая потеря всех
# подключённых аккаунтов Instagram, для DATABASE_URL/SESSION_SECRET/
# OWNER_PASSWORD — потеря доступа. Поэтому чтение и запись понимают все три
# формы, а запись НИКОГДА не дописывает второй строки к уже существующему
# ключу.
# ---------------------------------------------------------------------------

# env_get <file> <key> — значение ключа или пустая строка, если ключа нет.
env_get() {
  local file="$1" key="$2" raw first last
  raw="$(COMMENTDM_ENV_KEY="$key" awk '
    BEGIN { key = ENVIRON["COMMENTDM_ENV_KEY"] }
    {
      line = $0
      sub(/^[ \t]+/, "", line)
      sub(/^export[ \t]+/, "", line)
      eq = index(line, "=")
      if (eq == 0) next
      name = substr(line, 1, eq - 1)
      sub(/[ \t]+$/, "", name)
      if (name != key) next
      value = substr(line, eq + 1)
      sub(/^[ \t]+/, "", value)
      sub(/[ \t\r]+$/, "", value)
      print value
      exit
    }
  ' "$file" 2>/dev/null || true)"

  # Снимаем ровно один слой согласованных кавычек — так же, как это делают
  # и systemd, и node --env-file.
  if [ "${#raw}" -ge 2 ]; then
    first="${raw:0:1}"
    last="${raw: -1}"
    if { [ "$first" = '"' ] && [ "$last" = '"' ]; } \
      || { [ "$first" = "'" ] && [ "$last" = "'" ]; }; then
      raw="${raw:1:${#raw}-2}"
    fi
  fi
  printf '%s' "$raw"
}

# env_write_key <file> <key> <value> — ЕДИНСТВЕННАЯ точка записи в .env.
# Если ключ уже есть в любом из принимаемых видов — переписывает первую
# такую строку и выбрасывает возможные дубли того же ключа; второй строки с
# тем же ключом после этой функции не остаётся никогда. Если ключа нет —
# дописывает в конец. Владелец и режим файла восстанавливаются здесь же,
# внутри самой записи, чтобы ни один вызывающий не мог про это забыть.
env_write_key() {
  local file="$1" key="$2" value="$3" tmp
  if [ ! -e "$file" ]; then
    : > "$file"
    chmod 600 "$file" 2>/dev/null || true
  fi
  tmp="$(mktemp "${file}.XXXXXX")"
  if ! COMMENTDM_ENV_KEY="$key" COMMENTDM_ENV_VALUE="$value" awk '
    BEGIN {
      key = ENVIRON["COMMENTDM_ENV_KEY"]
      value = ENVIRON["COMMENTDM_ENV_VALUE"]
      done = 0
    }
    {
      line = $0
      sub(/^[ \t]+/, "", line)
      sub(/^export[ \t]+/, "", line)
      eq = index(line, "=")
      name = ""
      if (eq > 0) {
        name = substr(line, 1, eq - 1)
        sub(/[ \t]+$/, "", name)
      }
      if (eq > 0 && name == key) {
        if (done == 0) { print key "=" value; done = 1 }
        next
      }
      print $0
    }
    END { if (done == 0) print key "=" value }
  ' "$file" > "$tmp"; then
    rm -f "$tmp"
    err "Не удалось переписать $file (ключ $key)"
    return 1
  fi
  copy_file_identity "$file" "$tmp"
  mv "$tmp" "$file"
}

# env_set_if_absent <file> <key> <value> — never overwrites an existing
# (non-empty) value. This is what protects ENCRYPTION_KEY from ever being
# silently regenerated.
env_set_if_absent() {
  local file="$1" key="$2" value="$3"
  if [ -n "$(env_get "$file" "$key")" ]; then
    return 0
  fi
  env_write_key "$file" "$key" "$value"
}

# env_set <file> <key> <value> — always overwrites. Used by set-domain.sh to
# change APP_URL, which env_set_if_absent would refuse to touch.
env_set() {
  env_write_key "$1" "$2" "$3"
}

# load_env_file <file> — безопасная замена связке `set -a; . .env; set +a`.
#
# Точка ИСПОЛНЯЕТ файл. .env принадлежит пользователю приложения, а
# update.sh/rollback.sh работают из-под root: любая запись со стороны
# приложения превращалась бы в выполнение произвольной команды от root.
# Плюс легальное значение с пробелом (LEGAL_ENTITY_NAME=ООО Ромашка) точка
# разбирает как «присвоение и запуск команды Ромашка». Здесь строки только
# разбираются и экспортируются, ничего не исполняется.
load_env_file() {
  local file="$1" line key value
  [ -f "$file" ] || return 0
  while IFS= read -r line || [ -n "$line" ]; do
    line="${line#"${line%%[![:space:]]*}"}"
    case "$line" in
      ''|'#'*) continue ;;
    esac
    case "$line" in
      export[[:space:]]*)
        line="${line#export}"
        line="${line#"${line%%[![:space:]]*}"}"
        ;;
    esac
    case "$line" in
      *=*) ;;
      *) continue ;;
    esac
    key="${line%%=*}"
    value="${line#*=}"
    key="${key%"${key##*[![:space:]]}"}"
    case "$key" in
      ''|[0-9]*|*[!A-Za-z0-9_]*) continue ;;
    esac
    value="${value#"${value%%[![:space:]]*}"}"
    value="${value%"${value##*[![:space:]]}"}"
    value="${value%$'\r'}"
    if [ "${#value}" -ge 2 ]; then
      case "$value" in
        '"'*'"') value="${value#\"}"; value="${value%\"}" ;;
        "'"*"'") value="${value#\'}"; value="${value%\'}" ;;
      esac
    fi
    export "${key}=${value}"
  done < "$file"
}

# ---------------------------------------------------------------------------
# Домен. Строка с домена командной строки уезжает и в APP_URL, и в
# sed-подстановку Caddyfile: символ | ломает саму подстановку, а схема
# https:// в аргументе давала APP_URL=https://https://bot.example.com.
# ---------------------------------------------------------------------------

# normalize_domain <строка> — приводит к голому имени хоста: срезает схему,
# путь, завершающую точку, приводит к нижнему регистру.
normalize_domain() {
  local d="$1"
  d="${d#http://}"
  d="${d#https://}"
  d="${d%%/*}"
  d="${d%.}"
  printf '%s' "$d" | tr '[:upper:]' '[:lower:]'
}

# validate_domain <домен> — 0, если это допустимое доменное имя с точкой.
# Порт, пробел, @, | и прочее отсекаются здесь, а не превращаются в сломанный
# конфиг двумя шагами позже.
validate_domain() {
  local d="$1"
  [ -n "$d" ] || return 1
  [ "${#d}" -le 253 ] || return 1
  printf '%s' "$d" \
    | grep -qE '^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$'
}

# ---------------------------------------------------------------------------
# Build — same memory-limit heuristic as install.sh's build_app, so a
# rebuild on `npm run update` / rollback is exactly as safe on a small VPS as
# the original install.
# ---------------------------------------------------------------------------
compute_node_max_old_space() {
  local mem_kb mem_mb swap_kb swap_mb total
  mem_kb="$(awk '/^MemTotal:/ {print $2}' /proc/meminfo)"
  mem_mb=$(( mem_kb / 1024 ))
  swap_kb="$(awk '/^SwapTotal:/ {print $2}' /proc/meminfo)"
  swap_mb=$(( swap_kb / 1024 ))
  total=$(( mem_mb + swap_mb ))

  if [ "$total" -ge 6144 ]; then
    NODE_MAX_OLD_SPACE_MB=4096
  elif [ "$total" -ge 4096 ]; then
    NODE_MAX_OLD_SPACE_MB=3072
  else
    NODE_MAX_OLD_SPACE_MB=1536
  fi
}

# build_app_in <install_dir> — npm ci + npm run build with the memory limit
# above. Leaves files owned by whoever runs this (root, on the update/rollback
# path) — the caller is responsible for chowning back to APP_USER afterward,
# same as install.sh's finalize_permissions.
build_app_in() {
  local install_dir="$1"
  ( cd "$install_dir" || exit 1
    step "Ставлю зависимости (npm ci)"
    compute_node_max_old_space
    export NODE_OPTIONS="--max-old-space-size=${NODE_MAX_OLD_SPACE_MB}"
    npm ci --no-audit --no-fund
    ok "Зависимости установлены"

    step "Собираю приложение (next build, ограничение памяти ${NODE_MAX_OLD_SPACE_MB} МБ)"
    npm run build
    unset NODE_OPTIONS
    ok "Сборка завершена"
  )
}

# ---------------------------------------------------------------------------
# DNS check — same approach as install.sh's check_domain_and_dns (this is
# the other deliberate duplication described at the top of this file:
# install.sh cannot source this, since it must run before this file exists).
# ---------------------------------------------------------------------------
get_public_ip() {
  curl -fsS4 --max-time 5 https://api.ipify.org 2>/dev/null \
    || curl -fsS4 --max-time 5 https://ifconfig.me 2>/dev/null \
    || true
}

resolve_domain_ips() {
  local domain="$1" json
  json="$(curl -fsS --max-time 5 "https://dns.google/resolve?name=${domain}&type=A" 2>/dev/null || true)"
  if [ -n "$json" ]; then
    printf '%s' "$json" \
      | grep -oE '"data":"[0-9]{1,3}(\.[0-9]{1,3}){3}"' \
      | grep -oE '[0-9]{1,3}(\.[0-9]{1,3}){3}' \
      || true
    return
  fi
  getent ahosts "$domain" 2>/dev/null \
    | awk '{print $1}' \
    | grep -E '^[0-9]{1,3}(\.[0-9]{1,3}){3}$' \
    | sort -u \
    || true
}

# check_domain_dns_matches <domain> — prints ok/warn and returns non-zero if
# the domain's A record does not point at this server's public IP.
check_domain_dns_matches() {
  local domain="$1" server_ip resolved
  server_ip="$(get_public_ip)"
  if [ -z "$server_ip" ]; then
    warn "Не удалось определить публичный IP этого сервера — проверку DNS пропускаю."
    return 0
  fi

  resolved="$(resolve_domain_ips "$domain")"
  if [ -z "$resolved" ]; then
    err "Домен ${domain} не резолвится ни в один IP-адрес."
    return 1
  fi

  if printf '%s\n' "$resolved" | grep -qx "$server_ip"; then
    ok "DNS: ${domain} → ${server_ip} — совпадает с этим сервером"
    return 0
  fi

  err "DNS: ${domain} указывает на $(printf '%s' "$resolved" | tr '\n' ' ' | sed 's/ *$//'), а не на этот сервер (${server_ip})."
  return 1
}

# ---------------------------------------------------------------------------
# systemd units — the exact copy-with-substitution install.sh's
# install_systemd_units does, pulled out here because both install.sh and
# every script in this file need it and it must stay byte-for-byte the same
# templating rule in both places.
# ---------------------------------------------------------------------------
# install_systemd_units_from <install_dir> <app_user>
install_systemd_units_from() {
  local install_dir="$1" app_user="$2" unit
  step "Переустанавливаю systemd-юниты (приложение, воркер, суточный дамп)"
  for unit in commentdm.service commentdm-worker.service commentdm-backup.service commentdm-backup.timer; do
    # render_template, а не `sed ... > юнит`: прямая запись обнуляет
    # действующий юнит ДО того, как в него что-то попало.
    render_template "$install_dir/deploy/$unit" "/etc/systemd/system/$unit" \
      -e "s|__INSTALL_DIR__|${install_dir}|g" -e "s|__APP_USER__|${app_user}|g"
  done
  chmod +x "$install_dir/deploy/backup.sh"
  systemctl daemon-reload
  ok "systemd-юниты переустановлены, daemon-reload выполнен"
}
