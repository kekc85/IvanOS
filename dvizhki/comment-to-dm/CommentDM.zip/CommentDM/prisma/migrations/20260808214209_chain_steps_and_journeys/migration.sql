-- CreateEnum
CREATE TYPE "JourneyState" AS ENUM ('GATE_SENT', 'ACTIVE', 'DONE', 'EXPIRED', 'STOPPED', 'SKIPPED', 'FAILED');

-- AlterTable
ALTER TABLE "Automation" ADD COLUMN     "chainEnabled" BOOLEAN NOT NULL DEFAULT false;

-- CreateTable
CREATE TABLE "SequenceStep" (
    "id" TEXT NOT NULL,
    "automationId" TEXT NOT NULL,
    "position" INTEGER NOT NULL,
    "delaySeconds" INTEGER NOT NULL,
    "message" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "SequenceStep_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SubscriberJourney" (
    "id" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "automationId" TEXT NOT NULL,
    "instagramAccountId" TEXT NOT NULL,
    "subscriberId" TEXT NOT NULL,
    "subscriberName" TEXT,
    "commentId" TEXT NOT NULL,
    "conversationId" TEXT,
    "state" "JourneyState" NOT NULL,
    "gateSentAt" TIMESTAMP(3) NOT NULL,
    "lastUserMessageAt" TIMESTAMP(3),
    "nextStepPosition" INTEGER NOT NULL DEFAULT 0,
    "nextStepDueAt" TIMESTAMP(3),
    "attempts" INTEGER NOT NULL DEFAULT 0,
    "failReason" TEXT,
    "completedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "SubscriberJourney_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "SequenceStep_automationId_idx" ON "SequenceStep"("automationId");

-- CreateIndex
CREATE UNIQUE INDEX "SequenceStep_automationId_position_key" ON "SequenceStep"("automationId", "position");

-- CreateIndex
CREATE INDEX "SubscriberJourney_state_nextStepDueAt_idx" ON "SubscriberJourney"("state", "nextStepDueAt");

-- CreateIndex
CREATE INDEX "SubscriberJourney_state_instagramAccountId_idx" ON "SubscriberJourney"("state", "instagramAccountId");

-- CreateIndex
CREATE INDEX "SubscriberJourney_instagramAccountId_subscriberId_idx" ON "SubscriberJourney"("instagramAccountId", "subscriberId");

-- CreateIndex
CREATE UNIQUE INDEX "SubscriberJourney_automationId_subscriberId_key" ON "SubscriberJourney"("automationId", "subscriberId");

-- AddForeignKey
ALTER TABLE "SequenceStep" ADD CONSTRAINT "SequenceStep_automationId_fkey" FOREIGN KEY ("automationId") REFERENCES "Automation"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SubscriberJourney" ADD CONSTRAINT "SubscriberJourney_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES "Workspace"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SubscriberJourney" ADD CONSTRAINT "SubscriberJourney_automationId_fkey" FOREIGN KEY ("automationId") REFERENCES "Automation"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SubscriberJourney" ADD CONSTRAINT "SubscriberJourney_instagramAccountId_fkey" FOREIGN KEY ("instagramAccountId") REFERENCES "InstagramAccount"("id") ON DELETE CASCADE ON UPDATE CASCADE;
