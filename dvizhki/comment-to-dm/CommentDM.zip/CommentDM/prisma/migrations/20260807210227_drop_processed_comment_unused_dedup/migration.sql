/*
  Warnings:

  - You are about to drop the `ProcessedComment` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropTable
DROP TABLE "ProcessedComment";
