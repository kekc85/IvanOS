-- Additive only: one nullable column on an existing table, no backfill, no
-- default, no index. Nothing is rewritten — PostgreSQL adds a nullable column
-- as a catalog-only change, so this is instant even on a full DmLog.
--
-- dmAttemptedAt records the moment we actually called Meta for this comment.
-- It is the only honest evidence that our own earlier pass could have burned
-- the single private reply Instagram allows per comment. The statuses we used
-- before are not evidence: PENDING is written at the START of every pass and
-- again when an hourly-limit requeue is scheduled (Meta was never called), and
-- a FAILED row can equally come from "нет токена доступа" or "не удалось
-- расшифровать токен" — both written before any network call. Believing those
-- turned a deleted comment into a fake SENT plus a chain journey for a person
-- who never received anything. See priorSendAttempt in lib/queue/dm-worker.ts.
--
-- Rows written before this migration keep dmAttemptedAt NULL, which reads as
-- "no proof we ever reached Meta". That is deliberate: the conservative side
-- of this switch is an honest refusal, not an invented delivery.

-- AlterTable
ALTER TABLE "DmLog" ADD COLUMN "dmAttemptedAt" TIMESTAMP(3);
