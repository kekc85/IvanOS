-- Additive only: one nullable column plus its index. Journeys written before
-- this migration keep working — their commenterId is simply NULL, and the
-- pre-send guard that reads it treats "no commenter id" as "no live chain".

-- AlterTable
ALTER TABLE "SubscriberJourney" ADD COLUMN     "commenterId" TEXT;

-- CreateIndex
CREATE INDEX "SubscriberJourney_instagramAccountId_commenterId_idx" ON "SubscriberJourney"("instagramAccountId", "commenterId");
