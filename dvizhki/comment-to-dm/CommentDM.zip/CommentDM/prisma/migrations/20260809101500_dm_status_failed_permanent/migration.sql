-- Additive only: one new value in an existing enum, no table touched, no
-- backfill. Rows written before this migration keep their status as-is —
-- FAILED stays FAILED and keeps its right to be retried, exactly as before.
--
-- FAILED_PERMANENT marks a send that no retry can ever fix (the person's DMs
-- are closed, the comment is gone, the single private reply Instagram allows
-- on a comment is used up). The polling sweep treats such a row as handled,
-- so one dead comment stops burning a job every five minutes for 144 hours.
-- See lib/queue/send-failure.ts.
--
-- Safe inside a transaction on PostgreSQL 12+: the value is only ADDED here,
-- never used in the same transaction.

-- AlterEnum
ALTER TYPE "DmStatus" ADD VALUE 'FAILED_PERMANENT';
