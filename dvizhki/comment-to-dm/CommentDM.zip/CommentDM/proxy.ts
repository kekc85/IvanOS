import { NextResponse, type NextRequest } from "next/server";
import {
  SESSION_COOKIE_NAME,
  verifySessionToken,
} from "@/lib/auth/session-token";

// Every route under app/(dashboard)/ — kept in sync by hand, but checked
// against the actual directory listing by __tests__/proxy-route-coverage
// .test.ts, which fails the moment a new page lands under app/(dashboard)/
// without a matching entry here (see MEDIUM-7: half of these were missing —
// /overview, /inbox, /campaigns, /diagnostics — and nothing caught it).
// This is a redirect shortcut, not the actual gate (see the note below), so
// a missed entry does not leak data — DashboardLayout's own getCurrentUser()
// check still catches it — but it does mean an anonymous visitor reaches
// that check the slow way, via a full render, instead of being bounced
// before the page even starts loading.
const PROTECTED_PREFIXES = [
  "/dashboard",
  "/automations",
  "/campaigns",
  "/overview",
  "/inbox",
  "/logs",
  "/settings",
  "/diagnostics",
];

/**
 * The proxy runs on the Node.js runtime, so it can check the signature rather
 * than just the presence of a cookie. That matters for the /login branch
 * below: an expired or forged cookie must not bounce the owner away from the
 * only page that can fix it.
 *
 * This is still a redirect shortcut, not the gate. Pages and route handlers do
 * their own check with getCurrentUserId().
 */
function hasSessionCookie(request: NextRequest): boolean {
  const value = request.cookies.get(SESSION_COOKIE_NAME)?.value;
  if (!value) return false;

  const secret = process.env.SESSION_SECRET;
  // No secret means nothing can be verified anywhere in the app. Treat the
  // request as signed out so /login stays reachable and reports the real error.
  if (!secret) return false;

  return verifySessionToken(value, secret) !== null;
}

export function proxy(request: NextRequest) {
  const pathname = request.nextUrl.pathname;
  const isProtected = PROTECTED_PREFIXES.some(
    (prefix) => pathname === prefix || pathname.startsWith(`${prefix}/`)
  );
  const isLogin = pathname === "/login";
  const isAuthenticated = hasSessionCookie(request);

  if (isProtected && !isAuthenticated) {
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("callbackUrl", pathname);
    return NextResponse.redirect(loginUrl);
  }

  if (isLogin && isAuthenticated) {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/automations/:path*",
    "/campaigns/:path*",
    "/overview/:path*",
    "/inbox/:path*",
    "/logs/:path*",
    "/settings/:path*",
    "/diagnostics/:path*",
    "/login",
  ],
};
